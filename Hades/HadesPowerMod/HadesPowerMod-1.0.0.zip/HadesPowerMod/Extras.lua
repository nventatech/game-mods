function HadesPowerMod.FishNames()
	local names = {}
	local seen = {}
	for _, biome in pairs( FishingData.BiomeFish ) do
		if type( biome ) == "table" then
			for _, pool in pairs( biome ) do
				if type( pool ) == "table" then
					for _, entry in ipairs( pool ) do
						if type( entry ) == "table" and entry.Name ~= nil and not seen[entry.Name] then
							seen[entry.Name] = true
							table.insert( names, entry.Name )
						end
					end
				end
			end
		end
	end
	table.sort( names )
	return names
end

function HadesPowerMod.CatchAllFish()
	GameState.CaughtFish = GameState.CaughtFish or {}
	for _, name in ipairs( HadesPowerMod.FishNames() ) do
		IncrementTableValue( GameState.CaughtFish, name )
	end
end

function HadesPowerMod.CountFishTypes()
	local names = HadesPowerMod.FishNames()
	local caught = 0
	for _, name in ipairs( names ) do
		if GameState.CaughtFish ~= nil and ( GameState.CaughtFish[name] or 0 ) > 0 then
			caught = caught + 1
		end
	end
	return tostring( caught ) .. "/" .. tostring( #names )
end

function HadesPowerMod.CountQuests( statuses )
	GameState.QuestStatus = GameState.QuestStatus or {}
	local count = 0
	for _, name in ipairs( QuestOrderData ) do
		if statuses[ GameState.QuestStatus[name] or "" ] then
			count = count + 1
		end
	end
	return count
end

function HadesPowerMod.CompleteAllQuests()
	GameState.QuestStatus = GameState.QuestStatus or {}
	for _, name in ipairs( QuestOrderData ) do
		if GameState.QuestStatus[name] ~= "CashedOut" then
			GameState.QuestStatus[name] = "Complete"
		end
	end
end

function HadesPowerMod.CashOutAllQuests()
	GameState.QuestStatus = GameState.QuestStatus or {}
	for _, name in ipairs( QuestOrderData ) do
		local data = QuestData[name]
		if data ~= nil and GameState.QuestStatus[name] == "Complete" then
			if data.RewardResourceName ~= nil and data.RewardResourceAmount ~= nil then
				AddResource( data.RewardResourceName, data.RewardResourceAmount, "Quest" )
			end
			GameState.QuestStatus[name] = "CashedOut"
		end
	end
end

HadesPowerMod.TabDrawers.Extras = function( screen )
	HadesPowerMod.DrawPages( screen,
	{
		{
			{
				Label = HadesPowerMod.Text( "WholeCodex" ),
				GetValue = function() return "" end,
				OnExtra = function() UnlockEntireCodex() end,
				ExtraLabel = function( active ) return HadesPowerMod.Text( "Unlock" ) end,
			},
			{
				Label = HadesPowerMod.Text( "QuestsDone" ),
				GetValue = function() return tostring( HadesPowerMod.CountQuests( { Complete = true, CashedOut = true } ) ) .. "/" .. tostring( #QuestOrderData ) end,
				OnExtra = HadesPowerMod.CompleteAllQuests,
				ExtraLabel = function( active ) return HadesPowerMod.Text( "Complete" ) end,
			},
			{
				Label = HadesPowerMod.Text( "QuestRewards" ),
				GetValue = function() return tostring( HadesPowerMod.CountQuests( { Complete = true } ) ) end,
				OnExtra = HadesPowerMod.CashOutAllQuests,
				ExtraLabel = function( active ) return HadesPowerMod.Text( "Collect" ) end,
			},
			{
				Label = HadesPowerMod.Text( "FishCaught" ),
				GetValue = HadesPowerMod.CountFishTypes,
				OnExtra = HadesPowerMod.CatchAllFish,
				ExtraLabel = function( active ) return HadesPowerMod.Text( "Catch" ) end,
			},
		},
	})
end
