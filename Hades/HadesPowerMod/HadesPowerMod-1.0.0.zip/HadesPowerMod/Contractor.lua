function HadesPowerMod.ContractorItems()
	local items = {}
	for name, data in pairs( ConditionalItemData ) do
		if type( data ) == "table" and not data.DebugOnly and data.ResourceCost ~= nil and not data.Disabled and data.Slot ~= nil then
			table.insert( items, { Name = data.Name or name, Slot = data.Slot, Data = data } )
		end
	end
	for name, data in pairs( MusicPlayerTrackData ) do
		if type( data ) == "table" and not data.DebugOnly and data.ResourceCost ~= nil then
			table.insert( items, { Name = data.Name or name, Slot = "Music", Data = data, Music = true } )
		end
	end
	table.sort( items, function( a, b )
		if a.Data.ResourceCost ~= b.Data.ResourceCost then
			return a.Data.ResourceCost < b.Data.ResourceCost
		end
		return a.Name < b.Name
	end )
	return items
end

function HadesPowerMod.IsContractorItemOwned( item )
	return GameState.Cosmetics[item.Name] ~= nil
end

function HadesPowerMod.BuyContractorItem( item )
	if HadesPowerMod.IsContractorItemOwned( item ) then
		return
	end
	local data = item.Data
	AddCosmetic( item.Name, UIData.Constants.VISIBLE )
	if data.Names ~= nil then
		for _, name in pairs( data.Names ) do
			AddCosmetic( name, UIData.Constants.VISIBLE )
		end
	end
	if data.RemoveCosmetics ~= nil then
		for _, name in pairs( data.RemoveCosmetics ) do
			GameState.Cosmetics[name] = nil
		end
	end
	local onPurchased = data.OnPurchasedFunctionName ~= nil and _G[data.OnPurchasedFunctionName] or nil
	if onPurchased ~= nil then
		thread( onPurchased, data.OnPurchasedFunctionArgs )
	end
end

function HadesPowerMod.RemoveContractorItem( item )
	if item.Data.Removable and HadesPowerMod.IsContractorItemOwned( item ) then
		GameState.Cosmetics[item.Name] = nil
	end
end

function HadesPowerMod.CountOwnedItems( items )
	local owned = 0
	for _, item in ipairs( items ) do
		if HadesPowerMod.IsContractorItemOwned( item ) then
			owned = owned + 1
		end
	end
	return tostring( owned ) .. "/" .. tostring( #items )
end

function HadesPowerMod.BuyAllContractorItems( items )
	for _, item in ipairs( items ) do
		HadesPowerMod.BuyContractorItem( item )
	end
end

function HadesPowerMod.ContractorRow( item )
	return
	{
		Label = item.Name,
		GetValue = function() return HadesPowerMod.IsContractorItemOwned( item ) and HadesPowerMod.Text( "Owned" ) or "-" end,
		OnExtra = function()
			if HadesPowerMod.IsContractorItemOwned( item ) then
				HadesPowerMod.RemoveContractorItem( item )
			else
				HadesPowerMod.BuyContractorItem( item )
			end
		end,
		GetExtra = function() return HadesPowerMod.IsContractorItemOwned( item ) end,
		ExtraLabel = function( active )
			if not active then
				return HadesPowerMod.Text( "Buy" )
			end
			if item.Data.Removable then
				return HadesPowerMod.Text( "Remove" )
			end
			return "-"
		end,
	}
end

HadesPowerMod.TabDrawers.Contractor = function( screen )
	local items = HadesPowerMod.ContractorItems()
	local pages =
	{
		{
			{
				Label = HadesPowerMod.Text( "AllContractor" ),
				GetValue = function() return HadesPowerMod.CountOwnedItems( items ) end,
				OnExtra = function() HadesPowerMod.BuyAllContractorItems( items ) end,
				ExtraLabel = function( active ) return HadesPowerMod.Text( "Buy" ) end,
			},
		},
	}
	for _, slotName in ipairs( ScreenData.GhostAdmin.DisplayOrder ) do
		local slotItems = {}
		for _, item in ipairs( items ) do
			if item.Slot == slotName then
				table.insert( slotItems, item )
			end
		end
		if #slotItems > 0 then
			local rows =
			{
				{
					Label = slotName,
					LabelColor = HadesPowerMod.Colors.Active,
					GetValue = function() return HadesPowerMod.CountOwnedItems( slotItems ) end,
					OnExtra = function() HadesPowerMod.BuyAllContractorItems( slotItems ) end,
					ExtraLabel = function( active ) return HadesPowerMod.Text( "Buy" ) end,
				},
			}
			for _, item in ipairs( slotItems ) do
				table.insert( rows, HadesPowerMod.ContractorRow( item ) )
			end
			for _, page in ipairs( HadesPowerMod.ChunkRows( rows ) ) do
				table.insert( pages, page )
			end
		end
	end
	HadesPowerMod.DrawPages( screen, pages )
end
