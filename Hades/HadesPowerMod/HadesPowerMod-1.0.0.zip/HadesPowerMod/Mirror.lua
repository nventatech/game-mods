function HadesPowerMod.MetaUpgradeLevel( name )
	return GameState.MetaUpgrades[name] or 0
end

function HadesPowerMod.MetaUpgradeMaxLevel( name )
	local data = MetaUpgradeData[name]
	if data.CostTable ~= nil then
		return #data.CostTable
	end
	return data.MaxInvestment or 1
end

function HadesPowerMod.RefreshMetaUpgradeState()
	GameState.SpentShrinePointsCache = GetTotalSpentShrinePoints()
	UpdateActiveShrinePoints()
	if HadesPowerMod.InHouse() then
		CurrentRun.NumRerolls = GetNumMetaUpgrades( "RerollMetaUpgrade" ) + GetNumMetaUpgrades( "RerollPanelMetaUpgrade" )
		UpdateRerollUI( CurrentRun.NumRerolls )
	end
end

function HadesPowerMod.ChangeMetaUpgrade( name, delta )
	local data = MetaUpgradeData[name]
	local applyToHero = CurrentRun ~= nil and CurrentRun.Hero ~= nil and CurrentRun.MetaUpgrades == nil
	for i = 1, math.abs( delta ) do
		local level = HadesPowerMod.MetaUpgradeLevel( name )
		if delta > 0 then
			if level >= HadesPowerMod.MetaUpgradeMaxLevel( name ) then
				break
			end
			IncrementTableValue( GameState.MetaUpgrades, name )
			if applyToHero then
				ApplyMetaUpgrade( data, true, GameState.MetaUpgrades[name] > 1 )
			end
		else
			if level <= 0 then
				break
			end
			DecrementTableValue( GameState.MetaUpgrades, name )
			if applyToHero then
				ApplyMetaUpgrade( data, true, GameState.MetaUpgrades[name] <= 0, true )
			end
		end
	end
	HadesPowerMod.RefreshMetaUpgradeState()
end

function HadesPowerMod.SetMetaUpgradeLevel( name, level )
	HadesPowerMod.ChangeMetaUpgrade( name, level - HadesPowerMod.MetaUpgradeLevel( name ) )
end

function HadesPowerMod.MirrorTalent( index )
	return GameState.MetaUpgradesSelected[index] or MetaUpgradeOrder[index][1]
end

function HadesPowerMod.MirrorStageFor( index )
	local lockOrder = MetaUpgradeLockOrder
	if index <= lockOrder.BaseUnlocked then
		return 0
	end
	return math.ceil( ( index - lockOrder.BaseUnlocked ) / lockOrder.LockedSetsCount )
end

function HadesPowerMod.IsMirrorRowUnlocked( index )
	local name = HadesPowerMod.MirrorTalent( index )
	local bought = GameState.MetaUpgradesUnlocked[name] == true or MetaUpgradeData[name].Starting == true
	return bought and HadesPowerMod.MirrorStageFor( index ) <= ( GameState.MetaUpgradeStagesUnlocked or 0 )
end

function HadesPowerMod.UnlockMirrorRow( index )
	GameState.MetaUpgradeStagesUnlocked = math.max( GameState.MetaUpgradeStagesUnlocked or 0, HadesPowerMod.MirrorStageFor( index ) )
	for _, name in ipairs( MetaUpgradeOrder[index] ) do
		GameState.MetaUpgradesUnlocked[name] = true
	end
end

function HadesPowerMod.UnlockWholeMirror()
	for index = 1, #MetaUpgradeOrder do
		HadesPowerMod.UnlockMirrorRow( index )
	end
	GameState.Flags.SwapMetaupgradesEnabled = true
end

function HadesPowerMod.SwapMirrorTalent( index )
	local current = HadesPowerMod.MirrorTalent( index )
	local other = nil
	for _, name in ipairs( MetaUpgradeOrder[index] ) do
		if name ~= current then
			other = name
		end
	end
	if other == nil then
		return
	end
	GameState.MetaUpgradeState = GameState.MetaUpgradeState or {}
	local invested = HadesPowerMod.MetaUpgradeLevel( current )
	HadesPowerMod.ChangeMetaUpgrade( current, -invested )
	GameState.MetaUpgradeState[current] = invested
	GameState.MetaUpgradesSelected[index] = other
	HadesPowerMod.ChangeMetaUpgrade( other, GameState.MetaUpgradeState[other] or 0 )
	HadesPowerMod.Redraw()
end

function HadesPowerMod.CountMirrorRows( predicate )
	local count = 0
	for index = 1, #MetaUpgradeOrder do
		if predicate( index ) then
			count = count + 1
		end
	end
	return tostring( count ) .. "/" .. tostring( #MetaUpgradeOrder )
end

function HadesPowerMod.IsMirrorRowMaxed( index )
	local name = HadesPowerMod.MirrorTalent( index )
	return HadesPowerMod.MetaUpgradeLevel( name ) >= HadesPowerMod.MetaUpgradeMaxLevel( name )
end

function HadesPowerMod.MirrorRow( index )
	return
	{
		Label = HadesPowerMod.MirrorTalent( index ),
		GetValue = function()
			if not HadesPowerMod.IsMirrorRowUnlocked( index ) then
				return HadesPowerMod.Text( "Locked" )
			end
			local name = HadesPowerMod.MirrorTalent( index )
			return HadesPowerMod.LevelText( HadesPowerMod.MetaUpgradeLevel( name ), HadesPowerMod.MetaUpgradeMaxLevel( name ) )
		end,
		OnMinus = function() HadesPowerMod.ChangeMetaUpgrade( HadesPowerMod.MirrorTalent( index ), -1 ) end,
		OnPlus = function()
			if HadesPowerMod.IsMirrorRowUnlocked( index ) then
				HadesPowerMod.ChangeMetaUpgrade( HadesPowerMod.MirrorTalent( index ), 1 )
			end
		end,
		OnExtra = function()
			if HadesPowerMod.IsMirrorRowUnlocked( index ) then
				HadesPowerMod.SwapMirrorTalent( index )
			else
				HadesPowerMod.UnlockMirrorRow( index )
			end
		end,
		ExtraLabel = function( active )
			if HadesPowerMod.IsMirrorRowUnlocked( index ) then
				return HadesPowerMod.Text( "Swap" )
			end
			return HadesPowerMod.Text( "Unlock" )
		end,
	}
end

function HadesPowerMod.MirrorOverviewPage()
	return
	{
		{
			Label = HadesPowerMod.Text( "WholeMirror" ),
			GetValue = function() return HadesPowerMod.CountMirrorRows( HadesPowerMod.IsMirrorRowUnlocked ) end,
			OnExtra = HadesPowerMod.UnlockWholeMirror,
			ExtraLabel = function( active ) return HadesPowerMod.Text( "Unlock" ) end,
		},
		{
			Label = HadesPowerMod.Text( "MirrorMaxed" ),
			GetValue = function() return HadesPowerMod.CountMirrorRows( HadesPowerMod.IsMirrorRowMaxed ) end,
			OnExtra = function()
				HadesPowerMod.UnlockWholeMirror()
				for index = 1, #MetaUpgradeOrder do
					local name = HadesPowerMod.MirrorTalent( index )
					HadesPowerMod.SetMetaUpgradeLevel( name, HadesPowerMod.MetaUpgradeMaxLevel( name ) )
				end
			end,
			ExtraLabel = function( active ) return HadesPowerMod.Text( "Max" ) end,
		},
		{
			Label = HadesPowerMod.Text( "MirrorReset" ),
			GetValue = function() return "" end,
			OnExtra = function()
				for index = 1, #MetaUpgradeOrder do
					HadesPowerMod.SetMetaUpgradeLevel( HadesPowerMod.MirrorTalent( index ), 0 )
				end
			end,
			ExtraLabel = function( active ) return HadesPowerMod.Text( "Reset" ) end,
		},
	}
end

HadesPowerMod.TabDrawers.Mirror = function( screen )
	local pages = { HadesPowerMod.MirrorOverviewPage() }
	local rows = {}
	for index = 1, #MetaUpgradeOrder do
		table.insert( rows, HadesPowerMod.MirrorRow( index ) )
	end
	for _, page in ipairs( HadesPowerMod.ChunkRows( rows ) ) do
		table.insert( pages, page )
	end
	HadesPowerMod.DrawPages( screen, pages )
end
