HadesPowerMod.MaxHealthStep = 25
HadesPowerMod.MinMaxHealth = 50
HadesPowerMod.LastStandArgs =
{
	Name = "HadesPowerModLastStand",
	Icon = "ExtraLifeZag",
	WeaponName = "LastStandMetaUpgradeShield",
	HealFraction = 0.5,
}

function HadesPowerMod.Hero()
	if CurrentRun == nil then
		return nil
	end
	return CurrentRun.Hero
end

ModUtil.Path.Wrap( "CalculateDamageMultipliers", function( base, attacker, victim, weaponData, triggerArgs )
	local multiplier = base( attacker, victim, weaponData, triggerArgs )
	local hero = HadesPowerMod.Hero()
	if hero == nil or not HadesPowerMod.IsEnabled() then
		return multiplier
	end
	local settings = HadesPowerMod.Settings()
	local steps = HadesPowerMod.MultiplierSteps
	if attacker == hero and victim ~= hero and settings.DamageDealtStep > 0 then
		return multiplier * HadesPowerMod.StepFactor( settings.DamageDealtStep, steps )
	end
	if victim == hero and settings.DefenseStep > 0 then
		return multiplier / HadesPowerMod.StepFactor( settings.DefenseStep, steps )
	end
	return multiplier
end, HadesPowerMod )

ModUtil.Path.Wrap( "Damage", function( base, victim, triggerArgs )
	local hero = HadesPowerMod.Hero()
	if victim ~= nil and victim == hero and HadesPowerMod.IsEnabled() and HadesPowerMod.Settings().DefenseStep > HadesPowerMod.MultiplierSteps.Count then
		return
	end
	return base( victim, triggerArgs )
end, HadesPowerMod )

function HadesPowerMod.ChangeStep( key, delta )
	local settings = HadesPowerMod.Settings()
	settings[key] = HadesPowerMod.ClampStep( ( settings[key] or 0 ) + delta, HadesPowerMod.MultiplierSteps )
end

function HadesPowerMod.ChangeMaxHealth( delta )
	local hero = HadesPowerMod.Hero()
	if hero == nil then
		return
	end
	if delta < 0 and hero.MaxHealth + delta < HadesPowerMod.MinMaxHealth then
		return
	end
	AddMaxHealth( delta, "HadesPowerMod", { Silent = true, NoHealing = delta < 0 } )
	if hero.Health > hero.MaxHealth then
		hero.Health = hero.MaxHealth
	end
	thread( UpdateHealthUI )
end

function HadesPowerMod.HealHero()
	local hero = HadesPowerMod.Hero()
	if hero == nil then
		return
	end
	Heal( hero, { HealFraction = 1.0 } )
	thread( UpdateHealthUI )
end

function HadesPowerMod.LastStandCount( hero )
	if hero == nil or hero.LastStands == nil then
		return 0
	end
	return TableLength( hero.LastStands )
end

function HadesPowerMod.AddHeroLastStand()
	local hero = HadesPowerMod.Hero()
	if hero == nil then
		return
	end
	local args = ShallowCopyTable( HadesPowerMod.LastStandArgs )
	args.IncreaseMax = HadesPowerMod.LastStandCount( hero ) >= ( hero.MaxLastStands or 0 )
	AddLastStand( args )
end

function HadesPowerMod.RemoveHeroLastStand()
	local hero = HadesPowerMod.Hero()
	if hero == nil or HadesPowerMod.LastStandCount( hero ) == 0 then
		return
	end
	table.remove( hero.LastStands )
	UpdateLifePips( hero )
end

function HadesPowerMod.ChangeRerolls( delta )
	if CurrentRun == nil then
		return
	end
	CurrentRun.NumRerolls = math.max( 0, ( CurrentRun.NumRerolls or 0 ) + delta )
	UpdateRerollUI( CurrentRun.NumRerolls )
end

HadesPowerMod.InfiniteRerollAmount = 99

function HadesPowerMod.IsRerollInfinite()
	return HadesPowerMod.IsEnabled() and HadesPowerMod.Settings().InfiniteRerolls == true
end

function HadesPowerMod.ApplyInfiniteRerolls()
	if CurrentRun == nil or not HadesPowerMod.IsRerollInfinite() then
		return
	end
	if ( CurrentRun.NumRerolls or 0 ) < HadesPowerMod.InfiniteRerollAmount then
		CurrentRun.NumRerolls = HadesPowerMod.InfiniteRerollAmount
		UpdateRerollUI( CurrentRun.NumRerolls )
	end
end

function HadesPowerMod.ToggleInfiniteRerolls()
	local settings = HadesPowerMod.Settings()
	settings.InfiniteRerolls = not ( settings.InfiniteRerolls == true )
	HadesPowerMod.ApplyInfiniteRerolls()
end

for _, name in ipairs( { "AttemptBoonLootReroll", "AttemptPanelReroll", "AttemptReroll" } ) do
	ModUtil.Path.Wrap( name, function( base, ... )
		HadesPowerMod.ApplyInfiniteRerolls()
		return base( ... )
	end, HadesPowerMod )
end

table.insert( HadesPowerMod.EnabledListeners, HadesPowerMod.ApplyInfiniteRerolls )

function HadesPowerMod.SpeedFactor( key )
	if not HadesPowerMod.IsEnabled() then
		return 1
	end
	return HadesPowerMod.StepValue( HadesPowerMod.Settings()[key] or 0, HadesPowerMod.SpeedSteps )
end

function HadesPowerMod.MoveSpeedChanges( factor )
	return { { UnitProperty = "Speed", ChangeValue = factor, ChangeType = "Multiply" } }
end

function HadesPowerMod.AttackSpeedChanges( factor )
	local changes = {}
	local source = TraitData.HermesWeaponTrait and TraitData.HermesWeaponTrait.PropertyChanges or {}
	for _, change in ipairs( source ) do
		if change.ChangeType == "Multiply" and change.WeaponNames ~= nil and ( change.WeaponProperty ~= nil or change.EffectProperty ~= nil ) then
			table.insert( changes,
			{
				WeaponNames = change.WeaponNames,
				WeaponProperty = change.WeaponProperty,
				EffectName = change.EffectName,
				EffectProperty = change.EffectProperty,
				ChangeValue = 1 / factor,
				ChangeType = "Multiply",
				ExcludeLinked = change.ExcludeLinked,
			})
		end
	end
	return changes
end

function HadesPowerMod.ApplySpeedChanges( hero, moveFactor, attackFactor, reverse )
	if moveFactor ~= 1 then
		ApplyUnitPropertyChanges( hero, HadesPowerMod.MoveSpeedChanges( moveFactor ), true, reverse )
	end
	if attackFactor ~= 1 then
		for weaponName in pairs( hero.Weapons or {} ) do
			for _, change in ipairs( HadesPowerMod.AttackSpeedChanges( attackFactor ) ) do
				if Contains( change.WeaponNames, weaponName ) then
					ApplyWeaponPropertyChange( hero, weaponName, change, reverse )
				end
			end
		end
	end
end

function HadesPowerMod.ApplySpeed()
	local hero = HadesPowerMod.Hero()
	if hero == nil or hero.ObjectId == nil then
		return
	end
	local applied = HadesPowerMod.AppliedSpeed
	if applied ~= nil and applied.HeroId == hero.ObjectId then
		HadesPowerMod.ApplySpeedChanges( hero, applied.Move, applied.Attack, true )
	end
	local move = HadesPowerMod.SpeedFactor( "MoveSpeedStep" )
	local attack = HadesPowerMod.SpeedFactor( "AttackSpeedStep" )
	HadesPowerMod.ApplySpeedChanges( hero, move, attack, false )
	HadesPowerMod.AppliedSpeed = { HeroId = hero.ObjectId, Move = move, Attack = attack }
end

function HadesPowerMod.ChangeSpeedStep( key, delta )
	local settings = HadesPowerMod.Settings()
	settings[key] = HadesPowerMod.ClampFiniteStep( ( settings[key] or 0 ) + delta, HadesPowerMod.SpeedSteps )
	HadesPowerMod.ApplySpeed()
end

ModUtil.Path.Wrap( "SetupHeroObject", function( base, currentRun, applyLuaUpgrades )
	base( currentRun, applyLuaUpgrades )
	HadesPowerMod.AppliedSpeed = nil
	HadesPowerMod.ApplySpeed()
end, HadesPowerMod )

table.insert( HadesPowerMod.EnabledListeners, HadesPowerMod.ApplySpeed )

HadesPowerMod.TabDrawers.Player = function( screen )
	local steps = HadesPowerMod.MultiplierSteps

	HadesPowerMod.AddStepperRow( screen, 1,
	{
		Label = HadesPowerMod.Text( "DamageDealt" ),
		GetValue = function() return HadesPowerMod.StepLabel( HadesPowerMod.Settings().DamageDealtStep, steps ) end,
		OnMinus = function() HadesPowerMod.ChangeStep( "DamageDealtStep", -1 ) end,
		OnPlus = function() HadesPowerMod.ChangeStep( "DamageDealtStep", 1 ) end,
	})

	HadesPowerMod.AddStepperRow( screen, 2,
	{
		Label = HadesPowerMod.Text( "Defense" ),
		GetValue = function() return HadesPowerMod.StepLabel( HadesPowerMod.Settings().DefenseStep, steps ) end,
		OnMinus = function() HadesPowerMod.ChangeStep( "DefenseStep", -1 ) end,
		OnPlus = function() HadesPowerMod.ChangeStep( "DefenseStep", 1 ) end,
	})

	HadesPowerMod.AddStepperRow( screen, 3,
	{
		Label = HadesPowerMod.Text( "MoveSpeed" ),
		GetValue = function() return HadesPowerMod.StepLabel( HadesPowerMod.Settings().MoveSpeedStep, HadesPowerMod.SpeedSteps ) end,
		OnMinus = function() HadesPowerMod.ChangeSpeedStep( "MoveSpeedStep", -1 ) end,
		OnPlus = function() HadesPowerMod.ChangeSpeedStep( "MoveSpeedStep", 1 ) end,
	})

	HadesPowerMod.AddStepperRow( screen, 4,
	{
		Label = HadesPowerMod.Text( "AttackSpeed" ),
		GetValue = function() return HadesPowerMod.StepLabel( HadesPowerMod.Settings().AttackSpeedStep, HadesPowerMod.SpeedSteps ) end,
		OnMinus = function() HadesPowerMod.ChangeSpeedStep( "AttackSpeedStep", -1 ) end,
		OnPlus = function() HadesPowerMod.ChangeSpeedStep( "AttackSpeedStep", 1 ) end,
	})

	HadesPowerMod.AddStepperRow( screen, 5,
	{
		Label = HadesPowerMod.Text( "MaxHealth" ),
		GetValue = function()
			local hero = HadesPowerMod.Hero()
			if hero == nil then
				return "-"
			end
			return tostring( hero.Health ) .. " / " .. tostring( hero.MaxHealth )
		end,
		OnMinus = function() HadesPowerMod.ChangeMaxHealth( -HadesPowerMod.MaxHealthStep ) end,
		OnPlus = function() HadesPowerMod.ChangeMaxHealth( HadesPowerMod.MaxHealthStep ) end,
		OnExtra = function() HadesPowerMod.HealHero() end,
		ExtraLabel = function( active ) return HadesPowerMod.Text( "Heal" ) end,
	})

	HadesPowerMod.AddStepperRow( screen, 6,
	{
		Label = "ExtraChanceMetaUpgrade",
		GetValue = function()
			local hero = HadesPowerMod.Hero()
			return tostring( HadesPowerMod.LastStandCount( hero ) ) .. " / " .. tostring( hero ~= nil and hero.MaxLastStands or 0 )
		end,
		OnMinus = function() HadesPowerMod.RemoveHeroLastStand() end,
		OnPlus = function() HadesPowerMod.AddHeroLastStand() end,
	})

	HadesPowerMod.AddStepperRow( screen, 7,
	{
		Label = "RerollMetaUpgrade",
		GetValue = function() return tostring( CurrentRun ~= nil and CurrentRun.NumRerolls or 0 ) end,
		OnMinus = function() HadesPowerMod.ChangeRerolls( -1 ) end,
		OnPlus = function() HadesPowerMod.ChangeRerolls( 1 ) end,
		OnExtra = function() HadesPowerMod.ToggleInfiniteRerolls() end,
		GetExtra = function() return HadesPowerMod.Settings().InfiniteRerolls == true end,
		ExtraLabel = function( active ) return "INF" end,
	})
end
