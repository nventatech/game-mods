HadesPowerMod.CompanionMaxLevel = 5

function HadesPowerMod.KeepsakeNames( slot )
	local names = {}
	for _, traitName in ipairs( GiftOrdering ) do
		local data = TraitData[traitName]
		if data ~= nil and data.Slot == slot then
			table.insert( names, traitName )
		end
	end
	return names
end

function HadesPowerMod.FindGiftSource( traitName )
	for npcName, giftData in pairs( GiftData ) do
		if type( giftData ) == "table" then
			for level, levelData in pairs( giftData ) do
				if type( level ) == "number" and type( levelData ) == "table" and levelData.Gift == traitName then
					return npcName, level
				end
			end
		end
	end
end

function HadesPowerMod.UnlockKeepsake( traitName )
	local npcName, level = HadesPowerMod.FindGiftSource( traitName )
	if npcName == nil then
		return
	end
	local giftData = GiftData[npcName]
	local requirements = giftData.UnlockGameStateRequirements
	if giftData.Locked ~= nil and level >= giftData.Locked and requirements ~= nil and requirements.RequiredTextLines ~= nil then
		for _, line in ipairs( requirements.RequiredTextLines ) do
			TextLinesRecord[line] = true
		end
	end
	GameState.Gift[npcName] = GameState.Gift[npcName] or { Value = 0 }
	if ( GameState.Gift[npcName].Value or 0 ) < level then
		GameState.Gift[npcName].Value = level
	end
end

function HadesPowerMod.IsCompanion( traitName )
	return TraitData[traitName].Slot == "Assist"
end

function HadesPowerMod.KeepsakeMaxLevel( traitName )
	if HadesPowerMod.IsCompanion( traitName ) then
		return HadesPowerMod.CompanionMaxLevel
	end
	local thresholds = TraitData[traitName].ChamberThresholds
	if thresholds ~= nil then
		return #thresholds + 1
	end
	return 1
end

function HadesPowerMod.KeepsakeLevel( traitName )
	if HadesPowerMod.IsCompanion( traitName ) then
		return GetAssistKeepsakeLevel( traitName )
	end
	return GetKeepsakeLevel( traitName )
end

function HadesPowerMod.SetKeepsakeLevel( traitName, level )
	level = math.max( 1, math.min( HadesPowerMod.KeepsakeMaxLevel( traitName ), level ) )
	if HadesPowerMod.IsCompanion( traitName ) then
		GameState.AssistUnlocks = GameState.AssistUnlocks or {}
		if level > 1 then
			GameState.AssistUnlocks[traitName] = level - 1
		else
			GameState.AssistUnlocks[traitName] = nil
		end
		return
	end
	local thresholds = TraitData[traitName].ChamberThresholds
	if thresholds == nil then
		return
	end
	local chambers = 0
	for i = 1, level - 1 do
		chambers = chambers + thresholds[i]
	end
	GameState.KeepsakeChambers[traitName] = chambers
end

function HadesPowerMod.IsKeepsakeEquipped( traitName )
	if HadesPowerMod.IsCompanion( traitName ) then
		return GameState.LastAssistTrait == traitName
	end
	return GameState.LastAwardTrait == traitName
end

function HadesPowerMod.KeepsakeAction( traitName )
	if not IsKeepsakeUnlocked( traitName ) then
		HadesPowerMod.UnlockKeepsake( traitName )
	elseif HadesPowerMod.InHouse() then
		if HadesPowerMod.IsCompanion( traitName ) then
			GameState.LastAssistTrait = traitName
		else
			GameState.LastAwardTrait = traitName
		end
	end
end

function HadesPowerMod.KeepsakeActionLabel( traitName )
	if not IsKeepsakeUnlocked( traitName ) then
		return HadesPowerMod.Text( "Unlock" )
	end
	if HadesPowerMod.IsKeepsakeEquipped( traitName ) then
		return HadesPowerMod.Text( "Equipped" )
	end
	if HadesPowerMod.InHouse() then
		return HadesPowerMod.Text( "Equip" )
	end
	return "-"
end

function HadesPowerMod.CountKeepsakes( names, predicate )
	local count = 0
	for _, traitName in ipairs( names ) do
		if predicate( traitName ) then
			count = count + 1
		end
	end
	return tostring( count ) .. "/" .. tostring( #names )
end

function HadesPowerMod.IsKeepsakeAtMax( traitName )
	return HadesPowerMod.KeepsakeLevel( traitName ) >= HadesPowerMod.KeepsakeMaxLevel( traitName )
end

function HadesPowerMod.KeepsakeRow( traitName )
	return
	{
		Label = traitName,
		GetValue = function()
			if not IsKeepsakeUnlocked( traitName ) then
				return HadesPowerMod.Text( "Locked" )
			end
			return HadesPowerMod.LevelText( HadesPowerMod.KeepsakeLevel( traitName ), HadesPowerMod.KeepsakeMaxLevel( traitName ) )
		end,
		OnMinus = function() HadesPowerMod.SetKeepsakeLevel( traitName, HadesPowerMod.KeepsakeLevel( traitName ) - 1 ) end,
		OnPlus = function() HadesPowerMod.SetKeepsakeLevel( traitName, HadesPowerMod.KeepsakeLevel( traitName ) + 1 ) end,
		OnExtra = function() HadesPowerMod.KeepsakeAction( traitName ) end,
		GetExtra = function() return HadesPowerMod.IsKeepsakeEquipped( traitName ) end,
		ExtraLabel = function( active ) return HadesPowerMod.KeepsakeActionLabel( traitName ) end,
	}
end

function HadesPowerMod.CompanionUsed()
	return CurrentRun ~= nil and CurrentRun.CurrentRoom ~= nil and CurrentRun.CurrentRoom.UsedAssist == true
end

function HadesPowerMod.RechargeCompanion()
	if CurrentRun ~= nil and CurrentRun.CurrentRoom ~= nil then
		CurrentRun.CurrentRoom.UsedAssist = nil
	end
end

function HadesPowerMod.CompanionRow()
	return
	{
		Label = HadesPowerMod.Text( "Companion" ),
		GetValue = function()
			if CurrentRun == nil or CurrentRun.Hero == nil or HadesPowerMod.InHouse() then
				return "-"
			end
			return HadesPowerMod.CompanionUsed() and HadesPowerMod.Text( "Used" ) or HadesPowerMod.Text( "Ready" )
		end,
		OnExtra = HadesPowerMod.RechargeCompanion,
		ExtraLabel = function( active ) return HadesPowerMod.Text( "Recharge" ) end,
	}
end

function HadesPowerMod.KeepsakeOverviewPage( keepsakes, companions )
	local all = {}
	for _, traitName in ipairs( keepsakes ) do
		table.insert( all, traitName )
	end
	for _, traitName in ipairs( companions ) do
		table.insert( all, traitName )
	end
	return
	{
		{
			Label = HadesPowerMod.Text( "AllKeepsakes" ),
			GetValue = function() return HadesPowerMod.CountKeepsakes( keepsakes, IsKeepsakeUnlocked ) end,
			OnExtra = function()
				for _, traitName in ipairs( keepsakes ) do
					HadesPowerMod.UnlockKeepsake( traitName )
				end
			end,
			ExtraLabel = function( active ) return HadesPowerMod.Text( "Unlock" ) end,
		},
		{
			Label = HadesPowerMod.Text( "AllCompanions" ),
			GetValue = function() return HadesPowerMod.CountKeepsakes( companions, IsKeepsakeUnlocked ) end,
			OnExtra = function()
				for _, traitName in ipairs( companions ) do
					HadesPowerMod.UnlockKeepsake( traitName )
				end
			end,
			ExtraLabel = function( active ) return HadesPowerMod.Text( "Unlock" ) end,
		},
		{
			Label = HadesPowerMod.Text( "KeepsakesMaxed" ),
			GetValue = function() return HadesPowerMod.CountKeepsakes( all, HadesPowerMod.IsKeepsakeAtMax ) end,
			OnExtra = function()
				for _, traitName in ipairs( all ) do
					HadesPowerMod.SetKeepsakeLevel( traitName, HadesPowerMod.KeepsakeMaxLevel( traitName ) )
				end
			end,
			ExtraLabel = function( active ) return HadesPowerMod.Text( "Max" ) end,
		},
		HadesPowerMod.CompanionRow(),
	}
end

HadesPowerMod.TabDrawers.Keepsakes = function( screen )
	local keepsakes = HadesPowerMod.KeepsakeNames( "Keepsake" )
	local companions = HadesPowerMod.KeepsakeNames( "Assist" )
	local pages = { HadesPowerMod.KeepsakeOverviewPage( keepsakes, companions ) }
	for _, names in ipairs( { keepsakes, companions } ) do
		local rows = {}
		for _, traitName in ipairs( names ) do
			table.insert( rows, HadesPowerMod.KeepsakeRow( traitName ) )
		end
		for _, page in ipairs( HadesPowerMod.ChunkRows( rows ) ) do
			table.insert( pages, page )
		end
	end
	HadesPowerMod.DrawPages( screen, pages )
end
