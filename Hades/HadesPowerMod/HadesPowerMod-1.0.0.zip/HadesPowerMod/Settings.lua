HadesPowerMod.Languages = { "auto", "en", "pt" }

function HadesPowerMod.LanguageLabel( code )
	if code == "en" then
		return HadesPowerMod.Text( "LanguageEn" )
	end
	if code == "pt" then
		return HadesPowerMod.Text( "LanguagePt" )
	end
	return HadesPowerMod.Text( "LanguageAuto" )
end

function HadesPowerMod.CycleLanguage()
	local settings = HadesPowerMod.Settings()
	local index = 1
	for i, code in ipairs( HadesPowerMod.Languages ) do
		if code == settings.Language then
			index = i
		end
	end
	settings.Language = HadesPowerMod.Languages[ index % #HadesPowerMod.Languages + 1 ]
end

function HadesPowerMod.CycleMenuControl( key, otherKey )
	local settings = HadesPowerMod.Settings()
	local controls = HadesPowerMod.ComboControls
	local index = 1
	for i, name in ipairs( controls ) do
		if name == settings[key] then
			index = i
		end
	end
	for _ = 1, #controls do
		index = index % #controls + 1
		if controls[index] ~= settings[otherKey] then
			settings[key] = controls[index]
			return
		end
	end
end

function HadesPowerMod.RedrawWholeMenu( screen )
	if screen == nil then
		return
	end
	for _, tabName in ipairs( HadesPowerMod.Tabs ) do
		ModifyTextBox({ Id = screen.Components["Tab" .. tabName].Id, Text = HadesPowerMod.Text( "Tab" .. tabName ) })
	end
	ModifyTextBox({ Id = screen.Components.CloseButton.Id, Text = HadesPowerMod.Text( "Close" ) })
	HadesPowerMod.RefreshEnableButton( screen )
	HadesPowerMod.Redraw()
end

HadesPowerMod.TabDrawers.Settings = function( screen )
	HadesPowerMod.DrawPages( screen,
	{
		{
			{
				Label = HadesPowerMod.Text( "MenuControlA" ),
				GetValue = function() return HadesPowerMod.Text( "Control" .. HadesPowerMod.Settings().MenuControlA ) end,
				OnExtra = function() HadesPowerMod.CycleMenuControl( "MenuControlA", "MenuControlB" ) end,
				ExtraLabel = function( active ) return HadesPowerMod.Text( "Next" ) end,
			},
			{
				Label = HadesPowerMod.Text( "MenuControlB" ),
				GetValue = function() return HadesPowerMod.Text( "Control" .. HadesPowerMod.Settings().MenuControlB ) end,
				OnExtra = function() HadesPowerMod.CycleMenuControl( "MenuControlB", "MenuControlA" ) end,
				ExtraLabel = function( active ) return HadesPowerMod.Text( "Next" ) end,
			},
			{
				Label = HadesPowerMod.Text( "Language" ),
				GetValue = function() return HadesPowerMod.LanguageLabel( HadesPowerMod.Settings().Language ) end,
				OnExtra = function()
					HadesPowerMod.CycleLanguage()
					HadesPowerMod.RedrawWholeMenu( screen )
				end,
				ExtraLabel = function( active ) return HadesPowerMod.Text( "Next" ) end,
			},
			{
				Label = HadesPowerMod.Text( "RestoreDefaults" ),
				GetValue = function() return "" end,
				OnExtra = function()
					HadesPowerMod.ResetSettings()
					HadesPowerMod.RedrawWholeMenu( screen )
				end,
				ExtraLabel = function( active ) return HadesPowerMod.Text( "Restore" ) end,
			},
		},
	})
end
