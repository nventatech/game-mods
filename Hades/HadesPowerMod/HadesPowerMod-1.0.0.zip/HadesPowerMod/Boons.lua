HadesPowerMod.BoonSources = { "ZeusUpgrade", "PoseidonUpgrade", "AthenaUpgrade", "AphroditeUpgrade", "AresUpgrade", "ArtemisUpgrade", "DionysusUpgrade", "HermesUpgrade", "DemeterUpgrade", "TrialUpgrade", "WeaponUpgrade", "Current" }
HadesPowerMod.BoonRarities = { "Common", "Rare", "Epic", "Heroic", "Legendary" }
HadesPowerMod.BoonSourceIndex = 1
HadesPowerMod.BoonRarityIndex = 1
HadesPowerMod.BoonsPerPage = 5

function HadesPowerMod.BoonSource()
	return HadesPowerMod.BoonSources[HadesPowerMod.BoonSourceIndex]
end

function HadesPowerMod.AddUniqueTrait( names, seen, traitName )
	if traitName ~= nil and not seen[traitName] and TraitData[traitName] ~= nil then
		seen[traitName] = true
		table.insert( names, traitName )
	end
end

function HadesPowerMod.IsBoonTrait( traitName )
	local hammerIndex = LootData.WeaponUpgrade and LootData.WeaponUpgrade.TraitIndex
	local chaosBlessings = LootData.TrialUpgrade and LootData.TrialUpgrade.PermanentTraits
	return IsGodTrait( traitName ) or ( hammerIndex ~= nil and hammerIndex[traitName] ~= nil ) or ( chaosBlessings ~= nil and Contains( chaosBlessings, traitName ) )
end

function HadesPowerMod.BoonNames( source )
	local names = {}
	local seen = {}
	if source == "Current" then
		for _, trait in pairs( CurrentRun.Hero.Traits ) do
			if HadesPowerMod.IsBoonTrait( trait.Name ) then
				HadesPowerMod.AddUniqueTrait( names, seen, trait.Name )
			end
		end
		return names
	end
	local loot = LootData[source]
	if loot == nil then
		return names
	end
	if source == "TrialUpgrade" then
		for _, traitName in ipairs( loot.PermanentTraits or {} ) do
			HadesPowerMod.AddUniqueTrait( names, seen, traitName )
		end
		return names
	end
	if source == "WeaponUpgrade" then
		for _, traitName in ipairs( loot.Traits or {} ) do
			if TraitData[traitName] ~= nil and IsGameStateEligible( CurrentRun, TraitData[traitName] ) then
				HadesPowerMod.AddUniqueTrait( names, seen, traitName )
			end
		end
		return names
	end
	for _, listName in ipairs( { "WeaponUpgrades", "Traits" } ) do
		for _, traitName in ipairs( loot[listName] or {} ) do
			HadesPowerMod.AddUniqueTrait( names, seen, traitName )
		end
	end
	local linked = {}
	for traitName in pairs( loot.LinkedUpgrades or {} ) do
		table.insert( linked, traitName )
	end
	table.sort( linked )
	for _, traitName in ipairs( linked ) do
		HadesPowerMod.AddUniqueTrait( names, seen, traitName )
	end
	return names
end

function HadesPowerMod.BoonLevel( traitName )
	return GetTraitNameCount( CurrentRun.Hero, traitName )
end

function HadesPowerMod.BoonRarityFor( traitName )
	local levels = TraitData[traitName].RarityLevels
	if levels == nil then
		return nil
	end
	local wanted = HadesPowerMod.BoonRarities[HadesPowerMod.BoonRarityIndex]
	if levels[wanted] ~= nil then
		return wanted
	end
	for i = #HadesPowerMod.BoonRarities, 1, -1 do
		local rarity = HadesPowerMod.BoonRarities[i]
		if levels[rarity] ~= nil then
			return rarity
		end
	end
	return nil
end

function HadesPowerMod.GiveBoon( traitName )
	local slot = TraitData[traitName].Slot
	local replaced = nil
	if slot ~= nil then
		for _, trait in pairs( CurrentRun.Hero.Traits ) do
			local data = TraitData[trait.Name]
			if trait.Name ~= traitName and data ~= nil and data.Slot == slot then
				replaced = trait.Name
			end
		end
	end
	if replaced ~= nil then
		RemoveWeaponTrait( replaced )
	end
	AddTraitToHero({ TraitName = traitName, Rarity = HadesPowerMod.BoonRarityFor( traitName ) })
end

function HadesPowerMod.RemoveBoon( traitName )
	if TraitData[traitName].Slot ~= nil then
		RemoveWeaponTrait( traitName )
		return
	end
	while HeroHasTrait( traitName ) do
		RemoveTrait( CurrentRun.Hero, traitName )
	end
end

function HadesPowerMod.AddBoonLevel( traitName )
	if HadesPowerMod.BoonLevel( traitName ) == 0 then
		HadesPowerMod.GiveBoon( traitName )
	else
		AddTraitToHero({ TraitName = traitName })
	end
end

function HadesPowerMod.RemoveBoonLevel( traitName )
	local level = HadesPowerMod.BoonLevel( traitName )
	if level > 1 then
		RemoveTrait( CurrentRun.Hero, traitName )
	elseif level == 1 then
		HadesPowerMod.RemoveBoon( traitName )
	end
end

function HadesPowerMod.RedrawCurrentBoons()
	if HadesPowerMod.BoonSource() == "Current" then
		HadesPowerMod.Redraw()
	end
end

function HadesPowerMod.BoonRow( traitName )
	return
	{
		Label = traitName,
		GetValue = function()
			local level = HadesPowerMod.BoonLevel( traitName )
			if level == 0 then
				return "-"
			end
			return HadesPowerMod.Text( "LevelShort" ) .. " " .. tostring( level )
		end,
		OnMinus = function()
			HadesPowerMod.RemoveBoonLevel( traitName )
			HadesPowerMod.RedrawCurrentBoons()
		end,
		OnPlus = function() HadesPowerMod.AddBoonLevel( traitName ) end,
		OnExtra = function()
			if HadesPowerMod.BoonLevel( traitName ) > 0 then
				HadesPowerMod.RemoveBoon( traitName )
				HadesPowerMod.RedrawCurrentBoons()
			else
				HadesPowerMod.GiveBoon( traitName )
			end
		end,
		GetExtra = function() return HadesPowerMod.BoonLevel( traitName ) > 0 end,
		ExtraLabel = function( active ) return active and HadesPowerMod.Text( "Remove" ) or HadesPowerMod.Text( "Give" ) end,
	}
end

function HadesPowerMod.MinRarity()
	return HadesPowerMod.Settings().MinRarity or 1
end

function HadesPowerMod.CycleMinRarity()
	local settings = HadesPowerMod.Settings()
	settings.MinRarity = HadesPowerMod.MinRarity() % #HadesPowerMod.BoonRarities + 1
end

ModUtil.Path.Wrap( "GetRarityChances", function( base, args )
	local chances = base( args )
	if not HadesPowerMod.IsEnabled() then
		return chances
	end
	for index = 2, HadesPowerMod.MinRarity() do
		chances[ HadesPowerMod.BoonRarities[index] ] = 1
	end
	return chances
end, HadesPowerMod )

function HadesPowerMod.BoonSelectorRows()
	return
	{
		{
			Label = HadesPowerMod.Text( "MinRarity" ),
			LabelColor = HadesPowerMod.Colors.Active,
			GetValue = function() return HadesPowerMod.Text( "Rarity" .. HadesPowerMod.BoonRarities[ HadesPowerMod.MinRarity() ] ) end,
			OnExtra = HadesPowerMod.CycleMinRarity,
			ExtraLabel = function( active ) return HadesPowerMod.Text( "Next" ) end,
		},
		{
			Label = HadesPowerMod.Text( "BoonSource" ),
			LabelColor = HadesPowerMod.Colors.Active,
			GetValue = function()
				local source = HadesPowerMod.BoonSource()
				if source == "Current" then
					return HadesPowerMod.Text( "CurrentBoons" )
				end
				return source
			end,
			OnExtra = function()
				HadesPowerMod.BoonSourceIndex = HadesPowerMod.BoonSourceIndex % #HadesPowerMod.BoonSources + 1
				HadesPowerMod.TabPages.Boons = 1
				HadesPowerMod.Redraw()
			end,
			ExtraLabel = function( active ) return HadesPowerMod.Text( "Next" ) end,
		},
		{
			Label = HadesPowerMod.Text( "Rarity" ),
			LabelColor = HadesPowerMod.Colors.Active,
			GetValue = function() return HadesPowerMod.Text( "Rarity" .. HadesPowerMod.BoonRarities[HadesPowerMod.BoonRarityIndex] ) end,
			OnExtra = function() HadesPowerMod.BoonRarityIndex = HadesPowerMod.BoonRarityIndex % #HadesPowerMod.BoonRarities + 1 end,
			ExtraLabel = function( active ) return HadesPowerMod.Text( "Next" ) end,
		},
	}
end

HadesPowerMod.TabDrawers.Boons = function( screen )
	if CurrentRun == nil or CurrentRun.Hero == nil or HadesPowerMod.InHouse() then
		HadesPowerMod.DrawPages( screen, { { { Label = HadesPowerMod.Text( "RunOnly" ), GetValue = function() return "" end } } } )
		return
	end
	local pages = {}
	local page = nil
	for index, traitName in ipairs( HadesPowerMod.BoonNames( HadesPowerMod.BoonSource() ) ) do
		if ( index - 1 ) % HadesPowerMod.BoonsPerPage == 0 then
			page = HadesPowerMod.BoonSelectorRows()
			table.insert( pages, page )
		end
		table.insert( page, HadesPowerMod.BoonRow( traitName ) )
	end
	if #pages == 0 then
		table.insert( pages, HadesPowerMod.BoonSelectorRows() )
	end
	HadesPowerMod.DrawPages( screen, pages )
end
