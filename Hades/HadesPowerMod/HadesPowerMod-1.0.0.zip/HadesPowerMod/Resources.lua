HadesPowerMod.ResourceRows =
{
	{ Name = "Money", Label = "RoomRewardMoneyDrop", Step = 100 },
	{ Name = "MetaPoints", Step = 500 },
	{ Name = "Gems", Step = 50 },
	{ Name = "LockKeys", Step = 5 },
	{ Name = "GiftPoints", Step = 5 },
	{ Name = "SuperLockKeys", Step = 1 },
	{ Name = "SuperGems", Step = 1 },
	{ Name = "SuperGiftPoints", Step = 1 },
}

HadesPowerMod.InfiniteMoneyAmount = 99999
HadesPowerMod.ResourceFloor = {}

function HadesPowerMod.IsResourceInfinite( name )
	if name == nil then
		return false
	end
	return HadesPowerMod.IsEnabled() and HadesPowerMod.Settings()["Infinite" .. name] == true
end

function HadesPowerMod.ResourceLabel( row )
	if row.Label ~= nil then
		return row.Label
	end
	local data = ResourceData[row.Name]
	if data ~= nil and data.TitleName ~= nil then
		return data.TitleName
	end
	return row.Name
end

function HadesPowerMod.GetResourceAmount( name )
	if name == "Money" then
		return CurrentRun ~= nil and CurrentRun.Money or 0
	end
	return GameState.Resources[name] or 0
end

function HadesPowerMod.SetResourceAmount( name, amount )
	amount = math.max( 0, round( amount ) )
	if name == "Money" then
		if CurrentRun == nil then
			return
		end
		CurrentRun.Money = amount
		thread( UpdateMoneyUI, CurrentRun.Money )
		return
	end
	GameState.Resources[name] = amount
	HadesPowerMod.ResourceFloor[name] = amount
	UpdateResourceUI( name, amount )
end

function HadesPowerMod.AddResourceAmount( name, amount )
	if name == "Money" then
		HadesPowerMod.SetResourceAmount( name, HadesPowerMod.GetResourceAmount( name ) + amount )
		return
	end
	AddResource( name, amount, "HadesPowerMod", { NoLifetimeEffect = true, Silent = true } )
	HadesPowerMod.ResourceFloor[name] = GameState.Resources[name] or 0
end

function HadesPowerMod.ApplyInfiniteMoney()
	if CurrentRun == nil then
		return
	end
	local base = HadesPowerMod.MoneyBase
	if HadesPowerMod.IsResourceInfinite( "Money" ) then
		if base == nil or base.Run ~= CurrentRun then
			HadesPowerMod.MoneyBase = { Run = CurrentRun, Value = CurrentRun.Money or 0 }
		end
		if ( CurrentRun.Money or 0 ) < HadesPowerMod.InfiniteMoneyAmount then
			CurrentRun.Money = HadesPowerMod.InfiniteMoneyAmount
			thread( UpdateMoneyUI, CurrentRun.Money )
		end
	elseif base ~= nil then
		if base.Run == CurrentRun then
			CurrentRun.Money = base.Value
			thread( UpdateMoneyUI, CurrentRun.Money )
		end
		HadesPowerMod.MoneyBase = nil
	end
end

function HadesPowerMod.ToggleInfiniteResource( name )
	local settings = HadesPowerMod.Settings()
	local key = "Infinite" .. name
	settings[key] = not ( settings[key] == true )
	if name == "Money" then
		HadesPowerMod.ApplyInfiniteMoney()
	else
		HadesPowerMod.ResourceFloor[name] = GameState.Resources[name] or 0
	end
end

table.insert( HadesPowerMod.EnabledListeners, HadesPowerMod.ApplyInfiniteMoney )

OnAnyLoad{ function( triggerArgs )
	HadesPowerMod.ApplyInfiniteMoney()
	for _, row in ipairs( HadesPowerMod.ResourceRows ) do
		if row.Name ~= "Money" then
			HadesPowerMod.ResourceFloor[row.Name] = GameState.Resources[row.Name] or 0
		end
	end
end }

ModUtil.Path.Wrap( "SpendResource", function( base, name, amount, source, args )
	if HadesPowerMod.IsResourceInfinite( name ) then
		return true
	end
	return base( name, amount, source, args )
end, HadesPowerMod )

ModUtil.Path.Wrap( "HasResource", function( base, name, amount )
	if HadesPowerMod.IsResourceInfinite( name ) then
		return true
	end
	return base( name, amount )
end, HadesPowerMod )

ModUtil.Path.Wrap( "AddResource", function( base, name, amount, source, args )
	base( name, amount, source, args )
	if name ~= nil then
		HadesPowerMod.ResourceFloor[name] = GameState.Resources[name] or 0
	end
end, HadesPowerMod )

ModUtil.Path.Wrap( "UpdateResourceUI", function( base, name, value )
	local floor = name ~= nil and HadesPowerMod.ResourceFloor[name] or nil
	if floor ~= nil and HadesPowerMod.IsResourceInfinite( name ) and ( GameState.Resources[name] or 0 ) < floor then
		GameState.Resources[name] = floor
		value = floor
	end
	return base( name, value )
end, HadesPowerMod )

ModUtil.Path.Wrap( "SpendMoney", function( base, amount, source )
	if HadesPowerMod.IsResourceInfinite( "Money" ) then
		return
	end
	return base( amount, source )
end, HadesPowerMod )

HadesPowerMod.TabDrawers.Resources = function( screen )
	for index, row in ipairs( HadesPowerMod.ResourceRows ) do
		local name = row.Name
		HadesPowerMod.AddStepperRow( screen, index,
		{
			Label = HadesPowerMod.ResourceLabel( row ),
			GetValue = function() return HadesPowerMod.GetResourceAmount( name ) end,
			OnMinus = function() HadesPowerMod.SetResourceAmount( name, HadesPowerMod.GetResourceAmount( name ) - row.Step ) end,
			OnPlus = function() HadesPowerMod.AddResourceAmount( name, row.Step ) end,
			OnExtra = function() HadesPowerMod.ToggleInfiniteResource( name ) end,
			GetExtra = function() return HadesPowerMod.Settings()["Infinite" .. name] == true end,
			ExtraLabel = function( active ) return "INF" end,
		})
	end
end
