ModUtil.Mod.Register( "HadesPowerMod" )

HadesPowerMod.Version = "1.0.0"

HadesPowerMod.Defaults =
{
	Enabled = true,
	DamageDealtStep = 0,
	DefenseStep = 0,
	MoveSpeedStep = 0,
	AttackSpeedStep = 0,
	MinRarity = 1,
	InfiniteRerolls = false,
	MenuControlA = "Reload",
	MenuControlB = "Gift",
	Language = "auto",
}

HadesPowerMod.MultiplierSteps = { Count = 17, First = 2, Step = 0.5 }
HadesPowerMod.SpeedSteps = { Count = 8, First = 1.5, Step = 0.5 }
HadesPowerMod.InfiniteDamageFactor = 1000000
HadesPowerMod.EnabledListeners = {}

function HadesPowerMod.Settings()
	local data = HadesPowerMod.Data
	if data.Settings == nil then
		data.Settings = {}
	end
	local settings = data.Settings
	for key, value in pairs( HadesPowerMod.Defaults ) do
		if settings[key] == nil then
			settings[key] = value
		end
	end
	return settings
end

function HadesPowerMod.IsEnabled()
	return HadesPowerMod.Settings().Enabled == true
end

function HadesPowerMod.SetEnabled( enabled )
	HadesPowerMod.Settings().Enabled = enabled
	for _, listener in ipairs( HadesPowerMod.EnabledListeners ) do
		listener()
	end
end

function HadesPowerMod.ClampStep( position, steps )
	return math.max( 0, math.min( steps.Count + 1, position ) )
end

function HadesPowerMod.ClampFiniteStep( position, steps )
	return math.max( 0, math.min( steps.Count, position ) )
end

function HadesPowerMod.ResetSettings()
	local settings = HadesPowerMod.Settings()
	for key in pairs( settings ) do
		settings[key] = nil
	end
	HadesPowerMod.Settings()
	HadesPowerMod.SetEnabled( true )
end

function HadesPowerMod.StepValue( position, steps )
	if position <= 0 then
		return 1
	end
	if position > steps.Count then
		return math.huge
	end
	return steps.First + ( position - 1 ) * steps.Step
end

function HadesPowerMod.StepFactor( position, steps )
	if position > steps.Count then
		return HadesPowerMod.InfiniteDamageFactor
	end
	return HadesPowerMod.StepValue( position, steps )
end

function HadesPowerMod.StepLabel( position, steps )
	if position <= 0 then
		return "x1"
	end
	if position > steps.Count then
		return "INF"
	end
	local value = HadesPowerMod.StepValue( position, steps )
	if value % 1 == 0 then
		return "x" .. string.format( "%d", value )
	end
	return "x" .. string.format( "%.1f", value )
end

HadesPowerMod.Strings =
{
	en =
	{
		Title = "Hades Power Mod",
		Loaded = "Hades Power Mod loaded. Open the menu: ",
		TabPlayer = "Player",
		TabResources = "Resources",
		TabWeapons = "Weapons",
		TabKeepsakes = "Keepsakes",
		TabBoons = "Boons",
		TabMirror = "Mirror",
		TabPact = "Pact",
		TabContractor = "Contractor",
		TabExtras = "Extras",
		TabRun = "Run",
		TabStory = "Story",
		TabSettings = "Settings",
		EnableMod = "Enable mod",
		Close = "Close",
		On = "ON",
		Off = "OFF",
		ComingSoon = "Coming next",
		DamageDealt = "Damage dealt",
		Defense = "Defense",
		MaxHealth = "Health",
		Heal = "Heal",
		LevelShort = "Lv",
		Unlocked = "Unlocked",
		Locked = "Locked",
		Equipped = "Equipped",
		Unlock = "Unlock",
		Lock = "Lock",
		Equip = "Equip",
		Max = "Max",
		Reveal = "Reveal",
		AspectsFeature = "Weapon aspects",
		AllWeapons = "All weapons",
		AllAspects = "Aspects maxed",
		HiddenAspects = "Hidden aspects",
		AllKeepsakes = "All keepsakes",
		AllCompanions = "All companions",
		KeepsakesMaxed = "Keepsakes maxed",
		Swap = "Swap",
		Reset = "Reset",
		WholeMirror = "Whole mirror",
		MirrorMaxed = "Talents maxed",
		MirrorReset = "Reset talents",
		PactUnlocked = "Pact available",
		TotalHeat = "Total heat",
		PactMaxed = "Pact maxed",
		AllContractor = "All works",
		Owned = "Owned",
		Buy = "Buy",
		Remove = "Remove",
		BoonSource = "Boon source",
		CurrentBoons = "Current boons",
		Rarity = "Rarity",
		RarityCommon = "Common",
		RarityRare = "Rare",
		RarityEpic = "Epic",
		RarityHeroic = "Heroic",
		RarityLegendary = "Legendary",
		Next = "Next",
		Give = "Give",
		RunOnly = "Only during an escape",
		WholeCodex = "Whole Codex",
		QuestsDone = "Prophecies done",
		QuestRewards = "Rewards to collect",
		FishCaught = "Fish (one of each)",
		Complete = "Complete",
		Collect = "Collect",
		Catch = "Catch",
		MoveSpeed = "Move speed",
		AttackSpeed = "Attack speed",
		MinRarity = "Offered rarity (min)",
		Companion = "Companion",
		Ready = "Ready",
		Used = "Used",
		Recharge = "Recharge",
		ClearRoom = "Clear room",
		Enemies = "enemies",
		RerollDoors = "Reroll doors",
		Doors = "doors",
		Reroll = "Reroll",
		DoorReward = "Set every door to",
		Set = "Set",
		RewardWeaponUpgrade = "Daedalus Hammer",
		RewardStackUpgrade = "Pom of Power",
		RewardRoomRewardMaxHealthDrop = "Centaur Heart",
		RewardRoomRewardMoneyDrop = "Charon's Obol",
		RewardRoomRewardMetaPointDrop = "Darkness",
		RewardGemDrop = "Gemstones",
		RewardLockKeyDrop = "Chthonic Key",
		RewardGiftDrop = "Nectar",
		RewardSuperGemDrop = "Diamond",
		RewardSuperLockKeyDrop = "Titan Blood",
		RewardSuperGiftDrop = "Ambrosia",
		RewardTrialUpgrade = "Chaos",
		AffinityMaxed = "Affinity maxed",
		MenuControlA = "Menu key 1",
		MenuControlB = "Menu key 2",
		ControlReload = "Reload",
		ControlGift = "Gift",
		ControlCodex = "Codex",
		ControlAssist = "Companion",
		ControlShout = "Call",
		ControlAdvancedTooltip = "Details",
		Language = "Language",
		LanguageAuto = "Game language",
		LanguageEn = "English",
		LanguagePt = "Português",
		RestoreDefaults = "Restore defaults",
		Restore = "Restore",
		PressTogether = "press both together",
	},
	pt =
	{
		Title = "Hades Power Mod",
		Loaded = "Hades Power Mod carregado. Abrir o menu: ",
		TabPlayer = "Jogador",
		TabResources = "Recursos",
		TabWeapons = "Armas",
		TabKeepsakes = "Lembranças",
		TabBoons = "Bênçãos",
		TabMirror = "Espelho",
		TabPact = "Pacto",
		TabContractor = "Contratante",
		TabExtras = "Extras",
		TabRun = "Fuga",
		TabStory = "História",
		TabSettings = "Config",
		EnableMod = "Ativar mod",
		Close = "Fechar",
		On = "LIGADO",
		Off = "DESLIGADO",
		ComingSoon = "Em breve",
		DamageDealt = "Dano causado",
		Defense = "Defesa",
		MaxHealth = "Vida",
		Heal = "Curar",
		LevelShort = "Nv",
		Unlocked = "Liberado",
		Locked = "Travado",
		Equipped = "Equipado",
		Unlock = "Liberar",
		Lock = "Travar",
		Equip = "Equipar",
		Max = "Máx",
		Reveal = "Revelar",
		AspectsFeature = "Aspectos das armas",
		AllWeapons = "Todas as armas",
		AllAspects = "Aspectos no máximo",
		HiddenAspects = "Aspectos ocultos",
		AllKeepsakes = "Todas as lembranças",
		AllCompanions = "Todos os companheiros",
		KeepsakesMaxed = "Lembranças no máximo",
		Swap = "Trocar",
		Reset = "Zerar",
		WholeMirror = "Espelho inteiro",
		MirrorMaxed = "Talentos no máximo",
		MirrorReset = "Zerar talentos",
		PactUnlocked = "Pacto disponível",
		TotalHeat = "Calor total",
		PactMaxed = "Pacto no máximo",
		AllContractor = "Todas as obras",
		Owned = "Comprado",
		Buy = "Comprar",
		Remove = "Remover",
		BoonSource = "Origem",
		CurrentBoons = "Bênçãos atuais",
		Rarity = "Raridade",
		RarityCommon = "Comum",
		RarityRare = "Raro",
		RarityEpic = "Épico",
		RarityHeroic = "Heroico",
		RarityLegendary = "Lendário",
		Next = "Próximo",
		Give = "Dar",
		RunOnly = "Só durante uma fuga",
		WholeCodex = "Codex inteiro",
		QuestsDone = "Profecias concluídas",
		QuestRewards = "Recompensas a receber",
		FishCaught = "Peixes (um de cada)",
		Complete = "Concluir",
		Collect = "Receber",
		Catch = "Pegar",
		MoveSpeed = "Velocidade de movimento",
		AttackSpeed = "Velocidade de ataque",
		MinRarity = "Raridade oferecida (mín)",
		Companion = "Companheiro",
		Ready = "Pronto",
		Used = "Usado",
		Recharge = "Recarregar",
		ClearRoom = "Limpar sala",
		Enemies = "inimigos",
		RerollDoors = "Rerrolar portas",
		Doors = "portas",
		Reroll = "Rerrolar",
		DoorReward = "Todas as portas com",
		Set = "Aplicar",
		RewardWeaponUpgrade = "Martelo de Dédalo",
		RewardStackUpgrade = "Romã do Poder",
		RewardRoomRewardMaxHealthDrop = "Coração de Centauro",
		RewardRoomRewardMoneyDrop = "Óbolos de Caronte",
		RewardRoomRewardMetaPointDrop = "Escuridão",
		RewardGemDrop = "Gemas",
		RewardLockKeyDrop = "Chave Ctônica",
		RewardGiftDrop = "Néctar",
		RewardSuperGemDrop = "Diamante",
		RewardSuperLockKeyDrop = "Sangue de Titã",
		RewardSuperGiftDrop = "Ambrosia",
		RewardTrialUpgrade = "Caos",
		AffinityMaxed = "Afinidade no máximo",
		MenuControlA = "Tecla do menu 1",
		MenuControlB = "Tecla do menu 2",
		ControlReload = "Recarregar",
		ControlGift = "Presente",
		ControlCodex = "Codex",
		ControlAssist = "Companheiro",
		ControlShout = "Invocação",
		ControlAdvancedTooltip = "Detalhes",
		Language = "Idioma",
		LanguageAuto = "Idioma do jogo",
		LanguageEn = "English",
		LanguagePt = "Português",
		RestoreDefaults = "Restaurar padrões",
		Restore = "Restaurar",
		PressTogether = "aperte as duas juntas",
	},
}

function HadesPowerMod.Language()
	local chosen = HadesPowerMod.Settings().Language
	if chosen ~= nil and chosen ~= "auto" then
		return chosen
	end
	return string.sub( GetLanguage({}) or "en", 1, 2 )
end

function HadesPowerMod.Text( key )
	local strings = HadesPowerMod.Strings[ HadesPowerMod.Language() ] or HadesPowerMod.Strings.en
	return strings[key] or HadesPowerMod.Strings.en[key] or key
end

function HadesPowerMod.MenuControlText()
	local settings = HadesPowerMod.Settings()
	return HadesPowerMod.Text( "Control" .. settings.MenuControlA ) .. " + " .. HadesPowerMod.Text( "Control" .. settings.MenuControlB )
end

function HadesPowerMod.ShowNotice( text, duration )
	thread( function()
		local id = CreateScreenComponent({ Name = "BlankObstacle", Group = "Overlay", X = 960, Y = 140 }).Id
		CreateTextBox({ Id = id, Text = text, FontSize = 26, Color = Color.Yellow, Font = "AlegreyaSansSCBold", Justification = "Center", ShadowBlur = 0, ShadowColor = { 0, 0, 0, 1 }, ShadowOffset = { 0, 2 } })
		wait( duration )
		Destroy({ Id = id })
	end )
end

OnAnyLoad{ function( triggerArgs )
	if HadesPowerMod.NoticeShown then
		return
	end
	HadesPowerMod.NoticeShown = true
	thread( function()
		wait( 2 )
		HadesPowerMod.ShowNotice( HadesPowerMod.Text( "Loaded" ) .. HadesPowerMod.MenuControlText() .. " (" .. HadesPowerMod.Text( "PressTogether" ) .. ")", 8 )
	end )
end }
