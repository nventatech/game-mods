HadesPowerMod.MenuName = "HadesPowerModMenu"
HadesPowerMod.MenuGroup = HadesPowerMod.MenuGroup

HadesPowerMod.ComboControls = { "Reload", "Gift", "Codex", "Assist", "Shout", "AdvancedTooltip" }
HadesPowerMod.ComboWindow = 0.5
HadesPowerMod.ComboPressTimes = {}

HadesPowerMod.Tabs = { "Player", "Resources", "Weapons", "Keepsakes", "Mirror", "Pact", "Contractor", "Boons", "Run", "Story", "Extras", "Settings" }
HadesPowerMod.TabPages = {}

HadesPowerMod.TabDrawers = {}

HadesPowerMod.Layout =
{
	TabX = 470,
	TabStartY = 210,
	TabSpacing = 60,
	TabScale = 0.6,
	ContentCenterX = 1180,
	ContentStartY = 190,
	RowStartY = 280,
	RowSpacing = 70,
	LabelX = 700,
	MinusX = 1160,
	ValueX = 1275,
	PlusX = 1390,
	ExtraX = 1540,
	SmallScale = 0.45,
	FooterY = 930,
	EnableX = 900,
	CloseX = 1460,
	FooterScale = 0.8,
	ExtraScale = 0.6,
	RowsPerPage = 8,
	HotkeyX = -800,
	PagerY = 850,
	PagerPrevX = 1060,
	PagerLabelX = 1180,
	PagerNextX = 1300,
}

HadesPowerMod.Colors =
{
	Active = { 245, 200, 47, 255 },
	Idle = { 255, 255, 255, 255 },
	Dim = { 0.090, 0.055, 0.157, 0.85 },
}

HadesPowerMod.ComboRepeatGap = 0.15
HadesPowerMod.ComboCooldown = 0.8
HadesPowerMod.ComboFreshPress = {}
HadesPowerMod.ComboLockedUntil = 0

function HadesPowerMod.Now()
	if GetTime ~= nil then
		return GetTime({})
	end
	return _worldTime or 0
end

function HadesPowerMod.MenuControls()
	local settings = HadesPowerMod.Settings()
	return { settings.MenuControlA, settings.MenuControlB }
end

function HadesPowerMod.IsMenuControl( controlName )
	for _, name in ipairs( HadesPowerMod.MenuControls() ) do
		if name == controlName then
			return true
		end
	end
	return false
end

function HadesPowerMod.OnMenuControl( controlName )
	if not HadesPowerMod.IsMenuControl( controlName ) then
		return
	end
	local now = HadesPowerMod.Now()
	local lastPress = HadesPowerMod.ComboPressTimes[controlName]
	HadesPowerMod.ComboPressTimes[controlName] = now
	if lastPress ~= nil and now - lastPress < HadesPowerMod.ComboRepeatGap then
		return
	end
	if now < HadesPowerMod.ComboLockedUntil then
		return
	end
	HadesPowerMod.ComboFreshPress[controlName] = now
	for _, name in ipairs( HadesPowerMod.MenuControls() ) do
		local pressedAt = HadesPowerMod.ComboFreshPress[name]
		if pressedAt == nil or now - pressedAt > HadesPowerMod.ComboWindow then
			return
		end
	end
	HadesPowerMod.ComboFreshPress = {}
	HadesPowerMod.ComboLockedUntil = now + HadesPowerMod.ComboCooldown
	HadesPowerMod.ToggleMenu()
end

for _, controlName in ipairs( HadesPowerMod.ComboControls ) do
	OnControlPressed{ controlName,
		function( triggerArgs )
			HadesPowerMod.OnMenuControl( controlName )
		end
	}
end

OnAnyLoad{ function( triggerArgs )
	HadesPowerMod.Busy = false
	HadesPowerMod.Screen = nil
end }

ModUtil.Path.Wrap( "IsPauseBlocked", function( base )
	if IsScreenOpen( HadesPowerMod.MenuName ) then
		return true
	end
	return base()
end, HadesPowerMod )

function HadesPowerMod.ToggleMenu()
	if HadesPowerMod.Busy then
		return
	end
	local screen = HadesPowerMod.Screen
	if screen ~= nil and screen.KeepOpen then
		HadesPowerMod.Busy = true
		thread( HadesPowerModMenuClose, screen )
		return
	end
	if CurrentRun == nil or CurrentRun.Hero == nil or AreScreensActive() then
		return
	end
	HadesPowerMod.Busy = true
	thread( function()
		local ok = pcall( HadesPowerMod.OpenMenu )
		if not ok then
			HadesPowerMod.AbortMenu()
		end
		HadesPowerMod.Busy = false
	end )
end

function HadesPowerMod.AbortMenu()
	local screen = HadesPowerMod.Screen
	HadesPowerMod.Screen = nil
	if screen ~= nil then
		screen.KeepOpen = false
		Destroy({ Ids = GetAllIds( screen.Components ) })
	end
	HadesPowerMod.ReleaseCursor()
	UnfreezePlayerUnit()
	OnScreenClosed({ Flag = HadesPowerMod.MenuName })
end

function HadesPowerMod.UsingGamepad()
	return GetConfigOptionValue ~= nil and not GetConfigOptionValue({ Name = "UseMouse" })
end

function HadesPowerMod.GrabCursor()
	EnableShopGamepadCursor()
	SetConfigOption({ Name = "FreeFormSelectWrapY", Value = false })
	SetConfigOption({ Name = "FreeFormSelectStepDistance", Value = 32 })
	SetConfigOption({ Name = "FreeFormSelectSuccessDistanceStep", Value = 18 })
	SetConfigOption({ Name = "FreeFormSelectRepeatDelay", Value = 0.6 })
	SetConfigOption({ Name = "FreeFormSelectRepeatInterval", Value = 0.1 })
end

function HadesPowerMod.ReleaseCursor()
	DisableShopGamepadCursor()
	SetConfigOption({ Name = "FreeFormSelectWrapY", Value = false })
	SetConfigOption({ Name = "FreeFormSelectStepDistance", Value = 16 })
	SetConfigOption({ Name = "FreeFormSelectSuccessDistanceStep", Value = 8 })
	SetConfigOption({ Name = "FreeFormSelectRepeatDelay", Value = 0.0 })
end

function HadesPowerMod.TabY( tabName )
	local layout = HadesPowerMod.Layout
	for index, name in ipairs( HadesPowerMod.Tabs ) do
		if name == tabName then
			return layout.TabStartY + ( index - 1 ) * layout.TabSpacing
		end
	end
	return layout.TabStartY
end

function HadesPowerMod.CursorToTab( screen )
	if HadesPowerMod.UsingGamepad() then
		TeleportCursor({ OffsetX = HadesPowerMod.Layout.TabX, OffsetY = HadesPowerMod.TabY( screen.Tab ), ForceUseCheck = true })
	end
end

function HadesPowerMod.AddHotkeyButton( screen, key, hotkeys, functionName )
	local component = CreateScreenComponent({ Name = "ButtonDefault", Scale = 0.1, Group = HadesPowerMod.MenuGroup, X = HadesPowerMod.Layout.HotkeyX, Y = HadesPowerMod.Layout.HotkeyX })
	component.OnPressedFunctionName = functionName
	component.ControlHotkeys = hotkeys
	SetInteractProperty({ DestinationId = component.Id, Property = "FreeFormSelectable", Value = false })
	screen.Components[key] = component
	return component
end

function HadesPowerMod.FirstContentButton( screen )
	for _, key in ipairs( screen.ContentKeys ) do
		local component = screen.Components[key]
		if component ~= nil and component.OnPressedFunctionName ~= nil then
			return component
		end
	end
	return screen.Components.CloseButton
end

function HadesPowerMod.CursorBridge( screen, directionX, directionY )
	if directionX > 0 then
		return HadesPowerMod.FirstContentButton( screen )
	end
	if directionX < 0 then
		return screen.Components["Tab" .. screen.Tab]
	end
	if directionY > 0 then
		return screen.Components.CloseButton
	end
	if directionY < 0 then
		return screen.Components["Tab" .. HadesPowerMod.Tabs[1]]
	end
	return nil
end

ModUtil.Path.Wrap( "FreeFormSelectFailed", function( base, directionX, directionY )
	local screen = HadesPowerMod.Screen
	if screen == nil or not screen.KeepOpen then
		return base( directionX, directionY )
	end
	local target = HadesPowerMod.CursorBridge( screen, directionX or 0, directionY or 0 )
	if target ~= nil then
		TeleportCursor({ DestinationId = target.Id, ForceUseCheck = true })
	end
end, HadesPowerMod )

function HadesPowerMod.CycleTab( screen, delta )
	local count = #HadesPowerMod.Tabs
	local index = 1
	for i, name in ipairs( HadesPowerMod.Tabs ) do
		if name == screen.Tab then
			index = i
		end
	end
	index = ( index - 1 + delta ) % count + 1
	HadesPowerModMenuSelectTab( screen, { TabName = HadesPowerMod.Tabs[index] } )
	HadesPowerMod.CursorToTab( screen )
end

function HadesPowerMod.ButtonText( id, text, color )
	return
	{
		Id = id,
		Text = text,
		FontSize = 22,
		OffsetX = 0, OffsetY = 0,
		Color = color or HadesPowerMod.Colors.Idle,
		Font = "AlegreyaSansSCRegular",
		ShadowBlur = 0, ShadowColor = { 0, 0, 0, 1 }, ShadowOffset = { 0, 2 },
		Justification = "Center",
		DataProperties = { OpacityWithOwner = true },
	}
end

function HadesPowerMod.OpenMenu()
	local layout = HadesPowerMod.Layout
	local screen =
	{
		Name = HadesPowerMod.MenuName,
		Components = {},
		ContentKeys = {},
		Refreshers = {},
		Tab = HadesPowerMod.LastTab or HadesPowerMod.Tabs[1],
	}
	HadesPowerMod.Screen = screen
	local components = screen.Components

	OnScreenOpened({ Flag = screen.Name, PersistCombatUI = true })
	FreezePlayerUnit()
	HadesPowerMod.GrabCursor()

	components.Dim = CreateScreenComponent({ Name = "rectangle01", Group = HadesPowerMod.MenuGroup })
	SetScale({ Id = components.Dim.Id, Fraction = 4 })
	SetColor({ Id = components.Dim.Id, Color = HadesPowerMod.Colors.Dim })

	components.Background = CreateScreenComponent({ Name = "rectangle01", Group = HadesPowerMod.MenuGroup })
	SetAnimation({ DestinationId = components.Background.Id, Name = "QuestLogBackground_In", OffsetY = 30 })
	PlaySound({ Name = "/SFX/Menu Sounds/FatedListOpen" })

	CreateTextBox({ Id = components.Background.Id, Text = HadesPowerMod.Text( "Title" ), FontSize = 34, OffsetX = 0, OffsetY = -460, Color = Color.White, Font = "SpectralSCLightTitling", ShadowBlur = 0, ShadowColor = { 0, 0, 0, 1 }, ShadowOffset = { 0, 2 }, Justification = "Center" })

	for index, tabName in ipairs( HadesPowerMod.Tabs ) do
		local key = "Tab" .. tabName
		components[key] = CreateScreenComponent({ Name = "ButtonDefault", Scale = layout.TabScale, Group = HadesPowerMod.MenuGroup, X = layout.TabX, Y = layout.TabStartY + ( index - 1 ) * layout.TabSpacing })
		components[key].OnPressedFunctionName = "HadesPowerModMenuSelectTab"
		components[key].TabName = tabName
		CreateTextBox( HadesPowerMod.ButtonText( components[key].Id, HadesPowerMod.Text( key ) ) )
	end

	components.EnableButton = CreateScreenComponent({ Name = "ButtonDefault", Scale = layout.FooterScale, Group = HadesPowerMod.MenuGroup, X = layout.EnableX, Y = layout.FooterY })
	components.EnableButton.OnPressedFunctionName = "HadesPowerModMenuToggleEnabled"
	CreateTextBox( HadesPowerMod.ButtonText( components.EnableButton.Id, "" ) )

	components.CloseButton = CreateScreenComponent({ Name = "ButtonDefault", Scale = layout.FooterScale, Group = HadesPowerMod.MenuGroup, X = layout.CloseX, Y = layout.FooterY })
	components.CloseButton.OnPressedFunctionName = "HadesPowerModMenuClose"
	components.CloseButton.ControlHotkey = "Cancel"
	CreateTextBox( HadesPowerMod.ButtonText( components.CloseButton.Id, HadesPowerMod.Text( "Close" ) ) )

	HadesPowerMod.AddHotkeyButton( screen, "HotkeyTabPrev", { "MenuLeft" }, "HadesPowerModMenuTabUp" )
	HadesPowerMod.AddHotkeyButton( screen, "HotkeyTabNext", { "MenuRight" }, "HadesPowerModMenuTabDown" )

	HadesPowerMod.RefreshEnableButton( screen )
	HadesPowerMod.RefreshTabHighlight( screen )
	HadesPowerMod.DrawContent( screen )
	HadesPowerMod.CursorToTab( screen )

	screen.KeepOpen = true
	HadesPowerMod.Busy = false
	NotifyResultsTable[ "ScreenInput" .. screen.Name ] = nil
	thread( HandleWASDInput, screen )
	HandleScreenInput( screen )
end

function HadesPowerMod.RefreshEnableButton( screen )
	local enabled = HadesPowerMod.IsEnabled()
	local state = enabled and HadesPowerMod.Text( "On" ) or HadesPowerMod.Text( "Off" )
	local color = enabled and HadesPowerMod.Colors.Active or HadesPowerMod.Colors.Idle
	ModifyTextBox({ Id = screen.Components.EnableButton.Id, Text = HadesPowerMod.Text( "EnableMod" ) .. ": " .. state, Color = color })
end

function HadesPowerMod.RefreshTabHighlight( screen )
	for _, tabName in ipairs( HadesPowerMod.Tabs ) do
		local color = tabName == screen.Tab and HadesPowerMod.Colors.Active or HadesPowerMod.Colors.Idle
		ModifyTextBox({ Id = screen.Components["Tab" .. tabName].Id, Color = color })
	end
end

function HadesPowerMod.AddContent( screen, key, component )
	screen.Components[key] = component
	table.insert( screen.ContentKeys, key )
	return component
end

function HadesPowerMod.ClearContent( screen )
	for _, key in ipairs( screen.ContentKeys ) do
		local component = screen.Components[key]
		if component ~= nil then
			Destroy({ Id = component.Id })
			screen.Components[key] = nil
		end
	end
	screen.ContentKeys = {}
	screen.Refreshers = {}
end

function HadesPowerMod.AddText( screen, key, x, y, text, args )
	args = args or {}
	local component = HadesPowerMod.AddContent( screen, key, CreateScreenComponent({ Name = "BlankObstacle", Group = HadesPowerMod.MenuGroup, X = x, Y = y }) )
	CreateTextBox({ Id = component.Id, Text = text, FontSize = args.FontSize or 22, Color = args.Color or HadesPowerMod.Colors.Idle, Font = args.Font or "AlegreyaSansSCRegular", Justification = args.Justification or "Left", ShadowBlur = 0, ShadowColor = { 0, 0, 0, 1 }, ShadowOffset = { 0, 2 } })
	return component
end

function HadesPowerMod.AddButton( screen, key, x, y, scale, text, action )
	local component = HadesPowerMod.AddContent( screen, key, CreateScreenComponent({ Name = "ButtonDefault", Scale = scale, Group = HadesPowerMod.MenuGroup, X = x, Y = y }) )
	component.OnPressedFunctionName = "HadesPowerModMenuButton"
	component.Action = action
	CreateTextBox( HadesPowerMod.ButtonText( component.Id, text ) )
	return component
end

function HadesPowerMod.AddRefresher( screen, refresher )
	table.insert( screen.Refreshers, refresher )
	refresher()
end

function HadesPowerMod.RefreshContent( screen )
	for _, refresher in ipairs( screen.Refreshers ) do
		refresher()
	end
end

function HadesPowerMod.RowY( row )
	local layout = HadesPowerMod.Layout
	return layout.RowStartY + ( row - 1 ) * layout.RowSpacing
end

function HadesPowerMod.AddStepperRow( screen, row, args )
	local layout = HadesPowerMod.Layout
	local y = HadesPowerMod.RowY( row )
	local prefix = "Row" .. row
	HadesPowerMod.AddText( screen, prefix .. "Label", layout.LabelX, y, args.Label, { Color = args.LabelColor } )
	if args.OnMinus ~= nil then
		HadesPowerMod.AddButton( screen, prefix .. "Minus", layout.MinusX, y, layout.SmallScale, "-", args.OnMinus )
	end
	local value = HadesPowerMod.AddText( screen, prefix .. "Value", layout.ValueX, y, "", { Justification = "Center", Color = HadesPowerMod.Colors.Active } )
	if args.OnPlus ~= nil then
		HadesPowerMod.AddButton( screen, prefix .. "Plus", layout.PlusX, y, layout.SmallScale, "+", args.OnPlus )
	end
	local extra = nil
	if args.OnExtra ~= nil then
		extra = HadesPowerMod.AddButton( screen, prefix .. "Extra", layout.ExtraX, y, layout.ExtraScale, "", args.OnExtra )
	end
	HadesPowerMod.AddRefresher( screen, function()
		ModifyTextBox({ Id = value.Id, Text = tostring( args.GetValue() ) })
		if extra ~= nil then
			local active = args.GetExtra ~= nil and args.GetExtra() or false
			ModifyTextBox({ Id = extra.Id, Text = args.ExtraLabel( active ), Color = active and HadesPowerMod.Colors.Active or HadesPowerMod.Colors.Idle })
		end
	end )
end

function HadesPowerMod.ChunkRows( rows )
	local pages = {}
	local perPage = HadesPowerMod.Layout.RowsPerPage
	for index, row in ipairs( rows ) do
		local pageIndex = math.floor( ( index - 1 ) / perPage ) + 1
		pages[pageIndex] = pages[pageIndex] or {}
		table.insert( pages[pageIndex], row )
	end
	return pages
end

function HadesPowerMod.CurrentPage( tabName, pageCount )
	local page = HadesPowerMod.TabPages[tabName] or 1
	if page > pageCount then
		page = 1
	elseif page < 1 then
		page = pageCount
	end
	HadesPowerMod.TabPages[tabName] = page
	return page
end

function HadesPowerMod.DrawPages( screen, pages )
	local layout = HadesPowerMod.Layout
	local pageCount = math.max( 1, #pages )
	local page = HadesPowerMod.CurrentPage( screen.Tab, pageCount )
	for row, args in ipairs( pages[page] or {} ) do
		HadesPowerMod.AddStepperRow( screen, row, args )
	end
	if pageCount > 1 then
		HadesPowerMod.AddButton( screen, "PagePrev", layout.PagerPrevX, layout.PagerY, layout.SmallScale, "<", function() HadesPowerMod.ChangePage( screen, -1 ) end )
		HadesPowerMod.AddText( screen, "PageLabel", layout.PagerLabelX, layout.PagerY, tostring( page ) .. " / " .. tostring( pageCount ), { Justification = "Center", Color = HadesPowerMod.Colors.Active } )
		HadesPowerMod.AddButton( screen, "PageNext", layout.PagerNextX, layout.PagerY, layout.SmallScale, ">", function() HadesPowerMod.ChangePage( screen, 1 ) end )
	end
end

function HadesPowerMod.ChangePage( screen, delta )
	HadesPowerMod.TabPages[screen.Tab] = ( HadesPowerMod.TabPages[screen.Tab] or 1 ) + delta
	HadesPowerMod.DrawContent( screen )
end

function HadesPowerModMenuTabUp( screen, button )
	HadesPowerMod.CycleTab( screen, -1 )
end

function HadesPowerModMenuTabDown( screen, button )
	HadesPowerMod.CycleTab( screen, 1 )
end



function HadesPowerMod.Redraw()
	if HadesPowerMod.Screen ~= nil then
		HadesPowerMod.DrawContent( HadesPowerMod.Screen )
	end
end

function HadesPowerMod.DrawContent( screen )
	local layout = HadesPowerMod.Layout
	HadesPowerMod.ClearContent( screen )
	HadesPowerMod.AddText( screen, "Header", layout.ContentCenterX, layout.ContentStartY, HadesPowerMod.Text( "Tab" .. screen.Tab ), { FontSize = 28, Color = HadesPowerMod.Colors.Active, Font = "AlegreyaSansSCBold", Justification = "Center" } )
	local drawer = HadesPowerMod.TabDrawers[ screen.Tab ]
	if drawer ~= nil then
		drawer( screen )
	else
		HadesPowerMod.AddText( screen, "ComingSoon", layout.ContentCenterX, 540, HadesPowerMod.Text( "ComingSoon" ), { Justification = "Center" } )
	end
end

function HadesPowerModMenuButton( screen, button )
	if button.Action ~= nil then
		button.Action( screen, button )
	end
	HadesPowerMod.RefreshContent( screen )
end

function HadesPowerModMenuSelectTab( screen, button )
	screen.Tab = button.TabName
	HadesPowerMod.LastTab = button.TabName
	HadesPowerMod.RefreshTabHighlight( screen )
	HadesPowerMod.DrawContent( screen )
end

function HadesPowerModMenuToggleEnabled( screen, button )
	HadesPowerMod.SetEnabled( not HadesPowerMod.IsEnabled() )
	HadesPowerMod.RefreshEnableButton( screen )
	HadesPowerMod.RefreshContent( screen )
end

function HadesPowerModMenuClose( screen, button )
	if screen ~= nil and screen.KeepOpen then
		screen.KeepOpen = false
		HadesPowerMod.Screen = nil
		HadesPowerMod.ReleaseCursor()
		SetAnimation({ DestinationId = screen.Components.Background.Id, Name = "QuestLogBackground_Out" })
		PlaySound({ Name = "/SFX/Menu Sounds/FatedListClose" })
		CloseScreen( GetAllIds( screen.Components ), 0.1 )
		UnfreezePlayerUnit()
		OnScreenClosed({ Flag = screen.Name })
		if button == nil then
			NotifyResultsTable[ "ScreenInput" .. screen.Name ] = nil
			notify( "ScreenInput" .. screen.Name )
		end
	end
	HadesPowerMod.Busy = false
end
