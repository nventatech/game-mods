HadesPowerMod.DoorRewards =
{
	{ Type = "Boon", Loot = "ZeusUpgrade" },
	{ Type = "Boon", Loot = "PoseidonUpgrade" },
	{ Type = "Boon", Loot = "AthenaUpgrade" },
	{ Type = "Boon", Loot = "AphroditeUpgrade" },
	{ Type = "Boon", Loot = "AresUpgrade" },
	{ Type = "Boon", Loot = "ArtemisUpgrade" },
	{ Type = "Boon", Loot = "DionysusUpgrade" },
	{ Type = "Boon", Loot = "HermesUpgrade" },
	{ Type = "Boon", Loot = "DemeterUpgrade" },
	{ Type = "TrialUpgrade" },
	{ Type = "WeaponUpgrade" },
	{ Type = "StackUpgrade" },
	{ Type = "RoomRewardMaxHealthDrop" },
	{ Type = "RoomRewardMoneyDrop" },
	{ Type = "RoomRewardMetaPointDrop" },
	{ Type = "GemDrop" },
	{ Type = "LockKeyDrop" },
	{ Type = "GiftDrop" },
	{ Type = "SuperGemDrop" },
	{ Type = "SuperLockKeyDrop" },
	{ Type = "SuperGiftDrop" },
}

function HadesPowerMod.InRunRoom()
	return CurrentRun ~= nil and CurrentRun.Hero ~= nil and CurrentRun.CurrentRoom ~= nil and not HadesPowerMod.InHouse()
end

function HadesPowerMod.CountRequiredKills()
	local count = 0
	for _ in pairs( RequiredKillEnemies or {} ) do
		count = count + 1
	end
	return count
end

function HadesPowerMod.ClearRoom()
	if HadesPowerMod.InRunRoom() and HadesPowerMod.CountRequiredKills() > 0 then
		thread( DestroyRequiredKills )
	end
end

function HadesPowerMod.OfferedDoors()
	local doors = {}
	for _, door in pairs( OfferedExitDoors or {} ) do
		local room = door.Room
		if room ~= nil and room.ChosenRewardType ~= "Shop" and not room.NoReroll then
			table.insert( doors, door )
		end
	end
	return doors
end

function HadesPowerMod.ClearDoorIcons( door )
	for _, key in ipairs( { "DoorIconId", "DoorIconFront", "DoorIconBackingId" } ) do
		if door[key] ~= nil then
			Destroy({ Id = door[key] })
			door[key] = nil
		end
	end
	if door.AdditionalIcons ~= nil then
		Destroy({ Ids = door.AdditionalIcons })
		door.AdditionalIcons = nil
	end
end

function HadesPowerMod.RerollDoors()
	if not HadesPowerMod.InRunRoom() then
		return
	end
	for _, door in ipairs( HadesPowerMod.OfferedDoors() ) do
		HadesPowerMod.ClearDoorIcons( door )
		AttemptRerollDoor( CurrentRun, door )
	end
end

function HadesPowerMod.SetDoorReward( door, reward )
	local room = door.Room
	HadesPowerMod.ClearDoorIcons( door )
	room.ForceLootName = nil
	room.RewardOverrides = nil
	if room.Encounter ~= nil then
		room.Encounter.LootAName = nil
		room.Encounter.LootBName = nil
		room.Encounter = nil
	end
	room.ChosenRewardType = reward.Type
	room.ForceLootName = reward.Loot
	SetupRoomReward( CurrentRun, room, {} )
	CurrentRun.CurrentRoom.OfferedRewards = CurrentRun.CurrentRoom.OfferedRewards or {}
	CurrentRun.CurrentRoom.OfferedRewards[door.ObjectId] = { Type = room.ChosenRewardType, ForceLootName = room.ForceLootName, UseOptionalOverrides = room.UseOptionalOverrides }
	CreateDoorRewardPreview( door )
	RefreshUseButton( door.ObjectId, door )
end

function HadesPowerMod.SetAllDoorRewards( reward )
	if not HadesPowerMod.InRunRoom() then
		return
	end
	for _, door in ipairs( HadesPowerMod.OfferedDoors() ) do
		HadesPowerMod.SetDoorReward( door, reward )
	end
end

function HadesPowerMod.DoorRewardLabel( reward )
	if reward.Loot ~= nil then
		return reward.Loot
	end
	return HadesPowerMod.Text( "Reward" .. reward.Type )
end

function HadesPowerMod.CountDoorsWith( reward )
	local count = 0
	for _, door in ipairs( HadesPowerMod.OfferedDoors() ) do
		local room = door.Room
		if room.ChosenRewardType == reward.Type and ( reward.Loot == nil or room.ForceLootName == reward.Loot ) then
			count = count + 1
		end
	end
	return count
end

function HadesPowerMod.DoorRewardRow( reward )
	return
	{
		Label = HadesPowerMod.DoorRewardLabel( reward ),
		GetValue = function()
			local count = HadesPowerMod.CountDoorsWith( reward )
			if count == 0 then
				return "-"
			end
			return tostring( count )
		end,
		OnExtra = function() HadesPowerMod.SetAllDoorRewards( reward ) end,
		GetExtra = function() return HadesPowerMod.CountDoorsWith( reward ) > 0 end,
		ExtraLabel = function( active ) return HadesPowerMod.Text( "Set" ) end,
	}
end

HadesPowerMod.TabDrawers.Run = function( screen )
	if not HadesPowerMod.InRunRoom() then
		HadesPowerMod.DrawPages( screen, { { { Label = HadesPowerMod.Text( "RunOnly" ), GetValue = function() return "" end } } } )
		return
	end
	local rows =
	{
		{
			Label = HadesPowerMod.Text( "ClearRoom" ),
			GetValue = function() return tostring( HadesPowerMod.CountRequiredKills() ) .. " " .. HadesPowerMod.Text( "Enemies" ) end,
			OnExtra = HadesPowerMod.ClearRoom,
			ExtraLabel = function( active ) return HadesPowerMod.Text( "ClearRoom" ) end,
		},
		{
			Label = HadesPowerMod.Text( "RerollDoors" ),
			GetValue = function() return tostring( #HadesPowerMod.OfferedDoors() ) .. " " .. HadesPowerMod.Text( "Doors" ) end,
			OnExtra = HadesPowerMod.RerollDoors,
			ExtraLabel = function( active ) return HadesPowerMod.Text( "Reroll" ) end,
		},
		{
			Label = HadesPowerMod.Text( "DoorReward" ),
			LabelColor = HadesPowerMod.Colors.Active,
			GetValue = function() return "" end,
		},
	}
	for _, reward in ipairs( HadesPowerMod.DoorRewards ) do
		table.insert( rows, HadesPowerMod.DoorRewardRow( reward ) )
	end
	HadesPowerMod.DrawPages( screen, HadesPowerMod.ChunkRows( rows ) )
end
