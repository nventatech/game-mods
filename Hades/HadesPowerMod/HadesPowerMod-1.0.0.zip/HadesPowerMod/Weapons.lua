HadesPowerMod.WeaponOrder = { "SwordWeapon", "SpearWeapon", "ShieldWeapon", "BowWeapon", "FistWeapon", "GunWeapon" }

function HadesPowerMod.InHouse()
	return CurrentRun ~= nil and CurrentRun.Hero ~= nil and CurrentRun.Hero.IsDead == true
end

function HadesPowerMod.LevelText( level, maxLevel )
	return HadesPowerMod.Text( "LevelShort" ) .. " " .. tostring( level ) .. "/" .. tostring( maxLevel )
end

function HadesPowerMod.IsWeaponEquipped( weaponName )
	return CurrentRun ~= nil and CurrentRun.Hero ~= nil and GetEquippedWeapon() == weaponName
end

function HadesPowerMod.SetWeaponUnlocked( weaponName, unlocked )
	if unlocked then
		GameState.WeaponsUnlocked[weaponName] = true
	elseif not HadesPowerMod.IsWeaponEquipped( weaponName ) then
		GameState.WeaponsUnlocked[weaponName] = nil
	end
end

function HadesPowerMod.CountUnlockedWeapons()
	local count = 0
	for _, weaponName in ipairs( HadesPowerMod.WeaponOrder ) do
		if GameState.WeaponsUnlocked[weaponName] then
			count = count + 1
		end
	end
	return count
end

function HadesPowerMod.UnlockAllWeapons()
	for _, weaponName in ipairs( HadesPowerMod.WeaponOrder ) do
		HadesPowerMod.SetWeaponUnlocked( weaponName, true )
	end
end

function HadesPowerMod.AspectTextKey( weaponName, index )
	local data = WeaponUpgradeData[weaponName][index]
	return data.TraitName or data.RequiredInvestmentTraitName or weaponName
end

function HadesPowerMod.AspectLevel( weaponName, index )
	local unlocks = GameState.WeaponUnlocks[weaponName]
	return unlocks ~= nil and unlocks[index] or 0
end

function HadesPowerMod.AspectMaxLevel( weaponName, index )
	return WeaponUpgradeData[weaponName][index].MaxUpgradeLevel or 5
end

function HadesPowerMod.IsAspectHidden( weaponName, index )
	local requirements = WeaponUpgradeData[weaponName][index].GameStateRequirements
	return requirements ~= nil and not IsGameStateEligible( CurrentRun, requirements )
end

function HadesPowerMod.IsAspectEquipped( weaponName, index )
	return HadesPowerMod.IsWeaponEquipped( weaponName ) and GetEquippedWeaponTraitIndex( weaponName ) == index
end

function HadesPowerMod.SetAspectLevel( weaponName, index, level )
	level = math.max( 0, math.min( HadesPowerMod.AspectMaxLevel( weaponName, index ), level ) )
	local refresh = HadesPowerMod.InHouse() and HadesPowerMod.IsAspectEquipped( weaponName, index )
	if refresh then
		UnequipWeaponUpgrade()
	end
	GameState.WeaponUnlocks[weaponName] = GameState.WeaponUnlocks[weaponName] or {}
	if level > 0 then
		GameState.WeaponUnlocks[weaponName][index] = level
		GameState.Flags.AspectsUnlocked = true
	else
		GameState.WeaponUnlocks[weaponName][index] = nil
	end
	if not refresh then
		return
	end
	if level == 0 and not WeaponUpgradeData[weaponName][index].StartsUnlocked then
		GameState.LastWeaponUpgradeData[weaponName] = { Index = 1 }
	end
	EquipWeaponUpgrade( CurrentRun.Hero, { SkipTraitHighlight = true } )
end

function HadesPowerMod.ForEachAspect( action )
	for _, weaponName in ipairs( HadesPowerMod.WeaponOrder ) do
		for index = 1, #WeaponUpgradeData[weaponName] do
			action( weaponName, index )
		end
	end
end

function HadesPowerMod.MaxAllAspects()
	HadesPowerMod.ForEachAspect( function( weaponName, index )
		HadesPowerMod.SetAspectLevel( weaponName, index, HadesPowerMod.AspectMaxLevel( weaponName, index ) )
	end )
end

function HadesPowerMod.CountMaxedAspects()
	local maxed = 0
	local total = 0
	HadesPowerMod.ForEachAspect( function( weaponName, index )
		total = total + 1
		if HadesPowerMod.AspectLevel( weaponName, index ) >= HadesPowerMod.AspectMaxLevel( weaponName, index ) then
			maxed = maxed + 1
		end
	end )
	return maxed, total
end

function HadesPowerMod.RevealAspect( weaponName, index )
	local requirements = WeaponUpgradeData[weaponName][index].GameStateRequirements
	if requirements == nil or requirements.RequiredTextLines == nil then
		return
	end
	for _, line in ipairs( requirements.RequiredTextLines ) do
		TextLinesRecord[line] = true
	end
end

function HadesPowerMod.RevealAllAspects()
	HadesPowerMod.ForEachAspect( HadesPowerMod.RevealAspect )
end

function HadesPowerMod.CountHiddenAspects()
	local hidden = 0
	HadesPowerMod.ForEachAspect( function( weaponName, index )
		if HadesPowerMod.IsAspectHidden( weaponName, index ) then
			hidden = hidden + 1
		end
	end )
	return hidden
end

function HadesPowerMod.CanEquipAspect( weaponName, index )
	return HadesPowerMod.InHouse() and HadesPowerMod.IsWeaponEquipped( weaponName ) and IsWeaponUpgradeUnlocked( weaponName, index ) and not HadesPowerMod.IsAspectHidden( weaponName, index )
end

function HadesPowerMod.AspectAction( weaponName, index )
	if HadesPowerMod.IsAspectHidden( weaponName, index ) then
		HadesPowerMod.RevealAspect( weaponName, index )
	elseif HadesPowerMod.CanEquipAspect( weaponName, index ) and not HadesPowerMod.IsAspectEquipped( weaponName, index ) then
		SelectWeaponUpgrade( {}, weaponName, index )
	end
end

function HadesPowerMod.AspectActionLabel( weaponName, index )
	if HadesPowerMod.IsAspectHidden( weaponName, index ) then
		return HadesPowerMod.Text( "Reveal" )
	end
	if HadesPowerMod.IsAspectEquipped( weaponName, index ) then
		return HadesPowerMod.Text( "Equipped" )
	end
	if HadesPowerMod.CanEquipAspect( weaponName, index ) then
		return HadesPowerMod.Text( "Equip" )
	end
	return "-"
end

function HadesPowerMod.WeaponStateText( weaponName )
	if HadesPowerMod.IsWeaponEquipped( weaponName ) then
		return HadesPowerMod.Text( "Equipped" )
	end
	if GameState.WeaponsUnlocked[weaponName] then
		return HadesPowerMod.Text( "Unlocked" )
	end
	return HadesPowerMod.Text( "Locked" )
end

function HadesPowerMod.WeaponOverviewPage()
	return
	{
		{
			Label = HadesPowerMod.Text( "AspectsFeature" ),
			GetValue = function() return GameState.Flags.AspectsUnlocked and HadesPowerMod.Text( "Unlocked" ) or HadesPowerMod.Text( "Locked" ) end,
			OnExtra = function() GameState.Flags.AspectsUnlocked = not GameState.Flags.AspectsUnlocked end,
			GetExtra = function() return GameState.Flags.AspectsUnlocked == true end,
			ExtraLabel = function( active ) return active and HadesPowerMod.Text( "Lock" ) or HadesPowerMod.Text( "Unlock" ) end,
		},
		{
			Label = HadesPowerMod.Text( "AllWeapons" ),
			GetValue = function() return tostring( HadesPowerMod.CountUnlockedWeapons() ) .. "/" .. tostring( #HadesPowerMod.WeaponOrder ) end,
			OnExtra = HadesPowerMod.UnlockAllWeapons,
			ExtraLabel = function( active ) return HadesPowerMod.Text( "Unlock" ) end,
		},
		{
			Label = HadesPowerMod.Text( "AllAspects" ),
			GetValue = function()
				local maxed, total = HadesPowerMod.CountMaxedAspects()
				return tostring( maxed ) .. "/" .. tostring( total )
			end,
			OnExtra = HadesPowerMod.MaxAllAspects,
			ExtraLabel = function( active ) return HadesPowerMod.Text( "Max" ) end,
		},
		{
			Label = HadesPowerMod.Text( "HiddenAspects" ),
			GetValue = function() return tostring( HadesPowerMod.CountHiddenAspects() ) end,
			OnExtra = HadesPowerMod.RevealAllAspects,
			ExtraLabel = function( active ) return HadesPowerMod.Text( "Reveal" ) end,
		},
	}
end

function HadesPowerMod.WeaponPage( weaponName )
	local page =
	{
		{
			Label = weaponName,
			LabelColor = HadesPowerMod.Colors.Active,
			GetValue = function() return HadesPowerMod.WeaponStateText( weaponName ) end,
			OnExtra = function() HadesPowerMod.SetWeaponUnlocked( weaponName, not GameState.WeaponsUnlocked[weaponName] ) end,
			GetExtra = function() return GameState.WeaponsUnlocked[weaponName] == true end,
			ExtraLabel = function( active ) return active and HadesPowerMod.Text( "Lock" ) or HadesPowerMod.Text( "Unlock" ) end,
		},
	}
	for index = 1, #WeaponUpgradeData[weaponName] do
		table.insert( page,
		{
			Label = HadesPowerMod.AspectTextKey( weaponName, index ),
			GetValue = function() return HadesPowerMod.LevelText( HadesPowerMod.AspectLevel( weaponName, index ), HadesPowerMod.AspectMaxLevel( weaponName, index ) ) end,
			OnMinus = function() HadesPowerMod.SetAspectLevel( weaponName, index, HadesPowerMod.AspectLevel( weaponName, index ) - 1 ) end,
			OnPlus = function() HadesPowerMod.SetAspectLevel( weaponName, index, HadesPowerMod.AspectLevel( weaponName, index ) + 1 ) end,
			OnExtra = function() HadesPowerMod.AspectAction( weaponName, index ) end,
			GetExtra = function() return HadesPowerMod.IsAspectEquipped( weaponName, index ) end,
			ExtraLabel = function( active ) return HadesPowerMod.AspectActionLabel( weaponName, index ) end,
		})
	end
	return page
end

HadesPowerMod.TabDrawers.Weapons = function( screen )
	local pages = { HadesPowerMod.WeaponOverviewPage() }
	for _, weaponName in ipairs( HadesPowerMod.WeaponOrder ) do
		table.insert( pages, HadesPowerMod.WeaponPage( weaponName ) )
	end
	HadesPowerMod.DrawPages( screen, pages )
end
