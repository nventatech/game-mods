function HadesPowerMod.GiftMaximum( npcName )
	local data = GiftData[npcName]
	if data.Maximum ~= nil then
		return data.Maximum
	end
	for _, parentName in ipairs( data.InheritFrom or {} ) do
		local parent = GiftData[parentName]
		if parent ~= nil and parent.Maximum ~= nil then
			return parent.Maximum
		end
	end
	return GiftData.DefaultGiftData.Maximum
end

function HadesPowerMod.GiftNpcNames()
	local names = {}
	for npcName, data in pairs( GiftData ) do
		if type( data ) == "table" and npcName ~= "DefaultGiftData" and npcName ~= "DefaultGodGiftData" then
			table.insert( names, npcName )
		end
	end
	table.sort( names, function( a, b )
		local aNpc = string.sub( a, 1, 4 ) == "NPC_"
		local bNpc = string.sub( b, 1, 4 ) == "NPC_"
		if aNpc ~= bNpc then
			return aNpc
		end
		return a < b
	end )
	return names
end

function HadesPowerMod.GiftValue( npcName )
	local gift = GameState.Gift[npcName]
	if gift == nil then
		return 0
	end
	return gift.Value or 0
end

function HadesPowerMod.SetGiftValue( npcName, value )
	value = math.max( 0, math.min( HadesPowerMod.GiftMaximum( npcName ), value ) )
	GameState.Gift[npcName] = GameState.Gift[npcName] or { Value = 0 }
	local gift = GameState.Gift[npcName]
	local previous = gift.Value or 0
	gift.Value = value
	for level = previous + 1, value do
		local levelData = GiftData[npcName][level]
		if type( levelData ) == "table" and levelData.Gift ~= nil then
			gift.NewTraits = gift.NewTraits or {}
			table.insert( gift.NewTraits, levelData.Gift )
		end
	end
end

function HadesPowerMod.IsGiftMaxed( npcName )
	return HadesPowerMod.GiftValue( npcName ) >= HadesPowerMod.GiftMaximum( npcName )
end

function HadesPowerMod.GiftRow( npcName )
	return
	{
		Label = npcName,
		GetValue = function() return HadesPowerMod.LevelText( HadesPowerMod.GiftValue( npcName ), HadesPowerMod.GiftMaximum( npcName ) ) end,
		OnMinus = function() HadesPowerMod.SetGiftValue( npcName, HadesPowerMod.GiftValue( npcName ) - 1 ) end,
		OnPlus = function() HadesPowerMod.SetGiftValue( npcName, HadesPowerMod.GiftValue( npcName ) + 1 ) end,
		OnExtra = function() HadesPowerMod.SetGiftValue( npcName, HadesPowerMod.GiftMaximum( npcName ) ) end,
		GetExtra = function() return HadesPowerMod.IsGiftMaxed( npcName ) end,
		ExtraLabel = function( active ) return HadesPowerMod.Text( "Max" ) end,
	}
end

HadesPowerMod.TabDrawers.Story = function( screen )
	local names = HadesPowerMod.GiftNpcNames()
	local pages =
	{
		{
			{
				Label = HadesPowerMod.Text( "AffinityMaxed" ),
				GetValue = function() return HadesPowerMod.CountKeepsakes( names, HadesPowerMod.IsGiftMaxed ) end,
				OnExtra = function()
					for _, npcName in ipairs( names ) do
						HadesPowerMod.SetGiftValue( npcName, HadesPowerMod.GiftMaximum( npcName ) )
					end
				end,
				ExtraLabel = function( active ) return HadesPowerMod.Text( "Max" ) end,
			},
		},
	}
	local rows = {}
	for _, npcName in ipairs( names ) do
		table.insert( rows, HadesPowerMod.GiftRow( npcName ) )
	end
	for _, page in ipairs( HadesPowerMod.ChunkRows( rows ) ) do
		table.insert( pages, page )
	end
	HadesPowerMod.DrawPages( screen, pages )
end
