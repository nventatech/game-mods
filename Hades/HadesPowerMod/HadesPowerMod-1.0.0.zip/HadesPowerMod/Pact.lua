function HadesPowerMod.CountPactMaxed()
	local count = 0
	for _, name in ipairs( ShrineUpgradeOrder ) do
		if HadesPowerMod.MetaUpgradeLevel( name ) >= HadesPowerMod.MetaUpgradeMaxLevel( name ) then
			count = count + 1
		end
	end
	return tostring( count ) .. "/" .. tostring( #ShrineUpgradeOrder )
end

function HadesPowerMod.SetAllPactLevels( toMax )
	for _, name in ipairs( ShrineUpgradeOrder ) do
		local level = 0
		if toMax then
			level = HadesPowerMod.MetaUpgradeMaxLevel( name )
		end
		HadesPowerMod.SetMetaUpgradeLevel( name, level )
	end
end

function HadesPowerMod.PactOverviewPage()
	return
	{
		{
			Label = HadesPowerMod.Text( "PactUnlocked" ),
			GetValue = function() return GameState.Flags.ShrineUnlocked and HadesPowerMod.Text( "Unlocked" ) or HadesPowerMod.Text( "Locked" ) end,
			OnExtra = function() GameState.Flags.ShrineUnlocked = not GameState.Flags.ShrineUnlocked end,
			GetExtra = function() return GameState.Flags.ShrineUnlocked == true end,
			ExtraLabel = function( active ) return active and HadesPowerMod.Text( "Lock" ) or HadesPowerMod.Text( "Unlock" ) end,
		},
		{
			Label = HadesPowerMod.Text( "TotalHeat" ),
			GetValue = function() return tostring( GetTotalSpentShrinePoints() ) end,
			OnExtra = function() HadesPowerMod.SetAllPactLevels( false ) end,
			ExtraLabel = function( active ) return HadesPowerMod.Text( "Reset" ) end,
		},
		{
			Label = HadesPowerMod.Text( "PactMaxed" ),
			GetValue = HadesPowerMod.CountPactMaxed,
			OnExtra = function() HadesPowerMod.SetAllPactLevels( true ) end,
			ExtraLabel = function( active ) return HadesPowerMod.Text( "Max" ) end,
		},
	}
end

HadesPowerMod.TabDrawers.Pact = function( screen )
	local pages = { HadesPowerMod.PactOverviewPage() }
	local rows = {}
	for _, name in ipairs( ShrineUpgradeOrder ) do
		table.insert( rows,
		{
			Label = name,
			GetValue = function() return HadesPowerMod.LevelText( HadesPowerMod.MetaUpgradeLevel( name ), HadesPowerMod.MetaUpgradeMaxLevel( name ) ) end,
			OnMinus = function() HadesPowerMod.ChangeMetaUpgrade( name, -1 ) end,
			OnPlus = function() HadesPowerMod.ChangeMetaUpgrade( name, 1 ) end,
		})
	end
	for _, page in ipairs( HadesPowerMod.ChunkRows( rows ) ) do
		table.insert( pages, page )
	end
	HadesPowerMod.DrawPages( screen, pages )
end
