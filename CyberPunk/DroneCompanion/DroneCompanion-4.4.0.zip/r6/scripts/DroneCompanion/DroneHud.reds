module DroneCompanion

public class DCHud extends IScriptable {
  private let m_panel: wref<inkVerticalPanel>;
  private let m_rows: array<wref<inkHorizontalPanel>>;
  private let m_icons: array<wref<inkImage>>;
  private let m_names: array<wref<inkText>>;
  private let m_subs: array<wref<inkText>>;
  private let m_fills: array<wref<inkRectangle>>;
  private let m_last: String;

  private final func MakeText(size: Int32, parent: ref<inkCompoundWidget>) -> ref<inkText> {
    let text: ref<inkText> = new inkText();
    text.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
    text.SetFontStyle(n"Medium");
    text.SetFontSize(size);
    text.SetFitToContent(true);
    text.Reparent(parent);
    return text;
  }

  public final func Build(root: ref<inkCompoundWidget>) -> Void {
    let old: ref<inkWidget> = root.GetWidgetByPathName(n"dcSquadHud");
    if IsDefined(old) {
      root.RemoveChild(old);
    };

    let panel: ref<inkVerticalPanel> = new inkVerticalPanel();
    panel.SetName(n"dcSquadHud");
    panel.SetAnchor(inkEAnchor.TopLeft);
    panel.SetAnchorPoint(new Vector2(0.0, 0.0));
    panel.SetTranslation(new Vector2(10.0, 140.0));
    panel.SetScale(new Vector2(0.65, 0.65));
    panel.SetVisible(false);
    panel.Reparent(root);
    this.m_panel = panel;

    let i: Int32 = 0;
    while i < 8 {
      let row: ref<inkHorizontalPanel> = new inkHorizontalPanel();
      row.SetMargin(inkMargin(0.0, 0.0, 0.0, 10.0));
      row.SetVisible(false);
      row.Reparent(panel);
      ArrayPush(this.m_rows, row);

      let icon: ref<inkImage> = new inkImage();
      icon.SetAtlasResource(ResRef.FromString("dronecompanion\\gui\\dc_icons.inkatlas"));
      icon.SetSize(Vector2(44.0, 44.0));
      icon.SetMargin(inkMargin(0.0, 2.0, 10.0, 0.0));
      icon.Reparent(row);
      ArrayPush(this.m_icons, icon);

      let col: ref<inkVerticalPanel> = new inkVerticalPanel();
      col.Reparent(row);

      let name: ref<inkText> = this.MakeText(28, col);
      name.SetTintColor(new HDRColor(0.90, 0.90, 0.93, 1.0));
      ArrayPush(this.m_names, name);

      let barCv: ref<inkCanvas> = new inkCanvas();
      barCv.SetSize(Vector2(240.0, 8.0));
      barCv.SetMargin(inkMargin(0.0, 4.0, 0.0, 2.0));
      barCv.Reparent(col);

      let barBg: ref<inkRectangle> = new inkRectangle();
      barBg.SetSize(Vector2(240.0, 8.0));
      barBg.SetTintColor(new HDRColor(0.5, 0.5, 0.55, 1.0));
      barBg.SetOpacity(0.25);
      barBg.Reparent(barCv);

      let fill: ref<inkRectangle> = new inkRectangle();
      fill.SetSize(Vector2(240.0, 8.0));
      fill.Reparent(barCv);
      ArrayPush(this.m_fills, fill);

      let sub: ref<inkText> = this.MakeText(22, col);
      sub.SetTintColor(new HDRColor(0.55, 0.55, 0.60, 1.0));
      ArrayPush(this.m_subs, sub);

      i += 1;
    };
  }

  private final func HpColor(pct: Float) -> HDRColor {
    if pct >= 50.0 {
      return new HDRColor(0.35, 0.85, 0.40, 1.0);
    };
    if pct >= 25.0 {
      return new HDRColor(0.95, 0.78, 0.20, 1.0);
    };
    return new HDRColor(0.92, 0.22, 0.18, 1.0);
  }

  public final func Ready() -> Bool {
    return IsDefined(this.m_panel);
  }

  public final func SetState(payload: String) -> Void {
    if !IsDefined(this.m_panel) || Equals(payload, this.m_last) {
      return;
    };
    this.m_last = payload;
    if StrLen(payload) == 0 {
      this.m_panel.SetVisible(false);
      return;
    };
    let lines: array<String> = StrSplit(payload, "\n");
    let i: Int32 = 0;
    while i < ArraySize(this.m_rows) {
      if i < ArraySize(lines) {
        let f: array<String> = StrSplit(lines[i], "\t", true);
        if ArraySize(f) >= 4 {
          let pct: Float = StringToFloat(f[1], 0.0);
          this.m_icons[i].SetTexturePart(StringToName(f[0]));
          this.m_names[i].SetText(f[2]);
          this.m_subs[i].SetText(f[3]);
          this.m_fills[i].SetSize(Vector2(240.0 * MaxF(0.0, MinF(pct, 100.0)) / 100.0, 8.0));
          this.m_fills[i].SetTintColor(this.HpColor(pct));
          this.m_rows[i].SetVisible(true);
        } else {
          this.m_rows[i].SetVisible(false);
        };
      } else {
        this.m_rows[i].SetVisible(false);
      };
      i += 1;
    };
    this.m_panel.SetVisible(true);
  }
}

@addField(PlayerPuppet)
let m_dcHudPanel: ref<DCHud>;

@addMethod(PlayerPuppet)
public func DCKill(drone: wref<GameObject>) -> Bool {
  return true;
}

@addMethod(PlayerPuppet)
public func DCHudPush(payload: String) -> Bool {
  if IsDefined(this.m_dcHudPanel) && this.m_dcHudPanel.Ready() {
    this.m_dcHudPanel.SetState(payload);
    return true;
  };
  return false;
}

private static func DC_HudRoot() -> ref<inkCompoundWidget> {
  let layer: ref<inkLayerWrapper> = GameInstance.GetInkSystem().GetLayer(n"inkHUDLayer");
  if !IsDefined(layer) {
    return null;
  };
  return layer.GetVirtualWindow() as inkCompoundWidget;
}

@wrapMethod(healthbarWidgetGameController)
protected cb func OnPlayerAttach(playerGameObject: ref<GameObject>) -> Bool {
  let ret: Bool = wrappedMethod(playerGameObject);
  let pp: ref<PlayerPuppet> = playerGameObject as PlayerPuppet;
  if IsDefined(pp) {
    let root: ref<inkCompoundWidget> = DC_HudRoot();
    let hud: ref<DCHud> = new DCHud();
    if IsDefined(root) {
      hud.Build(root);
    };
    pp.m_dcHudPanel = hud;
    pp.DCEmit(hud.Ready() ? "hud:ok" : "hud:noroot");
  };
  return ret;
}
