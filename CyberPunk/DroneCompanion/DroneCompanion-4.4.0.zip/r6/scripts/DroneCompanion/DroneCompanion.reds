module DroneCompanion
import Codeware.Localization.*

public class DroneCompanionLocEN extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-DroneCompanion-Shard-Bombus", "Bombus Drone Control Shard");
    this.Text("Mod-DroneCompanion-Shard-Bombus-Desc", "Grey-market control authorization. Enables field deployment of Bombus support drones through a drone companion interface.");
    this.Text("Mod-DroneCompanion-Shard-Octant", "Octant Drone Control Shard");
    this.Text("Mod-DroneCompanion-Shard-Octant-Desc", "Grey-market control authorization. Enables field deployment of Octant combat drones through a drone companion interface.");
    this.Text("Mod-DroneCompanion-Shard-Griffin", "Griffin Drone Control Shard");
    this.Text("Mod-DroneCompanion-Shard-Griffin-Desc", "Grey-market control authorization. Enables field deployment of Griffin combat drones through a drone companion interface.");
    this.Text("Mod-DroneCompanion-Shard-Wyvern", "Wyvern Drone Control Shard");
    this.Text("Mod-DroneCompanion-Shard-Wyvern-Desc", "Grey-market control authorization. Enables field deployment of Wyvern combat drones through a drone companion interface.");
    this.Text("Mod-DroneCompanion-Shard-Minotaur", "Minotaur Mech Control Shard");
    this.Text("Mod-DroneCompanion-Shard-Minotaur-Desc", "Grey-market control authorization. Enables field deployment of Minotaur combat mechs through a drone companion interface.");
    this.Text("Mod-DroneCompanion-Shard-Android", "Android Control Shard");
    this.Text("Mod-DroneCompanion-Shard-Android-Desc", "Grey-market control authorization. Enables field deployment of combat androids through a drone companion interface.");
    this.Text("Mod-DroneCompanion-Shard-Cerberus", "Cerberus Control Shard");
    this.Text("Mod-DroneCompanion-Shard-Cerberus-Desc", "Grey-market control authorization, price to match. Deploys a Cerberus as an escort: it follows and takes hits, but its combat routines stay locked to its own mission.");
    this.Text("Mod-DroneCompanion-Shard-Flathead", "Flathead Control Shard");
    this.Text("Mod-DroneCompanion-Shard-Flathead-Desc", "Grey-market control authorization. Deploys a stationary Flathead unit for display: it does not follow or fight.");
    this.Text("Mod-DroneCompanion-Shard-Chimera", "Chimera Control Shard");
    this.Text("Mod-DroneCompanion-Shard-Chimera-Desc", "Grey-market control authorization, collector-grade. Deploys a stationary Chimera unit for display: it does not follow or fight.");
    this.Text("Mod-DroneCompanion-Capacity", "Drone Capacity Module");
    this.Text("Mod-DroneCompanion-Capacity-Desc", "Aftermarket co-processor for a drone companion interface. Each module raises the summon point pool by one, allowing more drones in the field at once.");
    this.Text("Mod-DroneCompanion-Hack-Repair", "Repair drone");
    this.Text("Mod-DroneCompanion-Hack-Hold", "Hold position");
    this.Text("Mod-DroneCompanion-Hack-Release", "Resume following");
    this.Text("Mod-DroneCompanion-Hack-Dismiss", "Dismiss drone");
    this.Text("Mod-DroneCompanion-Hack-Detonate", "Self-destruct");
    this.Text("Mod-DroneCompanion-Hack-Overclock", "Overclock drone");
    this.Text("Mod-DroneCompanion-Hack-Fortify", "Fortify drone");
    this.Text("Mod-DroneCompanion-Hack-Cooling", "Recharging");
    this.Text("Mod-DroneCompanion-Hack-Octant", "Dazzle target");
    this.Text("Mod-DroneCompanion-Hack-Wyvern", "Scan and mark");
    this.Text("Mod-DroneCompanion-Hack-Griffin", "EMP pulse");
    this.Text("Mod-DroneCompanion-Hack-Bombus", "Comms jammer");
    this.Text("Mod-DroneCompanion-Hack-Minotaur", "Taunt");
    this.Text("Mod-DroneCompanion-Title", "Drone Companion");
    this.Text("Mod-DroneCompanion-Set-Cat-Toggle", "Summon / dismiss all");
    this.Text("Mod-DroneCompanion-Set-Cat-Cycle", "Next model");
    this.Text("Mod-DroneCompanion-Set-Cat-Menu", "Open the screen");
    this.Text("Mod-DroneCompanion-Set-Cat-Command", "Tactical order");
    this.Text("Mod-DroneCompanion-Set-Mod", "Controller modifier (hold)");
    this.Text("Mod-DroneCompanion-Set-Mod-Desc", "Hold this shoulder button, then press the combo button. None removes the modifier from the combo.");
    this.Text("Mod-DroneCompanion-Set-Btn", "Controller button");
    this.Text("Mod-DroneCompanion-Set-Btn-Desc", "Pressed together with the modifier. With no modifier it also fires on that action's keyboard key. None disables the combo.");
    this.Text("Mod-DroneCompanion-Set-Key", "Keyboard key");
    this.Text("Mod-DroneCompanion-Set-Key-Desc", "Fires on its own, no modifier needed. None disables the key. The CET hotkeys keep working.");
  }
}

public class DroneCompanionLocPT extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-DroneCompanion-Shard-Bombus", "Shard de Controle - Drone Bombus");
    this.Text("Mod-DroneCompanion-Shard-Bombus-Desc", "Autorização de controle do mercado cinza. Libera o uso em campo de drones de suporte Bombus por interface de companion.");
    this.Text("Mod-DroneCompanion-Shard-Octant", "Shard de Controle - Drone Octant");
    this.Text("Mod-DroneCompanion-Shard-Octant-Desc", "Autorização de controle do mercado cinza. Libera o uso em campo de drones de combate Octant por interface de companion.");
    this.Text("Mod-DroneCompanion-Shard-Griffin", "Shard de Controle - Drone Griffin");
    this.Text("Mod-DroneCompanion-Shard-Griffin-Desc", "Autorização de controle do mercado cinza. Libera o uso em campo de drones de combate Griffin por interface de companion.");
    this.Text("Mod-DroneCompanion-Shard-Wyvern", "Shard de Controle - Drone Wyvern");
    this.Text("Mod-DroneCompanion-Shard-Wyvern-Desc", "Autorização de controle do mercado cinza. Libera o uso em campo de drones de combate Wyvern por interface de companion.");
    this.Text("Mod-DroneCompanion-Shard-Minotaur", "Shard de Controle - Mech Minotaur");
    this.Text("Mod-DroneCompanion-Shard-Minotaur-Desc", "Autorização de controle do mercado cinza. Libera o uso em campo de mechs de combate Minotaur por interface de companion.");
    this.Text("Mod-DroneCompanion-Shard-Android", "Shard de Controle - Android");
    this.Text("Mod-DroneCompanion-Shard-Android-Desc", "Autorização de controle do mercado cinza. Libera o uso em campo de androids de combate por interface de companion.");
    this.Text("Mod-DroneCompanion-Shard-Cerberus", "Shard de Controle - Cerberus");
    this.Text("Mod-DroneCompanion-Shard-Cerberus-Desc", "Autorização de controle do mercado cinza, com preço à altura. Libera o Cerberus como escolta: ele segue e aguenta dano, mas as rotinas de combate dele continuam presas à missão original.");
    this.Text("Mod-DroneCompanion-Shard-Flathead", "Shard de Controle - Flathead");
    this.Text("Mod-DroneCompanion-Shard-Flathead-Desc", "Autorização de controle do mercado cinza. Libera uma unidade Flathead estática de exibição: não segue nem luta.");
    this.Text("Mod-DroneCompanion-Shard-Chimera", "Shard de Controle - Chimera");
    this.Text("Mod-DroneCompanion-Shard-Chimera-Desc", "Autorização de controle do mercado cinza, nível colecionador. Libera uma unidade Chimera estática de exibição: não segue nem luta.");
    this.Text("Mod-DroneCompanion-Capacity", "Módulo de Capacidade de Drones");
    this.Text("Mod-DroneCompanion-Capacity-Desc", "Coprocessador paralelo para interface de drone companion. Cada módulo aumenta em um o total de pontos de invocação, permitindo mais drones em campo ao mesmo tempo.");
    this.Text("Mod-DroneCompanion-Hack-Repair", "Reparar drone");
    this.Text("Mod-DroneCompanion-Hack-Hold", "Manter posição");
    this.Text("Mod-DroneCompanion-Hack-Release", "Voltar a seguir");
    this.Text("Mod-DroneCompanion-Hack-Dismiss", "Dispensar drone");
    this.Text("Mod-DroneCompanion-Hack-Detonate", "Autodestruição");
    this.Text("Mod-DroneCompanion-Hack-Overclock", "Sobrecarregar drone");
    this.Text("Mod-DroneCompanion-Hack-Fortify", "Reforçar drone");
    this.Text("Mod-DroneCompanion-Hack-Cooling", "Recarregando");
    this.Text("Mod-DroneCompanion-Hack-Octant", "Ofuscar alvo");
    this.Text("Mod-DroneCompanion-Hack-Wyvern", "Escanear e marcar");
    this.Text("Mod-DroneCompanion-Hack-Griffin", "Pulso EMP");
    this.Text("Mod-DroneCompanion-Hack-Bombus", "Bloqueio de comunicações");
    this.Text("Mod-DroneCompanion-Hack-Minotaur", "Provocar");
    this.Text("Mod-DroneCompanion-Title", "Drone Companion");
    this.Text("Mod-DroneCompanion-Set-Cat-Toggle", "Invocar / dispensar todos");
    this.Text("Mod-DroneCompanion-Set-Cat-Cycle", "Próximo modelo");
    this.Text("Mod-DroneCompanion-Set-Cat-Menu", "Abrir a tela");
    this.Text("Mod-DroneCompanion-Set-Cat-Command", "Ordem tática");
    this.Text("Mod-DroneCompanion-Set-Mod", "Modificador do controle (segurar)");
    this.Text("Mod-DroneCompanion-Set-Mod-Desc", "Segure este botão de ombro e aperte o botão do combo. None tira o modificador do combo.");
    this.Text("Mod-DroneCompanion-Set-Btn", "Botão do controle");
    this.Text("Mod-DroneCompanion-Set-Btn-Desc", "Apertado junto com o modificador. Sem modificador, também dispara na tecla de teclado da mesma ação. None desativa o combo.");
    this.Text("Mod-DroneCompanion-Set-Key", "Tecla do teclado");
    this.Text("Mod-DroneCompanion-Set-Key-Desc", "Dispara sozinha, sem modificador. None desativa a tecla. Os atalhos do CET continuam funcionando.");
  }
}

public class DroneCompanionLocProvider extends ModLocalizationProvider {
  public func GetPackage(language: CName) -> ref<ModLocalizationPackage> {
    switch language {
      case n"pt-br": return new DroneCompanionLocPT();
      default: return new DroneCompanionLocEN();
    };
  }

  public func GetFallback() -> CName {
    return n"en-us";
  }
}

private static func DC_IsCompanionDrone(obj: wref<GameObject>) -> Bool {
  let sp: wref<ScriptedPuppet> = obj as ScriptedPuppet;
  if !IsDefined(sp) {
    return false;
  };
  let ses = GameInstance.GetStatusEffectSystem(sp.GetGame());
  return IsDefined(ses) && ses.HasStatusEffect(sp.GetEntityID(), t"DroneCompanion.CompanionSE");
}

private static func DC_IsPassive(obj: wref<GameObject>) -> Bool {
  let sp: wref<ScriptedPuppet> = obj as ScriptedPuppet;
  if !IsDefined(sp) {
    return false;
  };
  let ses = GameInstance.GetStatusEffectSystem(sp.GetGame());
  return IsDefined(ses) && ses.HasStatusEffect(sp.GetEntityID(), t"DroneCompanion.PassiveSE");
}

@wrapMethod(ScriptedPuppet)
public final func IsQuickHackAble() -> Bool {
  if DC_IsCompanionDrone(this) {
    return true;
  };
  return wrappedMethod();
}

@wrapMethod(ScriptedPuppetPS)
public final const func IsQuickHacksExposed() -> Bool {
  if DC_IsCompanionDrone(this.GetOwnerEntity() as ScriptedPuppet) {
    return true;
  };
  return wrappedMethod();
}

private static func DC_HackIDs() -> array<TweakDBID> {
  return [
    t"DroneCompanion.HackRepair",
    t"DroneCompanion.HackHold",
    t"DroneCompanion.HackDismiss",
    t"DroneCompanion.HackDetonate",
    t"DroneCompanion.HackOverclock",
    t"DroneCompanion.HackFortify",
    t"DroneCompanion.HackOctant",
    t"DroneCompanion.HackWyvern",
    t"DroneCompanion.HackGriffin",
    t"DroneCompanion.HackBombus",
    t"DroneCompanion.HackMinotaur"
  ];
}

private static func DC_CooldownIDs() -> array<TweakDBID> {
  return [
    t"DroneCompanion.HackRepairCd",
    t"DroneCompanion.HackHoldCd",
    t"DroneCompanion.HackDismissCd",
    t"DroneCompanion.HackDetonateCd",
    t"DroneCompanion.HackOverclockCd",
    t"DroneCompanion.HackFortifyCd",
    t"DroneCompanion.HackOctantCd",
    t"DroneCompanion.HackWyvernCd",
    t"DroneCompanion.HackGriffinCd",
    t"DroneCompanion.HackBombusCd",
    t"DroneCompanion.HackMinotaurCd"
  ];
}

private static func DC_CooldownFor(id: TweakDBID) -> TweakDBID {
  let ids: array<TweakDBID> = DC_HackIDs();
  let cds: array<TweakDBID> = DC_CooldownIDs();
  let i: Int32 = 0;
  while i < ArraySize(ids) {
    if ids[i] == id {
      return cds[i];
    };
    i += 1;
  };
  return TDBID.None();
}

@wrapMethod(ScriptedPuppet)
private final func TranslateChoicesIntoQuickSlotCommands(const choices: script_ref<array<ref<PuppetAction>>>, commands: script_ref<array<ref<QuickhackData>>>) -> Void {
  wrappedMethod(choices, commands);
  if !DC_IsCompanionDrone(this) {
    return;
  };
  let ses = GameInstance.GetStatusEffectSystem(this.GetGame());
  if !IsDefined(ses) {
    return;
  };
  let i: Int32 = 0;
  while i < ArraySize(Deref(commands)) {
    let cmd: ref<QuickhackData> = Deref(commands)[i];
    let action: ref<PuppetAction> = cmd.m_action as PuppetAction;
    if IsDefined(action) {
      let cooldown: TweakDBID = DC_CooldownFor(action.GetObjectActionID());
      if TDBID.IsValid(cooldown) && ses.HasStatusEffect(this.GetEntityID(), cooldown) {
        cmd.m_isLocked = true;
        cmd.m_inactiveReason = "Mod-DroneCompanion-Hack-Cooling";
        cmd.m_actionState = EActionInactivityReson.Locked;
      };
    };
    i += 1;
  };
}

private static func DC_ListHasAction(list: script_ref<array<PlayerQuickhackData>>, id: TweakDBID) -> Bool {
  let i: Int32 = 0;
  while i < ArraySize(Deref(list)) {
    if IsDefined(Deref(list)[i].actionRecord) && Deref(list)[i].actionRecord.GetID() == id {
      return true;
    };
    i += 1;
  };
  return false;
}

@wrapMethod(RPGManager)
public final static func GetPlayerQuickHackListWithQuality(player: wref<PlayerPuppet>) -> array<PlayerQuickhackData> {
  let list: array<PlayerQuickhackData> = wrappedMethod(player);
  if !IsDefined(player) {
    return list;
  };
  let ids: array<TweakDBID> = DC_HackIDs();
  let added: Int32 = 0;
  let data: PlayerQuickhackData;
  let record: wref<ObjectAction_Record>;
  let i: Int32 = 0;
  while i < ArraySize(ids) {
    record = TweakDBInterface.GetObjectActionRecord(ids[i]);
    if IsDefined(record) && !DC_ListHasAction(list, ids[i]) {
      data.actionRecord = record;
      data.quality = 4;
      ArrayPush(list, data);
      added += 1;
    };
    i += 1;
  };
  if added > 0 {
    PlayerPuppet.ChacheQuickHackList(player, list);
  };
  return list;
}

@wrapMethod(GameObject)
public final func FindAndRewardKiller(killType: gameKillType, opt instigator: wref<GameObject>) -> Void {
  if DC_IsCompanionDrone(instigator) {
    let player = GetPlayer(this.GetGame());
    if IsDefined(player) {
      player.DCKill(instigator);
    };
    instigator = player;
  };
  let i: Int32 = 0;
  while i < ArraySize(this.m_receivedDamageHistory) {
    if DC_IsCompanionDrone(this.m_receivedDamageHistory[i].source) {
      this.m_receivedDamageHistory[i].source = GetPlayer(this.GetGame());
    };
    i += 1;
  };
  wrappedMethod(killType, instigator);
}

@wrapMethod(DamageSystem)
private final func Process(hitEvent: ref<gameHitEvent>, cache: ref<CacheData>) -> Void {
  let instigator: wref<ScriptedPuppet> = hitEvent.attackData.GetInstigator() as ScriptedPuppet;
  let target: wref<ScriptedPuppet> = hitEvent.target as ScriptedPuppet;
  if IsDefined(instigator) && IsDefined(target) {
    let instOurs: Bool = DC_IsCompanionDrone(instigator);
    let targOurs: Bool = DC_IsCompanionDrone(target);
    if (instOurs && targOurs) || (instigator.IsPlayer() && targOurs) || (instOurs && target.IsPlayer()) {
      return;
    };
  };
  wrappedMethod(hitEvent, cache);
}

@wrapMethod(ReactionManagerComponent)
protected cb func OnDetectedEvent(evt: ref<OnDetectedEvent>) -> Bool {
  if IsDefined(evt) && IsDefined(evt.target) && evt.isVisible && DC_IsCompanionDrone(evt.target) && !DC_IsPassive(evt.target) {
    let owner: wref<ScriptedPuppet> = this.GetOwnerPuppet();
    if IsDefined(owner) && !DC_IsCompanionDrone(owner) {
      TargetTrackingExtension.InjectThreat(owner, evt.target);
    };
  };
  return wrappedMethod(evt);
}

@wrapMethod(SenseComponent)
public final static func ShouldIgnoreIfPlayerCompanion(owner: wref<Entity>, target: wref<Entity>) -> Bool {
  if DC_IsCompanionDrone(target as GameObject) && !DC_IsPassive(target as GameObject) {
    return false;
  };
  return wrappedMethod(owner, target);
}

@wrapMethod(PlayerPuppet)
private final func UpdateLookAtObject(target: ref<GameObject>) -> Void {
  wrappedMethod(target);
  if IsDefined(target) && DC_IsCompanionDrone(target) {
    this.m_isAimingAtFriendly = false;
  };
}

@wrapMethod(NpcNameplateGameController)
private final func HelperCheckDistance(entity: ref<Entity>) -> Bool {
  if IsDefined(entity) && DC_IsCompanionDrone(entity as GameObject) {
    return true;
  };
  return wrappedMethod(entity);
}

@wrapMethod(NpcNameplateGameController)
protected cb func OnNameplateDataChanged(value: Variant) -> Bool {
  wrappedMethod(value);
  let data: NPCNextToTheCrosshair = FromVariant<NPCNextToTheCrosshair>(value);
  if IsDefined(data.npc) && DC_IsCompanionDrone(data.npc) {
    this.m_visualController.UpdateNPCNamesEnabled(true);
  };
}

@wrapMethod(NameplateVisualsLogicController)
public final func SetVisualData(puppet: ref<GameObject>, const incomingData: script_ref<NPCNextToTheCrosshair>, opt isNewNpc: Bool) -> Void {
  wrappedMethod(puppet, incomingData, isNewNpc);
  if IsDefined(puppet) && DC_IsCompanionDrone(puppet) {
    this.UpdateHealthbarColor(false);
    inkWidgetRef.SetVisible(this.m_healthbarWidget, true);
  };
}

@wrapMethod(NameplateVisualsLogicController)
public final func UpdateHealthbarColor(isHostile: Bool) -> Void {
  if IsDefined(this.m_cachedPuppet) && DC_IsCompanionDrone(this.m_cachedPuppet) {
    inkWidgetRef.SetState(this.m_healthbarWidget, n"Friendly");
    inkWidgetRef.SetState(this.m_healthBarFull, n"Friendly");
    inkWidgetRef.SetState(this.m_healthBarFrame, n"Friendly");
    return;
  };
  wrappedMethod(isHostile);
}

@wrapMethod(DamageDigitsGameController)
protected cb func OnDamageAdded(value: Variant) -> Bool {
  if !IsDefined(this.m_realOwner) {
    return wrappedMethod(value);
  };
  let list: array<DamageInfo> = FromVariant<array<DamageInfo>>(value);
  let changed: Bool = false;
  let i: Int32 = 0;
  while i < ArraySize(list) {
    if DC_IsCompanionDrone(list[i].instigator) {
      let info: DamageInfo = list[i];
      info.instigator = this.m_realOwner;
      list[i] = info;
      changed = true;
    };
    i += 1;
  };
  if changed {
    return wrappedMethod(ToVariant(list));
  };
  return wrappedMethod(value);
}

