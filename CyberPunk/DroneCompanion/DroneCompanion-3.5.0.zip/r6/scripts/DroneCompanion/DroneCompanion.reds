module DroneCompanion
import Codeware.Localization.*

public class DroneCompanionLocEN extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-DroneCompanion-Shard-Bombus", "Bombus Drone Control Shard");
    this.Text("Mod-DroneCompanion-Shard-Bombus-Desc", "Grey-market control authorization. Enables field deployment of Bombus support drones through a drone companion interface.");
    this.Text("Mod-DroneCompanion-Shard-Octant", "Octant Drone Control Shard");
    this.Text("Mod-DroneCompanion-Shard-Octant-Desc", "Grey-market control authorization. Enables field deployment of Octant combat drones through a drone companion interface.");
    this.Text("Mod-DroneCompanion-Shard-Griffin", "Griffin Drone Control Shard");
    this.Text("Mod-DroneCompanion-Shard-Griffin-Desc", "Grey-market control authorization. Enables field deployment of Griffin combat drones through a drone companion interface.");
    this.Text("Mod-DroneCompanion-Shard-Wyvern", "Wyvern Drone Control Shard");
    this.Text("Mod-DroneCompanion-Shard-Wyvern-Desc", "Grey-market control authorization. Enables field deployment of Wyvern combat drones through a drone companion interface.");
    this.Text("Mod-DroneCompanion-Shard-Minotaur", "Minotaur Mech Control Shard");
    this.Text("Mod-DroneCompanion-Shard-Minotaur-Desc", "Grey-market control authorization. Enables field deployment of Minotaur combat mechs through a drone companion interface.");
    this.Text("Mod-DroneCompanion-Shard-Android", "Android Control Shard");
    this.Text("Mod-DroneCompanion-Shard-Android-Desc", "Grey-market control authorization. Enables field deployment of combat androids through a drone companion interface.");
    this.Text("Mod-DroneCompanion-Shard-Cerberus", "Cerberus Control Shard");
    this.Text("Mod-DroneCompanion-Shard-Cerberus-Desc", "Grey-market control authorization, price to match. Deploys a Cerberus as an escort: it follows and takes hits, but its combat routines stay locked to its own mission.");
    this.Text("Mod-DroneCompanion-Hack-Repair", "Repair drone");
    this.Text("Mod-DroneCompanion-Hack-Hold", "Hold position");
    this.Text("Mod-DroneCompanion-Hack-Release", "Resume following");
    this.Text("Mod-DroneCompanion-Hack-Dismiss", "Dismiss drone");
    this.Text("Mod-DroneCompanion-Hack-Detonate", "Self-destruct");
    this.Text("Mod-DroneCompanion-Hack-Octant", "Dazzle target");
    this.Text("Mod-DroneCompanion-Hack-Wyvern", "Scan and mark");
    this.Text("Mod-DroneCompanion-Hack-Griffin", "EMP pulse");
    this.Text("Mod-DroneCompanion-Hack-Bombus", "Comms jammer");
    this.Text("Mod-DroneCompanion-Hack-Minotaur", "Taunt");
  }
}

public class DroneCompanionLocPT extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-DroneCompanion-Shard-Bombus", "Shard de Controle - Drone Bombus");
    this.Text("Mod-DroneCompanion-Shard-Bombus-Desc", "Autorização de controle do mercado cinza. Libera o uso em campo de drones de suporte Bombus por interface de companion.");
    this.Text("Mod-DroneCompanion-Shard-Octant", "Shard de Controle - Drone Octant");
    this.Text("Mod-DroneCompanion-Shard-Octant-Desc", "Autorização de controle do mercado cinza. Libera o uso em campo de drones de combate Octant por interface de companion.");
    this.Text("Mod-DroneCompanion-Shard-Griffin", "Shard de Controle - Drone Griffin");
    this.Text("Mod-DroneCompanion-Shard-Griffin-Desc", "Autorização de controle do mercado cinza. Libera o uso em campo de drones de combate Griffin por interface de companion.");
    this.Text("Mod-DroneCompanion-Shard-Wyvern", "Shard de Controle - Drone Wyvern");
    this.Text("Mod-DroneCompanion-Shard-Wyvern-Desc", "Autorização de controle do mercado cinza. Libera o uso em campo de drones de combate Wyvern por interface de companion.");
    this.Text("Mod-DroneCompanion-Shard-Minotaur", "Shard de Controle - Mech Minotaur");
    this.Text("Mod-DroneCompanion-Shard-Minotaur-Desc", "Autorização de controle do mercado cinza. Libera o uso em campo de mechs de combate Minotaur por interface de companion.");
    this.Text("Mod-DroneCompanion-Shard-Android", "Shard de Controle - Android");
    this.Text("Mod-DroneCompanion-Shard-Android-Desc", "Autorização de controle do mercado cinza. Libera o uso em campo de androids de combate por interface de companion.");
    this.Text("Mod-DroneCompanion-Shard-Cerberus", "Shard de Controle - Cerberus");
    this.Text("Mod-DroneCompanion-Shard-Cerberus-Desc", "Autorização de controle do mercado cinza, com preço à altura. Libera o Cerberus como escolta: ele segue e aguenta dano, mas as rotinas de combate dele continuam presas à missão original.");
    this.Text("Mod-DroneCompanion-Hack-Repair", "Reparar drone");
    this.Text("Mod-DroneCompanion-Hack-Hold", "Manter posição");
    this.Text("Mod-DroneCompanion-Hack-Release", "Voltar a seguir");
    this.Text("Mod-DroneCompanion-Hack-Dismiss", "Dispensar drone");
    this.Text("Mod-DroneCompanion-Hack-Detonate", "Autodestruição");
    this.Text("Mod-DroneCompanion-Hack-Octant", "Ofuscar alvo");
    this.Text("Mod-DroneCompanion-Hack-Wyvern", "Escanear e marcar");
    this.Text("Mod-DroneCompanion-Hack-Griffin", "Pulso EMP");
    this.Text("Mod-DroneCompanion-Hack-Bombus", "Bloqueio de comunicações");
    this.Text("Mod-DroneCompanion-Hack-Minotaur", "Provocar");
  }
}

public class DroneCompanionLocProvider extends ModLocalizationProvider {
  public func GetPackage(language: CName) -> ref<ModLocalizationPackage> {
    switch language {
      case n"pt-br": return new DroneCompanionLocPT();
      default: return new DroneCompanionLocEN();
    };
  }

  public func GetFallback() -> CName {
    return n"en-us";
  }
}

private static func DC_IsCompanionDrone(obj: wref<GameObject>) -> Bool {
  let sp: wref<ScriptedPuppet> = obj as ScriptedPuppet;
  if !IsDefined(sp) {
    return false;
  };
  let ses = GameInstance.GetStatusEffectSystem(sp.GetGame());
  return IsDefined(ses) && ses.HasStatusEffect(sp.GetEntityID(), t"DroneCompanion.CompanionSE");
}

private static func DC_IsPassive(obj: wref<GameObject>) -> Bool {
  let sp: wref<ScriptedPuppet> = obj as ScriptedPuppet;
  if !IsDefined(sp) {
    return false;
  };
  let ses = GameInstance.GetStatusEffectSystem(sp.GetGame());
  return IsDefined(ses) && ses.HasStatusEffect(sp.GetEntityID(), t"DroneCompanion.PassiveSE");
}

@wrapMethod(ScriptedPuppet)
public final func IsQuickHackAble() -> Bool {
  if DC_IsCompanionDrone(this) {
    return true;
  };
  return wrappedMethod();
}

@wrapMethod(ScriptedPuppetPS)
public final const func IsQuickHacksExposed() -> Bool {
  if DC_IsCompanionDrone(this.GetOwnerEntity() as ScriptedPuppet) {
    return true;
  };
  return wrappedMethod();
}

private static func DC_HackIDs() -> array<TweakDBID> {
  return [
    t"DroneCompanion.HackRepair",
    t"DroneCompanion.HackHold",
    t"DroneCompanion.HackDismiss",
    t"DroneCompanion.HackDetonate",
    t"DroneCompanion.HackOctant",
    t"DroneCompanion.HackWyvern",
    t"DroneCompanion.HackGriffin",
    t"DroneCompanion.HackBombus",
    t"DroneCompanion.HackMinotaur"
  ];
}

private static func DC_ListHasAction(list: script_ref<array<PlayerQuickhackData>>, id: TweakDBID) -> Bool {
  let i: Int32 = 0;
  while i < ArraySize(Deref(list)) {
    if IsDefined(Deref(list)[i].actionRecord) && Deref(list)[i].actionRecord.GetID() == id {
      return true;
    };
    i += 1;
  };
  return false;
}

@wrapMethod(RPGManager)
public final static func GetPlayerQuickHackListWithQuality(player: wref<PlayerPuppet>) -> array<PlayerQuickhackData> {
  let list: array<PlayerQuickhackData> = wrappedMethod(player);
  if !IsDefined(player) {
    return list;
  };
  let ids: array<TweakDBID> = DC_HackIDs();
  let added: Int32 = 0;
  let missing: Int32 = 0;
  let data: PlayerQuickhackData;
  let record: wref<ObjectAction_Record>;
  let i: Int32 = 0;
  while i < ArraySize(ids) {
    record = TweakDBInterface.GetObjectActionRecord(ids[i]);
    if !IsDefined(record) {
      missing += 1;
    } else {
      if !DC_ListHasAction(list, ids[i]) {
        data.actionRecord = record;
        data.quality = 4;
        ArrayPush(list, data);
        added += 1;
      };
    };
    i += 1;
  };
  if added > 0 {
    PlayerPuppet.ChacheQuickHackList(player, list);
  };
  if missing > 0 {
    LogChannel(n"DEBUG", "[DroneCompanion] drone hack records missing in TweakDB");
  };
  return list;
}

@wrapMethod(GameObject)
public final func FindAndRewardKiller(killType: gameKillType, opt instigator: wref<GameObject>) -> Void {
  if DC_IsCompanionDrone(instigator) {
    instigator = GetPlayer(this.GetGame());
  };
  let i: Int32 = 0;
  while i < ArraySize(this.m_receivedDamageHistory) {
    if DC_IsCompanionDrone(this.m_receivedDamageHistory[i].source) {
      this.m_receivedDamageHistory[i].source = GetPlayer(this.GetGame());
    };
    i += 1;
  };
  wrappedMethod(killType, instigator);
}

@wrapMethod(DamageSystem)
private final func Process(hitEvent: ref<gameHitEvent>, cache: ref<CacheData>) -> Void {
  let instigator: wref<ScriptedPuppet> = hitEvent.attackData.GetInstigator() as ScriptedPuppet;
  let target: wref<ScriptedPuppet> = hitEvent.target as ScriptedPuppet;
  if IsDefined(instigator) && IsDefined(target) {
    let instOurs: Bool = DC_IsCompanionDrone(instigator);
    let targOurs: Bool = DC_IsCompanionDrone(target);
    if (instOurs && targOurs) || (instigator.IsPlayer() && targOurs) || (instOurs && target.IsPlayer()) {
      return;
    };
  };
  wrappedMethod(hitEvent, cache);
}

@wrapMethod(ReactionManagerComponent)
protected cb func OnDetectedEvent(evt: ref<OnDetectedEvent>) -> Bool {
  if IsDefined(evt) && IsDefined(evt.target) && evt.isVisible && DC_IsCompanionDrone(evt.target) && !DC_IsPassive(evt.target) {
    let owner: wref<ScriptedPuppet> = this.GetOwnerPuppet();
    if IsDefined(owner) && !DC_IsCompanionDrone(owner) {
      TargetTrackingExtension.InjectThreat(owner, evt.target);
    };
  };
  return wrappedMethod(evt);
}

@wrapMethod(SenseComponent)
public final static func ShouldIgnoreIfPlayerCompanion(owner: wref<Entity>, target: wref<Entity>) -> Bool {
  if DC_IsCompanionDrone(target as GameObject) && !DC_IsPassive(target as GameObject) {
    return false;
  };
  return wrappedMethod(owner, target);
}

@wrapMethod(PlayerPuppet)
private final func UpdateLookAtObject(target: ref<GameObject>) -> Void {
  wrappedMethod(target);
  if IsDefined(target) && DC_IsCompanionDrone(target) {
    this.m_isAimingAtFriendly = false;
  };
}

@wrapMethod(NpcNameplateGameController)
private final func HelperCheckDistance(entity: ref<Entity>) -> Bool {
  if IsDefined(entity) && DC_IsCompanionDrone(entity as GameObject) {
    return true;
  };
  return wrappedMethod(entity);
}

@wrapMethod(NpcNameplateGameController)
protected cb func OnNameplateDataChanged(value: Variant) -> Bool {
  wrappedMethod(value);
  let data: NPCNextToTheCrosshair = FromVariant<NPCNextToTheCrosshair>(value);
  if IsDefined(data.npc) && DC_IsCompanionDrone(data.npc) {
    this.m_visualController.UpdateNPCNamesEnabled(true);
  };
}

@wrapMethod(NameplateVisualsLogicController)
public final func SetVisualData(puppet: ref<GameObject>, const incomingData: script_ref<NPCNextToTheCrosshair>, opt isNewNpc: Bool) -> Void {
  wrappedMethod(puppet, incomingData, isNewNpc);
  if IsDefined(puppet) && DC_IsCompanionDrone(puppet) {
    this.UpdateHealthbarColor(false);
    inkWidgetRef.SetVisible(this.m_healthbarWidget, true);
  };
}

@wrapMethod(NameplateVisualsLogicController)
public final func UpdateHealthbarColor(isHostile: Bool) -> Void {
  if IsDefined(this.m_cachedPuppet) && DC_IsCompanionDrone(this.m_cachedPuppet) {
    inkWidgetRef.SetState(this.m_healthbarWidget, n"Friendly");
    inkWidgetRef.SetState(this.m_healthBarFull, n"Friendly");
    inkWidgetRef.SetState(this.m_healthBarFrame, n"Friendly");
    return;
  };
  wrappedMethod(isHostile);
}
