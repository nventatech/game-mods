module DroneCompanion

import Codeware.UI.*

public struct DCRow {
  public let id: String;
  public let kind: String;
  public let label: String;
  public let value: String;
  public let icon: String;
}

public class DCMenuPopup extends InGamePopup {
  protected let m_header: ref<InGamePopupHeader>;
  protected let m_footer: ref<InGamePopupFooter>;
  protected let m_content: ref<InGamePopupContent>;
  protected let m_tabBar: wref<inkHorizontalPanel>;
  protected let m_tabTexts: array<wref<inkText>>;
  protected let m_tabMarks: array<wref<inkRectangle>>;
  protected let m_tabs: array<String>;
  protected let m_tab: Int32;
  protected let m_listPanel: wref<inkVerticalPanel>;
  protected let m_rows: array<DCRow>;
  protected let m_rowLabels: array<wref<inkText>>;
  protected let m_rowValues: array<wref<inkText>>;
  protected let m_rowMarks: array<wref<inkRectangle>>;
  protected let m_rowTops: array<Float>;
  protected let m_contentHeight: Float;
  protected let m_sel: Int32;
  protected let m_scroll: Float;
  protected let m_payload: String;
  protected let m_owner: wref<PlayerPuppet>;
  protected let m_outer: wref<inkVerticalPanel>;
  protected let m_view: wref<inkScrollArea>;
  protected let m_scrollTrack: wref<inkRectangle>;
  protected let m_scrollThumb: wref<inkRectangle>;
  protected let m_hint: wref<inkText>;
  protected let m_scale: Float = 1.0;
  protected let m_accent: HDRColor;
  protected let m_hintLine: String;
  protected let m_rowBars: array<wref<inkRectangle>>;
  protected let m_accentKey: String;
  protected let m_hover: Int32;

  public func GetName() -> CName {
    return n"DCMenuPopup";
  }

  public func UseCursor() -> Bool {
    return true;
  }

  public func DCIsOpen() -> Bool {
    return this.IsInitialized();
  }

  public func DCBind(player: ref<PlayerPuppet>) -> Void {
    this.m_owner = player;
  }

  protected func DCEmit(action: String) -> Void {
    if IsDefined(this.m_owner) {
      this.m_owner.DCEmit(action);
    };
  }

  protected func DCAccent() -> HDRColor {
    if StrLen(this.m_accentKey) > 0 {
      return this.m_accent;
    };
    return new HDRColor(0.88, 0.16, 0.14, 1.0);
  }

  protected func DCColorOf(kind: String, selected: Bool) -> HDRColor {
    if selected {
      return new HDRColor(1.0, 1.0, 1.0, 1.0);
    };
    if Equals(kind, "head") {
      return this.DCAccent();
    };
    if Equals(kind, "warn") {
      return new HDRColor(1.0, 0.62, 0.20, 1.0);
    };
    if Equals(kind, "dim") {
      return new HDRColor(0.50, 0.50, 0.55, 1.0);
    };
    return new HDRColor(0.82, 0.82, 0.85, 1.0);
  }

  protected func DCApplyHints(line: String) -> Void {
    if Equals(line, this.m_hintLine) || !IsDefined(this.m_footer) {
      return;
    };
    this.m_hintLine = line;
    let hints: wref<ButtonHintsEx> = this.m_footer.GetHints();
    if !IsDefined(hints) {
      return;
    };
    hints.ClearButtonHints();
    let f: array<String> = StrSplit(line, "\t", true);
    let names: array<CName>;
    ArrayPush(names, n"click");
    ArrayPush(names, n"popup_navigate_right");
    ArrayPush(names, n"next_menu");
    ArrayPush(names, n"cancel");
    let i: Int32 = 1;
    while i < ArraySize(f) && i <= ArraySize(names) {
      if StrLen(f[i]) > 0 {
        hints.AddButtonHint(names[i - 1], f[i]);
      };
      i += 1;
    };
  }

  protected func DCStripMark(value: String) -> String {
    if StrLen(value) > 0 && (Equals(StrLeft(value, 1), "!") || Equals(StrLeft(value, 1), "*")) {
      return StrRight(value, StrLen(value) - 1);
    };
    return value;
  }

  protected func DCValueTone(row: DCRow) -> Int32 {
    if Equals(row.kind, "toggle") {
      return Equals(row.value, "1") ? 2 : 3;
    };
    if Equals(row.kind, "btn") {
      if StrLen(row.value) > 0 && Equals(StrLeft(row.value, 1), "!") {
        return 1;
      };
      if StrLen(row.value) > 0 && Equals(StrLeft(row.value, 1), "*") {
        return 2;
      };
      return 0;
    };
    return 4;
  }

  protected func DCToneColor(tone: Int32, selected: Bool) -> HDRColor {
    if tone == 1 {
      return new HDRColor(1.00, 0.62, 0.20, 1.0);
    };
    if tone == 2 {
      return new HDRColor(0.30, 0.85, 0.35, 1.0);
    };
    if tone == 3 {
      return selected ? new HDRColor(0.82, 0.82, 0.85, 1.0) : new HDRColor(0.50, 0.50, 0.55, 1.0);
    };
    if tone == 0 {
      return new HDRColor(1.00, 0.82, 0.00, 1.0);
    };
    return selected ? new HDRColor(1.0, 1.0, 1.0, 1.0) : new HDRColor(0.82, 0.82, 0.85, 1.0);
  }

  protected func DCIsSelectable(kind: String) -> Bool {
    return Equals(kind, "btn") || Equals(kind, "toggle") || Equals(kind, "choice")
      || Equals(kind, "slider") || Equals(kind, "item");
  }

  protected func DCIsWrapped(kind: String) -> Bool {
    return Equals(kind, "dim") || Equals(kind, "warn") || Equals(kind, "text");
  }

  protected func DCViewWidth() -> Float {
    return 1940.0;
  }

  protected func DCViewHeight() -> Float {
    return 940.0;
  }

  protected func DCS(value: Float) -> Float {
    return value * this.m_scale;
  }

  protected func DCFontSize(value: Int32) -> Int32 {
    return Cast<Int32>(MaxF(12.0, Cast<Float>(value) * this.m_scale));
  }

  protected func DCWrapWidth(row: DCRow) -> Float {
    return StrLen(row.value) > 0 ? 1150.0 : 1700.0;
  }

  protected func DCRowHeight(row: DCRow) -> Float {
    if Equals(row.kind, "head") {
      return this.DCS(92.0);
    };
    if this.DCIsWrapped(row.kind) {
      let charWidth: Float = Cast<Float>(this.DCFontSize(38)) * 0.46;
      let raw: Int32 = Cast<Int32>(this.DCWrapWidth(row) / charWidth);
      let perLine: Int32 = raw < 8 ? 8 : raw;
      let lines: Int32 = (StrLen(row.label) / perLine) + 1;
      return this.DCS(42.0) * Cast<Float>(lines) + this.DCS(8.0);
    };
    return this.DCS(52.0);
  }

  protected func DCMakeText(size: Int32, parent: ref<inkCompoundWidget>) -> ref<inkText> {
    let text: ref<inkText> = new inkText();
    text.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
    text.SetFontStyle(n"Medium");
    text.SetFontSize(size);
    text.SetFitToContent(true);
    text.SetVAlign(inkEVerticalAlign.Top);
    text.Reparent(parent);
    return text;
  }

  protected cb func OnCreate() {
    super.OnCreate();
    this.m_container.SetSize(Vector2(2320.0, 1360.0));
    this.m_hover = -1;

    this.m_header = InGamePopupHeader.Create();
    this.m_header.SetTitle("DRONE COMPANION");
    this.m_header.SetFluffLeft("");
    this.m_header.SetFluffRight("DRONECOMPANION");
    this.m_header.Reparent(this);

    this.m_footer = InGamePopupFooter.Create();
    this.m_footer.SetFluffIcon(n"fluff_triangle2");
    this.m_footer.Reparent(this);

    this.m_content = InGamePopupContent.Create();
    this.m_content.Reparent(this);

    let outer: ref<inkVerticalPanel> = new inkVerticalPanel();
    outer.SetName(n"outer");
    outer.SetMargin(inkMargin(24.0, 8.0, 0.0, 0.0));
    outer.Reparent(this.m_content.GetRootCompoundWidget());

    let tabBar: ref<inkHorizontalPanel> = new inkHorizontalPanel();
    tabBar.SetName(n"tabs");
    tabBar.SetMargin(inkMargin(0.0, 0.0, 0.0, 12.0));
    tabBar.Reparent(outer);
    this.m_tabBar = tabBar;

    let divider: ref<inkRectangle> = new inkRectangle();
    divider.SetSize(1900.0, 2.0);
    divider.SetTintColor(new HDRColor(0.70, 0.70, 0.75, 1.0));
    divider.SetOpacity(0.18);
    divider.SetMargin(inkMargin(0.0, 0.0, 0.0, 20.0));
    divider.Reparent(outer);

    let viewport: ref<inkCanvas> = new inkCanvas();
    viewport.SetSize(this.DCViewWidth() + 24.0, this.DCViewHeight());
    viewport.Reparent(outer);

    let view: ref<inkScrollArea> = new inkScrollArea();
    view.SetSize(Vector2(this.DCViewWidth(), this.DCViewHeight()));
    view.SetUseInternalMask(true);
    view.SetConstrainContentPosition(true);
    view.Reparent(viewport);
    this.m_view = view;

    let list: ref<inkVerticalPanel> = new inkVerticalPanel();
    list.SetName(n"list");
    list.Reparent(view);
    this.m_listPanel = list;

    let track: ref<inkRectangle> = new inkRectangle();
    track.SetSize(6.0, this.DCViewHeight());
    track.SetMargin(inkMargin(this.DCViewWidth() + 12.0, 0.0, 0.0, 0.0));
    track.SetTintColor(new HDRColor(0.70, 0.70, 0.75, 1.0));
    track.SetOpacity(0.10);
    track.Reparent(viewport);
    this.m_scrollTrack = track;

    let thumb: ref<inkRectangle> = new inkRectangle();
    thumb.SetSize(6.0, this.DCViewHeight());
    thumb.SetMargin(inkMargin(this.DCViewWidth() + 12.0, 0.0, 0.0, 0.0));
    thumb.SetTintColor(this.DCAccent());
    thumb.SetOpacity(0.0);
    thumb.Reparent(viewport);
    this.m_scrollThumb = thumb;

    let hint: ref<inkText> = this.DCMakeText(this.DCFontSize(30), outer);
    hint.SetMargin(inkMargin(0.0, 14.0, 0.0, 0.0));
    hint.SetTintColor(new HDRColor(0.70, 0.70, 0.75, 1.0));
    hint.SetOpacity(0.75);
    this.m_hint = hint;

    this.m_outer = outer;
    this.DCRebuildTabs();
    this.DCRebuildRows();
  }

  public func DCSetState(payload: String) -> Void {
    if Equals(payload, this.m_payload) {
      return;
    };
    let tabsBefore: Int32 = ArraySize(this.m_tabs);
    let accentBefore: String = this.m_accentKey;
    let keepId: String = this.DCSelectedId();
    this.m_payload = payload;
    this.DCParse(payload);
    this.DCApplyScale();
    this.DCRestoreSelection(keepId);
    if tabsBefore != ArraySize(this.m_tabs) || NotEquals(accentBefore, this.m_accentKey) {
      this.DCRebuildTabs();
      if IsDefined(this.m_scrollThumb) {
        this.m_scrollThumb.SetTintColor(this.DCAccent());
      };
    };
    this.DCRebuildRows();
  }

  protected func DCParse(payload: String) -> Void {
    ArrayClear(this.m_rows);
    let lines: array<String> = StrSplit(payload, "\n");
    let i: Int32 = 0;
    while i < ArraySize(lines) {
      let f: array<String> = StrSplit(lines[i], "\t", true);
      if ArraySize(f) >= 2 {
        if Equals(f[0], "T") {
          ArrayClear(this.m_tabs);
          let t: Int32 = 1;
          while t < ArraySize(f) {
            ArrayPush(this.m_tabs, f[t]);
            t += 1;
          };
        };
        if Equals(f[0], "A") {
          this.m_tab = StringToInt(f[1], 0);
        };
        if Equals(f[0], "F") {
          this.DCSetFooter(f[1]);
        };
        if Equals(f[0], "H") {
          this.DCApplyHints(lines[i]);
        };
        if Equals(f[0], "S") {
          this.m_scale = MaxF(0.6, MinF(2.0, StringToFloat(f[1], 1.0)));
        };
        if Equals(f[0], "C") && ArraySize(f) >= 4 {
          this.m_accent = new HDRColor(StringToFloat(f[1], 0.88), StringToFloat(f[2], 0.16), StringToFloat(f[3], 0.14), 1.0);
          this.m_accentKey = lines[i];
        };
        if Equals(f[0], "R") && ArraySize(f) >= 4 {
          let row: DCRow;
          row.id = f[1];
          row.kind = f[2];
          row.label = f[3];
          row.value = ArraySize(f) >= 5 ? f[4] : "";
          row.icon = ArraySize(f) >= 6 ? f[5] : "";
          ArrayPush(this.m_rows, row);
        };
      };
      i += 1;
    };
    this.DCClampSelection(1);
  }

  protected func DCApplyScale() -> Void {
    if IsDefined(this.m_hint) {
      this.m_hint.SetFontSize(this.DCFontSize(30));
    };
  }

  protected func DCSelectedId() -> String {
    if this.m_sel < 0 || this.m_sel >= ArraySize(this.m_rows) {
      return "";
    };
    return this.m_rows[this.m_sel].id;
  }

  protected func DCRestoreSelection(id: String) -> Void {
    if StrLen(id) == 0 {
      return;
    };
    let i: Int32 = 0;
    while i < ArraySize(this.m_rows) {
      if Equals(this.m_rows[i].id, id) {
        this.m_sel = i;
        return;
      };
      i += 1;
    };
  }

  protected func DCClampSelection(dir: Int32) -> Void {
    if ArraySize(this.m_rows) == 0 {
      this.m_sel = -1;
      return;
    };
    if this.m_sel < 0 {
      this.m_sel = 0;
    };
    if this.m_sel >= ArraySize(this.m_rows) {
      this.m_sel = ArraySize(this.m_rows) - 1;
    };
    let steps: Int32 = 0;
    while steps <= ArraySize(this.m_rows) {
      if this.DCIsSelectable(this.m_rows[this.m_sel].kind) {
        return;
      };
      this.m_sel += dir;
      if this.m_sel < 0 {
        this.m_sel = ArraySize(this.m_rows) - 1;
      };
      if this.m_sel >= ArraySize(this.m_rows) {
        this.m_sel = 0;
      };
      steps += 1;
    };
    this.m_sel = -1;
  }

  protected func DCRebuildTabs() -> Void {
    if !IsDefined(this.m_tabBar) {
      return;
    };
    this.m_tabBar.RemoveAllChildren();
    ArrayClear(this.m_tabTexts);
    ArrayClear(this.m_tabMarks);
    let i: Int32 = 0;
    while i < ArraySize(this.m_tabs) {
      let cell: ref<inkVerticalPanel> = new inkVerticalPanel();
      cell.SetMargin(inkMargin(0.0, 0.0, 64.0, 0.0));
      cell.Reparent(this.m_tabBar);

      let tab: ref<inkText> = this.DCMakeText(this.DCFontSize(46), cell);
      tab.SetHAlign(inkEHorizontalAlign.Center);
      tab.SetLetterCase(textLetterCase.UpperCase);
      tab.SetInteractive(true);
      tab.SetText(this.m_tabs[i]);
      ArrayPush(this.m_tabTexts, tab);

      let mark: ref<inkRectangle> = new inkRectangle();
      mark.SetSize(this.DCTabMarkWidth(i), 5.0);
      mark.SetHAlign(inkEHorizontalAlign.Center);
      mark.SetMargin(inkMargin(0.0, 8.0, 0.0, 0.0));
      mark.SetTintColor(this.DCAccent());
      mark.Reparent(cell);
      ArrayPush(this.m_tabMarks, mark);

      i += 1;
    };
    this.DCPaintTabs();
  }

  protected func DCTabMarkWidth(index: Int32) -> Float {
    if index < ArraySize(this.m_tabTexts) && IsDefined(this.m_tabTexts[index]) {
      let measured: Float = this.m_tabTexts[index].GetDesiredSize().X;
      if measured > 1.0 {
        return measured + 12.0;
      };
    };
    return Cast<Float>(StrLen(this.m_tabs[index])) * this.DCS(26.0) + 12.0;
  }

  protected func DCPaintTabs() -> Void {
    let i: Int32 = 0;
    while i < ArraySize(this.m_tabTexts) {
      this.m_tabMarks[i].SetSize(this.DCTabMarkWidth(i), 5.0);
      if i == this.m_tab {
        this.m_tabTexts[i].SetTintColor(this.DCAccent());
        this.m_tabTexts[i].SetOpacity(1.0);
        this.m_tabMarks[i].SetOpacity(1.0);
      } else {
        this.m_tabTexts[i].SetTintColor(new HDRColor(0.70, 0.70, 0.75, 1.0));
        this.m_tabTexts[i].SetOpacity(0.55);
        this.m_tabMarks[i].SetOpacity(0.0);
      };
      i += 1;
    };
  }

  protected func DCRebuildRows() -> Void {
    if !IsDefined(this.m_listPanel) {
      return;
    };
    this.m_listPanel.RemoveAllChildren();
    this.m_hover = -1;
    ArrayClear(this.m_rowLabels);
    ArrayClear(this.m_rowValues);
    ArrayClear(this.m_rowMarks);
    ArrayClear(this.m_rowBars);
    ArrayClear(this.m_rowTops);
    this.m_contentHeight = 0.0;

    let i: Int32 = 0;
    while i < ArraySize(this.m_rows) {
      let row: DCRow = this.m_rows[i];
      let height: Float = this.DCRowHeight(row);
      ArrayPush(this.m_rowTops, this.m_contentHeight);
      this.m_contentHeight += height;

      let isHead: Bool = Equals(row.kind, "head");
      let topPad: Float = this.DCS(isHead ? 30.0 : 10.0);

      let canvas: ref<inkCanvas> = new inkCanvas();
      canvas.SetSize(1900.0, height);
      canvas.Reparent(this.m_listPanel);

      let mark: ref<inkRectangle> = new inkRectangle();
      mark.SetSize(1900.0, height);
      mark.SetTintColor(this.DCAccent());
      mark.SetOpacity(0.0);
      mark.Reparent(canvas);
      ArrayPush(this.m_rowMarks, mark);

      let bar: ref<inkRectangle> = new inkRectangle();
      bar.SetSize(6.0, height);
      bar.SetAnchor(inkEAnchor.LeftFillVerticaly);
      bar.SetTintColor(this.DCAccent());
      bar.SetOpacity(0.0);
      bar.Reparent(canvas);
      ArrayPush(this.m_rowBars, bar);

      if isHead {
        let underline: ref<inkRectangle> = new inkRectangle();
        underline.SetSize(1860.0, 2.0);
        underline.SetAnchor(inkEAnchor.BottomFillHorizontaly);
        underline.SetAnchorPoint(new Vector2(0.0, 1.0));
        underline.SetTintColor(this.DCAccent());
        underline.SetOpacity(0.45);
        underline.Reparent(canvas);
      };

      if isHead && i > 0 {
        let divider: ref<inkRectangle> = new inkRectangle();
        divider.SetSize(1860.0, 2.0);
        divider.SetMargin(inkMargin(0.0, 6.0, 0.0, 0.0));
        divider.SetTintColor(new HDRColor(0.70, 0.70, 0.75, 1.0));
        divider.SetOpacity(0.14);
        divider.Reparent(canvas);
      };

      let line: ref<inkHorizontalPanel> = new inkHorizontalPanel();
      line.SetMargin(inkMargin(isHead ? 0.0 : 26.0, topPad, 0.0, 0.0));
      line.Reparent(canvas);

      if isHead && StrLen(row.icon) > 0 {
        let icon: ref<inkImage> = new inkImage();
        icon.SetAtlasResource(ResRef.FromString("dronecompanion\\gui\\dc_icons.inkatlas"));
        icon.SetTexturePart(StringToName(row.icon));
        icon.SetSize(Vector2(this.DCS(52.0), this.DCS(52.0)));
        icon.SetMargin(inkMargin(0.0, 0.0, 16.0, 0.0));
        icon.Reparent(line);
      };

      let label: ref<inkText> = this.DCMakeText(this.DCFontSize(isHead ? 44 : 38), line);
      label.SetInteractive(true);
      if this.DCIsWrapped(row.kind) {
        label.SetWrapping(true, this.DCWrapWidth(row));
      };
      label.SetText(row.label);
      label.RegisterToCallback(n"OnEnter", this, n"OnDCRowEnter");
      label.RegisterToCallback(n"OnLeave", this, n"OnDCRowLeave");
      ArrayPush(this.m_rowLabels, label);

      let value: ref<inkText> = this.DCMakeText(this.DCFontSize(isHead ? 40 : 38), canvas);
      value.SetAnchor(inkEAnchor.TopRight);
      value.SetAnchorPoint(new Vector2(1.0, 0.0));
      value.SetHAlign(inkEHorizontalAlign.Right);
      value.SetMargin(inkMargin(0.0, topPad, 40.0, 0.0));
      value.SetInteractive(true);
      value.SetText(this.DCValueOf(i));
      value.RegisterToCallback(n"OnEnter", this, n"OnDCRowEnter");
      value.RegisterToCallback(n"OnLeave", this, n"OnDCRowLeave");
      ArrayPush(this.m_rowValues, value);

      i += 1;
    };
    this.DCPaintRows();
    this.DCApplyScroll();
  }

  protected func DCValueOf(index: Int32) -> String {
    let row: DCRow = this.m_rows[index];
    if Equals(row.kind, "btn") {
      let text: String = this.DCStripMark(row.value);
      if StrLen(text) == 0 {
        text = "\u{25B8}";
      };
      return "[ " + text + " ]";
    };
    if Equals(row.kind, "toggle") {
      return Equals(row.value, "1") ? "[ ON ]" : "[ OFF ]";
    };
    if Equals(row.kind, "choice") || Equals(row.kind, "slider") {
      if index == this.m_sel {
        return "<  " + row.value + "  >";
      };
      return "   " + row.value + "   ";
    };
    return row.value;
  }

  protected func DCPaintRows() -> Void {
    let i: Int32 = 0;
    while i < ArraySize(this.m_rowLabels) {
      let selected: Bool = i == this.m_sel;
      let tone: Int32 = this.DCValueTone(this.m_rows[i]);
      this.m_rowLabels[i].SetTintColor(this.DCColorOf(this.m_rows[i].kind, selected));
      this.m_rowValues[i].SetText(this.DCValueOf(i));
      if tone == 4 {
        this.m_rowValues[i].SetTintColor(this.DCColorOf(this.m_rows[i].kind, selected));
      } else {
        this.m_rowValues[i].SetTintColor(this.DCToneColor(tone, selected));
      };
      this.m_rowMarks[i].SetOpacity(selected ? 0.16 : (i == this.m_hover ? 0.08 : 0.0));
      this.m_rowBars[i].SetOpacity(selected ? 1.0 : 0.0);
      i += 1;
    };
  }

  protected func DCRowIndexOf(target: wref<inkWidget>) -> Int32 {
    let i: Int32 = 0;
    while i < ArraySize(this.m_rowLabels) {
      if Equals(target, this.m_rowLabels[i]) || Equals(target, this.m_rowValues[i]) {
        return i;
      };
      i += 1;
    };
    return -1;
  }

  protected cb func OnDCRowEnter(evt: ref<inkPointerEvent>) -> Bool {
    let index: Int32 = this.DCRowIndexOf(evt.GetCurrentTarget());
    if index >= 0 && this.DCIsSelectable(this.m_rows[index].kind) {
      this.m_hover = index;
      this.DCPaintRows();
    };
    return false;
  }

  protected cb func OnDCRowLeave(evt: ref<inkPointerEvent>) -> Bool {
    if this.DCRowIndexOf(evt.GetCurrentTarget()) == this.m_hover {
      this.m_hover = -1;
      this.DCPaintRows();
    };
    return false;
  }

  protected func DCApplyScroll() -> Void {
    let viewHeight: Float = this.DCViewHeight();
    if this.m_sel >= 0 && this.m_sel < ArraySize(this.m_rowTops) {
      let top: Float = this.m_rowTops[this.m_sel];
      let height: Float = this.DCRowHeight(this.m_rows[this.m_sel]);
      if top + this.m_scroll < 0.0 {
        this.m_scroll = -top;
      };
      if top + height + this.m_scroll > viewHeight {
        this.m_scroll = viewHeight - top - height;
      };
    };
    let maxScroll: Float = MaxF(0.0, this.m_contentHeight - viewHeight);
    this.m_scroll = MinF(0.0, MaxF(-maxScroll, this.m_scroll));
    this.m_listPanel.SetTranslation(new Vector2(0.0, this.m_scroll));
    this.DCPaintScrollBar(maxScroll);
  }

  protected func DCPaintScrollBar(maxScroll: Float) -> Void {
    if !IsDefined(this.m_scrollThumb) || !IsDefined(this.m_scrollTrack) {
      return;
    };
    if maxScroll <= 0.0 {
      this.m_scrollThumb.SetOpacity(0.0);
      this.m_scrollTrack.SetOpacity(0.0);
      return;
    };
    let viewHeight: Float = this.DCViewHeight();
    let thumbHeight: Float = MaxF(60.0, viewHeight * viewHeight / this.m_contentHeight);
    let travel: Float = viewHeight - thumbHeight;
    let progress: Float = -this.m_scroll / maxScroll;
    this.m_scrollTrack.SetOpacity(0.10);
    this.m_scrollThumb.SetOpacity(0.55);
    this.m_scrollThumb.SetSize(6.0, thumbHeight);
    this.m_scrollThumb.SetMargin(inkMargin(this.DCViewWidth() + 12.0, travel * progress, 0.0, 0.0));
  }

  protected func DCScrollBy(lines: Float) -> Void {
    let maxScroll: Float = MaxF(0.0, this.m_contentHeight - this.DCViewHeight());
    if maxScroll <= 0.0 {
      return;
    };
    this.m_scroll = MinF(0.0, MaxF(-maxScroll, this.m_scroll - lines * this.DCS(52.0) * 3.0));
    this.m_listPanel.SetTranslation(new Vector2(0.0, this.m_scroll));
    this.DCPaintScrollBar(maxScroll);
  }

  protected func DCMove(dir: Int32) -> Void {
    if ArraySize(this.m_rows) == 0 {
      return;
    };
    this.m_sel += dir;
    if this.m_sel < 0 {
      this.m_sel = ArraySize(this.m_rows) - 1;
    };
    if this.m_sel >= ArraySize(this.m_rows) {
      this.m_sel = 0;
    };
    this.DCClampSelection(dir);
    this.DCPaintRows();
    this.DCApplyScroll();
    let id: String = this.DCSelectedId();
    if StrLen(id) > 0 {
      this.DCEmit("sel:" + id);
    };
  }

  protected func DCSwitchTab(dir: Int32) -> Void {
    if ArraySize(this.m_tabs) == 0 {
      return;
    };
    this.m_tab += dir;
    if this.m_tab < 0 {
      this.m_tab = ArraySize(this.m_tabs) - 1;
    };
    if this.m_tab >= ArraySize(this.m_tabs) {
      this.m_tab = 0;
    };
    this.m_sel = 0;
    this.m_scroll = 0.0;
    this.DCPaintTabs();
    this.DCEmit("tab:" + IntToString(this.m_tab));
  }

  protected func DCActivate(suffix: String) -> Void {
    if this.m_sel < 0 || this.m_sel >= ArraySize(this.m_rows) {
      return;
    };
    if StrLen(this.m_rows[this.m_sel].id) == 0 {
      return;
    };
    this.DCEmit(suffix + ":" + this.m_rows[this.m_sel].id);
  }

  protected cb func OnAttach() {
    super.OnAttach();
    this.RegisterToGlobalInputCallback(n"OnPostOnPress", this, n"OnDCInput");
    this.RegisterToGlobalInputCallback(n"OnPostOnAxis", this, n"OnDCWheel");
    this.DCEmit("menu:open");
  }

  protected cb func OnDetach() {
    this.UnregisterFromGlobalInputCallback(n"OnPostOnPress", this, n"OnDCInput");
    this.UnregisterFromGlobalInputCallback(n"OnPostOnAxis", this, n"OnDCWheel");
    this.DCEmit("menu:close");
    super.OnDetach();
  }

  protected cb func OnDCInput(evt: ref<inkPointerEvent>) -> Bool {
    if evt.IsAction(n"popup_navigate_up") {
      this.DCMove(-1);
      return false;
    };
    if evt.IsAction(n"popup_navigate_down") {
      this.DCMove(1);
      return false;
    };
    if evt.IsAction(n"popup_navigate_left") {
      this.DCActivate("dec");
      return false;
    };
    if evt.IsAction(n"popup_navigate_right") {
      this.DCActivate("inc");
      return false;
    };
    if evt.IsAction(n"proceed") {
      this.DCActivate("act");
      return false;
    };
    if evt.IsAction(n"next_menu") {
      this.DCSwitchTab(1);
      return false;
    };
    if evt.IsAction(n"prior_menu") {
      this.DCSwitchTab(-1);
      return false;
    };
    return false;
  }

  protected cb func OnDCWheel(evt: ref<inkPointerEvent>) -> Bool {
    if !evt.IsAction(n"mouse_wheel") {
      return false;
    };
    let axis: Float = evt.GetAxisData();
    if axis > 0.0 || axis < 0.0 {
      this.DCScrollBy(axis);
    };
    return false;
  }

  protected cb func OnGlobalReleaseInput(evt: ref<inkPointerEvent>) -> Bool {
    if evt.IsAction(n"mouse_left") && !evt.IsHandled() {
      let target: wref<inkWidget> = evt.GetTarget();
      let i: Int32 = 0;
      while IsDefined(target) && i < ArraySize(this.m_rowLabels) {
        if Equals(target, this.m_rowLabels[i]) || Equals(target, this.m_rowValues[i]) {
          if this.DCIsSelectable(this.m_rows[i].kind) {
            this.m_sel = i;
            this.DCPaintRows();
            this.DCActivate("act");
          };
          i = ArraySize(this.m_rowLabels);
        } else {
          i += 1;
        };
      };
      let t: Int32 = 0;
      while IsDefined(target) && t < ArraySize(this.m_tabTexts) {
        if Equals(target, this.m_tabTexts[t]) {
          this.m_tab = t;
          this.m_sel = 0;
          this.m_scroll = 0.0;
          this.DCPaintTabs();
          this.DCEmit("tab:" + IntToString(this.m_tab));
          t = ArraySize(this.m_tabTexts);
        } else {
          t += 1;
        };
      };
    };
    return super.OnGlobalReleaseInput(evt);
  }

  public func DCSetFooter(text: String) -> Void {
    if IsDefined(this.m_hint) {
      this.m_hint.SetText(text);
    };
  }

  public static func Show(player: ref<PlayerPuppet>, payload: String) -> ref<DCMenuPopup> {
    let popup: ref<DCMenuPopup> = new DCMenuPopup();
    popup.DCBind(player);
    popup.DCSetState(payload);
    GameInstance.GetUISystem(player.GetGame()).QueueEvent(ShowCustomPopupEvent.Create(popup));
    return popup;
  }
}

@addField(PlayerPuppet)
let m_dcPopup: ref<DCMenuPopup>;

@addMethod(PlayerPuppet)
public func DCEmit(action: String) -> Bool {
  return true;
}

@addMethod(PlayerPuppet)
public func DCPushState(payload: String) -> Bool {
  if IsDefined(this.m_dcPopup) && this.m_dcPopup.DCIsOpen() {
    this.m_dcPopup.DCSetState(payload);
    return true;
  };
  return false;
}

@addMethod(PlayerPuppet)
public func DCToggleMenu(payload: String) -> Bool {
  if IsDefined(this.m_dcPopup) && this.m_dcPopup.DCIsOpen() {
    this.m_dcPopup.Close();
    this.m_dcPopup = null;
    return false;
  };
  if GameInstance.GetSystemRequestsHandler().IsPreGame() {
    return false;
  };
  this.m_dcPopup = null;
  this.m_dcPopup = DCMenuPopup.Show(this, payload);
  return true;
}
