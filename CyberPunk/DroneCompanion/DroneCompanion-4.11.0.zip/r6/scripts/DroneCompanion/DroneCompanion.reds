module DroneCompanion
import Codeware.Localization.*

private static func DC_IsCompanionDrone(obj: wref<GameObject>) -> Bool {
  let sp: wref<ScriptedPuppet> = obj as ScriptedPuppet;
  if !IsDefined(sp) {
    return false;
  };
  let ses = GameInstance.GetStatusEffectSystem(sp.GetGame());
  return IsDefined(ses) && ses.HasStatusEffect(sp.GetEntityID(), t"DroneCompanion.CompanionSE");
}

private static func DC_IsPassive(obj: wref<GameObject>) -> Bool {
  let sp: wref<ScriptedPuppet> = obj as ScriptedPuppet;
  if !IsDefined(sp) {
    return false;
  };
  let ses = GameInstance.GetStatusEffectSystem(sp.GetGame());
  return IsDefined(ses) && ses.HasStatusEffect(sp.GetEntityID(), t"DroneCompanion.PassiveSE");
}

private static func DC_IsRival(obj: wref<GameObject>) -> Bool {
  let sp: wref<ScriptedPuppet> = obj as ScriptedPuppet;
  if !IsDefined(sp) {
    return false;
  };
  let ses = GameInstance.GetStatusEffectSystem(sp.GetGame());
  return IsDefined(ses) && ses.HasStatusEffect(sp.GetEntityID(), t"DroneCompanion.RivalSE");
}

private static func DC_IsArena(obj: wref<GameObject>) -> Bool {
  let sp: wref<ScriptedPuppet> = obj as ScriptedPuppet;
  if !IsDefined(sp) {
    return false;
  };
  let ses = GameInstance.GetStatusEffectSystem(sp.GetGame());
  return IsDefined(ses) && ses.HasStatusEffect(sp.GetEntityID(), t"DroneCompanion.ArenaSE");
}

@wrapMethod(ScriptedPuppet)
public final func IsQuickHackAble() -> Bool {
  if DC_IsCompanionDrone(this) {
    return true;
  };
  return wrappedMethod();
}

@wrapMethod(ScriptedPuppetPS)
public final const func IsQuickHacksExposed() -> Bool {
  if DC_IsCompanionDrone(this.GetOwnerEntity() as ScriptedPuppet) {
    return true;
  };
  return wrappedMethod();
}

private static func DC_HackIDs() -> array<TweakDBID> {
  return [
    t"DroneCompanion.HackRepair",
    t"DroneCompanion.HackHold",
    t"DroneCompanion.HackDismiss",
    t"DroneCompanion.HackDetonate",
    t"DroneCompanion.HackOverclock",
    t"DroneCompanion.HackFortify",
    t"DroneCompanion.HackOctant",
    t"DroneCompanion.HackWyvern",
    t"DroneCompanion.HackGriffin",
    t"DroneCompanion.HackBombus",
    t"DroneCompanion.HackMinotaur"
  ];
}

private static func DC_CooldownIDs() -> array<TweakDBID> {
  return [
    t"DroneCompanion.HackRepairCd",
    t"DroneCompanion.HackHoldCd",
    t"DroneCompanion.HackDismissCd",
    t"DroneCompanion.HackDetonateCd",
    t"DroneCompanion.HackOverclockCd",
    t"DroneCompanion.HackFortifyCd",
    t"DroneCompanion.HackOctantCd",
    t"DroneCompanion.HackWyvernCd",
    t"DroneCompanion.HackGriffinCd",
    t"DroneCompanion.HackBombusCd",
    t"DroneCompanion.HackMinotaurCd"
  ];
}

private static func DC_CooldownFor(id: TweakDBID) -> TweakDBID {
  let ids: array<TweakDBID> = DC_HackIDs();
  let cds: array<TweakDBID> = DC_CooldownIDs();
  let i: Int32 = 0;
  while i < ArraySize(ids) {
    if ids[i] == id {
      return cds[i];
    };
    i += 1;
  };
  return TDBID.None();
}

@wrapMethod(ScriptedPuppet)
private final func TranslateChoicesIntoQuickSlotCommands(const choices: script_ref<array<ref<PuppetAction>>>, commands: script_ref<array<ref<QuickhackData>>>) -> Void {
  wrappedMethod(choices, commands);
  if !DC_IsCompanionDrone(this) {
    return;
  };
  let ses = GameInstance.GetStatusEffectSystem(this.GetGame());
  if !IsDefined(ses) {
    return;
  };
  let i: Int32 = 0;
  while i < ArraySize(Deref(commands)) {
    let cmd: ref<QuickhackData> = Deref(commands)[i];
    let action: ref<PuppetAction> = cmd.m_action as PuppetAction;
    if IsDefined(action) {
      let cooldown: TweakDBID = DC_CooldownFor(action.GetObjectActionID());
      if TDBID.IsValid(cooldown) && ses.HasStatusEffect(this.GetEntityID(), cooldown) {
        cmd.m_isLocked = true;
        cmd.m_inactiveReason = "Mod-DroneCompanion-Hack-Cooling";
        cmd.m_actionState = EActionInactivityReson.Locked;
      };
    };
    i += 1;
  };
}

private static func DC_ListHasAction(list: script_ref<array<PlayerQuickhackData>>, id: TweakDBID) -> Bool {
  let i: Int32 = 0;
  while i < ArraySize(Deref(list)) {
    if IsDefined(Deref(list)[i].actionRecord) && Deref(list)[i].actionRecord.GetID() == id {
      return true;
    };
    i += 1;
  };
  return false;
}

@wrapMethod(RPGManager)
public final static func GetPlayerQuickHackListWithQuality(player: wref<PlayerPuppet>) -> array<PlayerQuickhackData> {
  let list: array<PlayerQuickhackData> = wrappedMethod(player);
  if !IsDefined(player) {
    return list;
  };
  let ids: array<TweakDBID> = DC_HackIDs();
  let added: Int32 = 0;
  let data: PlayerQuickhackData;
  let record: wref<ObjectAction_Record>;
  let i: Int32 = 0;
  while i < ArraySize(ids) {
    record = TweakDBInterface.GetObjectActionRecord(ids[i]);
    if IsDefined(record) && !DC_ListHasAction(list, ids[i]) {
      data.actionRecord = record;
      data.quality = 4;
      ArrayPush(list, data);
      added += 1;
    };
    i += 1;
  };
  if added > 0 {
    PlayerPuppet.ChacheQuickHackList(player, list);
  };
  return list;
}

@wrapMethod(GameObject)
public final func FindAndRewardKiller(killType: gameKillType, opt instigator: wref<GameObject>) -> Void {
  let arenaKill: Bool = DC_IsCompanionDrone(this) && DC_IsArena(this);
  if DC_IsCompanionDrone(instigator) {
    let player = GetPlayer(this.GetGame());
    if IsDefined(player) {
      player.DCKill(instigator);
      if !arenaKill {
        instigator = player;
      };
    };
  };
  if !arenaKill {
    let i: Int32 = 0;
    while i < ArraySize(this.m_receivedDamageHistory) {
      if DC_IsCompanionDrone(this.m_receivedDamageHistory[i].source) {
        this.m_receivedDamageHistory[i].source = GetPlayer(this.GetGame());
      };
      i += 1;
    };
  };
  wrappedMethod(killType, instigator);
}

@wrapMethod(DamageSystem)
private final func Process(hitEvent: ref<gameHitEvent>, cache: ref<CacheData>) -> Void {
  let instigator: wref<ScriptedPuppet> = hitEvent.attackData.GetInstigator() as ScriptedPuppet;
  let target: wref<ScriptedPuppet> = hitEvent.target as ScriptedPuppet;
  if IsDefined(instigator) && IsDefined(target) {
    let instOurs: Bool = DC_IsCompanionDrone(instigator);
    let targOurs: Bool = DC_IsCompanionDrone(target);
    if DC_IsRival(instigator) && target.IsPlayer() {
      return;
    };
    if instOurs && targOurs && DC_IsArena(instigator) && DC_IsArena(target) {
      wrappedMethod(hitEvent, cache);
      return;
    };
    if (instOurs && targOurs) || (instigator.IsPlayer() && targOurs) || (instOurs && target.IsPlayer()) {
      return;
    };
  };
  wrappedMethod(hitEvent, cache);
}

@wrapMethod(ReactionManagerComponent)
protected cb func OnDetectedEvent(evt: ref<OnDetectedEvent>) -> Bool {
  if IsDefined(evt) && IsDefined(evt.target) && evt.isVisible && DC_IsCompanionDrone(evt.target) && !DC_IsPassive(evt.target) {
    let owner: wref<ScriptedPuppet> = this.GetOwnerPuppet();
    if IsDefined(owner) && (!DC_IsCompanionDrone(owner)
      || (DC_IsArena(owner) && DC_IsArena(evt.target))) {
      TargetTrackingExtension.InjectThreat(owner, evt.target);
    };
  };
  return wrappedMethod(evt);
}

@wrapMethod(SenseComponent)
public final static func ShouldIgnoreIfPlayerCompanion(owner: wref<Entity>, target: wref<Entity>) -> Bool {
  if DC_IsCompanionDrone(target as GameObject) && !DC_IsPassive(target as GameObject) {
    return false;
  };
  return wrappedMethod(owner, target);
}

@wrapMethod(PlayerPuppet)
private final func UpdateLookAtObject(target: ref<GameObject>) -> Void {
  wrappedMethod(target);
  if IsDefined(target) && DC_IsCompanionDrone(target) {
    this.m_isAimingAtFriendly = false;
  };
}

@wrapMethod(NpcNameplateGameController)
private final func HelperCheckDistance(entity: ref<Entity>) -> Bool {
  if IsDefined(entity) && DC_IsCompanionDrone(entity as GameObject) {
    return true;
  };
  return wrappedMethod(entity);
}

@wrapMethod(NpcNameplateGameController)
protected cb func OnNameplateDataChanged(value: Variant) -> Bool {
  wrappedMethod(value);
  let data: NPCNextToTheCrosshair = FromVariant<NPCNextToTheCrosshair>(value);
  if IsDefined(data.npc) && DC_IsCompanionDrone(data.npc) {
    this.m_visualController.UpdateNPCNamesEnabled(true);
  };
}

@wrapMethod(NameplateVisualsLogicController)
public final func SetVisualData(puppet: ref<GameObject>, const incomingData: script_ref<NPCNextToTheCrosshair>, opt isNewNpc: Bool) -> Void {
  wrappedMethod(puppet, incomingData, isNewNpc);
  if IsDefined(puppet) && DC_IsCompanionDrone(puppet) {
    this.UpdateHealthbarColor(false);
    inkWidgetRef.SetVisible(this.m_healthbarWidget, true);
  };
}

@wrapMethod(NameplateVisualsLogicController)
public final func UpdateHealthbarColor(isHostile: Bool) -> Void {
  if IsDefined(this.m_cachedPuppet) && DC_IsCompanionDrone(this.m_cachedPuppet) {
    inkWidgetRef.SetState(this.m_healthbarWidget, n"Friendly");
    inkWidgetRef.SetState(this.m_healthBarFull, n"Friendly");
    inkWidgetRef.SetState(this.m_healthBarFrame, n"Friendly");
    return;
  };
  wrappedMethod(isHostile);
}

@wrapMethod(DamageDigitsGameController)
protected cb func OnDamageAdded(value: Variant) -> Bool {
  if !IsDefined(this.m_realOwner) {
    return wrappedMethod(value);
  };
  let list: array<DamageInfo> = FromVariant<array<DamageInfo>>(value);
  let changed: Bool = false;
  let i: Int32 = 0;
  while i < ArraySize(list) {
    if DC_IsCompanionDrone(list[i].instigator) {
      let info: DamageInfo = list[i];
      info.instigator = this.m_realOwner;
      list[i] = info;
      changed = true;
    };
    i += 1;
  };
  if changed {
    return wrappedMethod(ToVariant(list));
  };
  return wrappedMethod(value);
}

