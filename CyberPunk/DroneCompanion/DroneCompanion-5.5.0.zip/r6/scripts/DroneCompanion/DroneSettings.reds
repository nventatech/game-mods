module DroneCompanion
import Codeware.Localization.*

enum DCLang {
  Auto = 0,
  EN = 1,
  PT = 2,
  ES = 3,
  FR = 4,
  DE = 5,
  RU = 6,
  ZH = 7,
  PL = 8
}

enum DCPadMod {
  None = 0,
  LB = 1,
  RB = 2
}

enum DCPadBtn {
  None = 0,
  A = 1,
  X = 2,
  Y = 3,
  B = 4
}

enum DCHotkey {
  None = 0,
  F2 = 1,
  F6 = 2,
  F7 = 3,
  F8 = 4,
  F10 = 5,
  F11 = 6,
  Insert = 7,
  F1 = 8,
  F3 = 9,
  F4 = 10,
  F5 = 11,
  F9 = 12,
  F12 = 13,
  Num1 = 14,
  Num2 = 15,
  Num3 = 16
}

public class DroneCompanionSettings extends ScriptableSystem {

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Toggle")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Mod")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Mod-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"LB\", \"RB\"")
  public let toggleMod: DCPadMod = DCPadMod.LB;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Toggle")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Btn")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Btn-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"A\", \"X\", \"Y\", \"B\"")
  public let toggleBtn: DCPadBtn = DCPadBtn.A;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Toggle")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Key")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Key-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"F2\", \"F6\", \"F7\", \"F8\", \"F10\", \"F11\", \"Insert\", \"F1\", \"F3\", \"F4\", \"F5\", \"F9\", \"F12\", \"Numpad 1\", \"Numpad 2\", \"Numpad 3\"")
  public let toggleKey: DCHotkey = DCHotkey.F6;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Cycle")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Mod")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Mod-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"LB\", \"RB\"")
  public let cycleMod: DCPadMod = DCPadMod.RB;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Cycle")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Btn")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Btn-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"A\", \"X\", \"Y\", \"B\"")
  public let cycleBtn: DCPadBtn = DCPadBtn.A;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Cycle")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Key")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Key-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"F2\", \"F6\", \"F7\", \"F8\", \"F10\", \"F11\", \"Insert\", \"F1\", \"F3\", \"F4\", \"F5\", \"F9\", \"F12\", \"Numpad 1\", \"Numpad 2\", \"Numpad 3\"")
  public let cycleKey: DCHotkey = DCHotkey.F7;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Menu")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Mod")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Mod-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"LB\", \"RB\"")
  public let menuMod: DCPadMod = DCPadMod.LB;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Menu")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Btn")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Btn-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"A\", \"X\", \"Y\", \"B\"")
  public let menuBtn: DCPadBtn = DCPadBtn.X;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Menu")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Key")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Key-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"F2\", \"F6\", \"F7\", \"F8\", \"F10\", \"F11\", \"Insert\", \"F1\", \"F3\", \"F4\", \"F5\", \"F9\", \"F12\", \"Numpad 1\", \"Numpad 2\", \"Numpad 3\"")
  public let menuKey: DCHotkey = DCHotkey.F8;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Command")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Mod")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Mod-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"LB\", \"RB\"")
  public let commandMod: DCPadMod = DCPadMod.LB;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Command")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Btn")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Btn-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"A\", \"X\", \"Y\", \"B\"")
  public let commandBtn: DCPadBtn = DCPadBtn.B;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Command")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Key")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Key-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"F2\", \"F6\", \"F7\", \"F8\", \"F10\", \"F11\", \"Insert\", \"F1\", \"F3\", \"F4\", \"F5\", \"F9\", \"F12\", \"Numpad 1\", \"Numpad 2\", \"Numpad 3\"")
  public let commandKey: DCHotkey = DCHotkey.F10;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Preset1")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Mod")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Mod-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"LB\", \"RB\"")
  public let preset1Mod: DCPadMod = DCPadMod.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Preset1")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Btn")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Btn-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"A\", \"X\", \"Y\", \"B\"")
  public let preset1Btn: DCPadBtn = DCPadBtn.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Preset1")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Key")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Key-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"F2\", \"F6\", \"F7\", \"F8\", \"F10\", \"F11\", \"Insert\", \"F1\", \"F3\", \"F4\", \"F5\", \"F9\", \"F12\", \"Numpad 1\", \"Numpad 2\", \"Numpad 3\"")
  public let preset1Key: DCHotkey = DCHotkey.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Preset2")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Mod")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Mod-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"LB\", \"RB\"")
  public let preset2Mod: DCPadMod = DCPadMod.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Preset2")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Btn")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Btn-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"A\", \"X\", \"Y\", \"B\"")
  public let preset2Btn: DCPadBtn = DCPadBtn.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Preset2")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Key")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Key-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"F2\", \"F6\", \"F7\", \"F8\", \"F10\", \"F11\", \"Insert\", \"F1\", \"F3\", \"F4\", \"F5\", \"F9\", \"F12\", \"Numpad 1\", \"Numpad 2\", \"Numpad 3\"")
  public let preset2Key: DCHotkey = DCHotkey.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Preset3")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Mod")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Mod-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"LB\", \"RB\"")
  public let preset3Mod: DCPadMod = DCPadMod.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Preset3")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Btn")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Btn-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"A\", \"X\", \"Y\", \"B\"")
  public let preset3Btn: DCPadBtn = DCPadBtn.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Preset3")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Key")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Key-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"F2\", \"F6\", \"F7\", \"F8\", \"F10\", \"F11\", \"Insert\", \"F1\", \"F3\", \"F4\", \"F5\", \"F9\", \"F12\", \"Numpad 1\", \"Numpad 2\", \"Numpad 3\"")
  public let preset3Key: DCHotkey = DCHotkey.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Holster")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Mod")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Mod-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"LB\", \"RB\"")
  public let holsterMod: DCPadMod = DCPadMod.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Holster")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Btn")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Btn-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"A\", \"X\", \"Y\", \"B\"")
  public let holsterBtn: DCPadBtn = DCPadBtn.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Holster")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Key")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Key-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"F2\", \"F6\", \"F7\", \"F8\", \"F10\", \"F11\", \"Insert\", \"F1\", \"F3\", \"F4\", \"F5\", \"F9\", \"F12\", \"Numpad 1\", \"Numpad 2\", \"Numpad 3\"")
  public let holsterKey: DCHotkey = DCHotkey.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Preset4")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Mod")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Mod-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"LB\", \"RB\"")
  public let preset4Mod: DCPadMod = DCPadMod.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Preset4")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Btn")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Btn-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"A\", \"X\", \"Y\", \"B\"")
  public let preset4Btn: DCPadBtn = DCPadBtn.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Preset4")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Key")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Key-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"F2\", \"F6\", \"F7\", \"F8\", \"F10\", \"F11\", \"Insert\", \"F1\", \"F3\", \"F4\", \"F5\", \"F9\", \"F12\", \"Numpad 1\", \"Numpad 2\", \"Numpad 3\"")
  public let preset4Key: DCHotkey = DCHotkey.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Preset5")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Mod")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Mod-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"LB\", \"RB\"")
  public let preset5Mod: DCPadMod = DCPadMod.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Preset5")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Btn")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Btn-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"A\", \"X\", \"Y\", \"B\"")
  public let preset5Btn: DCPadBtn = DCPadBtn.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Preset5")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Key")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Key-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"F2\", \"F6\", \"F7\", \"F8\", \"F10\", \"F11\", \"Insert\", \"F1\", \"F3\", \"F4\", \"F5\", \"F9\", \"F12\", \"Numpad 1\", \"Numpad 2\", \"Numpad 3\"")
  public let preset5Key: DCHotkey = DCHotkey.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-StanceAll")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Mod")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Mod-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"LB\", \"RB\"")
  public let stanceallMod: DCPadMod = DCPadMod.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-StanceAll")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Btn")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Btn-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"A\", \"X\", \"Y\", \"B\"")
  public let stanceallBtn: DCPadBtn = DCPadBtn.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-StanceAll")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Key")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Key-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"F2\", \"F6\", \"F7\", \"F8\", \"F10\", \"F11\", \"Insert\", \"F1\", \"F3\", \"F4\", \"F5\", \"F9\", \"F12\", \"Numpad 1\", \"Numpad 2\", \"Numpad 3\"")
  public let stanceallKey: DCHotkey = DCHotkey.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Hijack")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Mod")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Mod-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"LB\", \"RB\"")
  public let hijackMod: DCPadMod = DCPadMod.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Hijack")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Btn")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Btn-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"A\", \"X\", \"Y\", \"B\"")
  public let hijackBtn: DCPadBtn = DCPadBtn.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Hijack")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Key")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Key-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"F2\", \"F6\", \"F7\", \"F8\", \"F10\", \"F11\", \"Insert\", \"F1\", \"F3\", \"F4\", \"F5\", \"F9\", \"F12\", \"Numpad 1\", \"Numpad 2\", \"Numpad 3\"")
  public let hijackKey: DCHotkey = DCHotkey.None;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Acquisition")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-L-immersive")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Immersive-Desc")
  public let immersive: Bool = true;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Acquisition")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-L-rigger")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-L-rigger_hint")
  public let rigger: Bool = true;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Language")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Lang")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Lang-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"Auto\", \"English\", \"Português (Brasil)\", \"Español\", \"Français\", \"Deutsch\", \"Русский\", \"简体中文\", \"Polski\"")
  public let language: DCLang = DCLang.Auto;

  public func LangCode() -> String {
    switch this.language {
      case DCLang.EN: return "en-us";
      case DCLang.PT: return "pt-br";
      case DCLang.ES: return "es-es";
      case DCLang.FR: return "fr-fr";
      case DCLang.DE: return "de-de";
      case DCLang.RU: return "ru-ru";
      case DCLang.ZH: return "zh-cn";
      case DCLang.PL: return "pl-pl";
      default: return "auto";
    };
  }

  public func SetLangCode(code: String) -> Void {
    if Equals(code, "en-us") { this.language = DCLang.EN; }
    else if Equals(code, "pt-br") { this.language = DCLang.PT; }
    else if Equals(code, "es-es") { this.language = DCLang.ES; }
    else if Equals(code, "fr-fr") { this.language = DCLang.FR; }
    else if Equals(code, "de-de") { this.language = DCLang.DE; }
    else if Equals(code, "ru-ru") { this.language = DCLang.RU; }
    else if Equals(code, "zh-cn") { this.language = DCLang.ZH; }
    else if Equals(code, "pl-pl") { this.language = DCLang.PL; }
    else { this.language = DCLang.Auto; };
  }

  public func RefreshTranslations() -> Void {
    GameInstance.GetScriptableSystemsContainer(this.GetGameInstance()).QueueRequest(UpdateTranslationsRequest.Create(true));
  }

  public func OnModSettingsChange() -> Void {
    this.RefreshTranslations();
  }

  public static func Get(game: GameInstance) -> ref<DroneCompanionSettings> {
    return GameInstance.GetScriptableSystemsContainer(game).Get(n"DroneCompanion.DroneCompanionSettings") as DroneCompanionSettings;
  }

  public func KeyOf(hotkey: DCHotkey) -> EInputKey {
    switch hotkey {
      case DCHotkey.F2: return EInputKey.IK_F2;
      case DCHotkey.F6: return EInputKey.IK_F6;
      case DCHotkey.F7: return EInputKey.IK_F7;
      case DCHotkey.F8: return EInputKey.IK_F8;
      case DCHotkey.F10: return EInputKey.IK_F10;
      case DCHotkey.F11: return EInputKey.IK_F11;
      case DCHotkey.Insert: return EInputKey.IK_Insert;
      case DCHotkey.F1: return EInputKey.IK_F1;
      case DCHotkey.F3: return EInputKey.IK_F3;
      case DCHotkey.F4: return EInputKey.IK_F4;
      case DCHotkey.F5: return EInputKey.IK_F5;
      case DCHotkey.F9: return EInputKey.IK_F9;
      case DCHotkey.F12: return EInputKey.IK_F12;
      case DCHotkey.Num1: return EInputKey.IK_NumPad1;
      case DCHotkey.Num2: return EInputKey.IK_NumPad2;
      case DCHotkey.Num3: return EInputKey.IK_NumPad3;
      default: return EInputKey.IK_None;
    };
  }

  public func Encode() -> String {
    return ToString(EnumInt(this.toggleMod)) + ":" + ToString(EnumInt(this.toggleBtn)) + ":" + ToString(EnumInt(this.toggleKey))
      + "," + ToString(EnumInt(this.cycleMod)) + ":" + ToString(EnumInt(this.cycleBtn)) + ":" + ToString(EnumInt(this.cycleKey))
      + "," + ToString(EnumInt(this.menuMod)) + ":" + ToString(EnumInt(this.menuBtn)) + ":" + ToString(EnumInt(this.menuKey))
      + "," + ToString(EnumInt(this.commandMod)) + ":" + ToString(EnumInt(this.commandBtn)) + ":" + ToString(EnumInt(this.commandKey))
      + "," + ToString(EnumInt(this.preset1Mod)) + ":" + ToString(EnumInt(this.preset1Btn)) + ":" + ToString(EnumInt(this.preset1Key))
      + "," + ToString(EnumInt(this.preset2Mod)) + ":" + ToString(EnumInt(this.preset2Btn)) + ":" + ToString(EnumInt(this.preset2Key))
      + "," + ToString(EnumInt(this.preset3Mod)) + ":" + ToString(EnumInt(this.preset3Btn)) + ":" + ToString(EnumInt(this.preset3Key))
      + "," + ToString(EnumInt(this.holsterMod)) + ":" + ToString(EnumInt(this.holsterBtn)) + ":" + ToString(EnumInt(this.holsterKey))
      + "," + ToString(EnumInt(this.preset4Mod)) + ":" + ToString(EnumInt(this.preset4Btn)) + ":" + ToString(EnumInt(this.preset4Key))
      + "," + ToString(EnumInt(this.preset5Mod)) + ":" + ToString(EnumInt(this.preset5Btn)) + ":" + ToString(EnumInt(this.preset5Key))
      + "," + ToString(EnumInt(this.stanceallMod)) + ":" + ToString(EnumInt(this.stanceallBtn)) + ":" + ToString(EnumInt(this.stanceallKey))
      + "," + ToString(EnumInt(this.hijackMod)) + ":" + ToString(EnumInt(this.hijackBtn)) + ":" + ToString(EnumInt(this.hijackKey));
  }

  @if(ModuleExists("ModSettingsModule"))
  private func OnAttach() -> Void {
    ModSettings.RegisterListenerToClass(this);
  }

  @if(!ModuleExists("ModSettingsModule"))
  private func OnAttach() -> Void {}

  @if(ModuleExists("ModSettingsModule"))
  private func OnDetach() -> Void {
    ModSettings.UnregisterListenerToClass(this);
  }

  @if(!ModuleExists("ModSettingsModule"))
  private func OnDetach() -> Void {}
}

@addField(PlayerPuppet)
let m_dcInBlockedMenu: Bool;

@wrapMethod(PauseMenuBackgroundGameController)
protected cb func OnInitialize() -> Bool {
  let player: ref<PlayerPuppet> = this.GetPlayerControlledObject() as PlayerPuppet;
  if IsDefined(player) {
    player.m_dcInBlockedMenu = true;
  };
  return wrappedMethod();
}

@wrapMethod(PauseMenuBackgroundGameController)
protected cb func OnUninitialize() -> Bool {
  let player: ref<PlayerPuppet> = this.GetPlayerControlledObject() as PlayerPuppet;
  if IsDefined(player) {
    player.m_dcInBlockedMenu = false;
  };
  return wrappedMethod();
}

@wrapMethod(DeathMenuGameController)
protected cb func OnInitialize() -> Bool {
  let player: ref<PlayerPuppet> = this.GetPlayerControlledObject() as PlayerPuppet;
  if IsDefined(player) {
    player.m_dcInBlockedMenu = true;
  };
  return wrappedMethod();
}

@wrapMethod(DeathMenuGameController)
protected cb func OnUninitialize() -> Bool {
  let player: ref<PlayerPuppet> = this.GetPlayerControlledObject() as PlayerPuppet;
  if IsDefined(player) {
    player.m_dcInBlockedMenu = false;
  };
  return wrappedMethod();
}

@wrapMethod(PlayerPuppet)
protected cb func OnGameAttached() -> Bool {
  let result: Bool = wrappedMethod();
  GameInstance.GetCallbackSystem().RegisterCallback(n"Input/Key", this, n"OnDCKeyInput")
    .SetLifetime(CallbackLifetime.Session);
  return result;
}

@wrapMethod(PlayerPuppet)
protected cb func OnDetach() -> Bool {
  GameInstance.GetCallbackSystem().UnregisterCallback(n"Input/Key", this, n"OnDCKeyInput");
  return wrappedMethod();
}

@addMethod(PlayerPuppet)
protected cb func OnDCKeyInput(event: ref<KeyInputEvent>) {
  if !Equals(event.GetAction(), EInputAction.IACT_Press) || this.m_dcInBlockedMenu {
    return;
  };
  let settings: ref<DroneCompanionSettings> = DroneCompanionSettings.Get(this.GetGame());
  if !IsDefined(settings) {
    return;
  };
  let key: EInputKey = event.GetKey();
  if Equals(key, EInputKey.IK_None) {
    return;
  };
  if VehicleComponent.IsMountedToVehicle(this.GetGame(), this) {
    if Equals(key, EInputKey.IK_G) {
      this.DCKeyCombo("chdrive");
      return;
    };
    if Equals(key, EInputKey.IK_Q) {
      this.DCKeyCombo("chcam");
      return;
    };
  };
  if Equals(key, settings.KeyOf(settings.toggleKey)) {
    this.DCKeyCombo("toggle");
    return;
  };
  if Equals(key, settings.KeyOf(settings.cycleKey)) {
    this.DCKeyCombo("cycle");
    return;
  };
  if Equals(key, settings.KeyOf(settings.menuKey)) {
    this.DCKeyCombo("menu");
    return;
  };
  if Equals(key, settings.KeyOf(settings.commandKey)) {
    this.DCKeyCombo("command");
    return;
  };
  if Equals(key, settings.KeyOf(settings.preset1Key)) {
    this.DCKeyCombo("preset1");
    return;
  };
  if Equals(key, settings.KeyOf(settings.preset2Key)) {
    this.DCKeyCombo("preset2");
    return;
  };
  if Equals(key, settings.KeyOf(settings.preset3Key)) {
    this.DCKeyCombo("preset3");
    return;
  };
  if Equals(key, settings.KeyOf(settings.holsterKey)) {
    this.DCKeyCombo("holster");
    return;
  };
  if Equals(key, settings.KeyOf(settings.preset4Key)) {
    this.DCKeyCombo("preset4");
    return;
  };
  if Equals(key, settings.KeyOf(settings.preset5Key)) {
    this.DCKeyCombo("preset5");
    return;
  };
  if Equals(key, settings.KeyOf(settings.stanceallKey)) {
    this.DCKeyCombo("stanceall");
    return;
  };
  if Equals(key, settings.KeyOf(settings.hijackKey)) {
    this.DCKeyCombo("hijack");
  };
}

@addMethod(PlayerPuppet)
public func DCKeyCombo(id: String) -> Void {}

@addMethod(PlayerPuppet)
public func DCGetBinds() -> String {
  let settings: ref<DroneCompanionSettings> = DroneCompanionSettings.Get(this.GetGame());
  return IsDefined(settings) ? settings.Encode() : "";
}

@addMethod(PlayerPuppet)
public func DCGetAcquisition() -> String {
  let settings: ref<DroneCompanionSettings> = DroneCompanionSettings.Get(this.GetGame());
  if !IsDefined(settings) {
    return "";
  };
  return (settings.immersive ? "1" : "0") + ":" + (settings.rigger ? "1" : "0");
}

@addMethod(PlayerPuppet)
public func DCGetLanguage() -> String {
  let settings: ref<DroneCompanionSettings> = DroneCompanionSettings.Get(this.GetGame());
  return IsDefined(settings) ? settings.LangCode() : "";
}

@addMethod(PlayerPuppet)
public func DCSetLanguage(code: String) -> Void {
  let settings: ref<DroneCompanionSettings> = DroneCompanionSettings.Get(this.GetGame());
  if IsDefined(settings) {
    settings.SetLangCode(code);
    settings.RefreshTranslations();
  };
}

@addMethod(PlayerPuppet)
public func DCGetTextEN(key: String) -> String {
  let package: ref<ModLocalizationPackage> = new DroneCompanionLocEN();
  let values: array<wref<IScriptable>> = package.GetEntriesList(EntryType.Interface);
  for value in values {
    let entry: wref<LocalizationEntry> = value as LocalizationEntry;
    if Equals(entry.GetKey(), key) {
      return entry.GetVariant(PlayerGender.Default);
    };
  };
  return "";
}

@addMethod(PlayerPuppet)
public func DCSetAcquisition(immersive: Bool, rigger: Bool) -> Void {
  let settings: ref<DroneCompanionSettings> = DroneCompanionSettings.Get(this.GetGame());
  if IsDefined(settings) {
    settings.immersive = immersive;
    settings.rigger = rigger;
  };
}
