module DroneCompanion

public class DCHud extends IScriptable {
  private let m_panel: wref<inkVerticalPanel>;
  private let m_rows: array<wref<inkHorizontalPanel>>;
  private let m_icons: array<wref<inkImage>>;
  private let m_names: array<wref<inkText>>;
  private let m_subs: array<wref<inkText>>;
  private let m_fills: array<wref<inkRectangle>>;
  private let m_last: String;
  private let m_scale: Float = 0.65;

  private final func MakeText(size: Int32, parent: ref<inkCompoundWidget>) -> ref<inkText> {
    let text: ref<inkText> = new inkText();
    text.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
    text.SetFontStyle(n"Medium");
    text.SetFontSize(size);
    text.SetFitToContent(true);
    text.Reparent(parent);
    return text;
  }

  public final func Build(root: ref<inkCompoundWidget>) -> Void {
    let old: ref<inkWidget> = root.GetWidgetByPathName(n"dcSquadHud");
    if IsDefined(old) {
      root.RemoveChild(old);
    };

    let panel: ref<inkVerticalPanel> = new inkVerticalPanel();
    panel.SetName(n"dcSquadHud");
    panel.SetAnchor(inkEAnchor.TopLeft);
    panel.SetAnchorPoint(new Vector2(0.0, 0.0));
    panel.SetTranslation(new Vector2(10.0, 140.0));
    panel.SetScale(new Vector2(this.m_scale, this.m_scale));
    panel.SetVisible(false);
    panel.Reparent(root);
    this.m_panel = panel;

    let i: Int32 = 0;
    while i < 8 {
      let row: ref<inkHorizontalPanel> = new inkHorizontalPanel();
      row.SetMargin(inkMargin(0.0, 0.0, 0.0, 10.0));
      row.SetVisible(false);
      row.Reparent(panel);
      ArrayPush(this.m_rows, row);

      let icon: ref<inkImage> = new inkImage();
      icon.SetAtlasResource(ResRef.FromString("dronecompanion\\gui\\dc_icons.inkatlas"));
      icon.SetSize(Vector2(44.0, 44.0));
      icon.SetMargin(inkMargin(0.0, 2.0, 10.0, 0.0));
      icon.Reparent(row);
      ArrayPush(this.m_icons, icon);

      let col: ref<inkVerticalPanel> = new inkVerticalPanel();
      col.Reparent(row);

      let name: ref<inkText> = this.MakeText(28, col);
      name.SetTintColor(new HDRColor(0.90, 0.90, 0.93, 1.0));
      name.SetLetterCase(textLetterCase.UpperCase);
      ArrayPush(this.m_names, name);

      let barCv: ref<inkCanvas> = new inkCanvas();
      barCv.SetSize(Vector2(240.0, 8.0));
      barCv.SetMargin(inkMargin(0.0, 4.0, 0.0, 2.0));
      barCv.Reparent(col);

      let barBg: ref<inkRectangle> = new inkRectangle();
      barBg.SetSize(Vector2(240.0, 8.0));
      barBg.SetTintColor(new HDRColor(0.5, 0.5, 0.55, 1.0));
      barBg.SetOpacity(0.25);
      barBg.Reparent(barCv);

      let fill: ref<inkRectangle> = new inkRectangle();
      fill.SetSize(Vector2(240.0, 8.0));
      fill.Reparent(barCv);
      ArrayPush(this.m_fills, fill);

      let sub: ref<inkText> = this.MakeText(22, col);
      sub.SetTintColor(new HDRColor(0.74, 0.74, 0.78, 1.0));
      ArrayPush(this.m_subs, sub);

      i += 1;
    };
  }

  private final func HpColor(pct: Float) -> HDRColor {
    if pct >= 50.0 {
      return new HDRColor(0.35, 0.85, 0.40, 1.0);
    };
    if pct >= 25.0 {
      return new HDRColor(0.95, 0.78, 0.20, 1.0);
    };
    return new HDRColor(0.92, 0.22, 0.18, 1.0);
  }

  public final func SetScale(scale: Float) -> Void {
    this.m_scale = MaxF(0.4, MinF(2.0, scale)) * 0.65;
    if IsDefined(this.m_panel) {
      this.m_panel.SetScale(new Vector2(this.m_scale, this.m_scale));
    };
  }

  public final func Ready() -> Bool {
    return IsDefined(this.m_panel);
  }

  public final func SetState(payload: String) -> Void {
    if !IsDefined(this.m_panel) || Equals(payload, this.m_last) {
      return;
    };
    this.m_last = payload;
    if StrLen(payload) == 0 {
      this.m_panel.SetVisible(false);
      return;
    };
    let lines: array<String> = StrSplit(payload, "\n");
    let i: Int32 = 0;
    while i < ArraySize(this.m_rows) {
      if i < ArraySize(lines) {
        let f: array<String> = StrSplit(lines[i], "\t", true);
        if ArraySize(f) >= 4 {
          let pct: Float = StringToFloat(f[1], 0.0);
          let isNote: Bool = pct < 0.0;
          this.m_icons[i].SetTexturePart(StringToName(f[0]));
          this.m_icons[i].SetVisible(!isNote);
          this.m_names[i].SetText(f[2]);
          this.m_subs[i].SetText(f[3]);
          this.m_fills[i].SetSize(Vector2(240.0 * MaxF(0.0, MinF(pct, 100.0)) / 100.0, 8.0));
          this.m_fills[i].SetTintColor(this.HpColor(pct));
          this.m_fills[i].SetVisible(!isNote);
          this.m_rows[i].SetVisible(true);
        } else {
          this.m_rows[i].SetVisible(false);
        };
      } else {
        this.m_rows[i].SetVisible(false);
      };
      i += 1;
    };
    this.m_panel.SetVisible(true);
  }
}

public class DCCamCross extends IScriptable {
  private let m_root: wref<inkCanvas>;
  private let m_parts: array<wref<inkRectangle>>;
  private let m_dot: wref<inkRectangle>;
  private let m_state: Int32 = 0;
  private let m_stateSet: Bool = false;

  private final func Bar(w: Float, h: Float, x: Float, y: Float,
      parent: ref<inkCompoundWidget>) -> ref<inkRectangle> {
    let bar: ref<inkRectangle> = new inkRectangle();
    bar.SetSize(Vector2(w, h));
    bar.SetAnchor(inkEAnchor.Centered);
    bar.SetAnchorPoint(new Vector2(0.5, 0.5));
    bar.SetTranslation(new Vector2(x, y));
    bar.Reparent(parent);
    return bar;
  }

  public final func Build(root: ref<inkCompoundWidget>) -> Void {
    let old: ref<inkWidget> = root.GetWidgetByPathName(n"dcCamCross");
    if IsDefined(old) {
      root.RemoveChild(old);
    };
    let canvas: ref<inkCanvas> = new inkCanvas();
    canvas.SetName(n"dcCamCross");
    canvas.SetAnchor(inkEAnchor.Centered);
    canvas.SetAnchorPoint(new Vector2(0.5, 0.5));
    canvas.SetSize(Vector2(200.0, 200.0));
    canvas.SetVisible(false);
    canvas.Reparent(root);
    this.m_root = canvas;

    ArrayPush(this.m_parts, this.Bar(22.0, 3.0, -30.0, 0.0, canvas));
    ArrayPush(this.m_parts, this.Bar(22.0, 3.0, 30.0, 0.0, canvas));
    ArrayPush(this.m_parts, this.Bar(3.0, 22.0, 0.0, -30.0, canvas));
    ArrayPush(this.m_parts, this.Bar(3.0, 22.0, 0.0, 30.0, canvas));
    this.m_dot = this.Bar(5.0, 5.0, 0.0, 0.0, canvas);
    ArrayPush(this.m_parts, this.m_dot);
  }

  public final func Ready() -> Bool {
    return IsDefined(this.m_root);
  }

  public final func SetState(state: Int32) -> Void {
    if !IsDefined(this.m_root) || (this.m_stateSet && state == this.m_state) {
      return;
    };
    this.m_state = state;
    this.m_stateSet = true;
    if state <= 0 {
      this.m_root.SetVisible(false);
      return;
    };
    let color: HDRColor = state == 2
      ? new HDRColor(0.99, 0.93, 0.35, 1.0)
      : new HDRColor(0.80, 0.86, 0.92, 1.0);
    let i: Int32 = 0;
    while i < ArraySize(this.m_parts) {
      this.m_parts[i].SetTintColor(color);
      this.m_parts[i].SetOpacity(state == 2 ? 1.0 : 0.55);
      i += 1;
    };
    this.m_root.SetVisible(true);
  }
}

public class DCCamHacks extends IScriptable {
  private let m_root: wref<inkVerticalPanel>;
  private let m_targetName: wref<inkText>;
  private let m_targetSub: wref<inkText>;
  private let m_rows: array<wref<inkCanvas>>;
  private let m_plates: array<wref<inkRectangle>>;
  private let m_marks: array<wref<inkRectangle>>;
  private let m_names: array<wref<inkText>>;
  private let m_costs: array<wref<inkText>>;
  private let m_last: String;

  private final func Label(size: Int32, parent: ref<inkCompoundWidget>) -> ref<inkText> {
    let text: ref<inkText> = new inkText();
    text.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
    text.SetFontStyle(n"Semi-Bold");
    text.SetFontSize(size);
    text.SetFitToContent(true);
    text.Reparent(parent);
    return text;
  }

  public final func Build(root: ref<inkCompoundWidget>) -> Void {
    let old: ref<inkWidget> = root.GetWidgetByPathName(n"dcCamHacks");
    if IsDefined(old) {
      root.RemoveChild(old);
    };

    let panel: ref<inkVerticalPanel> = new inkVerticalPanel();
    panel.SetName(n"dcCamHacks");
    panel.SetAnchor(inkEAnchor.Centered);
    panel.SetAnchorPoint(new Vector2(1.0, 0.5));
    panel.SetTranslation(new Vector2(-200.0, 0.0));
    panel.SetVisible(false);
    panel.Reparent(root);
    this.m_root = panel;

    let head: ref<inkVerticalPanel> = new inkVerticalPanel();
    head.SetMargin(inkMargin(0.0, 0.0, 0.0, 16.0));
    head.Reparent(panel);

    let tName: ref<inkText> = this.Label(34, head);
    tName.SetTintColor(new HDRColor(0.99, 0.93, 0.35, 1.0));
    tName.SetLetterCase(textLetterCase.UpperCase);
    this.m_targetName = tName;

    let tSub: ref<inkText> = this.Label(22, head);
    tSub.SetTintColor(new HDRColor(0.70, 0.72, 0.78, 1.0));
    this.m_targetSub = tSub;

    let i: Int32 = 0;
    while i < 6 {
      let slot: ref<inkCanvas> = new inkCanvas();
      slot.SetSize(Vector2(400.0, 46.0));
      slot.SetMargin(inkMargin(0.0, 0.0, 0.0, 4.0));
      slot.SetVisible(false);
      slot.Reparent(panel);

      let plate: ref<inkRectangle> = new inkRectangle();
      plate.SetSize(Vector2(400.0, 46.0));
      plate.SetTintColor(new HDRColor(0.02, 0.06, 0.09, 1.0));
      plate.SetOpacity(0.72);
      plate.Reparent(slot);
      ArrayPush(this.m_plates, plate);

      let row: ref<inkHorizontalPanel> = new inkHorizontalPanel();
      row.SetMargin(inkMargin(0.0, 6.0, 0.0, 0.0));
      row.Reparent(slot);
      ArrayPush(this.m_rows, slot);

      let bg: ref<inkRectangle> = new inkRectangle();
      bg.SetSize(Vector2(5.0, 34.0));
      bg.SetMargin(inkMargin(0.0, 0.0, 14.0, 0.0));
      bg.SetTintColor(new HDRColor(0.20, 0.90, 0.98, 1.0));
      bg.Reparent(row);
      ArrayPush(this.m_marks, bg);

      let name: ref<inkText> = this.Label(26, row);
      name.SetTintColor(new HDRColor(0.88, 0.92, 0.96, 1.0));
      name.SetLetterCase(textLetterCase.UpperCase);
      ArrayPush(this.m_names, name);

      let cost: ref<inkText> = this.Label(24, row);
      cost.SetMargin(inkMargin(20.0, 2.0, 0.0, 0.0));
      cost.SetTintColor(new HDRColor(0.20, 0.90, 0.98, 1.0));
      ArrayPush(this.m_costs, cost);

      i += 1;
    };
  }

  public final func Ready() -> Bool {
    return IsDefined(this.m_root);
  }

  public final func SetState(payload: String) -> Void {
    if !IsDefined(this.m_root) || Equals(payload, this.m_last) {
      return;
    };
    this.m_last = payload;
    if StrLen(payload) == 0 {
      this.m_root.SetVisible(false);
      return;
    };
    let lines: array<String> = StrSplit(payload, "\n");
    let head: array<String> = StrSplit(lines[0], "\t", true);
    this.m_targetName.SetText(head[0]);
    if ArraySize(head) > 1 {
      this.m_targetSub.SetText(head[1]);
    } else {
      this.m_targetSub.SetText("");
    };
    let i: Int32 = 0;
    while i < ArraySize(this.m_rows) {
      let idx: Int32 = i + 1;
      if idx < ArraySize(lines) {
        let f: array<String> = StrSplit(lines[idx], "\t", true);
        if ArraySize(f) >= 3 {
          let selected: Bool = Equals(f[0], "1");
          let usable: Bool = Equals(f[2], "1");
          this.m_marks[i].SetOpacity(selected ? 1.0 : 0.0);
          this.m_plates[i].SetOpacity(selected ? 0.88 : 0.55);
          this.m_plates[i].SetTintColor(selected
            ? new HDRColor(0.05, 0.16, 0.20, 1.0)
            : new HDRColor(0.02, 0.06, 0.09, 1.0));
          this.m_names[i].SetText(f[1]);
          this.m_names[i].SetTintColor(selected
            ? new HDRColor(0.99, 0.93, 0.35, 1.0)
            : new HDRColor(0.88, 0.90, 0.94, 1.0));
          this.m_names[i].SetOpacity(usable ? 1.0 : 0.45);
          this.m_costs[i].SetText(ArraySize(f) > 3 ? f[3] : "");
          this.m_costs[i].SetOpacity(usable ? 1.0 : 0.45);
          this.m_rows[i].SetVisible(true);
        } else {
          this.m_rows[i].SetVisible(false);
        };
      } else {
        this.m_rows[i].SetVisible(false);
      };
      i += 1;
    };
    this.m_root.SetVisible(true);
  }
}

@addField(PlayerPuppet)
let m_dcCamHacks: ref<DCCamHacks>;

@addField(PlayerPuppet)
let m_dcCamCross: ref<DCCamCross>;

@addMethod(PlayerPuppet)
public func DCCamCrossPush(state: Int32) -> Bool {
  if IsDefined(this.m_dcCamCross) && this.m_dcCamCross.Ready() {
    this.m_dcCamCross.SetState(state);
    return true;
  };
  return false;
}

@addMethod(PlayerPuppet)
public func DCCamPush(payload: String) -> Bool {
  if IsDefined(this.m_dcCamHacks) && this.m_dcCamHacks.Ready() {
    this.m_dcCamHacks.SetState(payload);
    return true;
  };
  return false;
}

@addField(PlayerPuppet)
let m_dcHudPanel: ref<DCHud>;

@addMethod(PlayerPuppet)
public func DCKill(drone: wref<GameObject>) -> Bool {
  return true;
}

@addMethod(PlayerPuppet)
public func DCHudScale(scale: Float) -> Bool {
  if IsDefined(this.m_dcHudPanel) {
    this.m_dcHudPanel.SetScale(scale);
    return true;
  };
  return false;
}

@addMethod(PlayerPuppet)
public func DCHudPush(payload: String) -> Bool {
  if IsDefined(this.m_dcHudPanel) && this.m_dcHudPanel.Ready() {
    this.m_dcHudPanel.SetState(payload);
    return true;
  };
  return false;
}

private static func DC_HudRoot() -> ref<inkCompoundWidget> {
  let layer: ref<inkLayerWrapper> = GameInstance.GetInkSystem().GetLayer(n"inkHUDLayer");
  if !IsDefined(layer) {
    return null;
  };
  return layer.GetVirtualWindow() as inkCompoundWidget;
}

@wrapMethod(healthbarWidgetGameController)
protected cb func OnPlayerAttach(playerGameObject: ref<GameObject>) -> Bool {
  let ret: Bool = wrappedMethod(playerGameObject);
  let pp: ref<PlayerPuppet> = playerGameObject as PlayerPuppet;
  if IsDefined(pp) {
    let root: ref<inkCompoundWidget> = DC_HudRoot();
    let hud: ref<DCHud> = new DCHud();
    if IsDefined(root) {
      hud.Build(root);
    };
    pp.m_dcHudPanel = hud;
    let cam: ref<DCCamHacks> = new DCCamHacks();
    if IsDefined(root) {
      cam.Build(root);
    };
    pp.m_dcCamHacks = cam;
    let cross: ref<DCCamCross> = new DCCamCross();
    if IsDefined(root) {
      cross.Build(root);
    };
    pp.m_dcCamCross = cross;
    pp.DCEmit(hud.Ready() ? "hud:ok" : "hud:noroot");
  };
  return ret;
}

@wrapMethod(WorldMappinsContainerController)
public func CreateMappinUIProfile(mappin: wref<IMappin>, mappinVariant: gamedataMappinVariant, customData: ref<MappinControllerCustomData>) -> MappinUIProfile {
  if Equals(mappinVariant, gamedataMappinVariant.CustomPositionVariant) {
    let id: EntityID = mappin.GetEntityID();
    if EntityID.IsDefined(id) {
      let player: ref<GameObject> = this.GetPlayerControlledObject();
      if IsDefined(player) && GameInstance.GetStatusEffectSystem(player.GetGame()).HasStatusEffect(id, t"DroneCompanion.CompanionSE") {
        return MappinUIProfile.None();
      };
    };
  };
  return wrappedMethod(mappin, mappinVariant, customData);
}

@wrapMethod(MinimapContainerController)
public func CreateMappinUIProfile(mappin: wref<IMappin>, mappinVariant: gamedataMappinVariant, customData: ref<MappinControllerCustomData>) -> MappinUIProfile {
  let id: EntityID = mappin.GetEntityID();
  if EntityID.IsDefined(id) {
    let player: ref<GameObject> = this.GetPlayerControlledObject();
    if IsDefined(player) && GameInstance.GetStatusEffectSystem(player.GetGame()).HasStatusEffect(id, t"DroneCompanion.CompanionSE") {
      if Equals(mappinVariant, gamedataMappinVariant.CustomPositionVariant) {
        return MappinUIProfile.Create(r"base\\gameplay\\gui\\widgets\\minimap\\minimap_poi_mappin.inkwidget", t"MappinUISpawnProfile.Always", t"MinimapMappinUIProfile.Default");
      };
      return MappinUIProfile.None();
    };
  };
  return wrappedMethod(mappin, mappinVariant, customData);
}

@wrapMethod(MinimapPOIMappinController)
protected func UpdateIcon() -> Void {
  wrappedMethod();
  let mappin: wref<IMappin> = this.GetMappin();
  if !IsDefined(mappin) || !Equals(mappin.GetVariant(), gamedataMappinVariant.CustomPositionVariant) {
    return;
  };
  let id: EntityID = mappin.GetEntityID();
  if !EntityID.IsDefined(id) {
    return;
  };
  let ses: ref<StatusEffectSystem> = GameInstance.GetStatusEffectSystem(GetGameInstance());
  if !IsDefined(ses) || !ses.HasStatusEffect(id, t"DroneCompanion.CompanionSE") {
    return;
  };
  let part: CName = n"";
  if ses.HasStatusEffect(id, t"DroneCompanion.ChassisOctantSE") { part = n"octant"; };
  if ses.HasStatusEffect(id, t"DroneCompanion.ChassisWyvernSE") { part = n"wyvern"; };
  if ses.HasStatusEffect(id, t"DroneCompanion.ChassisGriffinSE") { part = n"griffin"; };
  if ses.HasStatusEffect(id, t"DroneCompanion.ChassisBombusSE") { part = n"bombus"; };
  if ses.HasStatusEffect(id, t"DroneCompanion.ChassisMinotaurSE") { part = n"minotaur"; };
  if ses.HasStatusEffect(id, t"DroneCompanion.ChassisAndroidSE") { part = n"android"; };
  if ses.HasStatusEffect(id, t"DroneCompanion.ChassisFlatheadSE") { part = n"flathead"; };
  if ses.HasStatusEffect(id, t"DroneCompanion.ChassisChimeraSE") { part = n"chimera"; };
  if ses.HasStatusEffect(id, t"DroneCompanion.ChassisCerberusSE") { part = n"cerberus"; };
  if IsNameValid(part) {
    inkImageRef.SetAtlasResource(this.iconWidget, r"dronecompanion\\gui\\dc_icons.inkatlas");
    inkImageRef.SetTexturePart(this.iconWidget, part);
  };
}

@wrapMethod(BaseMinimapMappinController)
protected func Update() -> Void {
  wrappedMethod();
  let mappin: wref<IMappin> = this.GetMappin();
  if IsDefined(mappin) && !Equals(mappin.GetVariant(), gamedataMappinVariant.CustomPositionVariant) && !this.IsForceHide() {
    let id: EntityID = mappin.GetEntityID();
    if EntityID.IsDefined(id) && GameInstance.GetStatusEffectSystem(GetGameInstance()).HasStatusEffect(id, t"DroneCompanion.CompanionSE") {
      this.SetForceHide(true);
    };
  };
}
