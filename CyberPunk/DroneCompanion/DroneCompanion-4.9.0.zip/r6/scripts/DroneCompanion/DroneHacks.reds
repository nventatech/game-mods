module DroneCompanion

private static func DC_PuppetPS(target: wref<GameObject>) -> ref<ScriptedPuppetPS> {
  let sp: wref<ScriptedPuppet> = target as ScriptedPuppet;
  if !IsDefined(sp) {
    return null;
  };
  return sp.GetPuppetPS();
}

private static func DC_ApplyEffects(action: ref<ScriptableDeviceAction>,
    target: wref<GameObject>, player: ref<PlayerPuppet>) -> Int32 {
  let rec: wref<ObjectAction_Record> = action.GetObjectActionRecord();
  if !IsDefined(rec) {
    return 0;
  };
  let fx: array<wref<ObjectActionEffect_Record>>;
  rec.CompletionEffects(fx);
  let start: array<wref<ObjectActionEffect_Record>>;
  rec.StartEffects(start);
  let k: Int32 = 0;
  while k < ArraySize(start) {
    ArrayPush(fx, start[k]);
    k += 1;
  };
  let applied: Int32 = 0;
  let i: Int32 = 0;
  while i < ArraySize(fx) {
    let se: wref<StatusEffect_Record> = fx[i].StatusEffect();
    if IsDefined(se) {
      StatusEffectHelper.ApplyStatusEffect(target, se.GetID(), player.GetEntityID());
      applied += 1;
    };
    i += 1;
  };
  return applied;
}

private static func DC_IsOwnedHack(action: ref<ScriptableDeviceAction>,
    owned: array<TweakDBID>) -> Bool {
  if ArraySize(owned) == 0 {
    return true;
  };
  let rec: wref<ObjectAction_Record> = action.GetObjectActionRecord();
  if !IsDefined(rec) {
    return false;
  };
  if ArrayContains(owned, rec.GetID()) {
    return true;
  };
  let i: Int32 = 0;
  while i < ArraySize(owned) {
    let item: wref<Item_Record> = TweakDBInterface.GetItemRecord(owned[i]);
    if IsDefined(item) {
      let acts: array<wref<ObjectAction_Record>>;
      item.ObjectActions(acts);
      if ArrayContains(acts, rec) {
        return true;
      };
    };
    i += 1;
  };
  return false;
}

private static func DC_HackActions(player: ref<PlayerPuppet>, target: wref<GameObject>,
    out actions: array<ref<ScriptableDeviceAction>>) -> Bool {
  let sp: wref<ScriptedPuppet> = target as ScriptedPuppet;
  let ps: ref<ScriptedPuppetPS> = DC_PuppetPS(target);
  if IsDefined(sp) && IsDefined(ps) {
    let ctx: GetActionsContext = ps.GenerateContext(gamedeviceRequestType.Remote,
      Clearance.CreateClearance(0, 9), player, player.GetEntityID());
    let records: array<wref<ObjectAction_Record>>;
    sp.GetRecord().ObjectActions(records);
    let puppetActions: array<ref<PuppetAction>>;
    ps.GetAllChoices(records, ctx, puppetActions);
    let i: Int32 = 0;
    while i < ArraySize(puppetActions) {
      ArrayPush(actions, puppetActions[i]);
      i += 1;
    };
    return ArraySize(actions) > 0;
  };

  let device: wref<Device> = target as Device;
  if !IsDefined(device) {
    return false;
  };
  let dps: ref<ScriptableDeviceComponentPS> = device.GetDevicePS();
  if !IsDefined(dps) {
    return false;
  };
  let dctx: GetActionsContext = dps.GenerateContext(gamedeviceRequestType.Remote,
    Clearance.CreateClearance(0, 9), player, player.GetEntityID());
  let deviceActions: array<ref<DeviceAction>>;
  dps.GetQuickHackActions(deviceActions, dctx);
  let j: Int32 = 0;
  while j < ArraySize(deviceActions) {
    let sa: ref<ScriptableDeviceAction> = deviceActions[j] as ScriptableDeviceAction;
    if IsDefined(sa) {
      ArrayPush(actions, sa);
    };
    j += 1;
  };
  return ArraySize(actions) > 0;
}

@addMethod(PlayerPuppet)
public func DCHackList(target: wref<GameObject>) -> String {
  let actions: array<ref<ScriptableDeviceAction>>;
  if !DC_HackActions(this, target, actions) {
    return "";
  };
  let out: String = "";
  let i: Int32 = 0;
  while i < ArraySize(actions) {
    let sa: ref<ScriptableDeviceAction> = actions[i];
    if IsDefined(sa) {
      let label: String = "";
      let rec: wref<ObjectAction_Record> = sa.GetObjectActionRecord();
      if IsDefined(rec) && IsDefined(rec.ObjectActionUI()) {
        label = GetLocalizedTextByKey(rec.ObjectActionUI().Caption());
      };
      if StrLen(label) == 0 {
        label = NameToString(sa.actionName);
      };
      if StrLen(out) > 0 {
        out += "\n";
      };
      out += label + "\t" + ToString(sa.GetCost()) + "\t" + (sa.IsInactive() ? "0" : "1");
    };
    i += 1;
  };
  return out;
}

@addMethod(PlayerPuppet)
public func DCHackRun(target: wref<GameObject>, index: Int32) -> Int32 {
  let actions: array<ref<ScriptableDeviceAction>>;
  if !DC_HackActions(this, target, actions) {
    return 0;
  };
  if index < 0 || index >= ArraySize(actions) {
    return 0;
  };
  let sa: ref<ScriptableDeviceAction> = actions[index];
  if !IsDefined(sa) || sa.IsInactive() {
    return 0;
  };
  sa.SetExecutor(this);
  sa.RegisterAsRequester(target.GetEntityID());
  let ps: ref<ScriptedPuppetPS> = DC_PuppetPS(target);
  if IsDefined(ps) {
    if DC_IsOwnedHack(sa, RPGManager.GetPlayerQuickHackList(this)) {
      sa.ProcessRPGAction(this.GetGame());
      return 1;
    };
    if DC_ApplyEffects(sa, target, this) > 0 {
      return 2;
    };
    sa.CompleteAction(this.GetGame());
    GameInstance.GetPersistencySystem(this.GetGame())
      .QueuePSEvent(ps.GetID(), ps.GetClassName(), sa);
    return 3;
  };
  let device: wref<Device> = target as Device;
  if !IsDefined(device) {
    return 0;
  };
  let dps: ref<ScriptableDeviceComponentPS> = device.GetDevicePS();
  if !IsDefined(dps) {
    return 0;
  };
  GameInstance.GetPersistencySystem(this.GetGame())
    .QueuePSEvent(dps.GetID(), dps.GetClassName(), sa);
  return 1;
}
