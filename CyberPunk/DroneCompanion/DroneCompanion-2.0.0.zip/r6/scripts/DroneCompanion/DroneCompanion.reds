// DroneCompanion: combat integration that CET cannot express reliably.
// A companion drone is any puppet carrying the DroneCompanion.CompanionSE
// marker applied by the Lua side.

module DroneCompanion

private static func DC_IsCompanionDrone(obj: wref<GameObject>) -> Bool {
  let sp: wref<ScriptedPuppet> = obj as ScriptedPuppet;
  if !IsDefined(sp) {
    return false;
  };
  let ses = GameInstance.GetStatusEffectSystem(sp.GetGame());
  return IsDefined(ses) && ses.HasStatusEffect(sp.GetEntityID(), t"DroneCompanion.CompanionSE");
}

// no friendly fire in either direction between V and companion drones
@wrapMethod(DamageSystem)
private final func Process(hitEvent: ref<gameHitEvent>, cache: ref<CacheData>) -> Void {
  let instigator: wref<ScriptedPuppet> = hitEvent.attackData.GetInstigator() as ScriptedPuppet;
  let target: wref<ScriptedPuppet> = hitEvent.target as ScriptedPuppet;
  if IsDefined(instigator) && IsDefined(target) {
    let instOurs: Bool = DC_IsCompanionDrone(instigator);
    let targOurs: Bool = DC_IsCompanionDrone(target);
    if (instOurs && targOurs) || (instigator.IsPlayer() && targOurs) || (instOurs && target.IsPlayer()) {
      return;
    };
  };
  wrappedMethod(hitEvent, cache);
}

// enemies register the drones as threats instead of tunneling on V
@wrapMethod(ReactionManagerComponent)
protected cb func OnDetectedEvent(evt: ref<OnDetectedEvent>) -> Bool {
  if IsDefined(evt) && IsDefined(evt.target) && evt.isVisible && DC_IsCompanionDrone(evt.target) {
    let owner: wref<ScriptedPuppet> = this.GetOwnerPuppet();
    if IsDefined(owner) {
      TargetTrackingExtension.InjectThreat(owner, evt.target);
    };
  };
  return wrappedMethod(evt);
}

// senses must not skip companion drones as valid targets for enemies
@wrapMethod(SenseComponent)
public final static func ShouldIgnoreIfPlayerCompanion(owner: wref<Entity>, target: wref<Entity>) -> Bool {
  if DC_IsCompanionDrone(target as GameObject) {
    return false;
  };
  return wrappedMethod(owner, target);
}

// a drone crossing the crosshair must not lower V's weapon (damage to it is
// already voided in DamageSystem, so shooting through drones is safe)
@wrapMethod(PlayerPuppet)
private final func UpdateLookAtObject(target: ref<GameObject>) -> Void {
  wrappedMethod(target);
  if IsDefined(target) && DC_IsCompanionDrone(target) {
    this.m_isAimingAtFriendly = false;
  };
}

// nameplate + healthbar visible when looking at a companion drone
@wrapMethod(NpcNameplateGameController)
private final func HelperCheckDistance(entity: ref<Entity>) -> Bool {
  if IsDefined(entity) && DC_IsCompanionDrone(entity as GameObject) {
    return true;
  };
  return wrappedMethod(entity);
}

@wrapMethod(NpcNameplateGameController)
protected cb func OnNameplateDataChanged(value: Variant) -> Bool {
  wrappedMethod(value);
  let data: NPCNextToTheCrosshair = FromVariant<NPCNextToTheCrosshair>(value);
  if IsDefined(data.npc) && DC_IsCompanionDrone(data.npc) {
    this.m_visualController.UpdateNPCNamesEnabled(true);
  };
}

@wrapMethod(NameplateVisualsLogicController)
public final func SetVisualData(puppet: ref<GameObject>, const incomingData: script_ref<NPCNextToTheCrosshair>, opt isNewNpc: Bool) -> Void {
  wrappedMethod(puppet, incomingData, isNewNpc);
  if IsDefined(puppet) && DC_IsCompanionDrone(puppet) {
    this.UpdateHealthbarColor(false);
    inkWidgetRef.SetVisible(this.m_healthbarWidget, true);
  };
}

@wrapMethod(NameplateVisualsLogicController)
public final func UpdateHealthbarColor(isHostile: Bool) -> Void {
  if IsDefined(this.m_cachedPuppet) && DC_IsCompanionDrone(this.m_cachedPuppet) {
    inkWidgetRef.SetState(this.m_healthbarWidget, n"Friendly");
    inkWidgetRef.SetState(this.m_healthBarFull, n"Friendly");
    inkWidgetRef.SetState(this.m_healthBarFrame, n"Friendly");
    return;
  };
  wrappedMethod(isHostile);
}
