module DroneCompanion

enum DCPadMod {
  None = 0,
  LB = 1,
  RB = 2
}

enum DCPadBtn {
  None = 0,
  A = 1,
  X = 2,
  Y = 3,
  B = 4
}

enum DCHotkey {
  None = 0,
  F2 = 1,
  F6 = 2,
  F7 = 3,
  F8 = 4,
  F10 = 5,
  F11 = 6,
  Insert = 7
}

public class DroneCompanionSettings extends ScriptableSystem {

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Toggle")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Mod")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Mod-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"LB\", \"RB\"")
  public let toggleMod: DCPadMod = DCPadMod.LB;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Toggle")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Btn")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Btn-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"A\", \"X\", \"Y\", \"B\"")
  public let toggleBtn: DCPadBtn = DCPadBtn.A;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Toggle")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Key")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Key-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"F2\", \"F6\", \"F7\", \"F8\", \"F10\", \"F11\", \"Insert\"")
  public let toggleKey: DCHotkey = DCHotkey.F6;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Cycle")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Mod")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Mod-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"LB\", \"RB\"")
  public let cycleMod: DCPadMod = DCPadMod.RB;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Cycle")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Btn")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Btn-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"A\", \"X\", \"Y\", \"B\"")
  public let cycleBtn: DCPadBtn = DCPadBtn.A;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Cycle")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Key")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Key-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"F2\", \"F6\", \"F7\", \"F8\", \"F10\", \"F11\", \"Insert\"")
  public let cycleKey: DCHotkey = DCHotkey.F7;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Menu")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Mod")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Mod-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"LB\", \"RB\"")
  public let menuMod: DCPadMod = DCPadMod.LB;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Menu")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Btn")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Btn-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"A\", \"X\", \"Y\", \"B\"")
  public let menuBtn: DCPadBtn = DCPadBtn.X;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Menu")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Key")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Key-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"F2\", \"F6\", \"F7\", \"F8\", \"F10\", \"F11\", \"Insert\"")
  public let menuKey: DCHotkey = DCHotkey.F8;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Command")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Mod")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Mod-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"LB\", \"RB\"")
  public let commandMod: DCPadMod = DCPadMod.LB;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Command")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Btn")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Btn-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"A\", \"X\", \"Y\", \"B\"")
  public let commandBtn: DCPadBtn = DCPadBtn.B;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Command")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-Set-Key")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Key-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"None\", \"F2\", \"F6\", \"F7\", \"F8\", \"F10\", \"F11\", \"Insert\"")
  public let commandKey: DCHotkey = DCHotkey.F10;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Acquisition")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-L-immersive")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-Set-Immersive-Desc")
  public let immersive: Bool = true;

  @runtimeProperty("ModSettings.mod", "Mod-DroneCompanion-Title")
  @runtimeProperty("ModSettings.category", "Mod-DroneCompanion-Set-Cat-Acquisition")
  @runtimeProperty("ModSettings.displayName", "Mod-DroneCompanion-L-rigger")
  @runtimeProperty("ModSettings.description", "Mod-DroneCompanion-L-rigger_hint")
  public let rigger: Bool = true;

  public static func Get(game: GameInstance) -> ref<DroneCompanionSettings> {
    return GameInstance.GetScriptableSystemsContainer(game).Get(n"DroneCompanion.DroneCompanionSettings") as DroneCompanionSettings;
  }

  public func KeyOf(hotkey: DCHotkey) -> EInputKey {
    switch hotkey {
      case DCHotkey.F2: return EInputKey.IK_F2;
      case DCHotkey.F6: return EInputKey.IK_F6;
      case DCHotkey.F7: return EInputKey.IK_F7;
      case DCHotkey.F8: return EInputKey.IK_F8;
      case DCHotkey.F10: return EInputKey.IK_F10;
      case DCHotkey.F11: return EInputKey.IK_F11;
      case DCHotkey.Insert: return EInputKey.IK_Insert;
      default: return EInputKey.IK_None;
    };
  }

  public func Encode() -> String {
    return ToString(EnumInt(this.toggleMod)) + ":" + ToString(EnumInt(this.toggleBtn)) + ":" + ToString(EnumInt(this.toggleKey))
      + "," + ToString(EnumInt(this.cycleMod)) + ":" + ToString(EnumInt(this.cycleBtn)) + ":" + ToString(EnumInt(this.cycleKey))
      + "," + ToString(EnumInt(this.menuMod)) + ":" + ToString(EnumInt(this.menuBtn)) + ":" + ToString(EnumInt(this.menuKey))
      + "," + ToString(EnumInt(this.commandMod)) + ":" + ToString(EnumInt(this.commandBtn)) + ":" + ToString(EnumInt(this.commandKey));
  }

  @if(ModuleExists("ModSettingsModule"))
  private func OnAttach() -> Void {
    ModSettings.RegisterListenerToClass(this);
  }

  @if(!ModuleExists("ModSettingsModule"))
  private func OnAttach() -> Void {}

  @if(ModuleExists("ModSettingsModule"))
  private func OnDetach() -> Void {
    ModSettings.UnregisterListenerToClass(this);
  }

  @if(!ModuleExists("ModSettingsModule"))
  private func OnDetach() -> Void {}
}

@addField(PlayerPuppet)
let m_dcInBlockedMenu: Bool;

@wrapMethod(PauseMenuBackgroundGameController)
protected cb func OnInitialize() -> Bool {
  let player: ref<PlayerPuppet> = this.GetPlayerControlledObject() as PlayerPuppet;
  if IsDefined(player) {
    player.m_dcInBlockedMenu = true;
  };
  return wrappedMethod();
}

@wrapMethod(PauseMenuBackgroundGameController)
protected cb func OnUninitialize() -> Bool {
  let player: ref<PlayerPuppet> = this.GetPlayerControlledObject() as PlayerPuppet;
  if IsDefined(player) {
    player.m_dcInBlockedMenu = false;
  };
  return wrappedMethod();
}

@wrapMethod(DeathMenuGameController)
protected cb func OnInitialize() -> Bool {
  let player: ref<PlayerPuppet> = this.GetPlayerControlledObject() as PlayerPuppet;
  if IsDefined(player) {
    player.m_dcInBlockedMenu = true;
  };
  return wrappedMethod();
}

@wrapMethod(DeathMenuGameController)
protected cb func OnUninitialize() -> Bool {
  let player: ref<PlayerPuppet> = this.GetPlayerControlledObject() as PlayerPuppet;
  if IsDefined(player) {
    player.m_dcInBlockedMenu = false;
  };
  return wrappedMethod();
}

@wrapMethod(PlayerPuppet)
protected cb func OnGameAttached() -> Bool {
  let result: Bool = wrappedMethod();
  GameInstance.GetCallbackSystem().RegisterCallback(n"Input/Key", this, n"OnDCKeyInput")
    .SetLifetime(CallbackLifetime.Session);
  return result;
}

@wrapMethod(PlayerPuppet)
protected cb func OnDetach() -> Bool {
  GameInstance.GetCallbackSystem().UnregisterCallback(n"Input/Key", this, n"OnDCKeyInput");
  return wrappedMethod();
}

@addMethod(PlayerPuppet)
protected cb func OnDCKeyInput(event: ref<KeyInputEvent>) {
  if !Equals(event.GetAction(), EInputAction.IACT_Press) || this.m_dcInBlockedMenu {
    return;
  };
  let settings: ref<DroneCompanionSettings> = DroneCompanionSettings.Get(this.GetGame());
  if !IsDefined(settings) {
    return;
  };
  let key: EInputKey = event.GetKey();
  if Equals(key, EInputKey.IK_None) {
    return;
  };
  if Equals(key, settings.KeyOf(settings.toggleKey)) {
    this.DCKeyCombo("toggle");
    return;
  };
  if Equals(key, settings.KeyOf(settings.cycleKey)) {
    this.DCKeyCombo("cycle");
    return;
  };
  if Equals(key, settings.KeyOf(settings.menuKey)) {
    this.DCKeyCombo("menu");
    return;
  };
  if Equals(key, settings.KeyOf(settings.commandKey)) {
    this.DCKeyCombo("command");
  };
}

@addMethod(PlayerPuppet)
public func DCKeyCombo(id: String) -> Void {}

@addMethod(PlayerPuppet)
public func DCGetBinds() -> String {
  let settings: ref<DroneCompanionSettings> = DroneCompanionSettings.Get(this.GetGame());
  return IsDefined(settings) ? settings.Encode() : "";
}

@addMethod(PlayerPuppet)
public func DCGetAcquisition() -> String {
  let settings: ref<DroneCompanionSettings> = DroneCompanionSettings.Get(this.GetGame());
  if !IsDefined(settings) {
    return "";
  };
  return (settings.immersive ? "1" : "0") + ":" + (settings.rigger ? "1" : "0");
}

@addMethod(PlayerPuppet)
public func DCSetAcquisition(immersive: Bool, rigger: Bool) -> Void {
  let settings: ref<DroneCompanionSettings> = DroneCompanionSettings.Get(this.GetGame());
  if IsDefined(settings) {
    settings.immersive = immersive;
    settings.rigger = rigger;
  };
}
