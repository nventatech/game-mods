module DroneCompanion
import Codeware.Localization.*

private static func DC_IsCompanionDrone(obj: wref<GameObject>) -> Bool {
  let sp: wref<ScriptedPuppet> = obj as ScriptedPuppet;
  if !IsDefined(sp) {
    return false;
  };
  let ses = GameInstance.GetStatusEffectSystem(sp.GetGame());
  return IsDefined(ses) && ses.HasStatusEffect(sp.GetEntityID(), t"DroneCompanion.CompanionSE");
}

private static func DC_IsPassive(obj: wref<GameObject>) -> Bool {
  let sp: wref<ScriptedPuppet> = obj as ScriptedPuppet;
  if !IsDefined(sp) {
    return false;
  };
  let ses = GameInstance.GetStatusEffectSystem(sp.GetGame());
  return IsDefined(ses) && ses.HasStatusEffect(sp.GetEntityID(), t"DroneCompanion.PassiveSE");
}

private static func DC_IsRival(obj: wref<GameObject>) -> Bool {
  let sp: wref<ScriptedPuppet> = obj as ScriptedPuppet;
  if !IsDefined(sp) {
    return false;
  };
  let ses = GameInstance.GetStatusEffectSystem(sp.GetGame());
  return IsDefined(ses) && ses.HasStatusEffect(sp.GetEntityID(), t"DroneCompanion.RivalSE");
}

private static func DC_IsArena(obj: wref<GameObject>) -> Bool {
  let sp: wref<ScriptedPuppet> = obj as ScriptedPuppet;
  if !IsDefined(sp) {
    return false;
  };
  let ses = GameInstance.GetStatusEffectSystem(sp.GetGame());
  return IsDefined(ses) && ses.HasStatusEffect(sp.GetEntityID(), t"DroneCompanion.ArenaSE");
}

@wrapMethod(ScriptedPuppet)
public final func IsQuickHackAble() -> Bool {
  if DC_IsCompanionDrone(this) {
    return true;
  };
  return wrappedMethod();
}

@wrapMethod(ScriptedPuppetPS)
public final const func IsQuickHacksExposed() -> Bool {
  if DC_IsCompanionDrone(this.GetOwnerEntity() as ScriptedPuppet) {
    return true;
  };
  return wrappedMethod();
}

private static func DC_HackIDs() -> array<TweakDBID> {
  return [
    t"DroneCompanion.HackRepair",
    t"DroneCompanion.HackHold",
    t"DroneCompanion.HackDismiss",
    t"DroneCompanion.HackDetonate",
    t"DroneCompanion.HackOverclock",
    t"DroneCompanion.HackFortify",
    t"DroneCompanion.HackOctant",
    t"DroneCompanion.HackWyvern",
    t"DroneCompanion.HackGriffin",
    t"DroneCompanion.HackBombus",
    t"DroneCompanion.HackMinotaur"
  ];
}

private static func DC_CooldownIDs() -> array<TweakDBID> {
  return [
    t"DroneCompanion.HackRepairCd",
    t"DroneCompanion.HackHoldCd",
    t"DroneCompanion.HackDismissCd",
    t"DroneCompanion.HackDetonateCd",
    t"DroneCompanion.HackOverclockCd",
    t"DroneCompanion.HackFortifyCd",
    t"DroneCompanion.HackOctantCd",
    t"DroneCompanion.HackWyvernCd",
    t"DroneCompanion.HackGriffinCd",
    t"DroneCompanion.HackBombusCd",
    t"DroneCompanion.HackMinotaurCd"
  ];
}

private static func DC_CooldownFor(id: TweakDBID) -> TweakDBID {
  let ids: array<TweakDBID> = DC_HackIDs();
  let cds: array<TweakDBID> = DC_CooldownIDs();
  let i: Int32 = 0;
  while i < ArraySize(ids) {
    if ids[i] == id {
      return cds[i];
    };
    i += 1;
  };
  return TDBID.None();
}

@wrapMethod(ScriptedPuppet)
private final func TranslateChoicesIntoQuickSlotCommands(const choices: script_ref<array<ref<PuppetAction>>>, commands: script_ref<array<ref<QuickhackData>>>) -> Void {
  wrappedMethod(choices, commands);
  if !DC_IsCompanionDrone(this) {
    return;
  };
  let ses = GameInstance.GetStatusEffectSystem(this.GetGame());
  if !IsDefined(ses) {
    return;
  };
  let i: Int32 = 0;
  while i < ArraySize(Deref(commands)) {
    let cmd: ref<QuickhackData> = Deref(commands)[i];
    let action: ref<PuppetAction> = cmd.m_action as PuppetAction;
    if IsDefined(action) {
      let cooldown: TweakDBID = DC_CooldownFor(action.GetObjectActionID());
      if TDBID.IsValid(cooldown) && ses.HasStatusEffect(this.GetEntityID(), cooldown) {
        cmd.m_isLocked = true;
        cmd.m_inactiveReason = "Mod-DroneCompanion-Hack-Cooling";
        cmd.m_actionState = EActionInactivityReson.Locked;
      };
    };
    i += 1;
  };
}

private static func DC_ListHasAction(list: script_ref<array<PlayerQuickhackData>>, id: TweakDBID) -> Bool {
  let i: Int32 = 0;
  while i < ArraySize(Deref(list)) {
    if IsDefined(Deref(list)[i].actionRecord) && Deref(list)[i].actionRecord.GetID() == id {
      return true;
    };
    i += 1;
  };
  return false;
}

@wrapMethod(RPGManager)
public final static func GetPlayerQuickHackListWithQuality(player: wref<PlayerPuppet>) -> array<PlayerQuickhackData> {
  let list: array<PlayerQuickhackData> = wrappedMethod(player);
  if !IsDefined(player) {
    return list;
  };
  let ids: array<TweakDBID> = DC_HackIDs();
  let added: Int32 = 0;
  let data: PlayerQuickhackData;
  let record: wref<ObjectAction_Record>;
  let i: Int32 = 0;
  while i < ArraySize(ids) {
    record = TweakDBInterface.GetObjectActionRecord(ids[i]);
    if IsDefined(record) && !DC_ListHasAction(list, ids[i]) {
      data.actionRecord = record;
      data.quality = 4;
      ArrayPush(list, data);
      added += 1;
    };
    i += 1;
  };
  if added > 0 {
    PlayerPuppet.ChacheQuickHackList(player, list);
  };
  return list;
}

@wrapMethod(GameObject)
public final func FindAndRewardKiller(killType: gameKillType, opt instigator: wref<GameObject>) -> Void {
  let arenaKill: Bool = DC_IsCompanionDrone(this) && DC_IsArena(this);
  if DC_IsCompanionDrone(instigator) {
    let player = GetPlayer(this.GetGame());
    if IsDefined(player) {
      player.DCKill(instigator);
      if !arenaKill {
        instigator = player;
      };
    };
  };
  if !arenaKill {
    let i: Int32 = 0;
    while i < ArraySize(this.m_receivedDamageHistory) {
      if DC_IsCompanionDrone(this.m_receivedDamageHistory[i].source) {
        this.m_receivedDamageHistory[i].source = GetPlayer(this.GetGame());
      };
      i += 1;
    };
  };
  wrappedMethod(killType, instigator);
}

@wrapMethod(DamageSystem)
private final func Process(hitEvent: ref<gameHitEvent>, cache: ref<CacheData>) -> Void {
  let instigator: wref<ScriptedPuppet> = hitEvent.attackData.GetInstigator() as ScriptedPuppet;
  let target: wref<ScriptedPuppet> = hitEvent.target as ScriptedPuppet;
  if IsDefined(instigator) && IsDefined(target) {
    let instOurs: Bool = DC_IsCompanionDrone(instigator);
    let targOurs: Bool = DC_IsCompanionDrone(target);
    if instOurs && !targOurs && !target.IsPlayer() {
      target.m_dcLastAggressor = instigator;
    };
    if DC_IsRival(instigator) && target.IsPlayer() {
      return;
    };
    if instOurs && targOurs && DC_IsArena(instigator) && DC_IsArena(target) {
      wrappedMethod(hitEvent, cache);
      return;
    };
    if (instOurs && targOurs) || (instigator.IsPlayer() && targOurs) || (instOurs && target.IsPlayer()) {
      return;
    };
  };
  wrappedMethod(hitEvent, cache);
}

@wrapMethod(ReactionManagerComponent)
protected cb func OnDetectedEvent(evt: ref<OnDetectedEvent>) -> Bool {
  if IsDefined(evt) && IsDefined(evt.target) && evt.isVisible && DC_IsCompanionDrone(evt.target) && !DC_IsPassive(evt.target) {
    let owner: wref<ScriptedPuppet> = this.GetOwnerPuppet();
    if IsDefined(owner) && (!DC_IsCompanionDrone(owner)
      || (DC_IsArena(owner) && DC_IsArena(evt.target))) {
      TargetTrackingExtension.InjectThreat(owner, evt.target);
    };
  };
  return wrappedMethod(evt);
}

@wrapMethod(SenseComponent)
public final static func ShouldIgnoreIfPlayerCompanion(owner: wref<Entity>, target: wref<Entity>) -> Bool {
  if DC_IsCompanionDrone(target as GameObject) && !DC_IsPassive(target as GameObject) {
    return false;
  };
  return wrappedMethod(owner, target);
}

@wrapMethod(PlayerPuppet)
private final func UpdateLookAtObject(target: ref<GameObject>) -> Void {
  wrappedMethod(target);
  if IsDefined(target) && DC_IsCompanionDrone(target) {
    this.m_isAimingAtFriendly = false;
  };
}

@wrapMethod(NpcNameplateGameController)
private final func HelperCheckDistance(entity: ref<Entity>) -> Bool {
  if IsDefined(entity) && DC_IsCompanionDrone(entity as GameObject) {
    return true;
  };
  return wrappedMethod(entity);
}

@wrapMethod(NpcNameplateGameController)
protected cb func OnNameplateDataChanged(value: Variant) -> Bool {
  wrappedMethod(value);
  let data: NPCNextToTheCrosshair = FromVariant<NPCNextToTheCrosshair>(value);
  if IsDefined(data.npc) && DC_IsCompanionDrone(data.npc) {
    this.m_visualController.UpdateNPCNamesEnabled(true);
  };
}

@wrapMethod(NameplateVisualsLogicController)
public final func SetVisualData(puppet: ref<GameObject>, const incomingData: script_ref<NPCNextToTheCrosshair>, opt isNewNpc: Bool) -> Void {
  wrappedMethod(puppet, incomingData, isNewNpc);
  if IsDefined(puppet) && DC_IsCompanionDrone(puppet) {
    this.UpdateHealthbarColor(false);
    inkWidgetRef.SetVisible(this.m_healthbarWidget, true);
  };
}

@wrapMethod(NameplateVisualsLogicController)
public final func UpdateHealthbarColor(isHostile: Bool) -> Void {
  if IsDefined(this.m_cachedPuppet) && DC_IsCompanionDrone(this.m_cachedPuppet) {
    inkWidgetRef.SetState(this.m_healthbarWidget, n"Friendly");
    inkWidgetRef.SetState(this.m_healthBarFull, n"Friendly");
    inkWidgetRef.SetState(this.m_healthBarFrame, n"Friendly");
    return;
  };
  wrappedMethod(isHostile);
}

@wrapMethod(DamageDigitsGameController)
protected cb func OnDamageAdded(value: Variant) -> Bool {
  if !IsDefined(this.m_realOwner) {
    return wrappedMethod(value);
  };
  let list: array<DamageInfo> = FromVariant<array<DamageInfo>>(value);
  let changed: Bool = false;
  let i: Int32 = 0;
  while i < ArraySize(list) {
    if DC_IsCompanionDrone(list[i].instigator) {
      let info: DamageInfo = list[i];
      info.instigator = this.m_realOwner;
      list[i] = info;
      changed = true;
    };
    i += 1;
  };
  if changed {
    return wrappedMethod(ToVariant(list));
  };
  return wrappedMethod(value);
}


@addField(PlayerPuppet)
let m_dcMechArmor: Bool;

@addMethod(PlayerPuppet)
public func DCSetMechArmor(on: Bool) -> Void {
  this.m_dcMechArmor = on;
}

@wrapMethod(ScriptedWeakspotObject)
protected func ReadTweakData() -> Void {
  wrappedMethod();
  if !this.m_weakspotRecordData.m_isInvulnerable && DC_IsCompanionDrone(this.GetOwner()) {
    let player = GameInstance.GetPlayerSystem(this.GetGame()).GetLocalPlayerMainGameObject() as PlayerPuppet;
    if IsDefined(player) && player.m_dcMechArmor {
      this.m_weakspotRecordData.m_isInvulnerable = true;
    };
  };
}

private static func DC_CraftItemIds() -> array<TweakDBID> {
  return [
    t"DroneCompanion.CraftBombus",
    t"DroneCompanion.CraftFlathead",
    t"DroneCompanion.CraftOctant",
    t"DroneCompanion.CraftAndroid",
    t"DroneCompanion.CraftGriffin",
    t"DroneCompanion.CraftWyvern",
    t"DroneCompanion.CraftMinotaur",
    t"DroneCompanion.CraftCerberus",
    t"DroneCompanion.CraftChimera"
  ];
}

@addMethod(PlayerPuppet)
public func DCLearnRecipes() -> Void {
  let ids: array<TweakDBID> = DC_CraftItemIds();
  let i: Int32 = 0;
  while i < ArraySize(ids) {
    let req: ref<AddRecipeRequest> = new AddRecipeRequest();
    req.owner = this;
    req.recipe = ids[i];
    req.amount = 1;
    GameInstance.GetScriptableSystemsContainer(this.GetGame()).Get(n"CraftingSystem").QueueRequest(req);
    i += 1;
  };
}

@wrapMethod(CraftingMainLogicController)
protected func SetupFilters() -> Void {
  if IsDefined(this as CraftingLogicController) {
    ArrayPush(this.m_filters, EnumInt(DroneGearFilter.Category()));
  };
  wrappedMethod();
}

@wrapMethod(CraftingDataView)
public func FilterItem(item: ref<IScriptable>) -> Bool {
  if !Equals(this.m_itemFilterType, DroneGearFilter.Category()) {
    return wrappedMethod(item);
  };
  let recipeData: ref<RecipeData> = item as RecipeData;
  if IsDefined(recipeData) && IsDefined(recipeData.id) && recipeData.id.TagsContains(n"DroneCompanionCraft") {
    return true;
  };
  let craftData: ref<ItemCraftingData> = item as ItemCraftingData;
  if IsDefined(craftData) {
    let rec: ref<Item_Record> = TweakDBInterface.GetItemRecord(ItemID.GetTDBID(InventoryItemData.GetID(craftData.inventoryItem)));
    if IsDefined(rec) && rec.TagsContains(n"DroneCompanionCraft") {
      return true;
    };
  };
  return false;
}


@addField(ScriptedPuppet)
let m_dcLastAggressor: wref<ScriptedPuppet>;

private static func DC_ModulateThreat(threat: wref<GameObject>, out threatValue: Float) -> Void {
  if !DC_IsCompanionDrone(threat) || DC_IsPassive(threat) {
    return;
  };
  let sp: wref<ScriptedPuppet> = threat as ScriptedPuppet;
  if !IsDefined(sp) {
    return;
  };
  let hpPct: Float = GameInstance.GetStatPoolsSystem(sp.GetGame())
    .GetStatPoolValue(Cast<StatsObjectID>(sp.GetEntityID()), gamedataStatPoolType.Health, true);
  threatValue = threatValue * (0.5 + hpPct / 100.0);
}

@wrapMethod(AIActionTarget)
private final static func RegularThreatCalculation(owner: wref<ScriptedPuppet>, ownerPos: Vector4, targetTrackerComponent: ref<TargetTrackerComponent>, newTargetObject: wref<GameObject>, threat: wref<GameObject>, timeSinceTargetChange: Float, currentTime: Float, out threatValue: Float) -> Void {
  wrappedMethod(owner, ownerPos, targetTrackerComponent, newTargetObject, threat, timeSinceTargetChange, currentTime, threatValue);
  DC_ModulateThreat(threat, threatValue);
}

@wrapMethod(AIActionTarget)
private final static func BossThreatCalculation(owner: wref<ScriptedPuppet>, ownerPos: Vector4, targetTrackerComponent: ref<TargetTrackerComponent>, newTargetObject: wref<GameObject>, threat: wref<GameObject>, timeSinceTargetChange: Float, currentTime: Float, out threatValue: Float) -> Void {
  wrappedMethod(owner, ownerPos, targetTrackerComponent, newTargetObject, threat, timeSinceTargetChange, currentTime, threatValue);
  DC_ModulateThreat(threat, threatValue);
}

@wrapMethod(AIActionHelper)
public final static func TryChangingAttitudeToHostile(owner: ref<ScriptedPuppet>, target: ref<GameObject>) -> Bool {
  if IsDefined(owner) && IsDefined(target) && target.IsPlayer() && !DC_IsCompanionDrone(owner) {
    let playerDist: Float = Vector4.Distance(target.GetWorldPosition(), owner.GetWorldPosition());
    if playerDist > 20.0 {
      let bot: wref<ScriptedPuppet> = owner.m_dcLastAggressor;
      if IsDefined(bot) && DC_IsCompanionDrone(bot) && ScriptedPuppet.IsActive(bot)
        && Vector4.Distance(bot.GetWorldPosition(), owner.GetWorldPosition()) <= 30.0 {
        if wrappedMethod(owner, bot) {
          TargetTrackingExtension.InjectThreat(owner, bot, 4.0);
          return true;
        };
      };
    };
  };
  return wrappedMethod(owner, target);
}

private static func DC_IsFlinchReaction(reactionPlayed: animHitReactionType) -> Bool {
  return Equals(reactionPlayed, animHitReactionType.Stagger)
    || Equals(reactionPlayed, animHitReactionType.Impact)
    || Equals(reactionPlayed, animHitReactionType.Pain);
}

private static func DC_IsMechPuppet(obj: wref<GameObject>) -> Bool {
  let np: wref<NPCPuppet> = obj as NPCPuppet;
  return IsDefined(np) && Equals(np.GetNPCType(), gamedataNPCType.Mech);
}

@wrapMethod(HitReactionComponent)
private final func SendDataToAIBehavior(reactionPlayed: animHitReactionType) -> Void {
  if DC_IsFlinchReaction(reactionPlayed) && IsDefined(this.m_attackData) {
    let instigator: wref<GameObject> = this.m_attackData.GetInstigator();
    if DC_IsCompanionDrone(this.m_ownerNPC) && !DC_IsMechPuppet(instigator) {
      return;
    };
    if IsDefined(this.m_ownerNPC) && this.m_ownerNPC.IsBoss() && DC_IsCompanionDrone(instigator) {
      return;
    };
  };
  wrappedMethod(reactionPlayed);
}

@wrapMethod(HitReactionComponent)
protected final func SendMechDataToAIBehavior(reactionPlayed: animHitReactionType) -> Void {
  if DC_IsFlinchReaction(reactionPlayed) && IsDefined(this.m_attackData) {
    let instigator: wref<GameObject> = this.m_attackData.GetInstigator();
    if DC_IsCompanionDrone(this.m_ownerNPC) && !DC_IsMechPuppet(instigator) {
      return;
    };
    if DC_IsMechPuppet(this.m_ownerNPC) && !DC_IsMechPuppet(instigator) && DC_IsCompanionDrone(instigator) {
      return;
    };
  };
  wrappedMethod(reactionPlayed);
}


@wrapMethod(InventoryItemDisplayController)
protected func UpdateBlueprint() -> Void {
  wrappedMethod();
  if IsDefined(this.m_recipeData) && IsDefined(this.m_recipeData.id)
    && this.m_recipeData.id.TagsContains(n"DroneCompanionCraft") {
    inkWidgetRef.SetVisible(this.m_backgroundBlueprint, false);
    inkWidgetRef.SetVisible(this.m_iconBlueprint, false);
    inkImageRef.SetState(this.m_itemImage, n"Default");
    inkImageRef.Get(this.m_itemImage).DisableAllEffectsByType(inkEffectType.ColorFill);
  };
}


@addMethod(PlayerPuppet)
public func DCCraftItem(itemId: TweakDBID) -> Bool {
  let cs: ref<CraftingSystem> = GameInstance.GetScriptableSystemsContainer(this.GetGame()).Get(n"CraftingSystem") as CraftingSystem;
  let rec: ref<Item_Record> = TweakDBInterface.GetItemRecord(itemId);
  if !IsDefined(cs) || !IsDefined(rec) || !cs.CanItemBeCrafted(rec) {
    return false;
  };
  let req: ref<CraftItemRequest> = new CraftItemRequest();
  req.target = this;
  req.itemRecord = rec;
  req.amount = 1;
  cs.QueueRequest(req);
  return true;
}
