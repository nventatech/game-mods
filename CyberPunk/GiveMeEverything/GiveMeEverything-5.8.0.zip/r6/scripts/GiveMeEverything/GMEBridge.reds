public class GMEBridgeSystem extends ScriptableSystem {
    public let levelCap: Int32;
    public let damageTaken: Int32;
    public let damageSet: Bool;
    public let alwaysRestock: Bool;
}

public abstract class GMEBridge extends IScriptable {
    public static func Get(game: GameInstance) -> ref<GMEBridgeSystem> {
        return GameInstance.GetScriptableSystemsContainer(game).Get(n"GMEBridgeSystem") as GMEBridgeSystem;
    }

    public static func SetLevelCap(player: ref<GameObject>, value: Int32) -> Void {
        if !IsDefined(player) {
            return;
        }
        let system = GMEBridge.Get(player.GetGame());
        if IsDefined(system) {
            system.levelCap = value;
        }
    }

    public static func SetDamageTaken(player: ref<GameObject>, percent: Int32) -> Void {
        if !IsDefined(player) {
            return;
        }
        let system = GMEBridge.Get(player.GetGame());
        if IsDefined(system) {
            system.damageTaken = Max(0, Min(percent, 100));
            system.damageSet = true;
        }
    }

    public static func SetAlwaysRestock(player: ref<GameObject>, on: Bool) -> Void {
        if !IsDefined(player) {
            return;
        }
        let system = GMEBridge.Get(player.GetGame());
        if IsDefined(system) {
            system.alwaysRestock = on;
        }
    }

    public static func RestockAll(player: ref<GameObject>) -> Int32 {
        if !IsDefined(player) {
            return 0;
        }
        let market = MarketSystem.GetInstance(player.GetGame());
        if !IsDefined(market) {
            return 0;
        }
        return market.GMEFlagAllVendors();
    }

    public static func RestockVendor(vendorObject: ref<GameObject>) -> Bool {
        if !IsDefined(vendorObject) {
            return false;
        }
        let market = MarketSystem.GetInstance(vendorObject.GetGame());
        if !IsDefined(market) {
            return false;
        }
        let vendor = market.GetVendor(vendorObject);
        if !IsDefined(vendor) {
            return false;
        }
        vendor.gmeRestock = true;
        return true;
    }

    public static func LevelCapFor(owner: wref<GameObject>, type: gamedataProficiencyType) -> Int32 {
        if NotEquals(type, gamedataProficiencyType.Level) || !IsDefined(owner) {
            return 0;
        }
        let system = GMEBridge.Get(owner.GetGame());
        if !IsDefined(system) {
            return 0;
        }
        return system.levelCap;
    }

    public static func ClampLevel(owner: wref<GameObject>, type: gamedataProficiencyType, value: Int32) -> Int32 {
        let cap = GMEBridge.LevelCapFor(owner, type);
        if cap > 0 && value > cap {
            return cap;
        }
        return value;
    }

    public static func DamageTaken(game: GameInstance) -> Int32 {
        let system = GMEBridge.Get(game);
        if !IsDefined(system) || !system.damageSet {
            return 100;
        }
        return system.damageTaken;
    }

    public static func AlwaysRestock(game: GameInstance) -> Bool {
        let system = GMEBridge.Get(game);
        return IsDefined(system) && system.alwaysRestock;
    }
}

@wrapMethod(PlayerDevelopmentData)
private final const func GetProficiencyMaxLevel(type: gamedataProficiencyType) -> Int32 {
    return GMEBridge.ClampLevel(this.m_owner, type, wrappedMethod(type));
}

@wrapMethod(PlayerDevelopmentData)
public final const func GetProficiencyAbsoluteMaxLevel(type: gamedataProficiencyType) -> Int32 {
    return GMEBridge.ClampLevel(this.m_owner, type, wrappedMethod(type));
}

@wrapMethod(PlayerDevelopmentData)
public final const func IsProficiencyMaxLvl(type: gamedataProficiencyType) -> Bool {
    if wrappedMethod(type) {
        return true;
    }
    let cap = GMEBridge.LevelCapFor(this.m_owner, type);
    return cap > 0 && this.GetProficiencyLevel(type) >= cap;
}

@wrapMethod(DamageSystem)
private final func ProcessPlayerIncomingDamageMultiplier(hitEvent: ref<gameHitEvent>) -> Void {
    wrappedMethod(hitEvent);
    if IsDefined(hitEvent.target as PlayerPuppet) {
        let percent = GMEBridge.DamageTaken(hitEvent.target.GetGame());
        if percent < 100 {
            hitEvent.attackComputed.MultAttackValue(Cast<Float>(percent) / 100.0);
        }
    }
}

@addField(Vendor)
public let gmeRestock: Bool;

@wrapMethod(Vendor)
public final func OnVendorMenuOpen() -> Void {
    if GMEBridge.AlwaysRestock(this.m_gameInstance) {
        this.gmeRestock = true;
    }
    wrappedMethod();
}

@wrapMethod(Vendor)
protected func ShouldRegenerateStock() -> Bool {
    if this.gmeRestock {
        this.gmeRestock = false;
        return true;
    }
    return wrappedMethod();
}

@addMethod(MarketSystem)
public final func GMEFlagAllVendors() -> Int32 {
    let count = 0;
    for vendor in this.m_vendors {
        if IsDefined(vendor) {
            vendor.gmeRestock = true;
            count += 1;
        }
    }
    for vendor in this.m_vendingMachinesVendors {
        if IsDefined(vendor) {
            vendor.gmeRestock = true;
            count += 1;
        }
    }
    return count;
}
