public class GMEAimBridge extends IScriptable {
    public static func CameraPosition(player: ref<PlayerPuppet>) -> Vector4 {
        let transform: Transform;
        GameInstance.GetCameraSystem(player.GetGame()).GetActiveCameraWorldTransform(transform);
        return Transform.GetPosition(transform);
    }

    public static func LookAt(player: ref<PlayerPuppet>, point: Vector4, duration: Float, maxDuration: Float, snap: Bool) -> Void {
        let request: AimRequest;
        if !IsDefined(player) {
            return;
        }
        request.lookAtTarget = point;
        request.duration = duration;
        request.maxDuration = maxDuration;
        request.adjustPitch = true;
        request.adjustYaw = true;
        request.endOnTargetReached = snap;
        request.endOnCameraInputApplied = false;
        request.endOnTimeExceeded = true;
        request.endOnAimingStopped = false;
        request.easeIn = false;
        request.easeOut = false;
        request.checkRange = false;
        request.precision = 0.001;
        request.processAsInput = true;
        request.bodyPartsTracking = false;
        let targeting = GameInstance.GetTargetingSystem(player.GetGame());
        if snap {
            targeting.BreakLookAt(player);
        }
        targeting.LookAt(player, request);
    }

    public static func Release(player: ref<PlayerPuppet>) -> Void {
        if IsDefined(player) {
            GameInstance.GetTargetingSystem(player.GetGame()).BreakLookAt(player);
        }
    }
}
