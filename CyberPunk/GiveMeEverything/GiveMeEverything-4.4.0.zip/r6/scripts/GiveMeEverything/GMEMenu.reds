module GiveMeEverything

import Codeware.UI.*

public struct GMERow {
  public let id: String;
  public let kind: String;
  public let label: String;
  public let value: String;
  public let icon: String;
  public let res: String;
}

public class GMEMenuPopup extends InGamePopup {
  protected let m_header: ref<InGamePopupHeader>;
  protected let m_footer: ref<InGamePopupFooter>;
  protected let m_content: ref<InGamePopupContent>;
  protected let m_tabBar: wref<inkVerticalPanel>;
  protected let m_tabTexts: array<wref<inkText>>;
  protected let m_tabMarks: array<wref<inkRectangle>>;
  protected let m_tabs: array<String>;
  protected let m_tab: Int32;
  protected let m_listPanel: wref<inkVerticalPanel>;
  protected let m_fixedPanel: wref<inkVerticalPanel>;
  protected let m_rowFixed: array<Bool>;
  protected let m_footerText: String;
  protected let m_hintLine: String;
  protected let m_listWidth: Float;
  protected let m_rowWidth: Float;
  protected let m_rows: array<GMERow>;
  protected let m_rowLabels: array<wref<inkText>>;
  protected let m_rowValues: array<wref<inkText>>;
  protected let m_rowMarks: array<wref<inkRectangle>>;
  protected let m_rowTops: array<Float>;
  protected let m_contentHeight: Float;
  protected let m_viewHeight: Float;
  protected let m_view: wref<inkScrollArea>;
  protected let m_scrollBar: wref<inkCanvas>;
  protected let m_scrollTrack: wref<inkRectangle>;
  protected let m_scrollThumb: wref<inkRectangle>;
  protected let m_rowStripes: array<wref<inkRectangle>>;
  protected let m_rowBars: array<wref<inkRectangle>>;
  protected let m_sel: Int32;
  protected let m_scroll: Float;
  protected let m_payload: String;
  protected let m_owner: wref<PlayerPuppet>;

  public func GetName() -> CName {
    return n"GMEMenuPopup";
  }

  public func UseCursor() -> Bool {
    return true;
  }

  public func GMEIsOpen() -> Bool {
    return this.IsInitialized();
  }

  public func GMEBind(player: ref<PlayerPuppet>) -> Void {
    this.m_owner = player;
  }

  protected func GMEEmit(action: String) -> Void {
    if IsDefined(this.m_owner) {
      this.m_owner.GMEEmit(action);
    };
  }

  protected func GMEAccent() -> HDRColor {
    return new HDRColor(0.98, 0.85, 0.20, 1.0);
  }

  protected func GMERankColor(rank: Int32) -> HDRColor {
    if rank >= 10 {
      return new HDRColor(1.00, 0.60, 0.20, 1.0);
    };
    if rank >= 8 {
      return new HDRColor(0.75, 0.45, 0.95, 1.0);
    };
    if rank >= 6 {
      return new HDRColor(0.35, 0.62, 1.00, 1.0);
    };
    if rank >= 4 {
      return new HDRColor(0.45, 0.85, 0.45, 1.0);
    };
    return new HDRColor(0.82, 0.82, 0.85, 1.0);
  }

  protected func GMEColorOf(kind: String, selected: Bool) -> HDRColor {
    if selected {
      return new HDRColor(1.0, 1.0, 1.0, 1.0);
    };
    if Equals(kind, "head") {
      return this.GMEAccent();
    };
    if Equals(kind, "warn") {
      return new HDRColor(1.0, 0.62, 0.20, 1.0);
    };
    if Equals(kind, "dim") {
      return new HDRColor(0.50, 0.50, 0.55, 1.0);
    };
    return new HDRColor(0.82, 0.82, 0.85, 1.0);
  }

  protected func GMEIsSelectable(kind: String) -> Bool {
    return Equals(kind, "btn") || Equals(kind, "toggle") || Equals(kind, "choice") || Equals(kind, "check")
      || Equals(kind, "slider") || Equals(kind, "item")
      || Equals(kind, "fbtn") || Equals(kind, "fchoice") || Equals(kind, "ftoggle");
  }

  protected func GMEIsFixed(kind: String) -> Bool {
    return Equals(kind, "fbtn") || Equals(kind, "fchoice") || Equals(kind, "ftoggle");
  }

  protected func GMEIsWrapped(kind: String) -> Bool {
    return Equals(kind, "dim") || Equals(kind, "warn") || Equals(kind, "text");
  }

  protected func GMEIconOf(path: String) -> ref<UIIcon_Record> {
    let id: TweakDBID = TDBID.Create(path);
    let itemRec: ref<Item_Record> = TweakDBInterface.GetItemRecord(id);
    if IsDefined(itemRec) {
      return itemRec.Icon();
    };
    let vehRec: ref<Vehicle_Record> = TweakDBInterface.GetVehicleRecord(id);
    if IsDefined(vehRec) {
      return vehRec.Icon();
    };
    return null;
  }

  protected func GMERowHeight(row: GMERow) -> Float {
    if Equals(row.kind, "head") {
      return 84.0;
    };
    if this.GMEIsWrapped(row.kind) {
      let perLine: Int32 = StrLen(row.value) > 0 ? 62 : 92;
      let lines: Int32 = (StrLen(row.label) / perLine) + 1;
      return 40.0 * Cast<Float>(lines) + 16.0;
    };
    return 58.0;
  }

  protected func GMEMakeText(size: Int32, parent: ref<inkCompoundWidget>) -> ref<inkText> {
    let text: ref<inkText> = new inkText();
    text.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
    text.SetFontStyle(n"Medium");
    text.SetFontSize(size);
    text.SetFitToContent(true);
    text.SetVAlign(inkEVerticalAlign.Top);
    text.Reparent(parent);
    return text;
  }

  protected func GMEMeasure() -> Void {
    let aspect: Float = 1.7778;
    if IsDefined(this.m_owner) {
      let measured: Float = GameInstance.GetCameraSystem(this.m_owner.GetGame()).GetAspectRatio();
      if measured > 0.5 {
        aspect = measured;
      };
    };
    let canvasWidth: Float = 2160.0 * aspect;
    this.m_listWidth = MinF(2730.0, MaxF(1400.0, canvasWidth - 700.0));
    this.m_rowWidth = this.m_listWidth - 26.0;
  }

  protected cb func OnCreate() {
    super.OnCreate();
    this.GMEMeasure();
    this.m_container.SetSize(Vector2(this.m_listWidth + 130.0, 1560.0));

    this.m_header = InGamePopupHeader.Create();
    this.m_header.SetTitle("GIVE ME EVERYTHING");
    this.m_header.SetFluffLeft("");
    this.m_header.SetFluffRight("GIVEMEEVERYTHING");
    this.m_header.Reparent(this);

    this.m_footer = InGamePopupFooter.Create();
    this.m_footer.SetFluffIcon(n"fluff_triangle2");
    this.m_footer.Reparent(this);

    this.m_content = InGamePopupContent.Create();
    this.m_content.Reparent(this);

    let outer: ref<inkVerticalPanel> = new inkVerticalPanel();
    outer.SetName(n"outer");
    outer.SetMargin(inkMargin(24.0, 8.0, 0.0, 0.0));
    outer.Reparent(this.m_content.GetRootCompoundWidget());

    let tabBar: ref<inkVerticalPanel> = new inkVerticalPanel();
    tabBar.SetName(n"tabs");
    tabBar.SetMargin(inkMargin(0.0, 0.0, 0.0, 12.0));
    tabBar.Reparent(outer);
    this.m_tabBar = tabBar;

    let divider: ref<inkRectangle> = new inkRectangle();
    divider.SetSize(this.m_listWidth, 2.0);
    divider.SetTintColor(new HDRColor(0.70, 0.70, 0.75, 1.0));
    divider.SetOpacity(0.18);
    divider.SetMargin(inkMargin(0.0, 0.0, 0.0, 20.0));
    divider.Reparent(outer);

    let fixedRow: ref<inkHorizontalPanel> = new inkHorizontalPanel();
    fixedRow.SetName(n"fixedRow");
    fixedRow.SetMargin(inkMargin(0.0, 0.0, 0.0, 10.0));
    fixedRow.Reparent(outer);

    let fixed: ref<inkVerticalPanel> = new inkVerticalPanel();
    fixed.SetName(n"fixed");
    fixed.SetSize(Vector2(this.m_rowWidth, 0.0));
    fixed.SetFitToContent(true);
    fixed.Reparent(fixedRow);
    this.m_fixedPanel = fixed;

    let body: ref<inkHorizontalPanel> = new inkHorizontalPanel();
    body.SetName(n"body");
    body.Reparent(outer);

    this.m_viewHeight = 880.0;
    let view: ref<inkScrollArea> = new inkScrollArea();
    view.SetSize(Vector2(this.m_rowWidth, this.m_viewHeight));
    view.SetUseInternalMask(true);
    view.SetConstrainContentPosition(true);
    view.Reparent(body);
    this.m_view = view;

    let list: ref<inkVerticalPanel> = new inkVerticalPanel();
    list.SetName(n"list");
    list.Reparent(view);
    this.m_listPanel = list;

    let bar: ref<inkCanvas> = new inkCanvas();
    bar.SetSize(8.0, 880.0);
    bar.SetMargin(inkMargin(18.0, 0.0, 0.0, 0.0));
    bar.Reparent(body);
    this.m_scrollBar = bar;

    let track: ref<inkRectangle> = new inkRectangle();
    track.SetSize(4.0, 880.0);
    track.SetTintColor(new HDRColor(0.70, 0.70, 0.75, 1.0));
    track.SetOpacity(0.10);
    track.Reparent(bar);
    this.m_scrollTrack = track;

    let thumb: ref<inkRectangle> = new inkRectangle();
    thumb.SetSize(8.0, 120.0);
    thumb.SetTintColor(this.GMEAccent());
    thumb.SetOpacity(0.55);
    thumb.Reparent(bar);
    this.m_scrollThumb = thumb;

    this.GMERebuildTabs();
    this.GMERebuildRows();
  }

  public func GMESetState(payload: String) -> Void {
    if Equals(payload, this.m_payload) {
      return;
    };
    let tabsBefore: Int32 = ArraySize(this.m_tabs);
    let keepId: String = this.GMESelectedId();
    this.m_payload = payload;
    this.GMEParse(payload);
    this.GMERestoreSelection(keepId);
    if tabsBefore != ArraySize(this.m_tabs) {
      this.GMERebuildTabs();
    };
    this.GMERebuildRows();
  }

  protected func GMEParse(payload: String) -> Void {
    ArrayClear(this.m_rows);
    let lines: array<String> = StrSplit(payload, "\n");
    let i: Int32 = 0;
    while i < ArraySize(lines) {
      let f: array<String> = StrSplit(lines[i], "\t", true);
      if ArraySize(f) >= 2 {
        if Equals(f[0], "T") {
          ArrayClear(this.m_tabs);
          let t: Int32 = 1;
          while t < ArraySize(f) {
            ArrayPush(this.m_tabs, f[t]);
            t += 1;
          };
        } else {
          if Equals(f[0], "A") {
            this.m_tab = StringToInt(f[1], 0);
          } else {
            if Equals(f[0], "F") {
              this.GMESetFooter(f[1]);
            } else {
            if Equals(f[0], "H") {
              this.GMEApplyHints(lines[i]);
            } else {
              if Equals(f[0], "R") && ArraySize(f) >= 4 {
                let row: GMERow;
                row.id = f[1];
                row.kind = f[2];
                row.label = f[3];
                row.value = ArraySize(f) >= 5 ? f[4] : "";
                row.icon = ArraySize(f) >= 6 ? f[5] : "";
                row.res = ArraySize(f) >= 7 ? f[6] : "";
                ArrayPush(this.m_rows, row);
              };
            };
            };
          };
        };
      };
      i += 1;
    };
    this.GMEClampSelection(1);
  }

  protected func GMEApplyHints(line: String) -> Void {
    if Equals(line, this.m_hintLine) || !IsDefined(this.m_footer) {
      return;
    };
    this.m_hintLine = line;
    let hints: wref<ButtonHintsEx> = this.m_footer.GetHints();
    if !IsDefined(hints) {
      return;
    };
    hints.ClearButtonHints();
    let f: array<String> = StrSplit(line, "\t", true);
    let names: array<CName>;
    ArrayPush(names, n"click");
    ArrayPush(names, n"popup_navigate_right");
    ArrayPush(names, n"next_menu");
    ArrayPush(names, n"next_sub_menu");
    ArrayPush(names, n"cancel");
    let i: Int32 = 1;
    while i < ArraySize(f) && i <= ArraySize(names) {
      if StrLen(f[i]) > 0 {
        hints.AddButtonHint(names[i - 1], f[i]);
      };
      i += 1;
    };
  }

  protected func GMESelectedId() -> String {
    if this.m_sel < 0 || this.m_sel >= ArraySize(this.m_rows) {
      return "";
    };
    return this.m_rows[this.m_sel].id;
  }

  protected func GMERestoreSelection(id: String) -> Void {
    if StrLen(id) == 0 {
      return;
    };
    let i: Int32 = 0;
    while i < ArraySize(this.m_rows) {
      if Equals(this.m_rows[i].id, id) {
        this.m_sel = i;
        return;
      };
      i += 1;
    };
  }

  protected func GMEClampSelection(dir: Int32) -> Void {
    if ArraySize(this.m_rows) == 0 {
      this.m_sel = -1;
      return;
    };
    if this.m_sel < 0 {
      this.m_sel = 0;
    };
    if this.m_sel >= ArraySize(this.m_rows) {
      this.m_sel = ArraySize(this.m_rows) - 1;
    };
    let steps: Int32 = 0;
    while steps <= ArraySize(this.m_rows) {
      if this.GMEIsSelectable(this.m_rows[this.m_sel].kind) {
        return;
      };
      this.m_sel += dir;
      if this.m_sel < 0 {
        this.m_sel = ArraySize(this.m_rows) - 1;
      };
      if this.m_sel >= ArraySize(this.m_rows) {
        this.m_sel = 0;
      };
      steps += 1;
    };
    this.m_sel = -1;
  }

  protected func GMERebuildTabs() -> Void {
    if !IsDefined(this.m_tabBar) {
      return;
    };
    this.m_tabBar.RemoveAllChildren();
    ArrayClear(this.m_tabTexts);
    ArrayClear(this.m_tabMarks);
    let rowWidth: Float = 0.0;
    let row: ref<inkHorizontalPanel> = new inkHorizontalPanel();
    row.SetMargin(inkMargin(0.0, 0.0, 0.0, 6.0));
    row.Reparent(this.m_tabBar);
    let i: Int32 = 0;
    while i < ArraySize(this.m_tabs) {
      let width: Float = Cast<Float>(StrLen(this.m_tabs[i])) * 17.0 + 28.0;
      if rowWidth > 0.0 && rowWidth + width > this.m_listWidth {
        row = new inkHorizontalPanel();
        row.SetMargin(inkMargin(0.0, 0.0, 0.0, 6.0));
        row.Reparent(this.m_tabBar);
        rowWidth = 0.0;
      };
      rowWidth += width;

      let cell: ref<inkVerticalPanel> = new inkVerticalPanel();
      cell.SetMargin(inkMargin(0.0, 0.0, 28.0, 0.0));
      cell.Reparent(row);

      let tab: ref<inkText> = this.GMEMakeText(30, cell);
      tab.SetMargin(inkMargin(10.0, 4.0, 10.0, 4.0));
      tab.SetHAlign(inkEHorizontalAlign.Center);
      tab.SetLetterCase(textLetterCase.UpperCase);
      tab.SetInteractive(true);
      tab.SetText(this.m_tabs[i]);
      ArrayPush(this.m_tabTexts, tab);

      let mark: ref<inkRectangle> = new inkRectangle();
      mark.SetSize(Cast<Float>(StrLen(this.m_tabs[i])) * 17.0 + 8.0, 4.0);
      mark.SetHAlign(inkEHorizontalAlign.Center);
      mark.SetMargin(inkMargin(0.0, 8.0, 0.0, 0.0));
      mark.SetTintColor(this.GMEAccent());
      mark.Reparent(cell);
      ArrayPush(this.m_tabMarks, mark);

      i += 1;
    };
    this.GMEPaintTabs();
  }

  protected func GMEPaintTabs() -> Void {
    let i: Int32 = 0;
    while i < ArraySize(this.m_tabTexts) {
      if i == this.m_tab {
        this.m_tabTexts[i].SetTintColor(this.GMEAccent());
        this.m_tabTexts[i].SetOpacity(1.0);
        this.m_tabMarks[i].SetOpacity(1.0);
        this.m_tabMarks[i].SetSize(
          Cast<Float>(StrLen(this.m_tabs[i])) * 17.0 + 28.0, 5.0);
      } else {
        this.m_tabTexts[i].SetTintColor(new HDRColor(0.72, 0.74, 0.80, 1.0));
        this.m_tabTexts[i].SetOpacity(0.50);
        this.m_tabMarks[i].SetOpacity(0.0);
      };
      i += 1;
    };
    if IsDefined(this.m_header) {
      this.m_header.SetFluffLeft(IntToString(this.m_tab + 1) + " / " + IntToString(ArraySize(this.m_tabs)));
    };
  }

  protected func GMERebuildRows() -> Void {
    if !IsDefined(this.m_listPanel) {
      return;
    };
    this.m_listPanel.RemoveAllChildren();
    if IsDefined(this.m_fixedPanel) {
      this.m_fixedPanel.RemoveAllChildren();
    };
    ArrayClear(this.m_rowFixed);
    ArrayClear(this.m_rowLabels);
    ArrayClear(this.m_rowValues);
    ArrayClear(this.m_rowMarks);
    ArrayClear(this.m_rowStripes);
    ArrayClear(this.m_rowBars);
    ArrayClear(this.m_rowTops);
    this.m_contentHeight = 0.0;

    let stripe: Bool = false;
    let i: Int32 = 0;
    while i < ArraySize(this.m_rows) {
      let row: GMERow = this.m_rows[i];
      let height: Float = this.GMERowHeight(row);
      let fixed: Bool = this.GMEIsFixed(row.kind) && IsDefined(this.m_fixedPanel);
      ArrayPush(this.m_rowFixed, fixed);
      ArrayPush(this.m_rowTops, fixed ? 0.0 : this.m_contentHeight);
      if !fixed {
        this.m_contentHeight += height;
      };

      let isHead: Bool = Equals(row.kind, "head");
      let wrapped: Bool = this.GMEIsWrapped(row.kind);
      let topPad: Float = 10.0;

      let canvas: ref<inkCanvas> = new inkCanvas();
      canvas.SetSize(this.m_rowWidth, height);
      if fixed {
        canvas.Reparent(this.m_fixedPanel);
      } else {
        canvas.Reparent(this.m_listPanel);
      };

      let stripeRect: ref<inkRectangle> = new inkRectangle();
      stripeRect.SetSize(this.m_rowWidth, height);
      stripeRect.SetAnchor(inkEAnchor.Fill);
      stripeRect.SetTintColor(new HDRColor(0.62, 0.66, 0.74, 1.0));
      if isHead {
        stripeRect.SetOpacity(0.10);
        stripe = false;
      } else {
        if fixed {
          stripeRect.SetOpacity(0.08);
        } else {
          stripeRect.SetOpacity(stripe ? 0.05 : 0.0);
          stripe = !stripe;
        };
      };
      stripeRect.Reparent(canvas);
      ArrayPush(this.m_rowStripes, stripeRect);

      let mark: ref<inkRectangle> = new inkRectangle();
      mark.SetSize(this.m_rowWidth, height);
      mark.SetAnchor(inkEAnchor.Fill);
      mark.SetTintColor(this.GMEAccent());
      mark.SetOpacity(0.0);
      mark.Reparent(canvas);
      ArrayPush(this.m_rowMarks, mark);

      let bar: ref<inkRectangle> = new inkRectangle();
      bar.SetSize(6.0, height);
      bar.SetAnchor(inkEAnchor.LeftFillVerticaly);
      bar.SetTintColor(this.GMEAccent());
      bar.SetOpacity(0.0);
      bar.Reparent(canvas);
      ArrayPush(this.m_rowBars, bar);

      if isHead {
        let underline: ref<inkRectangle> = new inkRectangle();
        underline.SetSize(this.m_rowWidth, 2.0);
        underline.SetAnchor(inkEAnchor.BottomFillHorizontaly);
        underline.SetAnchorPoint(Vector2(0.0, 1.0));
        underline.SetTintColor(this.GMEAccent());
        underline.SetOpacity(0.45);
        underline.Reparent(canvas);
      };

      let iconShift: Float = 0.0;
      if StrLen(row.res) > 0 && !isHead && !wrapped {
        let iconRec: ref<UIIcon_Record> = this.GMEIconOf(row.res);
        if IsDefined(iconRec) && IsNameValid(iconRec.AtlasPartName()) {
          let img: ref<inkImage> = new inkImage();
          img.SetAtlasResource(iconRec.AtlasResourcePath());
          img.SetTexturePart(iconRec.AtlasPartName());
          img.SetSize(Vector2(96.0, 48.0));
          img.SetAnchor(inkEAnchor.CenterLeft);
          img.SetAnchorPoint(Vector2(0.0, 0.5));
          img.SetMargin(inkMargin(30.0, 0.0, 0.0, 0.0));
          img.SetOpacity(0.9);
          img.Reparent(canvas);
          iconShift = 112.0;
        };
      };

      let label: ref<inkText> = this.GMEMakeText(isHead ? 36 : 34, canvas);
      label.SetInteractive(true);
      if isHead {
        label.SetLetterCase(textLetterCase.UpperCase);
      };
      if wrapped {
        label.SetWrapping(true, this.m_rowWidth - (StrLen(row.value) > 0 ? 820.0 : 170.0));
        label.SetAnchor(inkEAnchor.TopLeft);
        label.SetAnchorPoint(Vector2(0.0, 0.0));
        label.SetMargin(inkMargin(isHead ? 22.0 : 34.0, topPad, 0.0, 0.0));
      } else {
        label.SetAnchor(inkEAnchor.CenterLeft);
        label.SetAnchorPoint(Vector2(0.0, 0.5));
        label.SetVAlign(inkEVerticalAlign.Center);
        label.SetMargin(inkMargin((isHead ? 22.0 : 34.0) + iconShift, 0.0, 0.0, 0.0));
      };
      label.SetText(row.label);
      ArrayPush(this.m_rowLabels, label);

      let value: ref<inkText> = this.GMEMakeText(34, canvas);
      value.SetHAlign(inkEHorizontalAlign.Right);
      value.SetInteractive(true);
      if wrapped {
        value.SetAnchor(inkEAnchor.TopRight);
        value.SetAnchorPoint(Vector2(1.0, 0.0));
        value.SetMargin(inkMargin(0.0, topPad, 34.0, 0.0));
      } else {
        value.SetAnchor(inkEAnchor.CenterRight);
        value.SetAnchorPoint(Vector2(1.0, 0.5));
        value.SetVAlign(inkEVerticalAlign.Center);
        value.SetMargin(inkMargin(0.0, 0.0, 34.0, 0.0));
      };
      value.SetText(this.GMEValueOf(i));
      ArrayPush(this.m_rowValues, value);

      i += 1;
    };
    this.GMEFitView();
    this.GMEPaintRows();
    this.GMEApplyScroll();
  }

  protected func GMEFitView() -> Void {
    let fixedHeight: Float = 0.0;
    let i: Int32 = 0;
    while i < ArraySize(this.m_rows) {
      if this.m_rowFixed[i] {
        fixedHeight += this.GMERowHeight(this.m_rows[i]);
      };
      i += 1;
    };
    let height: Float = 880.0 - MaxF(0.0, fixedHeight - 232.0);
    if AbsF(height - this.m_viewHeight) < 1.0 {
      return;
    };
    this.m_viewHeight = height;
    if IsDefined(this.m_view) {
      this.m_view.SetSize(Vector2(this.m_rowWidth, height));
    };
    if IsDefined(this.m_scrollBar) {
      this.m_scrollBar.SetSize(8.0, height);
    };
    if IsDefined(this.m_scrollTrack) {
      this.m_scrollTrack.SetSize(4.0, height);
    };
  }

  protected func GMEStripMark(value: String) -> String {
    if StrLen(value) > 0 && (Equals(StrLeft(value, 1), "!") || Equals(StrLeft(value, 1), "*")) {
      return StrRight(value, StrLen(value) - 1);
    };
    return value;
  }

  protected func GMEValueTone(row: GMERow) -> Int32 {
    if Equals(row.kind, "toggle") || Equals(row.kind, "ftoggle") || Equals(row.kind, "check") {
      return Equals(row.value, "1") ? 2 : 3;
    };
    if Equals(row.kind, "btn") || Equals(row.kind, "fbtn") {
      if StrLen(row.value) > 0 && Equals(StrLeft(row.value, 1), "!") {
        return 1;
      };
      if StrLen(row.value) > 0 && Equals(StrLeft(row.value, 1), "*") {
        return 2;
      };
      return 0;
    };
    return 4;
  }

  protected func GMEToneColor(tone: Int32, selected: Bool) -> HDRColor {
    if tone == 1 {
      return new HDRColor(1.00, 0.62, 0.20, 1.0);
    };
    if tone == 2 {
      return new HDRColor(0.30, 0.85, 0.35, 1.0);
    };
    if tone == 3 {
      return selected ? new HDRColor(0.82, 0.82, 0.85, 1.0) : new HDRColor(0.50, 0.50, 0.55, 1.0);
    };
    if tone == 0 {
      return new HDRColor(1.00, 0.82, 0.00, 1.0);
    };
    return selected ? this.GMEAccent() : new HDRColor(0.82, 0.82, 0.85, 1.0);
  }

  protected func GMEValueOf(index: Int32) -> String {
    let row: GMERow = this.m_rows[index];
    if Equals(row.kind, "btn") || Equals(row.kind, "fbtn") {
      let text: String = this.GMEStripMark(row.value);
      if StrLen(text) == 0 {
        text = "\u{25B8}";
      };
      return "[ " + text + " ]";
    };
    if Equals(row.kind, "toggle") || Equals(row.kind, "ftoggle") {
      return Equals(row.value, "1") ? "[ ON ]" : "[ OFF ]";
    };
    if Equals(row.kind, "check") {
      return Equals(row.value, "1") ? "[x]" : "[  ]";
    };
    if Equals(row.kind, "choice") || Equals(row.kind, "slider") {
      if index == this.m_sel {
        return "<  " + row.value + "  >";
      };
      return "   " + row.value + "   ";
    };
    return row.value;
  }

  protected func GMEPaintRows() -> Void {
    let i: Int32 = 0;
    while i < ArraySize(this.m_rowLabels) {
      let selected: Bool = i == this.m_sel;
      let rank: Int32 = StringToInt(this.m_rows[i].icon, 0);
      let isHead: Bool = Equals(this.m_rows[i].kind, "head");
      if (!selected || isHead) && rank > 0 {
        this.m_rowLabels[i].SetTintColor(this.GMERankColor(rank));
      } else {
        this.m_rowLabels[i].SetTintColor(this.GMEColorOf(this.m_rows[i].kind, selected));
      };
      this.m_rowLabels[i].SetFontStyle(selected ? n"Semi-Bold" : n"Medium");
      this.m_rowValues[i].SetText(this.GMEValueOf(i));
      this.m_rowValues[i].SetTintColor(this.GMEToneColor(this.GMEValueTone(this.m_rows[i]), selected));
      this.m_rowValues[i].SetFontStyle(selected ? n"Semi-Bold" : n"Medium");
      this.m_rowMarks[i].SetOpacity(selected ? 0.16 : 0.0);
      this.m_rowBars[i].SetOpacity(selected ? 1.0 : 0.0);
      i += 1;
    };
    this.GMEPaintFooter();
  }

  protected func GMEPaintFooter() -> Void {
    let total: Int32 = 0;
    let position: Int32 = 0;
    let i: Int32 = 0;
    while i < ArraySize(this.m_rows) {
      if this.GMEIsSelectable(this.m_rows[i].kind) && !this.m_rowFixed[i] {
        total += 1;
        if i == this.m_sel {
          position = total;
        };
      };
      i += 1;
    };
    if IsDefined(this.m_footer) {
      if total > 0 && position > 0 {
        this.m_footer.SetFluffText(this.m_footerText + "      "
          + IntToString(position) + " / " + IntToString(total));
      } else {
        this.m_footer.SetFluffText(this.m_footerText);
      };
    };
  }

  protected func GMEFlash() -> Void {
    if this.m_sel >= 0 && this.m_sel < ArraySize(this.m_rowMarks) {
      this.m_rowMarks[this.m_sel].SetOpacity(0.55);
    };
  }

  protected func GMEPlay(sound: CName) -> Void {
    if IsDefined(this.m_owner) {
      GameObject.PlaySoundEvent(this.m_owner, sound);
    };
  }

  protected func GMEApplyScroll() -> Void {
    let viewHeight: Float = this.m_viewHeight;
    if this.m_sel >= 0 && this.m_sel < ArraySize(this.m_rowTops) && !this.m_rowFixed[this.m_sel] {
      let top: Float = this.m_rowTops[this.m_sel];
      let height: Float = this.GMERowHeight(this.m_rows[this.m_sel]);
      if top + this.m_scroll < 0.0 {
        this.m_scroll = -top;
      };
      if top + height + this.m_scroll > viewHeight {
        this.m_scroll = viewHeight - top - height;
      };
    };
    let maxScroll: Float = MaxF(0.0, this.m_contentHeight - viewHeight);
    this.m_scroll = MinF(0.0, MaxF(-maxScroll, this.m_scroll));
    this.m_listPanel.SetTranslation(new Vector2(0.0, this.m_scroll));

    if IsDefined(this.m_scrollThumb) {
      if maxScroll <= 0.0 {
        this.m_scrollThumb.SetOpacity(0.0);
      } else {
        let ratio: Float = viewHeight / this.m_contentHeight;
        let thumbHeight: Float = MaxF(60.0, viewHeight * ratio);
        this.m_scrollThumb.SetOpacity(0.55);
        this.m_scrollThumb.SetSize(8.0, thumbHeight);
        this.m_scrollThumb.SetTranslation(
          new Vector2(0.0, (-this.m_scroll / maxScroll) * (viewHeight - thumbHeight)));
      };
    };
  }

  protected func GMEMove(dir: Int32) -> Void {
    if ArraySize(this.m_rows) == 0 {
      return;
    };
    this.m_sel += dir;
    if this.m_sel < 0 {
      this.m_sel = ArraySize(this.m_rows) - 1;
    };
    if this.m_sel >= ArraySize(this.m_rows) {
      this.m_sel = 0;
    };
    this.GMEClampSelection(dir);
    this.GMEPaintRows();
    this.GMEApplyScroll();
    this.GMEPlay(n"ui_menu_hover");
    let id: String = this.GMESelectedId();
    if StrLen(id) > 0 {
      this.GMEEmit("sel:" + id);
    };
  }

  protected func GMESwitchTab(dir: Int32) -> Void {
    if ArraySize(this.m_tabs) == 0 {
      return;
    };
    this.m_tab += dir;
    if this.m_tab < 0 {
      this.m_tab = ArraySize(this.m_tabs) - 1;
    };
    if this.m_tab >= ArraySize(this.m_tabs) {
      this.m_tab = 0;
    };
    this.m_sel = 0;
    this.m_scroll = 0.0;
    this.GMEPaintTabs();
    this.GMEPlay(n"ui_menu_tab_next");
    this.GMEEmit("tab:" + IntToString(this.m_tab));
  }

  protected func GMEActivate(suffix: String) -> Void {
    if this.m_sel < 0 || this.m_sel >= ArraySize(this.m_rows) {
      return;
    };
    if StrLen(this.m_rows[this.m_sel].id) == 0 {
      return;
    };
    this.GMEFlash();
    this.GMEPlay(Equals(suffix, "act") ? n"ui_menu_onpress" : n"ui_menu_hover");
    this.GMEEmit(suffix + ":" + this.m_rows[this.m_sel].id);
  }

  protected func SetTimeDilation() -> Void {
  }

  protected func ResetTimeDilation() -> Void {
  }

  protected cb func OnAttach() {
    super.OnAttach();
    this.RegisterToGlobalInputCallback(n"OnPostOnPress", this, n"OnGMEInput");
    this.GMEEmit("menu:open");
  }

  protected cb func OnDetach() {
    this.UnregisterFromGlobalInputCallback(n"OnPostOnPress", this, n"OnGMEInput");
    this.GMEEmit("menu:close");
    super.OnDetach();
  }

  protected func GMEFixedWith(suffix: String) -> Int32 {
    let i: Int32 = 0;
    while i < ArraySize(this.m_rows) {
      if this.m_rowFixed[i] && StrEndsWith(this.m_rows[i].id, suffix) {
        return i;
      };
      i += 1;
    };
    return -1;
  }

  protected func GMEShortcut(suffix: String, verb: String) -> Bool {
    let index: Int32 = this.GMEFixedWith(suffix);
    if index < 0 {
      return false;
    };
    this.GMEPlay(n"ui_menu_hover");
    this.GMEEmit(verb + ":" + this.m_rows[index].id);
    return true;
  }

  protected cb func OnGMEInput(evt: ref<inkPointerEvent>) -> Bool {
    if evt.IsAction(n"left_trigger") {
      this.GMEShortcut("grp", "dec");
      return false;
    };
    if evt.IsAction(n"right_trigger") {
      this.GMEShortcut("grp", "inc");
      return false;
    };
    if evt.IsAction(n"option_switch_prev") {
      this.GMEShortcut("page", "dec");
      return false;
    };
    if evt.IsAction(n"option_switch_next") {
      this.GMEShortcut("page", "inc");
      return false;
    };
    if evt.IsAction(n"popup_navigate_up") {
      this.GMEMove(-1);
      return false;
    };
    if evt.IsAction(n"popup_navigate_down") {
      this.GMEMove(1);
      return false;
    };
    if evt.IsAction(n"popup_navigate_left") {
      this.GMEActivate("dec");
      return false;
    };
    if evt.IsAction(n"popup_navigate_right") {
      this.GMEActivate("inc");
      return false;
    };
    if evt.IsAction(n"proceed") {
      this.GMEActivate("act");
      return false;
    };
    if evt.IsAction(n"next_menu") {
      this.GMESwitchTab(1);
      return false;
    };
    if evt.IsAction(n"prior_menu") {
      this.GMESwitchTab(-1);
      return false;
    };
    return false;
  }

  protected cb func OnGlobalReleaseInput(evt: ref<inkPointerEvent>) -> Bool {
    if evt.IsAction(n"mouse_left") && !evt.IsHandled() {
      let target: wref<inkWidget> = evt.GetTarget();
      let i: Int32 = 0;
      while IsDefined(target) && i < ArraySize(this.m_rowLabels) {
        if Equals(target, this.m_rowLabels[i]) || Equals(target, this.m_rowValues[i]) {
          if this.GMEIsSelectable(this.m_rows[i].kind) {
            this.m_sel = i;
            this.GMEPaintRows();
            this.GMEActivate("act");
          };
          i = ArraySize(this.m_rowLabels);
        } else {
          i += 1;
        };
      };
      let t: Int32 = 0;
      while IsDefined(target) && t < ArraySize(this.m_tabTexts) {
        if Equals(target, this.m_tabTexts[t]) {
          this.m_tab = t;
          this.m_sel = 0;
          this.m_scroll = 0.0;
          this.GMEPaintTabs();
          this.GMEEmit("tab:" + IntToString(this.m_tab));
          t = ArraySize(this.m_tabTexts);
        } else {
          t += 1;
        };
      };
    };
    return super.OnGlobalReleaseInput(evt);
  }

  public func GMESetFooter(text: String) -> Void {
    this.m_footerText = text;
    if IsDefined(this.m_footer) {
      this.m_footer.SetFluffText(text);
    };
  }

  public static func Show(player: ref<PlayerPuppet>, payload: String) -> ref<GMEMenuPopup> {
    let popup: ref<GMEMenuPopup> = new GMEMenuPopup();
    popup.GMEBind(player);
    popup.GMESetState(payload);
    GameInstance.GetUISystem(player.GetGame()).QueueEvent(ShowCustomPopupEvent.Create(popup));
    return popup;
  }
}

@addField(PlayerPuppet)
let m_gmePopup: ref<GMEMenuPopup>;

@addMethod(PlayerPuppet)
public func GMEEmit(action: String) -> Bool {
  return true;
}

@addMethod(PlayerPuppet)
public func GMEMenuIsOpen() -> Bool {
  return IsDefined(this.m_gmePopup) && this.m_gmePopup.GMEIsOpen();
}

@addMethod(PlayerPuppet)
public func GMEPushState(payload: String) -> Bool {
  if IsDefined(this.m_gmePopup) && this.m_gmePopup.GMEIsOpen() {
    this.m_gmePopup.GMESetState(payload);
    return true;
  };
  return false;
}

@addMethod(PlayerPuppet)
public func GMEToggleMenu(payload: String) -> Bool {
  if IsDefined(this.m_gmePopup) && this.m_gmePopup.GMEIsOpen() {
    this.m_gmePopup.Close();
    this.m_gmePopup = null;
    return false;
  };
  if GameInstance.GetSystemRequestsHandler().IsPreGame() {
    return false;
  };
  this.m_gmePopup = null;
  this.m_gmePopup = GMEMenuPopup.Show(this, payload);
  return true;
}
