module FindMyRide

enum FmrSortMode {
  Default = 0,
  Manufacturer = 1,
  Type = 2
}

enum FmrTheme {
  Netrunner = 0,
  Samurai = 1,
  Corpo = 2
}

public class FindMyRideSettings extends ScriptableSystem {

  @runtimeProperty("ModSettings.mod", "Mod-FindMyRide-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-FindMyRide-Set-SortMode")
  @runtimeProperty("ModSettings.description", "Mod-FindMyRide-Set-SortMode-Desc")
  @runtimeProperty("ModSettings.displayValues.Default", "Mod-FindMyRide-Sort-Default")
  @runtimeProperty("ModSettings.displayValues.Manufacturer", "Mod-FindMyRide-Sort-Manufacturer")
  @runtimeProperty("ModSettings.displayValues.Type", "Mod-FindMyRide-Sort-Type")
  public let sortMode: FmrSortMode = FmrSortMode.Default;

  @runtimeProperty("ModSettings.mod", "Mod-FindMyRide-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-FindMyRide-Set-FavsFirst")
  @runtimeProperty("ModSettings.description", "Mod-FindMyRide-Set-FavsFirst-Desc")
  public let favoritesFirst: Bool = true;

  @runtimeProperty("ModSettings.mod", "Mod-FindMyRide-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-FindMyRide-Set-RememberCategory")
  @runtimeProperty("ModSettings.description", "Mod-FindMyRide-Set-RememberCategory-Desc")
  public let rememberCategory: Bool = true;

  @runtimeProperty("ModSettings.mod", "Mod-FindMyRide-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-FindMyRide-Set-HideBeta")
  @runtimeProperty("ModSettings.description", "Mod-FindMyRide-Set-HideBeta-Desc")
  public let hideBetaWarning: Bool = true;

  @runtimeProperty("ModSettings.mod", "Mod-FindMyRide-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-FindMyRide-Set-MergeVariants")
  @runtimeProperty("ModSettings.description", "Mod-FindMyRide-Set-MergeVariants-Desc")
  public let mergeVariants: Bool = true;

  @runtimeProperty("ModSettings.mod", "Mod-FindMyRide-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-FindMyRide-Set-Theme")
  @runtimeProperty("ModSettings.description", "Mod-FindMyRide-Set-Theme-Desc")
  @runtimeProperty("ModSettings.displayValues.Netrunner", "Mod-FindMyRide-Theme-Netrunner")
  @runtimeProperty("ModSettings.displayValues.Samurai", "Mod-FindMyRide-Theme-Samurai")
  @runtimeProperty("ModSettings.displayValues.Corpo", "Mod-FindMyRide-Theme-Corpo")
  public let theme: FmrTheme = FmrTheme.Netrunner;

  public static func Get(game: GameInstance) -> ref<FindMyRideSettings> {
    return GameInstance.GetScriptableSystemsContainer(game).Get(n"FindMyRide.FindMyRideSettings") as FindMyRideSettings;
  }

  @if(ModuleExists("ModSettingsModule"))
  private func OnAttach() -> Void {
    ModSettings.RegisterListenerToClass(this);
  }

  @if(!ModuleExists("ModSettingsModule"))
  private func OnAttach() -> Void {}

  @if(ModuleExists("ModSettingsModule"))
  private func OnDetach() -> Void {
    ModSettings.UnregisterListenerToClass(this);
  }

  @if(!ModuleExists("ModSettingsModule"))
  private func OnDetach() -> Void {}
}
