module FindMyRide.Localization
import Codeware.Localization.*

public class English extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-FindMyRide-Cat-All", "All");
    this.Text("Mod-FindMyRide-Cat-Favorites", "Favorites");
    this.Text("Mod-FindMyRide-Cat-Recent", "Recent");
    this.Text("Mod-FindMyRide-Cat-Cars", "Cars");
    this.Text("Mod-FindMyRide-Cat-Motorcycles", "Motorcycles");
    this.Text("Mod-FindMyRide-Cat-Armed", "Armed");
    this.Text("Mod-FindMyRide-Cat-Hidden", "Hidden");
    this.Text("Mod-FindMyRide-Bar-Hide", "hide");
    this.Text("Mod-FindMyRide-Bar-Unhide", "unhide");
    this.Text("Mod-FindMyRide-Bar-SearchPrefix", "Search: ");
    this.Text("Mod-FindMyRide-Bar-SearchHint", "confirm   [Esc] clear");
    this.Text("Mod-FindMyRide-Bar-Search", "search");
    this.Text("Mod-FindMyRide-Bar-Clear", "clear");
    this.Text("Mod-FindMyRide-Title", "Find My Ride");
    this.Text("Mod-FindMyRide-Set-RememberCategory", "Remember category");
    this.Text("Mod-FindMyRide-Set-RememberCategory-Desc", "Reopen the vehicle list on the last category used. Off means it always opens on All.");
    this.Text("Mod-FindMyRide-Set-HideBeta", "Hide Beta warning");
    this.Text("Mod-FindMyRide-Set-HideBeta-Desc", "Hide the vanilla \"vehicle delivery is still in Beta\" disclaimer to free up screen space.");
    this.Text("Mod-FindMyRide-Set-SortMode", "Sort vehicles by");
    this.Text("Mod-FindMyRide-Set-SortMode-Desc", "List order. Default is the game's own: favorites first, then name. The other modes group by manufacturer or by vehicle type, keeping favorites on top.");
    this.Text("Mod-FindMyRide-Sort-Default", "Default (name)");
    this.Text("Mod-FindMyRide-Sort-Manufacturer", "Manufacturer");
    this.Text("Mod-FindMyRide-Sort-Type", "Vehicle type");
    this.Text("Mod-FindMyRide-Set-FavsFirst", "Favorites first");
    this.Text("Mod-FindMyRide-Set-FavsFirst-Desc", "Keep favorite vehicles at the top of the list. Off sorts everything together.");
    this.Text("Mod-FindMyRide-Set-MergeVariants", "Merge paint variants");
    this.Text("Mod-FindMyRide-Set-MergeVariants-Desc", "Some vehicles show up twice with the same name (CrystalCoat variants). Keep only one entry per name: the favorite, or the most recently called.");
    this.Text("Mod-FindMyRide-Set-Theme", "Panel color");
    this.Text("Mod-FindMyRide-Set-Theme-Desc", "Accent color of the search panel.");
    this.Text("Mod-FindMyRide-Theme-Netrunner", "Netrunner (cyan)");
    this.Text("Mod-FindMyRide-Theme-Samurai", "Samurai (yellow)");
    this.Text("Mod-FindMyRide-Theme-Corpo", "Corpo (red)");
    this.Text("Mod-FindMyRide-Bar-Tabs", "category");
    this.Text("Mod-FindMyRide-Info-HP", "hp");
  }
}

public class BrazilianPortuguese extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-FindMyRide-Cat-All", "Todos");
    this.Text("Mod-FindMyRide-Cat-Favorites", "Favoritos");
    this.Text("Mod-FindMyRide-Cat-Recent", "Recentes");
    this.Text("Mod-FindMyRide-Cat-Cars", "Carros");
    this.Text("Mod-FindMyRide-Cat-Motorcycles", "Motos");
    this.Text("Mod-FindMyRide-Cat-Armed", "Armados");
    this.Text("Mod-FindMyRide-Cat-Hidden", "Ocultos");
    this.Text("Mod-FindMyRide-Bar-Hide", "ocultar");
    this.Text("Mod-FindMyRide-Bar-Unhide", "mostrar");
    this.Text("Mod-FindMyRide-Bar-SearchPrefix", "Busca: ");
    this.Text("Mod-FindMyRide-Bar-SearchHint", "confirmar   [Esc] limpar");
    this.Text("Mod-FindMyRide-Bar-Search", "buscar");
    this.Text("Mod-FindMyRide-Bar-Clear", "limpar");
    this.Text("Mod-FindMyRide-Title", "Find My Ride");
    this.Text("Mod-FindMyRide-Set-RememberCategory", "Lembrar categoria");
    this.Text("Mod-FindMyRide-Set-RememberCategory-Desc", "Reabre a lista de veículos na última categoria usada. Desligado, abre sempre em Todos.");
    this.Text("Mod-FindMyRide-Set-HideBeta", "Ocultar aviso de Beta");
    this.Text("Mod-FindMyRide-Set-HideBeta-Desc", "Esconde o aviso original de que a entrega de veículos ainda está em Beta, liberando espaço na tela.");
    this.Text("Mod-FindMyRide-Set-SortMode", "Ordenar veículos por");
    this.Text("Mod-FindMyRide-Set-SortMode-Desc", "Ordem da lista. Padrão é a do jogo: favoritos primeiro, depois nome. Os outros modos agrupam por fabricante ou por tipo de veículo, mantendo favoritos no topo.");
    this.Text("Mod-FindMyRide-Sort-Default", "Padrão (nome)");
    this.Text("Mod-FindMyRide-Sort-Manufacturer", "Fabricante");
    this.Text("Mod-FindMyRide-Sort-Type", "Tipo de veículo");
    this.Text("Mod-FindMyRide-Set-FavsFirst", "Favoritos primeiro");
    this.Text("Mod-FindMyRide-Set-FavsFirst-Desc", "Mantém os veículos favoritos no topo da lista. Desligado, ordena tudo junto.");
    this.Text("Mod-FindMyRide-Set-MergeVariants", "Juntar variantes de pintura");
    this.Text("Mod-FindMyRide-Set-MergeVariants-Desc", "Alguns veículos aparecem duas vezes com o mesmo nome (variantes CrystalCoat). Mantém só uma entrada por nome: a favorita, ou a chamada mais recente.");
    this.Text("Mod-FindMyRide-Set-Theme", "Cor do painel");
    this.Text("Mod-FindMyRide-Set-Theme-Desc", "Cor de destaque do painel de busca.");
    this.Text("Mod-FindMyRide-Theme-Netrunner", "Netrunner (ciano)");
    this.Text("Mod-FindMyRide-Theme-Samurai", "Samurai (amarelo)");
    this.Text("Mod-FindMyRide-Theme-Corpo", "Corpo (vermelho)");
    this.Text("Mod-FindMyRide-Bar-Tabs", "categoria");
    this.Text("Mod-FindMyRide-Info-HP", "cv");
  }
}

public class LocalizationProvider extends ModLocalizationProvider {
  public func GetPackage(language: CName) -> ref<ModLocalizationPackage> {
    switch language {
      case n"pt-br": return new BrazilianPortuguese();
      default: return new English();
    };
  }

  public func GetFallback() -> CName {
    return n"en-us";
  }
}
