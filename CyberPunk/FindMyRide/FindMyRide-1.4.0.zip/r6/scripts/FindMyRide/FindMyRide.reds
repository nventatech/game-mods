module FindMyRide
import Codeware.Localization.*

public class FindMyRideState extends ScriptableSystem {
  public let lastCategory: Int32;
}

public func FmrFactKey(prefix: String, id: TweakDBID) -> CName {
  return StringToName(prefix + s"\(TDBID.ToNumber(id))");
}

public class FindMyRideDataView extends VehiclesManagerDataView {
  public let m_search: String;
  public let m_category: Int32;
  public let m_sortMode: Int32;
  public let m_favsFirst: Bool;
  public let m_recent: array<TweakDBID>;
  public let m_hidden: array<TweakDBID>;
  public let m_dupes: array<TweakDBID>;

  public func SortItem(lhs: ref<IScriptable>, rhs: ref<IScriptable>) -> Bool {
    if this.m_category == 2 {
      let li: ref<VehicleListItemData> = lhs as VehicleListItemData;
      let ri: ref<VehicleListItemData> = rhs as VehicleListItemData;
      if IsDefined(li) && IsDefined(ri) {
        return this.FmrRecentIndex(li.m_data.recordID) < this.FmrRecentIndex(ri.m_data.recordID);
      };
    };
    if this.m_sortMode == 0 && this.m_favsFirst {
      return super.SortItem(lhs, rhs);
    };
    let l: ref<VehicleListItemData> = lhs as VehicleListItemData;
    let r: ref<VehicleListItemData> = rhs as VehicleListItemData;
    if !IsDefined(l) || !IsDefined(r) {
      return false;
    };
    if this.m_favsFirst {
      let lFav: Bool = l.m_data.forcedFavorite || l.m_data.uiFavoriteIndex >= 0;
      let rFav: Bool = r.m_data.forcedFavorite || r.m_data.uiFavoriteIndex >= 0;
      if !Equals(lFav, rFav) {
        return lFav;
      };
    };
    let lKey: String;
    let rKey: String;
    if this.m_sortMode == 1 {
      lKey = FmrManufacturerName(l);
      rKey = FmrManufacturerName(r);
    };
    if this.m_sortMode == 2 {
      lKey = IntToString(FmrTypeOrder(l));
      rKey = IntToString(FmrTypeOrder(r));
    };
    if !Equals(lKey, rKey) {
      return UnicodeStringLessThan(lKey, rKey);
    };
    return UnicodeStringLessThan(GetLocalizedTextByKey(l.m_displayName), GetLocalizedTextByKey(r.m_displayName));
  }

  public func FmrVariantRank(item: ref<VehicleListItemData>) -> Int32 {
    let rank: Int32 = 0;
    if item.m_data.forcedFavorite || item.m_data.uiFavoriteIndex >= 0 {
      rank += 100000;
    };
    if ArrayContains(this.m_hidden, item.m_data.recordID) {
      rank -= 50000;
    };
    return rank + (10000 - this.FmrRecentIndex(item.m_data.recordID));
  }

  public func FmrRecentIndex(id: TweakDBID) -> Int32 {
    let i: Int32 = 0;
    while i < ArraySize(this.m_recent) {
      if this.m_recent[i] == id {
        return i;
      };
      i += 1;
    };
    return 9999;
  }

  public func FilterItem(data: ref<IScriptable>) -> Bool {
    let item: ref<VehicleListItemData> = data as VehicleListItemData;
    if !IsDefined(item) {
      return true;
    };
    if this.m_category == 2 && this.FmrRecentIndex(item.m_data.recordID) >= 9999 {
      return false;
    };
    let isHidden: Bool = ArrayContains(this.m_hidden, item.m_data.recordID);
    if this.m_category == 6 {
      if !isHidden {
        return false;
      };
    } else {
      if isHidden {
        return false;
      };
    };
    if ArrayContains(this.m_dupes, item.m_data.recordID) {
      return false;
    };
    if !FmrMatchesCategory(item, this.m_category) {
      return false;
    };
    if StrLen(this.m_search) > 0 {
      let needle: String = FmrNormalize(this.m_search);
      if StrContains(FmrNormalize(GetLocalizedTextByKey(item.m_displayName)), needle) {
        return true;
      };
      return StrContains(FmrNormalize(FmrManufacturerName(item)), needle);
    };
    return true;
  }
}

public func FmrManufacturerName(item: ref<VehicleListItemData>) -> String {
  let record: ref<Vehicle_Record> = TweakDBInterface.GetVehicleRecord(item.m_data.recordID);
  if !IsDefined(record) {
    return "";
  };
  let manufacturer: ref<VehicleManufacturer_Record> = record.Manufacturer();
  if !IsDefined(manufacturer) {
    return "";
  };
  return manufacturer.EnumName();
}

public func FmrNormalize(text: String) -> String {
  let result: String = StrLower(text);
  result = StrReplaceAll(result, " ", "");
  result = StrReplaceAll(result, "-", "");
  return result;
}

public func FmrTypeOrder(item: ref<VehicleListItemData>) -> Int32 {
  if Equals(item.m_data.vehicleType, gamedataVehicleType.Bike) {
    return 1;
  };
  let record: ref<Vehicle_Record> = TweakDBInterface.GetVehicleRecord(item.m_data.recordID);
  if IsDefined(record) && Equals(record.VehDataPackageHandle().DriverCombat().Type(), gamedataDriverCombatType.MountedWeapons) {
    return 2;
  };
  return 0;
}

public func FmrMatchesCategory(item: ref<VehicleListItemData>, category: Int32) -> Bool {
  if category == 0 || category == 2 || category == 6 {
    return true;
  };
  if category == 1 {
    return item.m_data.uiFavoriteIndex >= 0 || item.m_data.forcedFavorite;
  };
  let isBike: Bool = Equals(item.m_data.vehicleType, gamedataVehicleType.Bike);
  if category == 4 {
    return isBike;
  };
  let record: ref<Vehicle_Record> = TweakDBInterface.GetVehicleRecord(item.m_data.recordID);
  let isArmed: Bool = Equals(record.VehDataPackageHandle().DriverCombat().Type(), gamedataDriverCombatType.MountedWeapons);
  if category == 5 {
    return isArmed;
  };
  return !isBike && !isArmed;
}

public func FmrCategoryLabel(category: Int32, loc: ref<LocalizationSystem>) -> String {
  switch category {
    case 1: return loc.GetText("Mod-FindMyRide-Cat-Favorites");
    case 2: return loc.GetText("Mod-FindMyRide-Cat-Recent");
    case 3: return loc.GetText("Mod-FindMyRide-Cat-Cars");
    case 4: return loc.GetText("Mod-FindMyRide-Cat-Motorcycles");
    case 5: return loc.GetText("Mod-FindMyRide-Cat-Armed");
    case 6: return loc.GetText("Mod-FindMyRide-Cat-Hidden");
    default: return loc.GetText("Mod-FindMyRide-Cat-All");
  };
}

public func FmrKeyToChar(key: EInputKey) -> String {
  switch key {
    case EInputKey.IK_A: return "a";
    case EInputKey.IK_B: return "b";
    case EInputKey.IK_C: return "c";
    case EInputKey.IK_D: return "d";
    case EInputKey.IK_E: return "e";
    case EInputKey.IK_F: return "f";
    case EInputKey.IK_G: return "g";
    case EInputKey.IK_H: return "h";
    case EInputKey.IK_I: return "i";
    case EInputKey.IK_J: return "j";
    case EInputKey.IK_K: return "k";
    case EInputKey.IK_L: return "l";
    case EInputKey.IK_M: return "m";
    case EInputKey.IK_N: return "n";
    case EInputKey.IK_O: return "o";
    case EInputKey.IK_P: return "p";
    case EInputKey.IK_Q: return "q";
    case EInputKey.IK_R: return "r";
    case EInputKey.IK_S: return "s";
    case EInputKey.IK_T: return "t";
    case EInputKey.IK_U: return "u";
    case EInputKey.IK_V: return "v";
    case EInputKey.IK_W: return "w";
    case EInputKey.IK_X: return "x";
    case EInputKey.IK_Y: return "y";
    case EInputKey.IK_Z: return "z";
    case EInputKey.IK_0: return "0";
    case EInputKey.IK_1: return "1";
    case EInputKey.IK_2: return "2";
    case EInputKey.IK_3: return "3";
    case EInputKey.IK_4: return "4";
    case EInputKey.IK_5: return "5";
    case EInputKey.IK_6: return "6";
    case EInputKey.IK_7: return "7";
    case EInputKey.IK_8: return "8";
    case EInputKey.IK_9: return "9";
    case EInputKey.IK_NumPad0: return "0";
    case EInputKey.IK_NumPad1: return "1";
    case EInputKey.IK_NumPad2: return "2";
    case EInputKey.IK_NumPad3: return "3";
    case EInputKey.IK_NumPad4: return "4";
    case EInputKey.IK_NumPad5: return "5";
    case EInputKey.IK_NumPad6: return "6";
    case EInputKey.IK_NumPad7: return "7";
    case EInputKey.IK_NumPad8: return "8";
    case EInputKey.IK_NumPad9: return "9";
    case EInputKey.IK_Space: return " ";
    case EInputKey.IK_Minus: return "-";
    case EInputKey.IK_NumMinus: return "-";
    default: return "";
  };
}

@addField(VehiclesManagerPopupGameController)
let m_fmrSearchActive: Bool;

@addField(VehiclesManagerPopupGameController)
let m_fmrSearch: String;

@addField(VehiclesManagerPopupGameController)
let m_fmrCategory: Int32;

@addField(VehiclesManagerPopupGameController)
let m_fmrEatProceedRelease: Bool;

@addField(VehiclesManagerPopupGameController)
let m_fmrTypedCancelKey: Bool;

@addField(VehiclesManagerPopupGameController)
let m_fmrTypedProceedKey: Bool;

@addField(VehiclesManagerPopupGameController)
let m_fmrAteHubKey: Bool;

@addField(VehiclesManagerPopupGameController)
let m_fmrAtePadHideKey: Bool;

@addField(VehiclesManagerPopupGameController)
let m_fmrHints: wref<ButtonHints>;

@addField(VehiclesManagerPopupGameController)
let m_fmrHintKey: String;

@addField(VehiclesManagerPopupGameController)
let m_fmrPad: Bool;

@addField(VehiclesManagerPopupGameController)
let m_fmrBar: wref<inkText>;

@addField(VehiclesManagerPopupGameController)
let m_fmrInfo: wref<inkText>;

@addField(VehiclesManagerPopupGameController)
let m_fmrTabsRow: wref<inkHorizontalPanel>;

@addField(VehiclesManagerPopupGameController)
let m_fmrTabs: array<wref<inkText>>;

@wrapMethod(VehiclesManagerPopupGameController)
protected func SetupVirtualList() -> Void {
  wrappedMethod();
  this.m_dataView = new FindMyRideDataView();
  this.m_dataView.SetSource(this.m_dataSource);
  this.m_listController.SetSource(this.m_dataView);
}

@wrapMethod(VehiclesManagerPopupGameController)
protected cb func OnPlayerAttach(player: ref<GameObject>) -> Bool {
  let preSettings: ref<FindMyRideSettings> = FindMyRideSettings.Get(player.GetGame());
  let preView: ref<FindMyRideDataView> = this.m_dataView as FindMyRideDataView;
  if IsDefined(preView) {
    preView.m_sortMode = IsDefined(preSettings) ? EnumInt(preSettings.sortMode) : 0;
    preView.m_favsFirst = IsDefined(preSettings) ? preSettings.favoritesFirst : true;
  };
  let result: Bool = wrappedMethod(player);
  this.FmrLoadFactLists();
  this.m_fmrSearchActive = false;
  this.m_fmrSearch = "";
  let state: ref<FindMyRideState> = this.FmrState();
  let settings: ref<FindMyRideSettings> = this.FmrSettings();
  let remember: Bool = IsDefined(settings) ? settings.rememberCategory : true;
  this.m_fmrCategory = remember && IsDefined(state) ? state.lastCategory : 0;
  let attachView: ref<FindMyRideDataView> = this.m_dataView as FindMyRideDataView;
  if this.m_fmrCategory == 6 && (!IsDefined(attachView) || ArraySize(attachView.m_hidden) == 0) {
    this.m_fmrCategory = 0;
  };
  this.m_fmrEatProceedRelease = false;
  this.m_fmrTypedCancelKey = false;
  this.m_fmrTypedProceedKey = false;
  this.m_fmrAtePadHideKey = false;
  this.m_fmrHintKey = "";
  this.m_fmrPad = !player.PlayerLastUsedKBM();
  GameInstance.GetCallbackSystem().RegisterCallback(n"Input/Key", this, n"OnFmrKeyInput");
  let pco: ref<GameObject> = this.GetPlayerControlledObject();
  pco.RegisterInputListener(this, n"OpenMapMenu");
  pco.RegisterInputListener(this, n"OpenJournalMenu");
  pco.RegisterInputListener(this, n"OpenPerksMenu");
  pco.RegisterInputListener(this, n"OpenInventoryMenu");
  pco.RegisterInputListener(this, n"OpenCraftingMenu");
  pco.RegisterInputListener(this, n"OpenHubMenu");
  pco.RegisterInputListener(this, n"CharacterPanel");
  pco.RegisterInputListener(this, n"Inventory");
  pco.RegisterInputListener(this, n"PhoneInteract");
  pco.RegisterInputListener(this, n"showAll");
  pco.RegisterInputListener(this, n"call");
  pco.RegisterInputListener(this, n"track_quest");
  this.FmrCreateBar();
  if !IsDefined(settings) || settings.hideBetaWarning {
    this.FmrHideBetaWarning();
  };
  this.FmrApplyFilter();
  return result;
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrLoc() -> ref<LocalizationSystem> {
  return LocalizationSystem.GetInstance(this.GetPlayerControlledObject().GetGame());
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrSettings() -> ref<FindMyRideSettings> {
  return FindMyRideSettings.Get(this.GetPlayerControlledObject().GetGame());
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrState() -> ref<FindMyRideState> {
  let game: GameInstance = this.GetPlayerControlledObject().GetGame();
  return GameInstance.GetScriptableSystemsContainer(game).Get(n"FindMyRide.FindMyRideState") as FindMyRideState;
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrQuests() -> ref<QuestsSystem> {
  return GameInstance.GetQuestsSystem(this.GetPlayerControlledObject().GetGame());
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrLoadFactLists() -> Void {
  let view: ref<FindMyRideDataView> = this.m_dataView as FindMyRideDataView;
  let qs: ref<QuestsSystem> = this.FmrQuests();
  if !IsDefined(view) || !IsDefined(qs) || !IsDefined(this.m_dataSource) {
    return;
  };
  let hidden: array<TweakDBID>;
  let recIds: array<TweakDBID>;
  let recSeqs: array<Int32>;
  let entries: array<ref<IScriptable>> = this.m_dataSource.GetArray();
  for entry in entries {
    let item: ref<VehicleListItemData> = entry as VehicleListItemData;
    if IsDefined(item) {
      let id: TweakDBID = item.m_data.recordID;
      if qs.GetFact(FmrFactKey("fmr_h_", id)) > 0 {
        ArrayPush(hidden, id);
      };
      let seq: Int32 = qs.GetFact(FmrFactKey("fmr_r_", id));
      if seq > 0 {
        ArrayPush(recIds, id);
        ArrayPush(recSeqs, seq);
      };
    };
  };
  let recent: array<TweakDBID>;
  while ArraySize(recent) < 10 && ArraySize(recIds) > 0 {
    let best: Int32 = 0;
    let i: Int32 = 1;
    while i < ArraySize(recIds) {
      if recSeqs[i] > recSeqs[best] {
        best = i;
      };
      i += 1;
    };
    ArrayPush(recent, recIds[best]);
    ArrayErase(recIds, best);
    ArrayErase(recSeqs, best);
  };
  view.m_hidden = hidden;
  view.m_recent = recent;
  this.FmrComputeDupes(view, entries);
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrComputeDupes(view: ref<FindMyRideDataView>, entries: array<ref<IScriptable>>) -> Void {
  ArrayClear(view.m_dupes);
  let settings: ref<FindMyRideSettings> = this.FmrSettings();
  if IsDefined(settings) && !settings.mergeVariants {
    return;
  };
  let names: array<CName>;
  let kept: array<ref<VehicleListItemData>>;
  for entry in entries {
    let item: ref<VehicleListItemData> = entry as VehicleListItemData;
    if IsDefined(item) {
      let idx: Int32 = -1;
      let i: Int32 = 0;
      while i < ArraySize(names) && idx < 0 {
        if Equals(names[i], item.m_displayName) {
          idx = i;
        };
        i += 1;
      };
      if idx < 0 {
        ArrayPush(names, item.m_displayName);
        ArrayPush(kept, item);
      } else {
        if view.FmrVariantRank(item) > view.FmrVariantRank(kept[idx]) {
          ArrayPush(view.m_dupes, kept[idx].m_data.recordID);
          kept[idx] = item;
        } else {
          ArrayPush(view.m_dupes, item.m_data.recordID);
        };
      };
    };
  };
}

@wrapMethod(VehiclesManagerPopupGameController)
private final func ToggleFavorite() -> Void {
  wrappedMethod();
  let view: ref<FindMyRideDataView> = this.m_dataView as FindMyRideDataView;
  if !IsDefined(view) {
    return;
  };
  let index: Uint32 = this.m_listController.GetSelectedIndex();
  this.FmrLoadFactLists();
  view.Sort();
  view.Filter();
  if view.Size() > 0u {
    this.m_listController.SelectItem(index < view.Size() ? index : view.Size() - 1u);
  };
  this.FmrUpdateBar();
  this.FmrUpdateInfo();
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrHideBetaWarning() -> Void {
  let root: ref<inkCompoundWidget> = this.GetRootCompoundWidget();
  if IsDefined(root) {
    this.FmrHideBetaIn(root, true);
  };
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrHideBetaIn(parent: ref<inkCompoundWidget>, parentIsRoot: Bool) -> Void {
  let count: Int32 = parent.GetNumChildren();
  let i: Int32 = 0;
  while i < count {
    let child: ref<inkWidget> = parent.GetWidgetByIndex(i);
    if IsDefined(child) {
      let childName: String = StrLower(NameToString(child.GetName()));
      if StrContains(childName, "warning") || StrContains(childName, "beta") {
        child.SetVisible(false);
      } else {
        let text: ref<inkText> = child as inkText;
        if IsDefined(text) {
          let value: String = text.GetText();
          if StrContains(value, "LocKey") {
            value = GetLocalizedText(value);
          };
          if StrContains(StrLower(value), "beta") {
            if !parentIsRoot && count <= 3 {
              parent.SetVisible(false);
              return;
            };
            text.SetVisible(false);
          };
        };
        let compound: ref<inkCompoundWidget> = child as inkCompoundWidget;
        if IsDefined(compound) {
          this.FmrHideBetaIn(compound, false);
        };
      };
    };
    i += 1;
  };
}

@wrapMethod(BaseModalListPopupGameController)
protected cb func OnPlayerDetach(playerPuppet: ref<GameObject>) -> Bool {
  if IsDefined(this as VehiclesManagerPopupGameController) {
    GameInstance.GetCallbackSystem().UnregisterCallback(n"Input/Key", this, n"OnFmrKeyInput");
  };
  return wrappedMethod(playerPuppet);
}

@wrapMethod(VehiclesManagerPopupGameController)
protected cb func OnAction(action: ListenerAction, consumer: ListenerActionConsumer) -> Bool {
  let actionName: CName = ListenerAction.GetName(action);
  if this.m_fmrEatProceedRelease && Equals(actionName, n"proceed") {
    if ListenerAction.IsButtonJustReleased(action) {
      this.m_fmrEatProceedRelease = false;
    };
    ListenerActionConsumer.Consume(consumer);
    return true;
  };
  if this.m_fmrSearchActive {
    if this.m_fmrTypedCancelKey && (Equals(actionName, n"cancel") || Equals(actionName, n"OpenPauseMenu")) {
      this.m_fmrTypedCancelKey = false;
      ListenerActionConsumer.DontSendReleaseEvent(consumer);
      ListenerActionConsumer.Consume(consumer);
      return true;
    };
    if this.m_fmrTypedProceedKey && Equals(actionName, n"proceed") {
      this.m_fmrTypedProceedKey = false;
      ListenerActionConsumer.Consume(consumer);
      return true;
    };
    if Equals(actionName, n"cancel") || Equals(actionName, n"OpenPauseMenu") {
      if ListenerAction.IsButtonJustPressed(action) {
        this.m_fmrSearch = "";
        this.m_fmrSearchActive = false;
        this.FmrApplyFilter();
      };
      ListenerActionConsumer.DontSendReleaseEvent(consumer);
      ListenerActionConsumer.Consume(consumer);
      return true;
    };
    if Equals(actionName, n"proceed") {
      if ListenerAction.IsButtonJustPressed(action) {
        this.m_fmrSearchActive = false;
        this.m_fmrEatProceedRelease = true;
        this.FmrUpdateBar();
      };
      ListenerActionConsumer.Consume(consumer);
      return true;
    };
    ListenerActionConsumer.DontSendReleaseEvent(consumer);
    ListenerActionConsumer.Consume(consumer);
    return true;
  };
  if this.m_fmrAtePadHideKey && (Equals(actionName, n"showAll") || Equals(actionName, n"call") || Equals(actionName, n"track_quest")) {
    if ListenerAction.IsButtonJustReleased(action) {
      this.m_fmrAtePadHideKey = false;
    };
    ListenerActionConsumer.DontSendReleaseEvent(consumer);
    ListenerActionConsumer.Consume(consumer);
    return true;
  };
  if this.m_fmrAteHubKey && Equals(actionName, n"OpenHubMenu") {
    if ListenerAction.IsButtonJustReleased(action) {
      this.m_fmrAteHubKey = false;
    };
    ListenerActionConsumer.DontSendReleaseEvent(consumer);
    ListenerActionConsumer.Consume(consumer);
    return true;
  };
  if (Equals(actionName, n"cancel") || Equals(actionName, n"OpenPauseMenu")) && (StrLen(this.m_fmrSearch) > 0 || this.m_fmrCategory != 0) {
    if ListenerAction.IsButtonJustPressed(action) {
      if StrLen(this.m_fmrSearch) > 0 {
        this.m_fmrSearch = "";
      } else {
        this.m_fmrCategory = 0;
      };
      this.FmrApplyFilter();
    };
    ListenerActionConsumer.DontSendReleaseEvent(consumer);
    ListenerActionConsumer.Consume(consumer);
    return true;
  };
  if (Equals(actionName, n"proceed") || Equals(actionName, n"secondaryAction")) && !IsDefined(this.m_listController.GetSelectedItem()) {
    ListenerActionConsumer.Consume(consumer);
    return true;
  };
  return wrappedMethod(action, consumer);
}

@addMethod(VehiclesManagerPopupGameController)
protected cb func OnFmrKeyInput(event: ref<KeyInputEvent>) {
  if !Equals(event.GetAction(), EInputAction.IACT_Press) {
    return;
  };
  let key: EInputKey = event.GetKey();
  let pad: Bool = StrBeginsWith(EnumValueToString("EInputKey", Cast<Int64>(EnumInt(key))), "IK_Pad");
  if NotEquals(pad, this.m_fmrPad) {
    this.m_fmrPad = pad;
    this.FmrUpdateBar();
  };
  if Equals(key, EInputKey.IK_Tab) {
    this.m_fmrSearchActive = !this.m_fmrSearchActive;
    this.FmrUpdateBar();
    return;
  };
  if Equals(key, EInputKey.IK_Left) || Equals(key, EInputKey.IK_Pad_DigitLeft) || Equals(key, EInputKey.IK_Pad_LeftShoulder) {
    this.FmrCycleCategory(-1);
    return;
  };
  if Equals(key, EInputKey.IK_Right) || Equals(key, EInputKey.IK_Pad_DigitRight) || Equals(key, EInputKey.IK_Pad_RightShoulder) {
    this.FmrCycleCategory(1);
    return;
  };
  if !this.m_fmrSearchActive {
    if Equals(key, EInputKey.IK_H) {
      this.m_fmrAteHubKey = true;
      this.FmrToggleHidden();
    };
    if Equals(key, EInputKey.IK_Pad_Y_TRIANGLE) {
      this.m_fmrAtePadHideKey = true;
      this.FmrToggleHidden();
    };
    return;
  };
  if Equals(key, EInputKey.IK_C) {
    this.m_fmrTypedCancelKey = true;
  };
  if Equals(key, EInputKey.IK_F) {
    this.m_fmrTypedProceedKey = true;
  };
  if Equals(key, EInputKey.IK_Backspace) {
    if StrLen(this.m_fmrSearch) > 0 {
      this.m_fmrSearch = StrLeft(this.m_fmrSearch, StrLen(this.m_fmrSearch) - 1);
      this.FmrApplyFilter();
    };
    return;
  };
  let char: String = FmrKeyToChar(key);
  if StrLen(char) > 0 && StrLen(this.m_fmrSearch) < 24 {
    this.m_fmrSearch += char;
    this.FmrApplyFilter();
  };
}

@wrapMethod(VehiclesManagerPopupGameController)
protected func Activate() -> Void {
  let selected: ref<VehiclesManagerListItemController> = this.m_listController.GetSelectedItem() as VehiclesManagerListItemController;
  if IsDefined(selected) {
    let data: ref<VehicleListItemData> = selected.GetVehicleData();
    if IsDefined(data) && data.m_repairTimeRemaining == 0.0 {
      let qs: ref<QuestsSystem> = this.FmrQuests();
      if IsDefined(qs) {
        let seq: Int32 = qs.GetFact(n"fmr_seq") + 1;
        qs.SetFact(n"fmr_seq", seq);
        qs.SetFact(FmrFactKey("fmr_r_", data.m_data.recordID), seq);
      };
    };
  };
  wrappedMethod();
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrCycleCategory(step: Int32) -> Void {
  let view: ref<FindMyRideDataView> = this.m_dataView as FindMyRideDataView;
  let count: Int32 = IsDefined(view) && ArraySize(view.m_hidden) > 0 ? 7 : 6;
  this.m_fmrCategory = (this.m_fmrCategory + step + count) % count;
  this.FmrApplyFilter();
  if IsDefined(this.m_fmrTabsRow) {
    let fade: ref<inkAnimDef> = new inkAnimDef();
    let alpha: ref<inkAnimTransparency> = new inkAnimTransparency();
    alpha.SetStartTransparency(0.45);
    alpha.SetEndTransparency(1.0);
    alpha.SetDuration(0.18);
    fade.AddInterpolator(alpha);
    this.m_fmrTabsRow.PlayAnimation(fade);
  };
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrToggleHidden() -> Void {
  let sel: ref<VehiclesManagerListItemController> = this.m_listController.GetSelectedItem() as VehiclesManagerListItemController;
  if !IsDefined(sel) {
    return;
  };
  let data: ref<VehicleListItemData> = sel.GetVehicleData();
  let qs: ref<QuestsSystem> = this.FmrQuests();
  if !IsDefined(data) || !IsDefined(qs) {
    return;
  };
  let id: TweakDBID = data.m_data.recordID;
  let view: ref<FindMyRideDataView> = this.m_dataView as FindMyRideDataView;
  if IsDefined(view) {
    if ArrayContains(view.m_hidden, id) {
      qs.SetFact(FmrFactKey("fmr_h_", id), 0);
      ArrayRemove(view.m_hidden, id);
    } else {
      qs.SetFact(FmrFactKey("fmr_h_", id), 1);
      ArrayPush(view.m_hidden, id);
    };
    if this.m_fmrCategory == 6 && ArraySize(view.m_hidden) == 0 {
      this.m_fmrCategory = 0;
    };
  };
  this.FmrApplyFilter();
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrApplyFilter() -> Void {
  let view: ref<FindMyRideDataView> = this.m_dataView as FindMyRideDataView;
  if !IsDefined(view) {
    return;
  };
  view.m_search = this.m_fmrSearch;
  view.m_category = this.m_fmrCategory;
  let state: ref<FindMyRideState> = this.FmrState();
  if IsDefined(state) {
    state.lastCategory = this.m_fmrCategory;
  };
  view.Sort();
  view.Filter();
  if view.Size() > 0u {
    this.m_listController.SelectItem(0u);
  };
  this.FmrUpdateBar();
  this.FmrUpdateInfo();
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrAccent() -> HDRColor {
  let settings: ref<FindMyRideSettings> = this.FmrSettings();
  let theme: FmrTheme = IsDefined(settings) ? settings.theme : FmrTheme.Netrunner;
  if Equals(theme, FmrTheme.Samurai) {
    return new HDRColor(0.988, 0.933, 0.039, 1.0);
  };
  if Equals(theme, FmrTheme.Corpo) {
    return new HDRColor(1.0, 0.36, 0.32, 1.0);
  };
  return new HDRColor(0.368627, 0.964706, 1.0, 1.0);
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrTypingColor() -> HDRColor {
  let settings: ref<FindMyRideSettings> = this.FmrSettings();
  if IsDefined(settings) && Equals(settings.theme, FmrTheme.Samurai) {
    return new HDRColor(0.368627, 0.964706, 1.0, 1.0);
  };
  return new HDRColor(0.988, 0.933, 0.039, 1.0);
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrMakeText(name: CName, style: CName, size: Int32, color: HDRColor) -> ref<inkText> {
  let text: ref<inkText> = new inkText();
  text.SetName(name);
  text.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
  text.SetFontStyle(style);
  text.SetFontSize(size);
  text.SetTintColor(color);
  return text;
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrCreateBar() -> Void {
  let root: ref<inkCompoundWidget> = this.GetRootCompoundWidget();
  if !IsDefined(root) {
    return;
  };
  let panel: ref<inkCanvas> = new inkCanvas();
  panel.SetName(n"FindMyRidePanel");
  panel.SetAnchor(inkEAnchor.Centered);
  panel.SetAnchorPoint(new Vector2(0.5, 0.5));
  panel.SetTranslation(new Vector2(0.0, 560.0));
  panel.Reparent(root);

  let bg: ref<inkRectangle> = new inkRectangle();
  bg.SetName(n"FindMyRideBg");
  bg.SetSize(new Vector2(1720.0, 200.0));
  bg.SetAnchor(inkEAnchor.Centered);
  bg.SetAnchorPoint(new Vector2(0.5, 0.5));
  bg.SetTintColor(new HDRColor(0.008, 0.02, 0.03, 1.0));
  bg.SetOpacity(0.78);
  bg.Reparent(panel);

  let accent: ref<inkRectangle> = new inkRectangle();
  accent.SetName(n"FindMyRideAccent");
  accent.SetSize(new Vector2(1720.0, 4.0));
  accent.SetAnchor(inkEAnchor.Centered);
  accent.SetAnchorPoint(new Vector2(0.5, 0.5));
  accent.SetTranslation(new Vector2(0.0, -98.0));
  accent.SetTintColor(this.FmrAccent());
  accent.Reparent(panel);

  let tabs: ref<inkHorizontalPanel> = new inkHorizontalPanel();
  tabs.SetName(n"FindMyRideTabs");
  tabs.SetAnchor(inkEAnchor.Centered);
  tabs.SetAnchorPoint(new Vector2(0.5, 0.5));
  tabs.SetTranslation(new Vector2(0.0, -58.0));
  tabs.Reparent(panel);
  this.m_fmrTabsRow = tabs;
  ArrayClear(this.m_fmrTabs);
  let i: Int32 = 0;
  while i < 7 {
    let tab: ref<inkText> = this.FmrMakeText(n"FindMyRideTab", n"Medium", 34, new HDRColor(0.6, 0.65, 0.7, 1.0));
    tab.SetMargin(new inkMargin(22.0, 0.0, 22.0, 0.0));
    tab.Reparent(tabs);
    ArrayPush(this.m_fmrTabs, tab);
    i += 1;
  };

  let bar: ref<inkText> = this.FmrMakeText(n"FindMyRideBar", n"Medium", 32, this.FmrAccent());
  bar.SetAnchor(inkEAnchor.Centered);
  bar.SetAnchorPoint(new Vector2(0.5, 0.5));
  bar.SetHorizontalAlignment(textHorizontalAlignment.Center);
  bar.SetTranslation(new Vector2(0.0, 8.0));
  bar.Reparent(panel);
  this.m_fmrBar = bar;

  let hintsWidget: ref<inkWidget> = this.SpawnFromExternal(panel, r"base\\gameplay\\gui\\common\\buttonhints.inkwidget", n"Root");
  if IsDefined(hintsWidget) {
    hintsWidget.SetVisible(false);
    this.m_fmrHints = hintsWidget.GetController() as ButtonHints;
    let holder: ref<inkWidget> = IsDefined(this.m_fmrHints) ? inkWidgetRef.Get(this.m_fmrHints.m_horizontalHolder) : null;
    if IsDefined(holder) {
      holder.Reparent(panel);
      holder.SetAnchor(inkEAnchor.Centered);
      holder.SetAnchorPoint(new Vector2(0.5, 0.5));
      holder.SetMargin(new inkMargin(0.0, 0.0, 0.0, 0.0));
      holder.SetTranslation(new Vector2(0.0, 8.0));
    };
  };

  let info: ref<inkText> = this.FmrMakeText(n"FindMyRideInfo", n"Regular", 28, new HDRColor(0.8, 0.85, 0.9, 0.85));
  info.SetAnchor(inkEAnchor.Centered);
  info.SetAnchorPoint(new Vector2(0.5, 0.5));
  info.SetHorizontalAlignment(textHorizontalAlignment.Center);
  info.SetTranslation(new Vector2(0.0, 62.0));
  info.Reparent(panel);
  this.m_fmrInfo = info;
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrUpdateTabs() -> Void {
  let view: ref<FindMyRideDataView> = this.m_dataView as FindMyRideDataView;
  let count: Int32 = IsDefined(view) ? Cast<Int32>(view.Size()) : 0;
  let loc: ref<LocalizationSystem> = this.FmrLoc();
  if !IsDefined(loc) || ArraySize(this.m_fmrTabs) < 7 {
    return;
  };
  let i: Int32 = 0;
  while i < 7 {
    let tab: wref<inkText> = this.m_fmrTabs[i];
    if IsDefined(tab) {
      if i == 6 {
        tab.SetVisible(IsDefined(view) && ArraySize(view.m_hidden) > 0);
      };
      let label: String = FmrCategoryLabel(i, loc);
      if i == this.m_fmrCategory {
        label += " (" + IntToString(count) + ")";
        tab.SetTintColor(this.FmrAccent());
        tab.SetOpacity(1.0);
      } else {
        tab.SetTintColor(new HDRColor(0.6, 0.65, 0.7, 1.0));
        tab.SetOpacity(0.55);
      };
      tab.SetText(label);
    };
    i += 1;
  };
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrUpdateInfoFrom(item: ref<VehiclesManagerListItemController>) -> Void {
  if !IsDefined(this.m_fmrInfo) {
    return;
  };
  if !IsDefined(item) {
    this.m_fmrInfo.SetText("");
    return;
  };
  let data: ref<VehicleListItemData> = item.GetVehicleData();
  if !IsDefined(data) {
    this.m_fmrInfo.SetText("");
    return;
  };
  let loc: ref<LocalizationSystem> = this.FmrLoc();
  let typeKey: String;
  switch FmrTypeOrder(data) {
    case 1: typeKey = "Mod-FindMyRide-Cat-Motorcycles"; break;
    case 2: typeKey = "Mod-FindMyRide-Cat-Armed"; break;
    default: typeKey = "Mod-FindMyRide-Cat-Cars"; break;
  };
  let text: String = FmrManufacturerName(data);
  if StrLen(text) > 0 {
    text += "  -  ";
  };
  text += loc.GetText(typeKey);
  let record: ref<Vehicle_Record> = TweakDBInterface.GetVehicleRecord(data.m_data.recordID);
  let ui: wref<VehicleUIData_Record> = IsDefined(record) ? record.VehicleUIData() : null;
  if IsDefined(ui) {
    let year: String = ui.ProductionYear();
    if StrLen(year) > 0 {
      text += "  -  " + FmrLocText(year);
    };
    let hp: Int32 = RoundMath(ui.Horsepower());
    if hp > 0 {
      text += "  -  " + IntToString(hp) + " " + loc.GetText("Mod-FindMyRide-Info-HP");
    };
    let drive: String = ui.DriveLayout();
    if StrLen(drive) > 0 {
      text += "  -  " + FmrLocText(drive);
    };
  };
  this.m_fmrInfo.SetText(text);
}

public func FmrLocText(value: String) -> String {
  return StrContains(value, "LocKey") ? GetLocalizedText(value) : value;
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrUpdateInfo() -> Void {
  this.FmrUpdateInfoFrom(this.m_listController.GetSelectedItem() as VehiclesManagerListItemController);
}

@wrapMethod(VehiclesManagerPopupGameController)
protected func Select(previous: ref<inkVirtualCompoundItemController>, next: ref<inkVirtualCompoundItemController>) -> Void {
  wrappedMethod(previous, next);
  this.FmrUpdateInfoFrom(next as VehiclesManagerListItemController);
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrUpdateBar() -> Void {
  this.FmrUpdateTabs();
  if !IsDefined(this.m_fmrBar) {
    return;
  };
  let loc: ref<LocalizationSystem> = this.FmrLoc();
  if !IsDefined(loc) {
    return;
  };
  let text: String;
  if this.m_fmrSearchActive {
    text = loc.GetText("Mod-FindMyRide-Bar-SearchPrefix") + this.m_fmrSearch + "_   [Enter] " + loc.GetText("Mod-FindMyRide-Bar-SearchHint");
    this.m_fmrBar.SetTintColor(this.FmrTypingColor());
    this.m_fmrBar.SetVisible(true);
    if IsDefined(this.m_fmrHints) {
      this.m_fmrHints.Hide();
      this.m_fmrHintKey = "";
    };
  } else if IsDefined(this.m_fmrHints) {
    this.m_fmrBar.SetVisible(false);
    this.FmrApplyHints(loc);
    return;
  } else {
    text = "[Tab] " + loc.GetText("Mod-FindMyRide-Bar-Search");
    text += "   [H] " + (this.m_fmrCategory == 6 ? loc.GetText("Mod-FindMyRide-Bar-Unhide") : loc.GetText("Mod-FindMyRide-Bar-Hide"));
    if StrLen(this.m_fmrSearch) > 0 {
      text += "   \"" + this.m_fmrSearch + "\"";
    };
    if StrLen(this.m_fmrSearch) > 0 || this.m_fmrCategory != 0 {
      text += "   [Esc] " + loc.GetText("Mod-FindMyRide-Bar-Clear");
    };
    this.m_fmrBar.SetTintColor(this.FmrAccent());
    this.m_fmrBar.SetVisible(true);
  };
  this.m_fmrBar.SetText(text);
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrApplyHints(loc: ref<LocalizationSystem>) -> Void {
  let kbm: Bool = !this.m_fmrPad;
  let searchLabel: String = loc.GetText("Mod-FindMyRide-Bar-Search");
  if StrLen(this.m_fmrSearch) > 0 {
    searchLabel += "  \"" + this.m_fmrSearch + "\"";
  };
  let hideLabel: String = this.m_fmrCategory == 6 ? loc.GetText("Mod-FindMyRide-Bar-Unhide") : loc.GetText("Mod-FindMyRide-Bar-Hide");
  let clear: Bool = StrLen(this.m_fmrSearch) > 0 || this.m_fmrCategory != 0;
  let key: String = (kbm ? "k|" : "p|") + searchLabel + "|" + hideLabel + (clear ? "|c" : "");
  if Equals(key, this.m_fmrHintKey) {
    this.m_fmrHints.Show();
    return;
  };
  this.m_fmrHintKey = key;
  this.m_fmrHints.ClearButtonHints();
  if clear {
    this.m_fmrHints.AddButtonHint(n"cancel", loc.GetText("Mod-FindMyRide-Bar-Clear"));
  };
  this.m_fmrHints.AddButtonHint(kbm ? n"OpenHubMenu" : n"showAll", hideLabel);
  this.m_fmrHints.AddButtonHint(n"popup_navigate_right", loc.GetText("Mod-FindMyRide-Bar-Tabs"));
  if kbm {
    this.m_fmrHints.AddButtonHint(n"popup_goto", searchLabel);
  };
  this.m_fmrHints.Show();
}
