module FindMyRide
import Codeware.Localization.*

public class FmrVanillaIndex extends IScriptable {
  public let keys: array<Uint64>;

  public func Contains(id: TweakDBID) -> Bool {
    let key: Uint64 = TDBID.ToNumber(id) % 1099511627776ul;
    let lo: Int32 = 0;
    let hi: Int32 = ArraySize(this.keys) - 1;
    while lo <= hi {
      let mid: Int32 = (lo + hi) / 2;
      let value: Uint64 = this.keys[mid];
      if value == key {
        return true;
      };
      if value < key {
        lo = mid + 1;
      } else {
        hi = mid - 1;
      };
    };
    return false;
  }
}

public class FindMyRideState extends ScriptableSystem {
  public let lastCategory: Int32;
  public let vanilla: ref<FmrVanillaIndex>;
}

public func FmrFactKey(prefix: String, id: TweakDBID) -> CName {
  return StringToName(prefix + s"\(TDBID.ToNumber(id))");
}

public class FindMyRideDataView extends VehiclesManagerDataView {
  public let m_search: String;
  public let m_category: Int32;
  public let m_sortMode: Int32;
  public let m_favsFirst: Bool;
  public let m_recent: array<TweakDBID>;
  public let m_hidden: array<TweakDBID>;
  public let m_dupes: array<TweakDBID>;
  public let m_mods: array<TweakDBID>;

  public func SortItem(lhs: ref<IScriptable>, rhs: ref<IScriptable>) -> Bool {
    if this.m_category == 2 {
      let li: ref<VehicleListItemData> = lhs as VehicleListItemData;
      let ri: ref<VehicleListItemData> = rhs as VehicleListItemData;
      if IsDefined(li) && IsDefined(ri) {
        return this.FmrRecentIndex(li.m_data.recordID) < this.FmrRecentIndex(ri.m_data.recordID);
      };
    };
    if this.m_sortMode == 0 && this.m_favsFirst {
      return super.SortItem(lhs, rhs);
    };
    let l: ref<VehicleListItemData> = lhs as VehicleListItemData;
    let r: ref<VehicleListItemData> = rhs as VehicleListItemData;
    if !IsDefined(l) || !IsDefined(r) {
      return false;
    };
    if this.m_favsFirst {
      let lFav: Bool = l.m_data.forcedFavorite || l.m_data.uiFavoriteIndex >= 0;
      let rFav: Bool = r.m_data.forcedFavorite || r.m_data.uiFavoriteIndex >= 0;
      if !Equals(lFav, rFav) {
        return lFav;
      };
    };
    let lKey: String;
    let rKey: String;
    if this.m_sortMode == 1 {
      lKey = FmrManufacturerName(l);
      rKey = FmrManufacturerName(r);
    };
    if this.m_sortMode == 2 {
      lKey = IntToString(FmrTypeOrder(l));
      rKey = IntToString(FmrTypeOrder(r));
    };
    if !Equals(lKey, rKey) {
      return UnicodeStringLessThan(lKey, rKey);
    };
    return UnicodeStringLessThan(GetLocalizedTextByKey(l.m_displayName), GetLocalizedTextByKey(r.m_displayName));
  }

  public func FmrVariantRank(item: ref<VehicleListItemData>) -> Int32 {
    let rank: Int32 = 0;
    if item.m_data.forcedFavorite || item.m_data.uiFavoriteIndex >= 0 {
      rank += 100000;
    };
    if ArrayContains(this.m_hidden, item.m_data.recordID) {
      rank -= 50000;
    };
    return rank + (10000 - this.FmrRecentIndex(item.m_data.recordID));
  }

  public func FmrRecentIndex(id: TweakDBID) -> Int32 {
    let i: Int32 = 0;
    while i < ArraySize(this.m_recent) {
      if this.m_recent[i] == id {
        return i;
      };
      i += 1;
    };
    return 9999;
  }

  public func FilterItem(data: ref<IScriptable>) -> Bool {
    let item: ref<VehicleListItemData> = data as VehicleListItemData;
    if !IsDefined(item) {
      return true;
    };
    return this.FmrPasses(item, this.m_category);
  }

  public func FmrPasses(item: ref<VehicleListItemData>, category: Int32) -> Bool {
    let id: TweakDBID = item.m_data.recordID;
    if category == 2 && this.FmrRecentIndex(id) >= 9999 {
      return false;
    };
    let isHidden: Bool = ArrayContains(this.m_hidden, id);
    if category == 7 {
      if !isHidden {
        return false;
      };
    } else {
      if isHidden {
        return false;
      };
    };
    if ArrayContains(this.m_dupes, id) {
      return false;
    };
    if category == 6 && !ArrayContains(this.m_mods, id) {
      return false;
    };
    if !FmrMatchesCategory(item, category) {
      return false;
    };
    return this.FmrMatchesSearch(item);
  }

  public func FmrMatchesSearch(item: ref<VehicleListItemData>) -> Bool {
    if StrLen(this.m_search) == 0 {
      return true;
    };
    let needle: String = FmrNormalize(this.m_search);
    if StrContains(FmrNormalize(GetLocalizedTextByKey(item.m_displayName)), needle) {
      return true;
    };
    return StrContains(FmrNormalize(FmrManufacturerName(item)), needle);
  }
}

public func FmrManufacturerName(item: ref<VehicleListItemData>) -> String {
  let record: ref<Vehicle_Record> = TweakDBInterface.GetVehicleRecord(item.m_data.recordID);
  if !IsDefined(record) {
    return "";
  };
  let manufacturer: ref<VehicleManufacturer_Record> = record.Manufacturer();
  if !IsDefined(manufacturer) {
    return "";
  };
  return manufacturer.EnumName();
}

public func FmrNormalize(text: String) -> String {
  let result: String = StrLower(text);
  result = StrReplaceAll(result, " ", "");
  result = StrReplaceAll(result, "-", "");
  return result;
}

public func FmrTypeOrder(item: ref<VehicleListItemData>) -> Int32 {
  if Equals(item.m_data.vehicleType, gamedataVehicleType.Bike) {
    return 1;
  };
  let record: ref<Vehicle_Record> = TweakDBInterface.GetVehicleRecord(item.m_data.recordID);
  if IsDefined(record) && Equals(record.VehDataPackageHandle().DriverCombat().Type(), gamedataDriverCombatType.MountedWeapons) {
    return 2;
  };
  return 0;
}

public func FmrMatchesCategory(item: ref<VehicleListItemData>, category: Int32) -> Bool {
  if category == 0 || category == 2 || category == 6 || category == 7 {
    return true;
  };
  if category == 1 {
    return item.m_data.uiFavoriteIndex >= 0 || item.m_data.forcedFavorite;
  };
  let isBike: Bool = Equals(item.m_data.vehicleType, gamedataVehicleType.Bike);
  if category == 4 {
    return isBike;
  };
  let record: ref<Vehicle_Record> = TweakDBInterface.GetVehicleRecord(item.m_data.recordID);
  let isArmed: Bool = Equals(record.VehDataPackageHandle().DriverCombat().Type(), gamedataDriverCombatType.MountedWeapons);
  if category == 5 {
    return isArmed;
  };
  return !isBike && !isArmed;
}

public func FmrCategoryLabel(category: Int32, loc: ref<LocalizationSystem>) -> String {
  switch category {
    case 1: return loc.GetText("Mod-FindMyRide-Cat-Favorites");
    case 2: return loc.GetText("Mod-FindMyRide-Cat-Recent");
    case 3: return loc.GetText("Mod-FindMyRide-Cat-Cars");
    case 4: return loc.GetText("Mod-FindMyRide-Cat-Motorcycles");
    case 5: return loc.GetText("Mod-FindMyRide-Cat-Armed");
    case 6: return loc.GetText("Mod-FindMyRide-Cat-Mods");
    case 7: return loc.GetText("Mod-FindMyRide-Cat-Hidden");
    default: return loc.GetText("Mod-FindMyRide-Cat-All");
  };
}

public func FmrKeyToChar(key: EInputKey) -> String {
  switch key {
    case EInputKey.IK_A: return "a";
    case EInputKey.IK_B: return "b";
    case EInputKey.IK_C: return "c";
    case EInputKey.IK_D: return "d";
    case EInputKey.IK_E: return "e";
    case EInputKey.IK_F: return "f";
    case EInputKey.IK_G: return "g";
    case EInputKey.IK_H: return "h";
    case EInputKey.IK_I: return "i";
    case EInputKey.IK_J: return "j";
    case EInputKey.IK_K: return "k";
    case EInputKey.IK_L: return "l";
    case EInputKey.IK_M: return "m";
    case EInputKey.IK_N: return "n";
    case EInputKey.IK_O: return "o";
    case EInputKey.IK_P: return "p";
    case EInputKey.IK_Q: return "q";
    case EInputKey.IK_R: return "r";
    case EInputKey.IK_S: return "s";
    case EInputKey.IK_T: return "t";
    case EInputKey.IK_U: return "u";
    case EInputKey.IK_V: return "v";
    case EInputKey.IK_W: return "w";
    case EInputKey.IK_X: return "x";
    case EInputKey.IK_Y: return "y";
    case EInputKey.IK_Z: return "z";
    case EInputKey.IK_0: return "0";
    case EInputKey.IK_1: return "1";
    case EInputKey.IK_2: return "2";
    case EInputKey.IK_3: return "3";
    case EInputKey.IK_4: return "4";
    case EInputKey.IK_5: return "5";
    case EInputKey.IK_6: return "6";
    case EInputKey.IK_7: return "7";
    case EInputKey.IK_8: return "8";
    case EInputKey.IK_9: return "9";
    case EInputKey.IK_NumPad0: return "0";
    case EInputKey.IK_NumPad1: return "1";
    case EInputKey.IK_NumPad2: return "2";
    case EInputKey.IK_NumPad3: return "3";
    case EInputKey.IK_NumPad4: return "4";
    case EInputKey.IK_NumPad5: return "5";
    case EInputKey.IK_NumPad6: return "6";
    case EInputKey.IK_NumPad7: return "7";
    case EInputKey.IK_NumPad8: return "8";
    case EInputKey.IK_NumPad9: return "9";
    case EInputKey.IK_Space: return " ";
    case EInputKey.IK_Minus: return "-";
    case EInputKey.IK_NumMinus: return "-";
    default: return "";
  };
}

@addField(VehiclesManagerPopupGameController)
let m_fmrSearchActive: Bool;

@addField(VehiclesManagerPopupGameController)
let m_fmrSearch: String;

@addField(VehiclesManagerPopupGameController)
let m_fmrCategory: Int32;

@addField(VehiclesManagerPopupGameController)
let m_fmrEatProceedRelease: Bool;

@addField(VehiclesManagerPopupGameController)
let m_fmrTypedCancelKey: Bool;

@addField(VehiclesManagerPopupGameController)
let m_fmrTypedProceedKey: Bool;

@addField(VehiclesManagerPopupGameController)
let m_fmrAteHubKey: Bool;

@addField(VehiclesManagerPopupGameController)
let m_fmrAtePadHideKey: Bool;

@addField(VehiclesManagerPopupGameController)
let m_fmrHintKey: String;

@addField(VehiclesManagerPopupGameController)
let m_fmrPad: Bool;

@addField(VehiclesManagerPopupGameController)
let m_fmrVanillaTheme: Bool;

@addField(VehiclesManagerPopupGameController)
let m_fmrTabsRow: wref<inkHorizontalPanel>;

@addField(VehiclesManagerPopupGameController)
let m_fmrTabBoxes: array<wref<inkWidget>>;

@addField(VehiclesManagerPopupGameController)
let m_fmrTabs: array<wref<inkText>>;

@addField(VehiclesManagerPopupGameController)
let m_fmrTabLines: array<wref<inkRectangle>>;

@addField(VehiclesManagerPopupGameController)
let m_fmrPrevHint: wref<ButtonHintListItem>;

@addField(VehiclesManagerPopupGameController)
let m_fmrNextHint: wref<ButtonHintListItem>;

@addField(VehiclesManagerPopupGameController)
let m_fmrHideHint: wref<ButtonHintListItem>;

@addField(VehiclesManagerPopupGameController)
let m_fmrSearchIcon: wref<inkWidget>;

@addField(VehiclesManagerPopupGameController)
let m_fmrSearchText: wref<inkText>;

@addField(VehiclesManagerPopupGameController)
let m_fmrInfoMain: wref<inkText>;

@addField(VehiclesManagerPopupGameController)
let m_fmrInfoMod: wref<inkText>;

@addField(VehiclesManagerPopupGameController)
let m_fmrInfoSpecs: wref<inkText>;

@addField(VehiclesManagerPopupGameController)
let m_fmrEmpty: wref<inkText>;

@addField(VehiclesManagerPopupGameController)
let m_fmrCloseText: wref<inkText>;

@addField(VehiclesManagerPopupGameController)
let m_fmrCloseCleared: Bool;

@wrapMethod(VehiclesManagerPopupGameController)
protected func SetupVirtualList() -> Void {
  wrappedMethod();
  this.m_dataView = new FindMyRideDataView();
  this.m_dataView.SetSource(this.m_dataSource);
  this.m_listController.SetSource(this.m_dataView);
}

@wrapMethod(VehiclesManagerPopupGameController)
protected cb func OnPlayerAttach(player: ref<GameObject>) -> Bool {
  let preSettings: ref<FindMyRideSettings> = FindMyRideSettings.Get(player.GetGame());
  let preView: ref<FindMyRideDataView> = this.m_dataView as FindMyRideDataView;
  if IsDefined(preView) {
    preView.m_sortMode = IsDefined(preSettings) ? EnumInt(preSettings.sortMode) : 0;
    preView.m_favsFirst = IsDefined(preSettings) ? preSettings.favoritesFirst : true;
  };
  let result: Bool = wrappedMethod(player);
  this.FmrLoadFactLists();
  this.m_fmrSearchActive = false;
  this.m_fmrSearch = "";
  let state: ref<FindMyRideState> = this.FmrState();
  let settings: ref<FindMyRideSettings> = this.FmrSettings();
  let remember: Bool = IsDefined(settings) ? settings.rememberCategory : true;
  this.m_fmrCategory = remember && IsDefined(state) ? state.lastCategory : 0;
  if !this.FmrCategoryAvailable(this.m_fmrCategory) {
    this.m_fmrCategory = 0;
  };
  this.m_fmrEatProceedRelease = false;
  this.m_fmrTypedCancelKey = false;
  this.m_fmrTypedProceedKey = false;
  this.m_fmrAtePadHideKey = false;
  this.m_fmrHintKey = "";
  this.m_fmrCloseCleared = false;
  this.m_fmrPad = !player.PlayerLastUsedKBM();
  this.m_fmrVanillaTheme = !IsDefined(settings) || Equals(settings.theme, FmrTheme.Vanilla);
  GameInstance.GetCallbackSystem().RegisterCallback(n"Input/Key", this, n"OnFmrKeyInput");
  let pco: ref<GameObject> = this.GetPlayerControlledObject();
  pco.RegisterInputListener(this, n"OpenMapMenu");
  pco.RegisterInputListener(this, n"OpenJournalMenu");
  pco.RegisterInputListener(this, n"OpenPerksMenu");
  pco.RegisterInputListener(this, n"OpenInventoryMenu");
  pco.RegisterInputListener(this, n"OpenCraftingMenu");
  pco.RegisterInputListener(this, n"OpenHubMenu");
  pco.RegisterInputListener(this, n"CharacterPanel");
  pco.RegisterInputListener(this, n"Inventory");
  pco.RegisterInputListener(this, n"PhoneInteract");
  pco.RegisterInputListener(this, n"showAll");
  pco.RegisterInputListener(this, n"call");
  pco.RegisterInputListener(this, n"track_quest");
  if !IsDefined(settings) || settings.hideBetaWarning {
    this.FmrHideBetaWarning();
  };
  this.FmrBuildUi();
  this.FmrApplyFilter();
  return result;
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrLoc() -> ref<LocalizationSystem> {
  return LocalizationSystem.GetInstance(this.GetPlayerControlledObject().GetGame());
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrSettings() -> ref<FindMyRideSettings> {
  return FindMyRideSettings.Get(this.GetPlayerControlledObject().GetGame());
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrState() -> ref<FindMyRideState> {
  let game: GameInstance = this.GetPlayerControlledObject().GetGame();
  return GameInstance.GetScriptableSystemsContainer(game).Get(n"FindMyRide.FindMyRideState") as FindMyRideState;
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrQuests() -> ref<QuestsSystem> {
  return GameInstance.GetQuestsSystem(this.GetPlayerControlledObject().GetGame());
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrVanilla() -> ref<FmrVanillaIndex> {
  let state: ref<FindMyRideState> = this.FmrState();
  if IsDefined(state) && IsDefined(state.vanilla) {
    return state.vanilla;
  };
  let index: ref<FmrVanillaIndex> = new FmrVanillaIndex();
  index.keys = FmrVanillaVehicleKeys();
  if IsDefined(state) {
    state.vanilla = index;
  };
  return index;
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrLoadFactLists() -> Void {
  let view: ref<FindMyRideDataView> = this.m_dataView as FindMyRideDataView;
  let qs: ref<QuestsSystem> = this.FmrQuests();
  if !IsDefined(view) || !IsDefined(qs) || !IsDefined(this.m_dataSource) {
    return;
  };
  let vanilla: ref<FmrVanillaIndex> = this.FmrVanilla();
  let hidden: array<TweakDBID>;
  let mods: array<TweakDBID>;
  let recIds: array<TweakDBID>;
  let recSeqs: array<Int32>;
  let entries: array<ref<IScriptable>> = this.m_dataSource.GetArray();
  for entry in entries {
    let item: ref<VehicleListItemData> = entry as VehicleListItemData;
    if IsDefined(item) {
      let id: TweakDBID = item.m_data.recordID;
      if qs.GetFact(FmrFactKey("fmr_h_", id)) > 0 {
        ArrayPush(hidden, id);
      };
      if !vanilla.Contains(id) {
        ArrayPush(mods, id);
      };
      let seq: Int32 = qs.GetFact(FmrFactKey("fmr_r_", id));
      if seq > 0 {
        ArrayPush(recIds, id);
        ArrayPush(recSeqs, seq);
      };
    };
  };
  let recent: array<TweakDBID>;
  while ArraySize(recent) < 10 && ArraySize(recIds) > 0 {
    let best: Int32 = 0;
    let i: Int32 = 1;
    while i < ArraySize(recIds) {
      if recSeqs[i] > recSeqs[best] {
        best = i;
      };
      i += 1;
    };
    ArrayPush(recent, recIds[best]);
    ArrayErase(recIds, best);
    ArrayErase(recSeqs, best);
  };
  view.m_hidden = hidden;
  view.m_mods = mods;
  view.m_recent = recent;
  this.FmrComputeDupes(view, entries);
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrComputeDupes(view: ref<FindMyRideDataView>, entries: array<ref<IScriptable>>) -> Void {
  ArrayClear(view.m_dupes);
  let settings: ref<FindMyRideSettings> = this.FmrSettings();
  if IsDefined(settings) && !settings.mergeVariants {
    return;
  };
  let names: array<CName>;
  let kept: array<ref<VehicleListItemData>>;
  for entry in entries {
    let item: ref<VehicleListItemData> = entry as VehicleListItemData;
    if IsDefined(item) {
      let idx: Int32 = -1;
      let i: Int32 = 0;
      while i < ArraySize(names) && idx < 0 {
        if Equals(names[i], item.m_displayName) {
          idx = i;
        };
        i += 1;
      };
      if idx < 0 {
        ArrayPush(names, item.m_displayName);
        ArrayPush(kept, item);
      } else {
        if view.FmrVariantRank(item) > view.FmrVariantRank(kept[idx]) {
          ArrayPush(view.m_dupes, kept[idx].m_data.recordID);
          kept[idx] = item;
        } else {
          ArrayPush(view.m_dupes, item.m_data.recordID);
        };
      };
    };
  };
}

@wrapMethod(VehiclesManagerPopupGameController)
private final func ToggleFavorite() -> Void {
  wrappedMethod();
  let view: ref<FindMyRideDataView> = this.m_dataView as FindMyRideDataView;
  if !IsDefined(view) {
    return;
  };
  let index: Uint32 = this.m_listController.GetSelectedIndex();
  this.FmrLoadFactLists();
  view.Sort();
  view.Filter();
  if view.Size() > 0u {
    this.m_listController.SelectItem(index < view.Size() ? index : view.Size() - 1u);
  };
  this.FmrRefreshUi();
  this.FmrUpdateInfo();
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrHideBetaWarning() -> Void {
  let root: ref<inkCompoundWidget> = this.GetRootCompoundWidget();
  if IsDefined(root) {
    this.FmrHideBetaIn(root, true);
  };
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrHideBetaIn(parent: ref<inkCompoundWidget>, parentIsRoot: Bool) -> Void {
  let count: Int32 = parent.GetNumChildren();
  let i: Int32 = 0;
  while i < count {
    let child: ref<inkWidget> = parent.GetWidgetByIndex(i);
    if IsDefined(child) {
      let childName: String = StrLower(NameToString(child.GetName()));
      if StrContains(childName, "warning") || StrContains(childName, "beta") {
        child.SetVisible(false);
      } else {
        let text: ref<inkText> = child as inkText;
        if IsDefined(text) {
          let value: String = text.GetText();
          if StrContains(value, "LocKey") {
            value = GetLocalizedText(value);
          };
          if StrContains(StrLower(value), "beta") {
            if !parentIsRoot && count <= 3 {
              parent.SetVisible(false);
              return;
            };
            text.SetVisible(false);
          };
        };
        let compound: ref<inkCompoundWidget> = child as inkCompoundWidget;
        if IsDefined(compound) {
          this.FmrHideBetaIn(compound, false);
        };
      };
    };
    i += 1;
  };
}

@wrapMethod(BaseModalListPopupGameController)
protected cb func OnPlayerDetach(playerPuppet: ref<GameObject>) -> Bool {
  if IsDefined(this as VehiclesManagerPopupGameController) {
    GameInstance.GetCallbackSystem().UnregisterCallback(n"Input/Key", this, n"OnFmrKeyInput");
  };
  return wrappedMethod(playerPuppet);
}

@wrapMethod(VehiclesManagerPopupGameController)
protected cb func OnAction(action: ListenerAction, consumer: ListenerActionConsumer) -> Bool {
  let actionName: CName = ListenerAction.GetName(action);
  if this.m_fmrEatProceedRelease && Equals(actionName, n"proceed") {
    if ListenerAction.IsButtonJustReleased(action) {
      this.m_fmrEatProceedRelease = false;
    };
    ListenerActionConsumer.Consume(consumer);
    return true;
  };
  if this.m_fmrSearchActive {
    if this.m_fmrTypedCancelKey && (Equals(actionName, n"cancel") || Equals(actionName, n"OpenPauseMenu")) {
      this.m_fmrTypedCancelKey = false;
      ListenerActionConsumer.DontSendReleaseEvent(consumer);
      ListenerActionConsumer.Consume(consumer);
      return true;
    };
    if this.m_fmrTypedProceedKey && Equals(actionName, n"proceed") {
      this.m_fmrTypedProceedKey = false;
      ListenerActionConsumer.Consume(consumer);
      return true;
    };
    if Equals(actionName, n"cancel") || Equals(actionName, n"OpenPauseMenu") {
      if ListenerAction.IsButtonJustPressed(action) {
        this.m_fmrSearch = "";
        this.m_fmrSearchActive = false;
        this.FmrApplyFilter();
      };
      ListenerActionConsumer.DontSendReleaseEvent(consumer);
      ListenerActionConsumer.Consume(consumer);
      return true;
    };
    if Equals(actionName, n"proceed") {
      if ListenerAction.IsButtonJustPressed(action) {
        this.m_fmrSearchActive = false;
        this.m_fmrEatProceedRelease = true;
        this.FmrRefreshUi();
      };
      ListenerActionConsumer.Consume(consumer);
      return true;
    };
    ListenerActionConsumer.DontSendReleaseEvent(consumer);
    ListenerActionConsumer.Consume(consumer);
    return true;
  };
  if this.m_fmrAtePadHideKey && (Equals(actionName, n"showAll") || Equals(actionName, n"call") || Equals(actionName, n"track_quest")) {
    if ListenerAction.IsButtonJustReleased(action) {
      this.m_fmrAtePadHideKey = false;
    };
    ListenerActionConsumer.DontSendReleaseEvent(consumer);
    ListenerActionConsumer.Consume(consumer);
    return true;
  };
  if this.m_fmrAteHubKey && Equals(actionName, n"OpenHubMenu") {
    if ListenerAction.IsButtonJustReleased(action) {
      this.m_fmrAteHubKey = false;
    };
    ListenerActionConsumer.DontSendReleaseEvent(consumer);
    ListenerActionConsumer.Consume(consumer);
    return true;
  };
  if (Equals(actionName, n"cancel") || Equals(actionName, n"OpenPauseMenu")) && (StrLen(this.m_fmrSearch) > 0 || this.m_fmrCategory != 0) {
    if ListenerAction.IsButtonJustPressed(action) {
      if StrLen(this.m_fmrSearch) > 0 {
        this.m_fmrSearch = "";
      } else {
        this.m_fmrCategory = 0;
      };
      this.FmrApplyFilter();
    };
    ListenerActionConsumer.DontSendReleaseEvent(consumer);
    ListenerActionConsumer.Consume(consumer);
    return true;
  };
  if (Equals(actionName, n"proceed") || Equals(actionName, n"secondaryAction")) && !IsDefined(this.m_listController.GetSelectedItem()) {
    ListenerActionConsumer.Consume(consumer);
    return true;
  };
  return wrappedMethod(action, consumer);
}

@addMethod(VehiclesManagerPopupGameController)
protected cb func OnFmrKeyInput(event: ref<KeyInputEvent>) {
  if !Equals(event.GetAction(), EInputAction.IACT_Press) {
    return;
  };
  let key: EInputKey = event.GetKey();
  let pad: Bool = StrBeginsWith(EnumValueToString("EInputKey", Cast<Int64>(EnumInt(key))), "IK_Pad");
  if NotEquals(pad, this.m_fmrPad) {
    this.m_fmrPad = pad;
    this.FmrRefreshUi();
  };
  if Equals(key, EInputKey.IK_Tab) {
    this.m_fmrSearchActive = !this.m_fmrSearchActive;
    this.FmrRefreshUi();
    return;
  };
  if Equals(key, EInputKey.IK_Left) || Equals(key, EInputKey.IK_Pad_DigitLeft) || Equals(key, EInputKey.IK_Pad_LeftShoulder) {
    this.FmrCycleCategory(-1);
    return;
  };
  if Equals(key, EInputKey.IK_Right) || Equals(key, EInputKey.IK_Pad_DigitRight) || Equals(key, EInputKey.IK_Pad_RightShoulder) {
    this.FmrCycleCategory(1);
    return;
  };
  if !this.m_fmrSearchActive {
    if Equals(key, EInputKey.IK_H) {
      this.m_fmrAteHubKey = true;
      this.FmrToggleHidden();
    };
    if Equals(key, EInputKey.IK_Pad_Y_TRIANGLE) {
      this.m_fmrAtePadHideKey = true;
      this.FmrToggleHidden();
    };
    return;
  };
  if Equals(key, EInputKey.IK_C) {
    this.m_fmrTypedCancelKey = true;
  };
  if Equals(key, EInputKey.IK_F) {
    this.m_fmrTypedProceedKey = true;
  };
  if Equals(key, EInputKey.IK_Backspace) {
    if StrLen(this.m_fmrSearch) > 0 {
      this.m_fmrSearch = StrLeft(this.m_fmrSearch, StrLen(this.m_fmrSearch) - 1);
      this.FmrApplyFilter();
    };
    return;
  };
  let char: String = FmrKeyToChar(key);
  if StrLen(char) > 0 && StrLen(this.m_fmrSearch) < 24 {
    this.m_fmrSearch += char;
    this.FmrApplyFilter();
  };
}

@wrapMethod(VehiclesManagerPopupGameController)
protected func Activate() -> Void {
  let selected: ref<VehiclesManagerListItemController> = this.m_listController.GetSelectedItem() as VehiclesManagerListItemController;
  if IsDefined(selected) {
    let data: ref<VehicleListItemData> = selected.GetVehicleData();
    if IsDefined(data) && data.m_repairTimeRemaining == 0.0 {
      let qs: ref<QuestsSystem> = this.FmrQuests();
      if IsDefined(qs) {
        let seq: Int32 = qs.GetFact(n"fmr_seq") + 1;
        qs.SetFact(n"fmr_seq", seq);
        qs.SetFact(FmrFactKey("fmr_r_", data.m_data.recordID), seq);
      };
    };
  };
  wrappedMethod();
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrCategoryAvailable(category: Int32) -> Bool {
  if category < 0 || category > 7 {
    return false;
  };
  let view: ref<FindMyRideDataView> = this.m_dataView as FindMyRideDataView;
  if category == 6 {
    return IsDefined(view) && ArraySize(view.m_mods) > 0;
  };
  if category == 7 {
    return IsDefined(view) && ArraySize(view.m_hidden) > 0;
  };
  return true;
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrCycleCategory(step: Int32) -> Void {
  let next: Int32 = this.m_fmrCategory;
  let tries: Int32 = 0;
  next = (next + step + 8) % 8;
  while !this.FmrCategoryAvailable(next) && tries < 8 {
    next = (next + step + 8) % 8;
    tries += 1;
  };
  this.m_fmrCategory = next;
  this.FmrApplyFilter();
  if IsDefined(this.m_fmrTabsRow) {
    let fade: ref<inkAnimDef> = new inkAnimDef();
    let alpha: ref<inkAnimTransparency> = new inkAnimTransparency();
    alpha.SetStartTransparency(0.45);
    alpha.SetEndTransparency(1.0);
    alpha.SetDuration(0.18);
    fade.AddInterpolator(alpha);
    this.m_fmrTabsRow.PlayAnimation(fade);
  };
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrToggleHidden() -> Void {
  let sel: ref<VehiclesManagerListItemController> = this.m_listController.GetSelectedItem() as VehiclesManagerListItemController;
  if !IsDefined(sel) {
    return;
  };
  let data: ref<VehicleListItemData> = sel.GetVehicleData();
  let qs: ref<QuestsSystem> = this.FmrQuests();
  if !IsDefined(data) || !IsDefined(qs) {
    return;
  };
  let id: TweakDBID = data.m_data.recordID;
  let view: ref<FindMyRideDataView> = this.m_dataView as FindMyRideDataView;
  if IsDefined(view) {
    if ArrayContains(view.m_hidden, id) {
      qs.SetFact(FmrFactKey("fmr_h_", id), 0);
      ArrayRemove(view.m_hidden, id);
    } else {
      qs.SetFact(FmrFactKey("fmr_h_", id), 1);
      ArrayPush(view.m_hidden, id);
    };
    if this.m_fmrCategory == 7 && ArraySize(view.m_hidden) == 0 {
      this.m_fmrCategory = 0;
    };
  };
  this.FmrApplyFilter();
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrApplyFilter() -> Void {
  let view: ref<FindMyRideDataView> = this.m_dataView as FindMyRideDataView;
  if !IsDefined(view) {
    return;
  };
  view.m_search = this.m_fmrSearch;
  view.m_category = this.m_fmrCategory;
  let state: ref<FindMyRideState> = this.FmrState();
  if IsDefined(state) {
    state.lastCategory = this.m_fmrCategory;
  };
  view.Sort();
  view.Filter();
  if view.Size() > 0u {
    this.m_listController.SelectItem(0u);
  };
  this.FmrRefreshUi();
  this.FmrUpdateInfo();
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrAccent() -> HDRColor {
  let settings: ref<FindMyRideSettings> = this.FmrSettings();
  let theme: FmrTheme = IsDefined(settings) ? settings.theme : FmrTheme.Netrunner;
  switch theme {
    case FmrTheme.Samurai: return new HDRColor(0.988, 0.933, 0.039, 1.0);
    case FmrTheme.Corpo: return new HDRColor(1.0, 0.36, 0.32, 1.0);
    case FmrTheme.Militech: return new HDRColor(0.58, 0.74, 1.0, 1.0);
    case FmrTheme.Valentinos: return new HDRColor(1.0, 0.84, 0.4, 1.0);
    case FmrTheme.Maelstrom: return new HDRColor(1.0, 0.58, 0.28, 1.0);
    case FmrTheme.VoodooBoys: return new HDRColor(0.45, 1.0, 0.66, 1.0);
    case FmrTheme.Mox: return new HDRColor(1.0, 0.56, 0.82, 1.0);
    case FmrTheme.Arasaka: return new HDRColor(0.92, 0.35, 0.45, 1.0);
    default: return new HDRColor(0.368627, 0.964706, 1.0, 1.0);
  };
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrTypingColor() -> HDRColor {
  let settings: ref<FindMyRideSettings> = this.FmrSettings();
  if IsDefined(settings) && (Equals(settings.theme, FmrTheme.Samurai) || Equals(settings.theme, FmrTheme.Valentinos)) {
    return new HDRColor(0.368627, 0.964706, 1.0, 1.0);
  };
  return new HDRColor(0.988, 0.933, 0.039, 1.0);
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrMutedColor() -> HDRColor {
  return new HDRColor(0.6, 0.65, 0.7, 1.0);
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrPaint(widget: ref<inkWidget>, color: HDRColor, styleKey: CName) -> Void {
  if !IsDefined(widget) {
    return;
  };
  if this.m_fmrVanillaTheme {
    widget.BindProperty(n"tintColor", styleKey);
  } else {
    widget.SetTintColor(color);
  };
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrMakeText(name: CName, style: CName, size: Int32) -> ref<inkText> {
  let text: ref<inkText> = new inkText();
  text.SetName(name);
  text.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
  text.SetFontStyle(style);
  text.SetFontSize(size);
  if this.m_fmrVanillaTheme {
    text.SetStyle(r"base\\gameplay\\gui\\common\\main_colors.inkstyle");
  };
  return text;
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrSpawnHint(parent: ref<inkCompoundWidget>, action: CName, label: String) -> ref<ButtonHintListItem> {
  let widget: ref<inkWidget> = this.SpawnFromExternal(parent, r"base\\gameplay\\gui\\common\\buttonhints.inkwidget", n"ButtonHintListItem");
  if !IsDefined(widget) {
    return null;
  };
  widget.SetVAlign(inkEVerticalAlign.Center);
  let hint: ref<ButtonHintListItem> = widget.GetController() as ButtonHintListItem;
  if IsDefined(hint) {
    hint.SetData(action, label);
  };
  let text: ref<inkText> = this.FmrHintLabel(hint);
  if IsDefined(text) {
    text.BindProperty(n"fontSize", n"MainColors.ReadableSmall");
    text.BindProperty(n"fontStyle", n"MainColors.HeaderFontWeight");
    text.SetLetterCase(textLetterCase.UpperCase);
    text.SetVisible(StrLen(label) > 0);
  };
  return hint;
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrHintLabel(hint: ref<ButtonHintListItem>) -> ref<inkText> {
  if !IsDefined(hint) {
    return null;
  };
  let root: ref<inkCompoundWidget> = hint.GetRootWidget() as inkCompoundWidget;
  if !IsDefined(root) {
    return null;
  };
  return root.GetWidget(n"holder/label") as inkText;
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrBuildUi() -> Void {
  let root: ref<inkCompoundWidget> = this.GetRootCompoundWidget();
  let container: ref<inkCompoundWidget> = IsDefined(root) ? root.GetWidget(n"containerRoot") as inkCompoundWidget : null;
  if !IsDefined(container) {
    return;
  };
  let wrapper: ref<inkWidget> = container.GetWidget(n"wrapper");
  if IsDefined(wrapper) {
    let margin: inkMargin = wrapper.GetMargin();
    margin.top += 32.0;
    wrapper.SetMargin(margin);
  };
  this.FmrBuildTabs(container);
  this.FmrBuildSearch(container);
  this.FmrBuildInfo(container);
  this.FmrBuildEmpty(container);
  this.FmrBuildHints(container);
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrBuildTabs(container: ref<inkCompoundWidget>) -> Void {
  let bar: ref<inkCanvas> = new inkCanvas();
  bar.SetName(n"FindMyRideTabBar");
  bar.SetAnchor(inkEAnchor.TopCenter);
  bar.SetAnchorPoint(new Vector2(0.5, 0.0));
  bar.SetSize(new Vector2(MaxF(container.GetSize().X - 152.0, 1488.0), 66.0));
  bar.SetTranslation(new Vector2(0.0, 118.0));
  bar.Reparent(container);

  if !this.m_fmrVanillaTheme {
    let plate: ref<inkRectangle> = new inkRectangle();
    plate.SetName(n"FindMyRidePlate");
    plate.SetAnchor(inkEAnchor.Fill);
    plate.SetTintColor(new HDRColor(0.008, 0.02, 0.03, 1.0));
    plate.SetOpacity(0.6);
    plate.Reparent(bar);
  };

  let row: ref<inkHorizontalPanel> = new inkHorizontalPanel();
  row.SetName(n"FindMyRideTabs");
  row.SetAnchor(inkEAnchor.Centered);
  row.SetAnchorPoint(new Vector2(0.5, 0.5));
  row.SetFitToContent(true);
  row.Reparent(bar);
  this.m_fmrTabsRow = row;

  this.m_fmrPrevHint = this.FmrSpawnHint(row, n"popup_navigate_left", "");
  ArrayClear(this.m_fmrTabBoxes);
  ArrayClear(this.m_fmrTabs);
  ArrayClear(this.m_fmrTabLines);
  let i: Int32 = 0;
  while i < 8 {
    let box: ref<inkVerticalPanel> = new inkVerticalPanel();
    box.SetName(n"FindMyRideTabBox");
    box.SetFitToContent(true);
    box.SetVAlign(inkEVerticalAlign.Center);
    box.SetMargin(new inkMargin(16.0, 0.0, 16.0, 0.0));
    box.Reparent(row);
    let tab: ref<inkText> = this.FmrMakeText(n"FindMyRideTab", n"Medium", 32);
    tab.Reparent(box);
    let line: ref<inkRectangle> = new inkRectangle();
    line.SetName(n"FindMyRideTabLine");
    line.SetSize(new Vector2(0.0, 3.0));
    line.SetHAlign(inkEHorizontalAlign.Fill);
    line.SetMargin(new inkMargin(0.0, 2.0, 0.0, 0.0));
    if this.m_fmrVanillaTheme {
      line.SetStyle(r"base\\gameplay\\gui\\common\\main_colors.inkstyle");
    };
    line.Reparent(box);
    ArrayPush(this.m_fmrTabBoxes, box);
    ArrayPush(this.m_fmrTabs, tab);
    ArrayPush(this.m_fmrTabLines, line);
    i += 1;
  };
  this.m_fmrNextHint = this.FmrSpawnHint(row, n"popup_navigate_right", "");
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrBuildSearch(container: ref<inkCompoundWidget>) -> Void {
  let top: ref<inkCompoundWidget> = container.GetWidget(n"top_holder") as inkCompoundWidget;
  if !IsDefined(top) {
    return;
  };
  let box: ref<inkHorizontalPanel> = new inkHorizontalPanel();
  box.SetName(n"FindMyRideSearch");
  box.SetFitToContent(true);
  box.SetHAlign(inkEHorizontalAlign.Right);
  box.SetVAlign(inkEVerticalAlign.Center);
  box.SetMargin(new inkMargin(0.0, 8.0, 40.0, 6.0));
  box.Reparent(top);
  let hint: ref<ButtonHintListItem> = this.FmrSpawnHint(box, n"popup_goto", "");
  this.m_fmrSearchIcon = IsDefined(hint) ? hint.GetRootWidget() : null;
  let text: ref<inkText> = this.FmrMakeText(n"FindMyRideSearchText", n"Semi-Bold", 38);
  text.SetLetterCase(textLetterCase.UpperCase);
  text.SetVAlign(inkEVerticalAlign.Center);
  text.SetMargin(new inkMargin(6.0, 0.0, 0.0, 0.0));
  text.Reparent(box);
  this.m_fmrSearchText = text;
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrBuildInfo(container: ref<inkCompoundWidget>) -> Void {
  let image: ref<inkCompoundWidget> = container.GetWidget(n"wrapper/container/image") as inkCompoundWidget;
  if !IsDefined(image) {
    return;
  };
  let fluff: ref<inkWidget> = image.GetWidget(n"Fluff_window_car");
  if IsDefined(fluff) {
    fluff.SetVisible(false);
  };
  let panel: ref<inkVerticalPanel> = new inkVerticalPanel();
  panel.SetName(n"FindMyRideInfo");
  panel.SetFitToContent(true);
  panel.SetAnchor(inkEAnchor.BottomLeft);
  panel.SetAnchorPoint(new Vector2(0.0, 1.0));
  panel.SetTranslation(new Vector2(16.0, -14.0));
  panel.Reparent(image);
  let head: ref<inkHorizontalPanel> = new inkHorizontalPanel();
  head.SetFitToContent(true);
  head.Reparent(panel);
  let main: ref<inkText> = this.FmrMakeText(n"FindMyRideInfoMain", n"Semi-Bold", 28);
  main.SetLetterCase(textLetterCase.UpperCase);
  main.Reparent(head);
  let tag: ref<inkText> = this.FmrMakeText(n"FindMyRideInfoMod", n"Semi-Bold", 28);
  tag.SetMargin(new inkMargin(14.0, 0.0, 0.0, 0.0));
  tag.Reparent(head);
  let specs: ref<inkText> = this.FmrMakeText(n"FindMyRideInfoSpecs", n"Regular", 24);
  specs.Reparent(panel);
  this.FmrPaint(main, this.FmrAccent(), n"MainColors.Blue");
  this.FmrPaint(tag, this.FmrTypingColor(), n"MainColors.Red");
  this.FmrPaint(specs, new HDRColor(0.8, 0.85, 0.9, 1.0), n"MainColors.Red");
  specs.SetOpacity(0.85);
  this.m_fmrInfoMain = main;
  this.m_fmrInfoMod = tag;
  this.m_fmrInfoSpecs = specs;
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrBuildEmpty(container: ref<inkCompoundWidget>) -> Void {
  let list: ref<inkCompoundWidget> = container.GetWidget(n"wrapper/container/vehicelsList") as inkCompoundWidget;
  if !IsDefined(list) {
    return;
  };
  let scroll: ref<inkWidget> = list.GetWidget(n"scrollArea");
  let left: Float = IsDefined(scroll) ? scroll.GetMargin().left : 0.0;
  let text: ref<inkText> = this.FmrMakeText(n"FindMyRideEmpty", n"Medium", 38);
  text.SetLetterCase(textLetterCase.UpperCase);
  text.SetHAlign(inkEHorizontalAlign.Left);
  text.SetVAlign(inkEVerticalAlign.Top);
  text.SetMargin(new inkMargin(left + 60.0, 24.0, 0.0, 0.0));
  text.SetVisible(false);
  text.Reparent(list);
  this.FmrPaint(text, this.FmrMutedColor(), n"MainColors.Red");
  this.m_fmrEmpty = text;
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrBuildHints(container: ref<inkCompoundWidget>) -> Void {
  let hints: ref<inkCompoundWidget> = container.GetWidget(n"inputHints") as inkCompoundWidget;
  if !IsDefined(hints) {
    return;
  };
  this.m_fmrCloseText = hints.GetWidget(n"inputClose/text") as inkText;
  let hint: ref<ButtonHintListItem> = this.FmrSpawnHint(hints, n"OpenHubMenu", "");
  if !IsDefined(hint) {
    return;
  };
  let widget: ref<inkWidget> = hint.GetRootWidget();
  widget.SetName(n"FindMyRideHide");
  hints.ReorderChild(widget, hints.GetNumChildren() - 2);
  this.m_fmrHideHint = hint;
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrRefreshUi() -> Void {
  this.FmrUpdateTabs();
  this.FmrUpdateSearch();
  this.FmrUpdateHints();
  this.FmrUpdateCloseHint();
  this.FmrUpdateEmpty();
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrCountCategories(view: ref<FindMyRideDataView>) -> array<Int32> {
  let counts: array<Int32>;
  ArrayResize(counts, 8);
  if !IsDefined(view) || !IsDefined(this.m_dataSource) {
    return counts;
  };
  let entries: array<ref<IScriptable>> = this.m_dataSource.GetArray();
  for entry in entries {
    let item: ref<VehicleListItemData> = entry as VehicleListItemData;
    if IsDefined(item) {
      let id: TweakDBID = item.m_data.recordID;
      if !ArrayContains(view.m_dupes, id) && view.FmrMatchesSearch(item) {
        if ArrayContains(view.m_hidden, id) {
          counts[7] += 1;
        } else {
          counts[0] += 1;
          if FmrMatchesCategory(item, 1) {
            counts[1] += 1;
          };
          if view.FmrRecentIndex(id) < 9999 {
            counts[2] += 1;
          };
          if FmrMatchesCategory(item, 3) {
            counts[3] += 1;
          };
          if FmrMatchesCategory(item, 4) {
            counts[4] += 1;
          };
          if FmrMatchesCategory(item, 5) {
            counts[5] += 1;
          };
          if ArrayContains(view.m_mods, id) {
            counts[6] += 1;
          };
        };
      };
    };
  };
  return counts;
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrUpdateTabs() -> Void {
  let loc: ref<LocalizationSystem> = this.FmrLoc();
  if !IsDefined(loc) || ArraySize(this.m_fmrTabs) < 8 {
    return;
  };
  let view: ref<FindMyRideDataView> = this.m_dataView as FindMyRideDataView;
  let counts: array<Int32> = this.FmrCountCategories(view);
  let i: Int32 = 0;
  while i < 8 {
    let box: wref<inkWidget> = this.m_fmrTabBoxes[i];
    let tab: wref<inkText> = this.m_fmrTabs[i];
    let line: wref<inkRectangle> = this.m_fmrTabLines[i];
    if IsDefined(box) {
      box.SetVisible(this.FmrCategoryAvailable(i));
    };
    if IsDefined(tab) {
      tab.SetText(FmrCategoryLabel(i, loc) + " " + IntToString(counts[i]));
      if i == this.m_fmrCategory {
        this.FmrPaint(tab, this.FmrAccent(), n"MainColors.Blue");
        tab.SetOpacity(1.0);
      } else {
        this.FmrPaint(tab, this.FmrMutedColor(), n"MainColors.Red");
        tab.SetOpacity(0.55);
      };
    };
    if IsDefined(line) {
      this.FmrPaint(line, this.FmrAccent(), n"MainColors.Blue");
      line.SetOpacity(i == this.m_fmrCategory ? 1.0 : 0.0);
    };
    i += 1;
  };
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrUpdateSearch() -> Void {
  if !IsDefined(this.m_fmrSearchText) {
    return;
  };
  let loc: ref<LocalizationSystem> = this.FmrLoc();
  if !IsDefined(loc) {
    return;
  };
  let hasSearch: Bool = StrLen(this.m_fmrSearch) > 0;
  if IsDefined(this.m_fmrSearchIcon) {
    this.m_fmrSearchIcon.SetVisible(!this.m_fmrPad);
  };
  if this.m_fmrSearchActive {
    this.m_fmrSearchText.SetText(this.m_fmrSearch + "_");
    this.FmrPaint(this.m_fmrSearchText, this.FmrTypingColor(), n"MainColors.Blue");
    this.m_fmrSearchText.SetOpacity(1.0);
  } else {
    if hasSearch {
      this.m_fmrSearchText.SetText("\"" + this.m_fmrSearch + "\"");
      this.FmrPaint(this.m_fmrSearchText, this.FmrAccent(), n"MainColors.Blue");
      this.m_fmrSearchText.SetOpacity(1.0);
    } else {
      this.m_fmrSearchText.SetText(loc.GetText("Mod-FindMyRide-Search-Placeholder"));
      this.FmrPaint(this.m_fmrSearchText, this.FmrMutedColor(), n"MainColors.Red");
      this.m_fmrSearchText.SetOpacity(0.7);
    };
  };
  this.m_fmrSearchText.SetVisible(!this.m_fmrPad || hasSearch || this.m_fmrSearchActive);
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrUpdateHints() -> Void {
  let loc: ref<LocalizationSystem> = this.FmrLoc();
  if !IsDefined(loc) {
    return;
  };
  if IsDefined(this.m_fmrHideHint) {
    this.m_fmrHideHint.GetRootWidget().SetVisible(!this.m_fmrSearchActive);
  };
  let hideLabel: String = this.m_fmrCategory == 7 ? loc.GetText("Mod-FindMyRide-Bar-Unhide") : loc.GetText("Mod-FindMyRide-Bar-Hide");
  let key: String = (this.m_fmrPad ? "p|" : "k|") + hideLabel;
  if Equals(key, this.m_fmrHintKey) {
    return;
  };
  this.m_fmrHintKey = key;
  if IsDefined(this.m_fmrHideHint) {
    this.m_fmrHideHint.SetData(this.m_fmrPad ? n"showAll" : n"OpenHubMenu", hideLabel);
    let label: ref<inkText> = this.FmrHintLabel(this.m_fmrHideHint);
    if IsDefined(label) {
      label.SetVisible(true);
    };
  };
  if IsDefined(this.m_fmrPrevHint) {
    this.m_fmrPrevHint.SetData(this.m_fmrPad ? n"popup_prior" : n"popup_navigate_left", "");
  };
  if IsDefined(this.m_fmrNextHint) {
    this.m_fmrNextHint.SetData(this.m_fmrPad ? n"popup_next" : n"popup_navigate_right", "");
  };
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrUpdateCloseHint() -> Void {
  if !IsDefined(this.m_fmrCloseText) {
    return;
  };
  let clear: Bool = this.m_fmrSearchActive || StrLen(this.m_fmrSearch) > 0 || this.m_fmrCategory != 0;
  if Equals(clear, this.m_fmrCloseCleared) {
    return;
  };
  this.m_fmrCloseCleared = clear;
  if clear {
    let loc: ref<LocalizationSystem> = this.FmrLoc();
    if IsDefined(loc) {
      this.m_fmrCloseText.SetText(loc.GetText("Mod-FindMyRide-Bar-Clear"));
    };
  } else {
    this.m_fmrCloseText.SetLocalizedTextScript("LocKey#22195");
  };
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrUpdateEmpty() -> Void {
  if !IsDefined(this.m_fmrEmpty) {
    return;
  };
  let view: ref<FindMyRideDataView> = this.m_dataView as FindMyRideDataView;
  let empty: Bool = IsDefined(view) && view.Size() == 0u;
  if empty {
    let loc: ref<LocalizationSystem> = this.FmrLoc();
    if IsDefined(loc) {
      this.m_fmrEmpty.SetText(loc.GetText("Mod-FindMyRide-Empty"));
    };
  };
  this.m_fmrEmpty.SetVisible(empty);
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrUpdateInfoFrom(item: ref<VehiclesManagerListItemController>) -> Void {
  if !IsDefined(this.m_fmrInfoMain) || !IsDefined(this.m_fmrInfoSpecs) || !IsDefined(this.m_fmrInfoMod) {
    return;
  };
  let data: ref<VehicleListItemData> = IsDefined(item) ? item.GetVehicleData() : null;
  if !IsDefined(data) {
    this.m_fmrInfoMain.SetText("");
    this.m_fmrInfoMod.SetText("");
    this.m_fmrInfoSpecs.SetText("");
    return;
  };
  let loc: ref<LocalizationSystem> = this.FmrLoc();
  let typeKey: String;
  switch FmrTypeOrder(data) {
    case 1: typeKey = "Mod-FindMyRide-Cat-Motorcycles"; break;
    case 2: typeKey = "Mod-FindMyRide-Cat-Armed"; break;
    default: typeKey = "Mod-FindMyRide-Cat-Cars"; break;
  };
  let main: String = FmrManufacturerName(data);
  if StrLen(main) > 0 {
    main += "  -  ";
  };
  main += loc.GetText(typeKey);
  this.m_fmrInfoMain.SetText(main);
  let view: ref<FindMyRideDataView> = this.m_dataView as FindMyRideDataView;
  let isMod: Bool = IsDefined(view) && ArrayContains(view.m_mods, data.m_data.recordID);
  this.m_fmrInfoMod.SetText(isMod ? loc.GetText("Mod-FindMyRide-Info-Mod") : "");
  let specs: String;
  let record: ref<Vehicle_Record> = TweakDBInterface.GetVehicleRecord(data.m_data.recordID);
  let ui: wref<VehicleUIData_Record> = IsDefined(record) ? record.VehicleUIData() : null;
  if IsDefined(ui) {
    let year: String = ui.ProductionYear();
    if StrLen(year) > 0 {
      specs = FmrLocText(year);
    };
    let hp: Int32 = RoundMath(ui.Horsepower());
    if hp > 0 {
      specs += (StrLen(specs) > 0 ? "  -  " : "") + IntToString(hp) + " " + loc.GetText("Mod-FindMyRide-Info-HP");
    };
    let drive: String = ui.DriveLayout();
    if StrLen(drive) > 0 {
      specs += (StrLen(specs) > 0 ? "  -  " : "") + FmrLocText(drive);
    };
  };
  this.m_fmrInfoSpecs.SetText(specs);
}

public func FmrLocText(value: String) -> String {
  return StrContains(value, "LocKey") ? GetLocalizedText(value) : value;
}

@addMethod(VehiclesManagerPopupGameController)
private final func FmrUpdateInfo() -> Void {
  this.FmrUpdateInfoFrom(this.m_listController.GetSelectedItem() as VehiclesManagerListItemController);
}

@wrapMethod(VehiclesManagerPopupGameController)
protected func Select(previous: ref<inkVirtualCompoundItemController>, next: ref<inkVirtualCompoundItemController>) -> Void {
  wrappedMethod(previous, next);
  this.FmrUpdateInfoFrom(next as VehiclesManagerListItemController);
}
