module BestInSlot
import Codeware.Localization.*

public func BisWeaponScore(item: ref<UIInventoryItem>) -> Float {
  let stat: ref<UIInventoryItemStat> = item.GetPrimaryStat();
  let dps: Float = IsDefined(stat) ? stat.Value : 0.0;
  let quality: Float = Cast<Float>(item.GetQualityInt());
  let iconic: Float = item.IsIconic() ? 1.0 : 0.0;
  let weight: Float = 1.0 + 0.06 * quality + 0.10 * iconic + 0.03 * item.GetItemPlus();
  return dps * weight + item.GetComparisonQualityF();
}

public func BisGenericScore(item: ref<UIInventoryItem>) -> Float {
  let stat: ref<UIInventoryItemStat> = item.GetPrimaryStat();
  let statValue: Float = IsDefined(stat) ? stat.Value : 0.0;
  return item.GetComparisonQualityF() * 1000.0 + MinF(statValue, 999.0);
}

public func BisScore(item: ref<UIInventoryItem>) -> Float {
  return item.IsWeapon() ? BisWeaponScore(item) : BisGenericScore(item);
}

public func BisIsRankable(item: ref<UIInventoryItem>) -> Bool {
  if !IsDefined(item) || ItemID.HasFlag(item.GetID(), gameEItemIDFlag.Preview) {
    return false;
  };
  if item.IsWeapon() || item.IsAnyCyberware() || item.IsHealingItem() || item.IsProgram() {
    return true;
  };
  if Equals(item.GetItemType(), gamedataItemType.Gad_Grenade) {
    return true;
  };
  return item.IsClothing() && NotEquals(item.GetEquipmentArea(), gamedataEquipmentArea.Invalid);
}

public func BisWeaponCategory(itemType: gamedataItemType) -> Int32 {
  switch itemType {
    case gamedataItemType.Wea_Handgun:
    case gamedataItemType.Wea_Revolver:
      return 1;
    case gamedataItemType.Wea_SubmachineGun:
      return 2;
    case gamedataItemType.Wea_AssaultRifle:
    case gamedataItemType.Wea_Rifle:
      return 3;
    case gamedataItemType.Wea_PrecisionRifle:
    case gamedataItemType.Wea_SniperRifle:
      return 4;
    case gamedataItemType.Wea_Shotgun:
    case gamedataItemType.Wea_ShotgunDual:
      return 5;
    case gamedataItemType.Wea_LightMachineGun:
    case gamedataItemType.Wea_HeavyMachineGun:
      return 6;
    case gamedataItemType.Wea_Katana:
    case gamedataItemType.Wea_Sword:
    case gamedataItemType.Wea_Knife:
    case gamedataItemType.Wea_Machete:
    case gamedataItemType.Wea_Chainsword:
    case gamedataItemType.Wea_LongBlade:
    case gamedataItemType.Wea_ShortBlade:
      return 7;
    case gamedataItemType.Wea_Hammer:
    case gamedataItemType.Wea_OneHandedClub:
    case gamedataItemType.Wea_TwoHandedClub:
    case gamedataItemType.Wea_Axe:
    case gamedataItemType.Wea_Fists:
    case gamedataItemType.Wea_Melee:
      return 8;
    default:
      return 1000 + EnumInt(itemType);
  };
}

public func BisGroupKey(item: ref<UIInventoryItem>) -> Int32 {
  let key: Int32;
  if item.IsWeapon() {
    return BisWeaponCategory(item.GetItemType());
  };
  if item.IsClothing() {
    return 10000 + EnumInt(item.GetEquipmentArea());
  };
  if item.IsAnyCyberware() {
    key = 100000 + EnumInt(item.GetEquipmentArea()) * 1000 + EnumInt(item.GetItemType());
    if Equals(item.GetEquipmentArea(), gamedataEquipmentArea.SystemReplacementCW) {
      if item.IsCyberdeck() {
        key += 1000000;
      } else {
        if Equals(TweakDBInterface.GetCName(ItemID.GetTDBID(item.GetID()) + t".cyberwareType", n"None"), n"Sandevistan") {
          key += 2000000;
        } else {
          key += 3000000;
        };
      };
    };
    return key;
  };
  if item.IsProgram() {
    return 40000000 + Cast<Int32>(TDBID.ToNumber(TDBID.Create(item.GetName())) % Cast<Uint64>(1000000));
  };
  if item.IsHealingItem() {
    return 29000;
  };
  return 30000 + EnumInt(item.GetItemType());
}

@addField(PlayerPuppet)
let m_bisBestHashes: [Uint64];

@addField(PlayerPuppet)
let m_bisBestWeapons: [ItemID];

@addField(PlayerPuppet)
let m_bisBestWeaponKeys: [Int32];

@addField(PlayerPuppet)
let m_bisBestClothes: [ItemID];

@addField(PlayerPuppet)
let m_bisBestConsumables: [ItemID];

@addField(PlayerPuppet)
let m_bisEqKeys: [Int32];

@addField(PlayerPuppet)
let m_bisEqScores: [Float];

@addField(PlayerPuppet)
let m_bisDirty: Bool;

@addField(PlayerPuppet)
let m_bisReady: Bool;

@addMethod(PlayerPuppet)
public final func BisMarkDirty() -> Void {
  this.m_bisDirty = true;
}

@addMethod(PlayerPuppet)
public final func BisIsEquipped(itemID: ItemID) -> Bool {
  let equipment: ref<EquipmentSystem> = EquipmentSystem.GetInstance(this);
  return IsDefined(equipment) && equipment.IsEquipped(this, itemID);
}

@addMethod(PlayerPuppet)
public final func BisIsBest(itemID: ItemID) -> Bool {
  let hash: Uint64 = ItemID.GetCombinedHash(itemID);
  let i: Int32 = 0;
  if this.m_bisDirty || !this.m_bisReady {
    this.BisRecompute();
  };
  while i < ArraySize(this.m_bisBestHashes) {
    if this.m_bisBestHashes[i] == hash {
      return true;
    };
    i += 1;
  };
  return false;
}

@addMethod(PlayerPuppet)
public final func BisIsUpgrade(item: ref<UIInventoryItem>) -> Bool {
  if !BisIsRankable(item) || this.BisIsEquipped(item.GetID()) {
    return false;
  };
  if this.m_bisDirty || !this.m_bisReady {
    this.BisRecompute();
  };
  let key: Int32 = BisGroupKey(item);
  let i: Int32 = 0;
  while i < ArraySize(this.m_bisEqKeys) {
    if this.m_bisEqKeys[i] == key {
      return BisScore(item) > this.m_bisEqScores[i];
    };
    i += 1;
  };
  return false;
}

@addMethod(PlayerPuppet)
public final func BisRecompute() -> Void {
  let uiSystem: ref<UIInventoryScriptableSystem> = UIInventoryScriptableSystem.GetInstance(this.GetGame());
  let values: [wref<IScriptable>];
  let bestPerGroup: [wref<UIInventoryItem>];
  let groupKeys: [Int32];
  let item: wref<UIInventoryItem>;
  let key: Int32;
  let idx: Int32;
  let j: Int32;
  let i: Int32;
  this.m_bisDirty = false;
  if !IsDefined(uiSystem) {
    return;
  };
  this.m_bisReady = true;
  uiSystem.GetPlayerItemsMap().GetValues(values);
  ArrayClear(this.m_bisEqKeys);
  ArrayClear(this.m_bisEqScores);
  while i < ArraySize(values) {
    item = values[i] as UIInventoryItem;
    if BisIsRankable(item) {
      key = BisGroupKey(item);
      idx = -1;
      j = 0;
      while j < ArraySize(groupKeys) {
        if groupKeys[j] == key {
          idx = j;
        };
        j += 1;
      };
      if idx < 0 {
        ArrayPush(groupKeys, key);
        ArrayPush(bestPerGroup, item);
      } else {
        if BisScore(item) > BisScore(bestPerGroup[idx]) {
          bestPerGroup[idx] = item;
        };
      };
      if this.BisIsEquipped(item.GetID()) {
        idx = -1;
        j = 0;
        while j < ArraySize(this.m_bisEqKeys) {
          if this.m_bisEqKeys[j] == key {
            idx = j;
          };
          j += 1;
        };
        if idx < 0 {
          ArrayPush(this.m_bisEqKeys, key);
          ArrayPush(this.m_bisEqScores, BisScore(item));
        } else {
          if BisScore(item) > this.m_bisEqScores[idx] {
            this.m_bisEqScores[idx] = BisScore(item);
          };
        };
      };
    };
    i += 1;
  };
  ArrayClear(this.m_bisBestHashes);
  ArrayClear(this.m_bisBestWeapons);
  ArrayClear(this.m_bisBestWeaponKeys);
  ArrayClear(this.m_bisBestClothes);
  ArrayClear(this.m_bisBestConsumables);
  i = 0;
  while i < ArraySize(bestPerGroup) {
    ArrayPush(this.m_bisBestHashes, ItemID.GetCombinedHash(bestPerGroup[i].GetID()));
    if bestPerGroup[i].IsWeapon() {
      ArrayPush(this.m_bisBestWeapons, bestPerGroup[i].GetID());
      ArrayPush(this.m_bisBestWeaponKeys, groupKeys[i]);
    } else {
      if bestPerGroup[i].IsClothing() {
        ArrayPush(this.m_bisBestClothes, bestPerGroup[i].GetID());
      } else {
        if bestPerGroup[i].IsHealingItem() || Equals(bestPerGroup[i].GetItemType(), gamedataItemType.Gad_Grenade) {
          ArrayPush(this.m_bisBestConsumables, bestPerGroup[i].GetID());
        };
      };
    };
    i += 1;
  };
}

@addMethod(PlayerPuppet)
private final func BisTopWeaponOfGroup(key: Int32) -> ItemID {
  let i: Int32 = 0;
  while i < ArraySize(this.m_bisBestWeaponKeys) {
    if this.m_bisBestWeaponKeys[i] == key {
      return this.m_bisBestWeapons[i];
    };
    i += 1;
  };
  return ItemID.None();
}

@addMethod(PlayerPuppet)
private final func BisSortedTopWeapons(uiSystem: ref<UIInventoryScriptableSystem>) -> [ItemID] {
  let sortedIds: [ItemID];
  let sortedScores: [Float];
  let item: wref<UIInventoryItem>;
  let score: Float;
  let j: Int32;
  let i: Int32;
  while i < ArraySize(this.m_bisBestWeapons) {
    item = uiSystem.GetPlayerItem(this.m_bisBestWeapons[i]);
    if IsDefined(item) {
      score = BisWeaponScore(item);
      j = 0;
      while j < ArraySize(sortedScores) && sortedScores[j] >= score {
        j += 1;
      };
      ArrayInsert(sortedIds, j, this.m_bisBestWeapons[i]);
      ArrayInsert(sortedScores, j, score);
    };
    i += 1;
  };
  return sortedIds;
}

@addMethod(PlayerPuppet)
public final func BisEquipBest() -> Void {
  let game: GameInstance = this.GetGame();
  let uiSystem: ref<UIInventoryScriptableSystem> = UIInventoryScriptableSystem.GetInstance(game);
  let equipment: ref<EquipmentSystem> = GameInstance.GetScriptableSystemsContainer(game).Get(n"EquipmentSystem") as EquipmentSystem;
  this.BisRecompute();
  if !IsDefined(uiSystem) || !IsDefined(equipment) {
    return;
  };
  if BisKeepWeaponCategories() {
    this.BisEquipSameCategoryWeapons(uiSystem, equipment);
  } else {
    this.BisEquipTopWeapons(uiSystem, equipment);
  };
  if BisEquipClothes() {
    this.BisEquipEach(uiSystem, equipment, this.m_bisBestClothes);
  };
  if BisEquipConsumables() {
    this.BisEquipEach(uiSystem, equipment, this.m_bisBestConsumables);
  };
}

@addMethod(PlayerPuppet)
private final func BisEquipTopWeapons(uiSystem: ref<UIInventoryScriptableSystem>, equipment: ref<EquipmentSystem>) -> Void {
  let sortedIds: [ItemID] = this.BisSortedTopWeapons(uiSystem);
  let slots: Int32 = UIInventoryScriptableSystem.NumberOfWeaponSlots();
  let slot: Int32 = 0;
  while slot < ArraySize(sortedIds) && slot < slots {
    if equipment.GetItemInEquipSlot(this, gamedataEquipmentArea.Weapon, slot) != sortedIds[slot] {
      BisQueueEquip(equipment, this, sortedIds[slot], slot);
    };
    slot += 1;
  };
}

@addMethod(PlayerPuppet)
private final func BisEquipSameCategoryWeapons(uiSystem: ref<UIInventoryScriptableSystem>, equipment: ref<EquipmentSystem>) -> Void {
  let slots: Int32 = UIInventoryScriptableSystem.NumberOfWeaponSlots();
  let usedKeys: [Int32];
  let assigned: [ItemID];
  let emptySlots: [Int32];
  let sortedIds: [ItemID];
  let current: ItemID;
  let best: ItemID;
  let item: wref<UIInventoryItem>;
  let key: Int32;
  let next: Int32;
  let slot: Int32;
  let i: Int32;
  while slot < slots {
    current = equipment.GetItemInEquipSlot(this, gamedataEquipmentArea.Weapon, slot);
    item = null;
    if ItemID.IsValid(current) {
      item = uiSystem.GetPlayerItem(current);
    };
    if IsDefined(item) {
      key = BisGroupKey(item);
      ArrayPush(usedKeys, key);
      best = this.BisTopWeaponOfGroup(key);
      if ItemID.IsValid(best) && best != current && !ArrayContains(assigned, best) && !this.BisIsEquipped(best) {
        BisQueueEquip(equipment, this, best, slot);
        ArrayPush(assigned, best);
      };
    } else {
      ArrayPush(emptySlots, slot);
    };
    slot += 1;
  };
  sortedIds = this.BisSortedTopWeapons(uiSystem);
  while i < ArraySize(sortedIds) && next < ArraySize(emptySlots) {
    item = uiSystem.GetPlayerItem(sortedIds[i]);
    if IsDefined(item) {
      key = BisGroupKey(item);
      if !ArrayContains(usedKeys, key) && !ArrayContains(assigned, sortedIds[i]) && !this.BisIsEquipped(sortedIds[i]) {
        BisQueueEquip(equipment, this, sortedIds[i], emptySlots[next]);
        ArrayPush(usedKeys, key);
        ArrayPush(assigned, sortedIds[i]);
        next += 1;
      };
    };
    i += 1;
  };
}

@addMethod(PlayerPuppet)
private final func BisEquipEach(uiSystem: ref<UIInventoryScriptableSystem>, equipment: ref<EquipmentSystem>, ids: [ItemID]) -> Void {
  let i: Int32 = 0;
  while i < ArraySize(ids) {
    if IsDefined(uiSystem.GetPlayerItem(ids[i])) && !this.BisIsEquipped(ids[i]) {
      BisQueueEquip(equipment, this, ids[i], 0);
    };
    i += 1;
  };
}

public func BisQueueEquip(equipment: ref<EquipmentSystem>, player: ref<PlayerPuppet>, itemID: ItemID, slotIndex: Int32) -> Void {
  let request: ref<EquipRequest> = new EquipRequest();
  request.owner = player;
  request.itemID = itemID;
  request.slotIndex = slotIndex;
  request.addToInventory = false;
  request.equipToCurrentActiveSlot = false;
  equipment.QueueRequest(request);
}

public func BisMarkPlayerDirty(player: wref<PlayerPuppet>) -> Void {
  if IsDefined(player) {
    player.BisMarkDirty();
  };
}

@wrapMethod(UIInventoryScriptableSystem)
private final func OnInventoryItemAdded(request: ref<UIInventoryScriptableSystemInventoryAddItem>) -> Void {
  wrappedMethod(request);
  BisMarkPlayerDirty(this.m_attachedPlayer);
}

@wrapMethod(UIInventoryScriptableSystem)
private final func OnInventoryItemRemoved(request: ref<UIInventoryScriptableSystemInventoryRemoveItem>) -> Void {
  wrappedMethod(request);
  BisMarkPlayerDirty(this.m_attachedPlayer);
}

@wrapMethod(UIInventoryScriptableSystem)
private final func RefreshItem(itemID: ItemID) -> Void {
  wrappedMethod(itemID);
  BisMarkPlayerDirty(this.m_attachedPlayer);
}

@wrapMethod(UIInventoryScriptableSystem)
private final func OnPartInstallRequest(request: ref<PartInstallRequest>) -> Void {
  wrappedMethod(request);
  BisMarkPlayerDirty(this.m_attachedPlayer);
}

@wrapMethod(UIInventoryScriptableSystem)
private final func OnPartUninstallRequest(request: ref<PartUninstallRequest>) -> Void {
  wrappedMethod(request);
  BisMarkPlayerDirty(this.m_attachedPlayer);
}

@wrapMethod(EquipmentSystemPlayerData)
private final func EquipItem(itemID: ItemID, slotIndex: Int32, opt blockActiveSlotsUpdate: Bool, opt forceEquipWeapon: Bool) -> Void {
  wrappedMethod(itemID, slotIndex, blockActiveSlotsUpdate, forceEquipWeapon);
  BisMarkPlayerDirty(this.m_owner as PlayerPuppet);
}

@wrapMethod(EquipmentSystemPlayerData)
private final func UnequipItem(equipAreaIndex: Int32, slotIndex: Int32, opt forceRemove: Bool) -> Void {
  wrappedMethod(equipAreaIndex, slotIndex, forceRemove);
  BisMarkPlayerDirty(this.m_owner as PlayerPuppet);
}

public func BisGold() -> HDRColor {
  return new HDRColor(2.2, 1.5, 0.2, 1.0);
}

public func BisAddFrameEdge(frame: ref<inkCanvas>, name: CName, anchor: inkEAnchor, anchorPoint: Vector2, size: Vector2) -> Void {
  let edge: ref<inkRectangle> = new inkRectangle();
  edge.SetName(name);
  edge.SetAnchor(anchor);
  edge.SetAnchorPoint(anchorPoint);
  edge.SetSize(size);
  edge.SetTintColor(BisGold());
  edge.SetOpacity(1.0);
  edge.Reparent(frame);
}

@addField(InventoryItemDisplayController)
let m_bisBadge: wref<inkWidget>;

@addField(InventoryItemDisplayController)
let m_bisUpBadge: wref<inkWidget>;

@addField(InventoryItemDisplayController)
let m_bisFrame: wref<inkWidget>;

@addField(InventoryItemDisplayController)
let m_bisBadgeText: wref<inkText>;

@addField(InventoryItemDisplayController)
let m_bisUpBadgeText: wref<inkText>;

@addMethod(InventoryItemDisplayController)
private final func BisPlaceBadges() -> Void {
  let root: ref<inkCompoundWidget> = this.GetRootCompoundWidget();
  let width: Float = IsDefined(root) ? root.GetWidth() : 0.0;
  let tight: Bool = width < 220.0;
  let chipWidth: Float = tight ? 62.0 : 94.0;
  let x: Float = width > chipWidth + 14.0 ? width - chipWidth - 6.0 : 5.0;
  if !IsDefined(this.m_bisBadge) || !IsDefined(this.m_bisUpBadge) {
    return;
  };
  this.m_bisBadge.SetSize(new Vector2(chipWidth, tight ? 32.0 : 44.0));
  this.m_bisBadge.SetTranslation(new Vector2(x, 5.0));
  this.m_bisUpBadge.SetSize(new Vector2(tight ? 34.0 : 50.0, tight ? 34.0 : 50.0));
  this.m_bisUpBadge.SetTranslation(new Vector2(5.0, 5.0));
  if IsDefined(this.m_bisBadgeText) {
    this.m_bisBadgeText.SetFontSize(tight ? 24 : 33);
  };
  if IsDefined(this.m_bisUpBadgeText) {
    this.m_bisUpBadgeText.SetFontSize(tight ? 26 : 38);
  };
}

@wrapMethod(InventoryItemDisplayController)
protected func NewUpdateIndicators(itemData: ref<UIInventoryItem>) -> Void {
  wrappedMethod(itemData);
  this.BisUpdateBadge(itemData);
}

@wrapMethod(InventoryItemDisplayController)
protected func NewRefreshUI(itemData: ref<UIInventoryItem>) -> Void {
  wrappedMethod(itemData);
  this.BisUpdateBadge(itemData);
}

@wrapMethod(InventoryItemDisplayController)
protected func RefreshUI() -> Void {
  wrappedMethod();
  this.BisUpdateBadgeLegacy();
}

@addMethod(InventoryItemDisplayController)
private final func BisIsHudContext() -> Bool {
  return Equals(this.m_itemDisplayContext, ItemDisplayContext.DPAD_RADIAL);
}

@addMethod(InventoryItemDisplayController)
private final func BisShowBadges(isBest: Bool, isUpgrade: Bool) -> Void {
  this.BisPlaceBadges();
  this.m_bisBadge.SetVisible(isBest);
  this.m_bisFrame.SetVisible(isBest);
  this.m_bisUpBadge.SetVisible(isUpgrade);
}

@addMethod(InventoryItemDisplayController)
private final func BisLegacyItem(player: ref<PlayerPuppet>) -> ref<UIInventoryItem> {
  let uiSystem: ref<UIInventoryScriptableSystem> = UIInventoryScriptableSystem.GetInstance(GetGameInstance());
  let gameData: ref<gameItemData> = InventoryItemData.GetGameItemData(this.m_itemData);
  let item: ref<UIInventoryItem>;
  if !IsDefined(uiSystem) {
    return null;
  };
  item = uiSystem.GetPlayerItem(InventoryItemData.GetID(this.m_itemData));
  if !IsDefined(item) && IsDefined(gameData) {
    item = UIInventoryItem.Make(player, gameData, uiSystem.GetInventoryItemsManager());
  };
  return item;
}

@addMethod(InventoryItemDisplayController)
private final func BisUpdateBadgeLegacy() -> Void {
  let player: ref<PlayerPuppet>;
  let item: ref<UIInventoryItem>;
  let isBest: Bool;
  let isUpgrade: Bool;
  this.BisEnsureBadge();
  if !IsDefined(this.m_bisBadge) || !IsDefined(this.m_bisUpBadge) || !IsDefined(this.m_bisFrame) {
    return;
  };
  if !this.BisIsHudContext() && !InventoryItemData.IsEmpty(this.m_itemData) {
    player = GetPlayer(GetGameInstance());
    if IsDefined(player) {
      isBest = player.BisIsBest(InventoryItemData.GetID(this.m_itemData));
      if !isBest && BisShowUpgradeBadge() {
        item = this.BisLegacyItem(player);
        isUpgrade = IsDefined(item) && player.BisIsUpgrade(item);
      };
    };
  };
  this.BisShowBadges(isBest, isUpgrade);
}

@addMethod(InventoryItemDisplayController)
private final func BisUpdateBadge(itemData: ref<UIInventoryItem>) -> Void {
  let player: ref<PlayerPuppet>;
  let isBest: Bool;
  let isUpgrade: Bool;
  this.BisEnsureBadge();
  if !IsDefined(this.m_bisBadge) || !IsDefined(this.m_bisUpBadge) || !IsDefined(this.m_bisFrame) {
    return;
  };
  if !this.BisIsHudContext() && IsDefined(itemData) {
    player = GetPlayer(GetGameInstance());
    isBest = IsDefined(player) && player.BisIsBest(itemData.GetID());
    isUpgrade = IsDefined(player) && !isBest && BisShowUpgradeBadge() && player.BisIsUpgrade(itemData);
  };
  this.BisShowBadges(isBest, isUpgrade);
}

@addMethod(InventoryItemDisplayController)
private final func BisEnsureBadge() -> Void {
  let root: ref<inkCompoundWidget> = this.GetRootCompoundWidget();
  let frame: ref<inkCanvas>;
  let chip: ref<inkCanvas>;
  let bg: ref<inkRectangle>;
  let label: ref<inkText>;
  if !IsDefined(root) {
    return;
  };
  if !IsDefined(this.m_bisFrame) {
    frame = new inkCanvas();
    frame.SetName(n"BisFrame");
    frame.SetAnchor(inkEAnchor.Fill);
    frame.SetAffectsLayoutWhenHidden(false);
    frame.SetVisible(false);
    BisAddFrameEdge(frame, n"BisFrameTop", inkEAnchor.TopFillHorizontaly, new Vector2(0.0, 0.0), new Vector2(0.0, 3.0));
    BisAddFrameEdge(frame, n"BisFrameBottom", inkEAnchor.BottomFillHorizontaly, new Vector2(0.0, 1.0), new Vector2(0.0, 3.0));
    BisAddFrameEdge(frame, n"BisFrameLeft", inkEAnchor.LeftFillVerticaly, new Vector2(0.0, 0.0), new Vector2(3.0, 0.0));
    BisAddFrameEdge(frame, n"BisFrameRight", inkEAnchor.RightFillVerticaly, new Vector2(1.0, 0.0), new Vector2(3.0, 0.0));
    frame.Reparent(root);
    this.m_bisFrame = frame;
  };
  if !IsDefined(this.m_bisBadge) {
    chip = new inkCanvas();
    chip.SetName(n"BisBadge");
    chip.SetSize(new Vector2(94.0, 44.0));
    chip.SetAnchor(inkEAnchor.TopLeft);
    chip.SetAnchorPoint(new Vector2(0.0, 0.0));
    chip.SetTranslation(new Vector2(5.0, 5.0));
    chip.SetHAlign(inkEHorizontalAlign.Left);
    chip.SetVAlign(inkEVerticalAlign.Top);
    chip.SetAffectsLayoutWhenHidden(false);
    bg = new inkRectangle();
    bg.SetName(n"BisBadgeOutline");
    bg.SetAnchor(inkEAnchor.Fill);
    bg.SetTintColor(new HDRColor(0.0, 0.0, 0.0, 1.0));
    bg.SetOpacity(0.9);
    bg.Reparent(chip);
    bg = new inkRectangle();
    bg.SetName(n"BisBadgeBg");
    bg.SetAnchor(inkEAnchor.Fill);
    bg.SetMargin(new inkMargin(3.0, 3.0, 3.0, 3.0));
    bg.SetTintColor(BisGold());
    bg.SetOpacity(1.0);
    bg.Reparent(chip);
    label = new inkText();
    label.SetName(n"BisBadgeText");
    label.SetText(LocalizationSystem.GetInstance(GetGameInstance()).GetText("Mod-BestInSlot-Badge-Top"));
    label.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
    label.SetFontStyle(n"Bold");
    label.SetFontSize(33);
    label.SetTintColor(new HDRColor(0.05, 0.05, 0.05, 1.0));
    label.SetAnchor(inkEAnchor.Fill);
    label.SetHorizontalAlignment(textHorizontalAlignment.Center);
    label.SetVerticalAlignment(textVerticalAlignment.Center);
    label.Reparent(chip);
    chip.Reparent(root);
    this.m_bisBadge = chip;
    this.m_bisBadgeText = label;
  };
  if !IsDefined(this.m_bisUpBadge) {
    chip = new inkCanvas();
    chip.SetName(n"BisUpBadge");
    chip.SetSize(new Vector2(50.0, 50.0));
    chip.SetAnchor(inkEAnchor.TopLeft);
    chip.SetAnchorPoint(new Vector2(0.0, 0.0));
    chip.SetTranslation(new Vector2(5.0, 5.0));
    chip.SetHAlign(inkEHorizontalAlign.Left);
    chip.SetVAlign(inkEVerticalAlign.Top);
    chip.SetAffectsLayoutWhenHidden(false);
    bg = new inkRectangle();
    bg.SetName(n"BisUpBadgeOutline");
    bg.SetAnchor(inkEAnchor.Fill);
    bg.SetTintColor(new HDRColor(0.0, 0.0, 0.0, 1.0));
    bg.SetOpacity(0.9);
    bg.Reparent(chip);
    bg = new inkRectangle();
    bg.SetName(n"BisUpBadgeBg");
    bg.SetAnchor(inkEAnchor.Fill);
    bg.SetMargin(new inkMargin(3.0, 3.0, 3.0, 3.0));
    bg.SetTintColor(new HDRColor(0.3, 2.0, 0.5, 1.0));
    bg.SetOpacity(1.0);
    bg.Reparent(chip);
    label = new inkText();
    label.SetName(n"BisUpBadgeText");
    label.SetText("+");
    label.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
    label.SetFontStyle(n"Bold");
    label.SetFontSize(38);
    label.SetTintColor(new HDRColor(0.05, 0.05, 0.05, 1.0));
    label.SetAnchor(inkEAnchor.Fill);
    label.SetHorizontalAlignment(textHorizontalAlignment.Center);
    label.SetVerticalAlignment(textVerticalAlignment.Center);
    label.Reparent(chip);
    chip.Reparent(root);
    this.m_bisUpBadge = chip;
    this.m_bisUpBadgeText = label;
  };
}

public func BisIsPadKey(key: EInputKey) -> Bool {
  return StrBeginsWith(EnumValueToString("EInputKey", Cast<Int64>(EnumInt(key))), "IK_Pad");
}

public func BisComboFired(key: EInputKey, hotkey: BisHotkey, padHeld: Bool) -> Bool {
  let padBtn: EInputKey = BisPadBtnKey();
  if Equals(key, BisHotkeyToInput(hotkey)) {
    return true;
  };
  return padHeld && !Equals(padBtn, EInputKey.IK_None) && Equals(key, padBtn);
}

public func BisShowHint(hints: wref<ButtonHints>, tag: CName, pad: Bool, hotkey: BisHotkey, textKey: String) -> Void {
  let text: String = LocalizationSystem.GetInstance(GetGameInstance()).GetText(textKey);
  if !IsDefined(hints) {
    return;
  };
  if !pad {
    hints.BisSetKeyHint(tag, BisHotkeyToInput(hotkey), text);
    return;
  };
  if Equals(BisPadBtnKey(), EInputKey.IK_None) {
    hints.BisRemoveHint(tag);
    return;
  };
  hints.BisSetKeyHint(tag, BisPadBtnKey(), BisPadModLabel() + " + " + text);
}

@addMethod(ButtonHints)
public final func BisSetKeyHint(tag: CName, key: EInputKey, label: String) -> Void {
  let hint: wref<ButtonHintListItem> = this.CheckForPreExisting(tag);
  let widget: wref<inkWidget>;
  if !IsDefined(hint) {
    widget = this.SpawnFromLocal(inkWidgetRef.Get(this.m_horizontalHolder), n"ButtonHintListItem");
    if IsDefined(widget) {
      hint = widget.GetController() as ButtonHintListItem;
    };
  };
  if IsDefined(hint) {
    hint.BisSetKey(tag, key, label);
  };
}

@addMethod(ButtonHints)
public final func BisRemoveHint(tag: CName) -> Void {
  if IsDefined(this.CheckForPreExisting(tag)) {
    this.RemoveButtonHint(tag);
  };
}

@addMethod(ButtonHintListItem)
public final func BisSetKey(tag: CName, key: EInputKey, label: String) -> Void {
  let data: inkInputKeyData;
  inkInputKeyData.SetInputKey(data, key);
  this.m_actionName = tag;
  inkTextRef.SetText(this.m_label, label);
  if IsDefined(this.m_buttonHint) {
    this.m_buttonHint.SetInputKey(data);
  };
}

@addField(BackpackMainGameController)
let m_bisPad: Bool;

@addField(BackpackMainGameController)
let m_bisPadHeld: Bool;

@addField(BackpackMainGameController)
let m_bisHooked: Bool;

@wrapMethod(BackpackMainGameController)
protected cb func OnPlayerAttach(playerPuppet: ref<GameObject>) -> Bool {
  let player: ref<PlayerPuppet> = playerPuppet as PlayerPuppet;
  if IsDefined(player) {
    player.BisRecompute();
  };
  let result: Bool = wrappedMethod(playerPuppet);
  if IsDefined(this.m_player) {
    this.m_bisPad = !this.m_player.PlayerLastUsedKBM();
  };
  this.BisRefreshHint();
  if !this.m_bisHooked {
    this.m_bisHooked = true;
    GameInstance.GetCallbackSystem().RegisterCallback(n"Input/Key", this, n"OnBisKeyInput");
  };
  return result;
}

@addMethod(BackpackMainGameController)
private final func BisRefreshHint() -> Void {
  BisShowHint(this.m_buttonHintsController, n"bis_equip_best", this.m_bisPad, BisEquipHotkey(), "Mod-BestInSlot-Bar-EquipBest");
}

@wrapMethod(BackpackMainGameController)
protected cb func OnUninitialize() -> Bool {
  GameInstance.GetCallbackSystem().UnregisterCallback(n"Input/Key", this, n"OnBisKeyInput");
  this.m_bisHooked = false;
  return wrappedMethod();
}

@addMethod(BackpackMainGameController)
protected cb func OnBisKeyInput(event: ref<KeyInputEvent>) {
  let key: EInputKey = event.GetKey();
  let pad: Bool = BisIsPadKey(key);
  if Equals(key, BisPadModKey()) {
    this.m_bisPadHeld = !Equals(event.GetAction(), EInputAction.IACT_Release);
  };
  if !Equals(event.GetAction(), EInputAction.IACT_Press) {
    return;
  };
  if NotEquals(pad, this.m_bisPad) {
    this.m_bisPad = pad;
    this.BisRefreshHint();
  };
  if IsDefined(this.m_player) && BisComboFired(key, BisEquipHotkey(), this.m_bisPadHeld) {
    this.m_player.BisEquipBest();
  };
}

@addField(gameuiInventoryGameController)
let m_bisPad: Bool;

@addField(gameuiInventoryGameController)
let m_bisPadHeld: Bool;

@addField(gameuiInventoryGameController)
let m_bisHooked: Bool;

@wrapMethod(gameuiInventoryGameController)
protected cb func OnInitialize() -> Bool {
  let player: ref<PlayerPuppet> = GetPlayer(GetGameInstance());
  if IsDefined(player) {
    player.BisRecompute();
  };
  let result: Bool = wrappedMethod();
  if IsDefined(this.m_player) {
    this.m_bisPad = !this.m_player.PlayerLastUsedKBM();
  };
  this.BisRefreshInvHint();
  if !this.m_bisHooked {
    this.m_bisHooked = true;
    GameInstance.GetCallbackSystem().RegisterCallback(n"Input/Key", this, n"OnBisInvKeyInput");
  };
  return result;
}

@addMethod(gameuiInventoryGameController)
private final func BisRefreshInvHint() -> Void {
  BisShowHint(this.m_buttonHintsController, n"bis_equip_best", this.m_bisPad, BisEquipHotkey(), "Mod-BestInSlot-Bar-EquipBest");
}

@wrapMethod(gameuiInventoryGameController)
private func SwapMode(mode: InventoryModes) -> Void {
  wrappedMethod(mode);
  this.BisRefreshInvHint();
}

@wrapMethod(gameuiInventoryGameController)
protected cb func OnUninitialize() -> Bool {
  GameInstance.GetCallbackSystem().UnregisterCallback(n"Input/Key", this, n"OnBisInvKeyInput");
  this.m_bisHooked = false;
  return wrappedMethod();
}

@addMethod(gameuiInventoryGameController)
protected cb func OnBisInvKeyInput(event: ref<KeyInputEvent>) {
  let key: EInputKey = event.GetKey();
  let pad: Bool = BisIsPadKey(key);
  if Equals(key, BisPadModKey()) {
    this.m_bisPadHeld = !Equals(event.GetAction(), EInputAction.IACT_Release);
  };
  if !Equals(event.GetAction(), EInputAction.IACT_Press) {
    return;
  };
  if NotEquals(pad, this.m_bisPad) {
    this.m_bisPad = pad;
    this.BisRefreshInvHint();
  };
  if IsDefined(this.m_player) && BisComboFired(key, BisEquipHotkey(), this.m_bisPadHeld) {
    this.m_player.BisEquipBest();
  };
}

@wrapMethod(RipperDocGameController)
protected cb func OnInitialize() -> Bool {
  let result: Bool = wrappedMethod();
  let player: ref<PlayerPuppet> = GetPlayer(GetGameInstance());
  if IsDefined(player) {
    player.BisRecompute();
  };
  return result;
}

@addField(FullscreenVendorGameController)
let m_bisPad: Bool;

@addField(FullscreenVendorGameController)
let m_bisPadHeld: Bool;

@addField(FullscreenVendorGameController)
let m_bisHooked: Bool;

@addField(FullscreenVendorGameController)
let m_bisSellPopupToken: ref<inkGameNotificationToken>;

@wrapMethod(FullscreenVendorGameController)
protected cb func OnInitialize() -> Bool {
  let player: ref<PlayerPuppet> = GetPlayer(GetGameInstance());
  if IsDefined(player) {
    player.BisRecompute();
  };
  let result: Bool = wrappedMethod();
  if IsDefined(player) {
    this.m_bisPad = !player.PlayerLastUsedKBM();
  };
  this.BisRefreshVendorHint();
  if !this.m_bisHooked {
    this.m_bisHooked = true;
    GameInstance.GetCallbackSystem().RegisterCallback(n"Input/Key", this, n"OnBisVendorKeyInput");
  };
  return result;
}

@addMethod(FullscreenVendorGameController)
private final func BisRefreshVendorHint() -> Void {
  BisShowHint(this.m_buttonHintsController, n"bis_sell_nontop", this.m_bisPad, BisSellHotkey(), "Mod-BestInSlot-Bar-SellNonTop");
}

@wrapMethod(FullscreenVendorGameController)
protected cb func OnUninitialize() -> Bool {
  GameInstance.GetCallbackSystem().UnregisterCallback(n"Input/Key", this, n"OnBisVendorKeyInput");
  this.m_bisHooked = false;
  return wrappedMethod();
}

@addMethod(FullscreenVendorGameController)
protected cb func OnBisVendorKeyInput(event: ref<KeyInputEvent>) {
  let key: EInputKey = event.GetKey();
  let pad: Bool = BisIsPadKey(key);
  if Equals(key, BisPadModKey()) {
    this.m_bisPadHeld = !Equals(event.GetAction(), EInputAction.IACT_Release);
  };
  if !Equals(event.GetAction(), EInputAction.IACT_Press) {
    return;
  };
  if NotEquals(pad, this.m_bisPad) {
    this.m_bisPad = pad;
    this.BisRefreshVendorHint();
  };
  if BisComboFired(key, BisSellHotkey(), this.m_bisPadHeld) {
    this.BisOpenSellNonTopConfirmation();
  };
}

@addMethod(FullscreenVendorGameController)
private final func BisGetSellableNonTop() -> [wref<gameItemData>] {
  let result: [wref<gameItemData>];
  let values: [wref<IScriptable>];
  let item: wref<UIInventoryItem>;
  let i: Int32;
  let player: ref<PlayerPuppet> = GetPlayer(GetGameInstance());
  let uiSystem: ref<UIInventoryScriptableSystem> = UIInventoryScriptableSystem.GetInstance(GetGameInstance());
  if !IsDefined(player) || !IsDefined(uiSystem) {
    return result;
  };
  player.BisRecompute();
  uiSystem.GetPlayerItemsMap().GetValues(values);
  let limit: Int32 = BisSellLimit();
  while i < ArraySize(values) && ArraySize(result) < limit {
    item = values[i] as UIInventoryItem;
    if IsDefined(item)
      && (item.IsWeapon() || (BisSellClothes() && item.IsClothing()))
      && !player.BisIsEquipped(item.GetID())
      && !item.IsPlayerFavourite()
      && !item.IsQuestItem()
      && (BisSellIconics() || !item.IsIconic())
      && !player.BisIsBest(item.GetID())
      && this.m_VendorDataManager.CanPlayerSellItem(item.GetID())
      && IsDefined(item.GetRealItemData()) {
      ArrayPush(result, item.GetRealItemData());
    };
    i += 1;
  };
  return result;
}

@addMethod(FullscreenVendorGameController)
private final func BisOpenSellNonTopConfirmation() -> Void {
  let data: ref<VendorSellJunkPopupData>;
  let vendorMoney: Int32;
  let limitedItems: [ref<VendorJunkSellItem>];
  let sellableItems: [wref<gameItemData>] = this.BisGetSellableNonTop();
  if ArraySize(sellableItems) == 0 || this.m_isPopupPending {
    return;
  };
  this.m_isPopupPending = true;
  vendorMoney = MarketSystem.GetVendorMoney(this.m_VendorDataManager.GetVendorInstance());
  limitedItems = this.GetLimitedSellableItems(sellableItems, vendorMoney);
  data = new VendorSellJunkPopupData();
  data.notificationName = n"base\\gameplay\\gui\\widgets\\notifications\\vendor_sell_junk_confirmation.inkwidget";
  data.isBlocking = true;
  data.useCursor = true;
  data.queueName = n"modal_popup";
  data.items = sellableItems;
  data.itemsQuantity = ArraySize(sellableItems);
  data.totalPrice = this.GetBulkSellPrice(sellableItems);
  data.limitedTotalPrice = Cast<Int32>(this.GetBulkSellPrice(limitedItems));
  data.limitedItems = limitedItems;
  data.limitedItemsQuantity = ArraySize(limitedItems);
  this.m_bisSellPopupToken = this.ShowGameNotification(data);
  this.m_bisSellPopupToken.RegisterListener(this, n"OnBisSellPopupClosed");
  this.m_buttonHintsController.Hide();
}

@addMethod(FullscreenVendorGameController)
protected cb func OnBisSellPopupClosed(data: ref<inkGameNotificationData>) -> Bool {
  let itemsData: [wref<gameItemData>];
  let amounts: [Int32];
  let i: Int32;
  this.m_isPopupPending = false;
  this.m_bisSellPopupToken = null;
  let closeData: ref<VendorSellJunkPopupCloseData> = data as VendorSellJunkPopupCloseData;
  if IsDefined(closeData) && closeData.confirm {
    while i < ArraySize(closeData.limitedItems) {
      ArrayPush(itemsData, closeData.limitedItems[i].item);
      ArrayPush(amounts, closeData.limitedItems[i].quantity);
      i += 1;
    };
    this.m_VendorDataManager.SellItemsToVendor(itemsData, amounts);
    this.PlaySound(n"Item", n"OnSell");
    this.m_TooltipsManager.HideTooltips();
  } else {
    this.PlaySound(n"Button", n"OnPress");
  };
  this.m_buttonHintsController.Show();
}

@addMethod(NewItemCompareBuilder)
public final func BisTopFirst() -> ref<NewItemCompareBuilder> {
  let player: ref<PlayerPuppet> = GetPlayer(GetGameInstance());
  if IsDefined(player) && IsDefined(this.m_sortData1) && IsDefined(this.m_sortData2) {
    this.m_compareBuilder.BoolTrue(player.BisIsBest(this.m_sortData1.GetID()), player.BisIsBest(this.m_sortData2.GetID()));
  };
  return this;
}

@wrapMethod(BackpackDataView)
protected func NewPreSortingInjection(builder: ref<NewItemCompareBuilder>) -> ref<NewItemCompareBuilder> {
  let result: ref<NewItemCompareBuilder> = wrappedMethod(builder);
  if BisTopFirst() {
    return result.BisTopFirst();
  };
  return result;
}

@addField(LootingListItemController)
let m_bisUpBadge: wref<inkWidget>;

@addMethod(LootingListItemController)
private final func BisEnsureLootBadge() -> Void {
  let root: ref<inkCompoundWidget> = this.GetRootCompoundWidget();
  let outer: ref<inkCompoundWidget>;
  let row: ref<inkCompoundWidget>;
  let content: ref<inkCompoundWidget>;
  let line: ref<inkCompoundWidget>;
  let chip: ref<inkCanvas>;
  let bg: ref<inkRectangle>;
  let label: ref<inkText>;
  if IsDefined(this.m_bisUpBadge) || !IsDefined(root) {
    return;
  };
  outer = root.GetWidget(n"wrapper") as inkCompoundWidget;
  row = IsDefined(outer) ? outer.GetWidget(n"item_wrapper") as inkCompoundWidget : null;
  content = IsDefined(row) ? row.GetWidget(n"content") as inkCompoundWidget : null;
  line = IsDefined(content) ? content.GetWidget(n"wrapper") as inkCompoundWidget : null;
  if !IsDefined(line) {
    return;
  };
  chip = new inkCanvas();
  chip.SetName(n"BisLootUpBadge");
  chip.SetSize(new Vector2(40.0, 40.0));
  chip.SetVAlign(inkEVerticalAlign.Center);
  chip.SetMargin(new inkMargin(4.0, 0.0, 4.0, 0.0));
  chip.SetAffectsLayoutWhenHidden(false);
  chip.SetVisible(false);
  bg = new inkRectangle();
  bg.SetName(n"BisLootUpBadgeOutline");
  bg.SetAnchor(inkEAnchor.Fill);
  bg.SetTintColor(new HDRColor(0.0, 0.0, 0.0, 1.0));
  bg.SetOpacity(0.9);
  bg.Reparent(chip);
  bg = new inkRectangle();
  bg.SetName(n"BisLootUpBadgeBg");
  bg.SetAnchor(inkEAnchor.Fill);
  bg.SetMargin(new inkMargin(3.0, 3.0, 3.0, 3.0));
  bg.SetTintColor(new HDRColor(0.3, 2.0, 0.5, 1.0));
  bg.SetOpacity(1.0);
  bg.Reparent(chip);
  label = new inkText();
  label.SetName(n"BisLootUpBadgeText");
  label.SetText("+");
  label.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
  label.SetFontStyle(n"Bold");
  label.SetFontSize(32);
  label.SetTintColor(new HDRColor(0.05, 0.05, 0.05, 1.0));
  label.SetAnchor(inkEAnchor.Fill);
  label.SetHorizontalAlignment(textHorizontalAlignment.Center);
  label.SetVerticalAlignment(textVerticalAlignment.Center);
  label.Reparent(chip);
  chip.Reparent(line);
  line.ReorderChild(chip, 2);
  this.m_bisUpBadge = chip;
}

@addMethod(LootingListItemController)
private final func BisIsLootUpgrade() -> Bool {
  let uiSystem: ref<UIInventoryScriptableSystem> = UIInventoryScriptableSystem.GetInstance(GetGameInstance());
  let player: ref<PlayerPuppet>;
  let item: ref<UIInventoryItem>;
  if !IsDefined(uiSystem) || !BisShowUpgradeBadge() || !IsDefined(this.m_lootingData) || !IsDefined(this.m_lootingData.gameItemData)
    || NotEquals(this.m_lootingData.lootItemType, LootItemType.Default) {
    return false;
  };
  player = GetPlayer(GetGameInstance());
  if !IsDefined(player) {
    return false;
  };
  item = UIInventoryItem.Make(player, this.m_lootingData.gameItemData, uiSystem.GetInventoryItemsManager());
  return IsDefined(item) && player.BisIsUpgrade(item);
}

@wrapMethod(LootingListItemController)
protected func RefreshUI() -> Void {
  wrappedMethod();
  this.BisEnsureLootBadge();
  if IsDefined(this.m_bisUpBadge) {
    this.m_bisUpBadge.SetVisible(this.BisIsLootUpgrade());
  };
}
