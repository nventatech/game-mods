module BestInSlot.Localization
import Codeware.Localization.*

public class English extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-BestInSlot-Badge-Top", "TOP");
    this.Text("Mod-BestInSlot-Bar-EquipBest", "Equip best loadout");
    this.Text("Mod-BestInSlot-Bar-SellNonTop", "Sell everything without TOP");
    this.Text("Mod-BestInSlot-Title", "Best In Slot");
    this.Text("Mod-BestInSlot-Set-EquipKey", "Equip best loadout key");
    this.Text("Mod-BestInSlot-Set-EquipKey-Desc", "Key that equips the best loadout in the backpack and character screens.");
    this.Text("Mod-BestInSlot-Set-SellKey", "Bulk-sell key");
    this.Text("Mod-BestInSlot-Set-SellKey-Desc", "Key that sells everything without the TOP badge at a vendor.");
    this.Text("Mod-BestInSlot-Set-PadMod", "Controller modifier");
    this.Text("Mod-BestInSlot-Set-PadMod-Desc", "Shoulder button you hold before pressing the controller button below.");
    this.Text("Mod-BestInSlot-Set-PadBtn", "Controller button");
    this.Text("Mod-BestInSlot-Set-PadBtn-Desc", "Pressed with the modifier held, does the same as the keys above. Off disables the controller shortcut.");
    this.Text("Mod-BestInSlot-Set-TopFirst", "TOP items first");
    this.Text("Mod-BestInSlot-Set-TopFirst-Desc", "Items with the TOP badge go to the top of the grid, whichever sorting you picked.");
    this.Text("Mod-BestInSlot-Set-UpgradeBadge", "Upgrade (+) badge");
    this.Text("Mod-BestInSlot-Set-UpgradeBadge-Desc", "Green (+) on items that beat the one you have equipped in the same slot or type.");
    this.Text("Mod-BestInSlot-Set-SellClothes", "Bulk-sell includes clothes");
    this.Text("Mod-BestInSlot-Set-SellClothes-Desc", "Selling also covers clothes without the TOP badge. Equipped, favorite and quest items never sell.");
    this.Text("Mod-BestInSlot-Set-SellIconics", "Bulk-sell includes iconics");
    this.Text("Mod-BestInSlot-Set-SellIconics-Desc", "Selling also covers iconic items without the TOP badge. Off by default: most iconics can't be found again once sold.");
    this.Text("Mod-BestInSlot-Set-SellLimit", "Items sold per press");
    this.Text("Mod-BestInSlot-Set-SellLimit-Desc", "Most items the sell key sells at once. Press it again for the rest. Warning: selling hundreds of items to the same vendor can crash the game, a limit of the game itself. Sell a few rounds, then switch vendors.");
    this.Text("Mod-BestInSlot-Set-EquipConsumables", "Equip best consumables");
    this.Text("Mod-BestInSlot-Set-EquipConsumables-Desc", "Also slots the best healing item and grenade. Off equips weapons and clothes only.");
    this.Text("Mod-BestInSlot-Set-EquipClothes", "Equip best clothes");
    this.Text("Mod-BestInSlot-Set-EquipClothes-Desc", "The key also puts on the TOP clothes. Since 2.0 clothes only change your look, so turn this off to keep your outfit.");
    this.Text("Mod-BestInSlot-Set-WeaponMode", "Weapons the key equips");
    this.Text("Mod-BestInSlot-Set-WeaponMode-Desc", "Keep categories: each equipped weapon is swapped for the TOP of its category, and empty slots get the best category you are not using. Best overall: the 3 TOP weapons with the highest DPS, any category.");
    this.Text("Mod-BestInSlot-Set-WeaponMode-KeepCategories", "Keep categories");
    this.Text("Mod-BestInSlot-Set-WeaponMode-BestOverall", "Best overall");
  }
}

public class BrazilianPortuguese extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-BestInSlot-Badge-Top", "TOP");
    this.Text("Mod-BestInSlot-Bar-EquipBest", "Equipar os melhores");
    this.Text("Mod-BestInSlot-Bar-SellNonTop", "Vender tudo sem TOP");
    this.Text("Mod-BestInSlot-Title", "Best In Slot");
    this.Text("Mod-BestInSlot-Set-EquipKey", "Tecla de equipar os melhores");
    this.Text("Mod-BestInSlot-Set-EquipKey-Desc", "Tecla que equipa os melhores itens nas telas de mochila e personagem.");
    this.Text("Mod-BestInSlot-Set-SellKey", "Tecla de venda em massa");
    this.Text("Mod-BestInSlot-Set-SellKey-Desc", "Tecla que vende tudo sem o selo TOP no vendedor.");
    this.Text("Mod-BestInSlot-Set-PadMod", "Modificador do controle");
    this.Text("Mod-BestInSlot-Set-PadMod-Desc", "Botão de ombro que você segura antes de apertar o botão abaixo.");
    this.Text("Mod-BestInSlot-Set-PadBtn", "Botão do controle");
    this.Text("Mod-BestInSlot-Set-PadBtn-Desc", "Apertado com o modificador segurado, faz o mesmo que as teclas acima. Off desliga o atalho no controle.");
    this.Text("Mod-BestInSlot-Set-TopFirst", "Itens TOP primeiro");
    this.Text("Mod-BestInSlot-Set-TopFirst-Desc", "Itens com o selo TOP vão para o começo da grade, seja qual for a ordenação escolhida.");
    this.Text("Mod-BestInSlot-Set-UpgradeBadge", "Selo (+) de upgrade");
    this.Text("Mod-BestInSlot-Set-UpgradeBadge-Desc", "Selo (+) verde em item melhor que o equipado do mesmo slot ou tipo.");
    this.Text("Mod-BestInSlot-Set-SellClothes", "Venda em massa inclui roupas");
    this.Text("Mod-BestInSlot-Set-SellClothes-Desc", "A venda também pega roupas sem o selo TOP. Equipados, favoritos e itens de missão nunca são vendidos.");
    this.Text("Mod-BestInSlot-Set-SellIconics", "Venda em massa inclui icônicos");
    this.Text("Mod-BestInSlot-Set-SellIconics-Desc", "A venda também pega itens icônicos sem o selo TOP. Desligado por padrão: a maioria dos icônicos não aparece de novo depois de vendida.");
    this.Text("Mod-BestInSlot-Set-SellLimit", "Itens vendidos por vez");
    this.Text("Mod-BestInSlot-Set-SellLimit-Desc", "Máximo de itens que a tecla de venda vende de uma vez. Aperte de novo para o resto. Aviso: vender centenas de itens para o mesmo vendedor pode travar o jogo, é um limite do próprio jogo. Venda algumas levas e troque de vendedor.");
    this.Text("Mod-BestInSlot-Set-EquipConsumables", "Equipar melhores consumíveis");
    this.Text("Mod-BestInSlot-Set-EquipConsumables-Desc", "Também põe no slot o melhor item de cura e granada. Desligado, equipa só armas e roupas.");
    this.Text("Mod-BestInSlot-Set-EquipClothes", "Equipar melhores roupas");
    this.Text("Mod-BestInSlot-Set-EquipClothes-Desc", "A tecla também veste as roupas TOP. Desde a 2.0 roupa só muda o visual: desligue para manter sua roupa.");
    this.Text("Mod-BestInSlot-Set-WeaponMode", "Armas que a tecla equipa");
    this.Text("Mod-BestInSlot-Set-WeaponMode-Desc", "Manter categorias: cada arma equipada é trocada pela TOP da mesma categoria, e slot vazio recebe a melhor categoria que você não está usando. Melhores no geral: as 3 armas TOP de maior DPS, de qualquer categoria.");
    this.Text("Mod-BestInSlot-Set-WeaponMode-KeepCategories", "Manter categorias");
    this.Text("Mod-BestInSlot-Set-WeaponMode-BestOverall", "Melhores no geral");
  }
}

public class LocalizationProvider extends ModLocalizationProvider {
  public func GetPackage(language: CName) -> ref<ModLocalizationPackage> {
    switch language {
      case n"pt-br": return new BrazilianPortuguese();
      default: return new English();
    };
  }

  public func GetFallback() -> CName {
    return n"en-us";
  }
}
