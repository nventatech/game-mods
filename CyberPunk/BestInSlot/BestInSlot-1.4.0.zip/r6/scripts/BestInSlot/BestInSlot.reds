module BestInSlot
import Codeware.Localization.*

public func BisWeaponScore(item: ref<UIInventoryItem>) -> Float {
  let stat: ref<UIInventoryItemStat> = item.GetPrimaryStat();
  let dps: Float = IsDefined(stat) ? stat.Value : 0.0;
  let quality: Float = Cast<Float>(item.GetQualityInt());
  let iconic: Float = item.IsIconic() ? 1.0 : 0.0;
  let weight: Float = 1.0 + 0.06 * quality + 0.10 * iconic + 0.03 * item.GetItemPlus();
  return dps * weight + item.GetComparisonQualityF();
}

public func BisGenericScore(item: ref<UIInventoryItem>) -> Float {
  let stat: ref<UIInventoryItemStat> = item.GetPrimaryStat();
  let statValue: Float = IsDefined(stat) ? stat.Value : 0.0;
  return item.GetComparisonQualityF() * 1000.0 + MinF(statValue, 999.0);
}

public func BisScore(item: ref<UIInventoryItem>) -> Float {
  return item.IsWeapon() ? BisWeaponScore(item) : BisGenericScore(item);
}

public func BisIsRankable(item: ref<UIInventoryItem>) -> Bool {
  if !IsDefined(item) || ItemID.HasFlag(item.GetID(), gameEItemIDFlag.Preview) {
    return false;
  };
  if item.IsWeapon() || item.IsAnyCyberware() || item.IsHealingItem() || item.IsProgram() {
    return true;
  };
  if Equals(item.GetItemType(), gamedataItemType.Gad_Grenade) {
    return true;
  };
  return item.IsClothing() && NotEquals(item.GetEquipmentArea(), gamedataEquipmentArea.Invalid);
}

public func BisGroupKey(item: ref<UIInventoryItem>) -> Int32 {
  let key: Int32;
  if item.IsWeapon() {
    return EnumInt(item.GetItemType());
  };
  if item.IsClothing() {
    return 10000 + EnumInt(item.GetEquipmentArea());
  };
  if item.IsAnyCyberware() {
    key = 100000 + EnumInt(item.GetEquipmentArea()) * 1000 + EnumInt(item.GetItemType());
    if Equals(item.GetEquipmentArea(), gamedataEquipmentArea.SystemReplacementCW) {
      if item.IsCyberdeck() {
        key += 1000000;
      } else {
        if Equals(TweakDBInterface.GetCName(ItemID.GetTDBID(item.GetID()) + t".cyberwareType", n"None"), n"Sandevistan") {
          key += 2000000;
        } else {
          key += 3000000;
        };
      };
    };
    return key;
  };
  if item.IsProgram() {
    return 40000000 + Cast<Int32>(TDBID.ToNumber(TDBID.Create(item.GetName())) % Cast<Uint64>(1000000));
  };
  return 30000 + EnumInt(item.GetItemType());
}

@addField(PlayerPuppet)
let m_bisBestHashes: [Uint64];

@addField(PlayerPuppet)
let m_bisBestWeapons: [ItemID];

@addField(PlayerPuppet)
let m_bisBestClothes: [ItemID];

@addField(PlayerPuppet)
let m_bisBestConsumables: [ItemID];

@addField(PlayerPuppet)
let m_bisEqKeys: [Int32];

@addField(PlayerPuppet)
let m_bisEqScores: [Float];

@addMethod(PlayerPuppet)
public final func BisIsBest(itemID: ItemID) -> Bool {
  let hash: Uint64 = ItemID.GetCombinedHash(itemID);
  let i: Int32 = 0;
  while i < ArraySize(this.m_bisBestHashes) {
    if this.m_bisBestHashes[i] == hash {
      return true;
    };
    i += 1;
  };
  return false;
}

@addMethod(PlayerPuppet)
public final func BisIsUpgrade(item: ref<UIInventoryItem>) -> Bool {
  if !BisIsRankable(item) || item.IsEquipped() {
    return false;
  };
  let key: Int32 = BisGroupKey(item);
  let i: Int32 = 0;
  while i < ArraySize(this.m_bisEqKeys) {
    if this.m_bisEqKeys[i] == key {
      return BisScore(item) > this.m_bisEqScores[i];
    };
    i += 1;
  };
  return false;
}

@addMethod(PlayerPuppet)
public final func BisRecompute() -> Void {
  let uiSystem: ref<UIInventoryScriptableSystem> = UIInventoryScriptableSystem.GetInstance(this.GetGame());
  let values: [wref<IScriptable>];
  let bestPerGroup: [wref<UIInventoryItem>];
  let groupKeys: [Int32];
  let item: wref<UIInventoryItem>;
  let key: Int32;
  let idx: Int32;
  let j: Int32;
  let i: Int32;
  if !IsDefined(uiSystem) {
    return;
  };
  uiSystem.GetPlayerItemsMap().GetValues(values);
  ArrayClear(this.m_bisEqKeys);
  ArrayClear(this.m_bisEqScores);
  while i < ArraySize(values) {
    item = values[i] as UIInventoryItem;
    if BisIsRankable(item) {
      key = BisGroupKey(item);
      idx = -1;
      j = 0;
      while j < ArraySize(groupKeys) {
        if groupKeys[j] == key {
          idx = j;
        };
        j += 1;
      };
      if idx < 0 {
        ArrayPush(groupKeys, key);
        ArrayPush(bestPerGroup, item);
      } else {
        if BisScore(item) > BisScore(bestPerGroup[idx]) {
          bestPerGroup[idx] = item;
        };
      };
      if item.IsEquipped() {
        idx = -1;
        j = 0;
        while j < ArraySize(this.m_bisEqKeys) {
          if this.m_bisEqKeys[j] == key {
            idx = j;
          };
          j += 1;
        };
        if idx < 0 {
          ArrayPush(this.m_bisEqKeys, key);
          ArrayPush(this.m_bisEqScores, BisScore(item));
        } else {
          if BisScore(item) > this.m_bisEqScores[idx] {
            this.m_bisEqScores[idx] = BisScore(item);
          };
        };
      };
    };
    i += 1;
  };
  ArrayClear(this.m_bisBestHashes);
  ArrayClear(this.m_bisBestWeapons);
  ArrayClear(this.m_bisBestClothes);
  ArrayClear(this.m_bisBestConsumables);
  i = 0;
  while i < ArraySize(bestPerGroup) {
    ArrayPush(this.m_bisBestHashes, ItemID.GetCombinedHash(bestPerGroup[i].GetID()));
    if bestPerGroup[i].IsWeapon() {
      ArrayPush(this.m_bisBestWeapons, bestPerGroup[i].GetID());
    } else {
      if bestPerGroup[i].IsClothing() {
        ArrayPush(this.m_bisBestClothes, bestPerGroup[i].GetID());
      } else {
        if bestPerGroup[i].IsHealingItem() || Equals(bestPerGroup[i].GetItemType(), gamedataItemType.Gad_Grenade) {
          ArrayPush(this.m_bisBestConsumables, bestPerGroup[i].GetID());
        };
      };
    };
    i += 1;
  };
}

@addMethod(PlayerPuppet)
public final func BisEquipBest() -> Int32 {
  let game: GameInstance = this.GetGame();
  let uiSystem: ref<UIInventoryScriptableSystem> = UIInventoryScriptableSystem.GetInstance(game);
  let equipment: ref<EquipmentSystem> = GameInstance.GetScriptableSystemsContainer(game).Get(n"EquipmentSystem") as EquipmentSystem;
  let sortedIds: [ItemID];
  let sortedScores: [Float];
  let item: wref<UIInventoryItem>;
  let score: Float;
  let count: Int32;
  let slot: Int32;
  let j: Int32;
  let i: Int32;
  this.BisRecompute();
  if !IsDefined(uiSystem) || !IsDefined(equipment) {
    return 0;
  };
  while i < ArraySize(this.m_bisBestWeapons) {
    item = uiSystem.GetPlayerItem(this.m_bisBestWeapons[i]);
    if IsDefined(item) {
      score = BisWeaponScore(item);
      j = 0;
      while j < ArraySize(sortedScores) && sortedScores[j] >= score {
        j += 1;
      };
      ArrayInsert(sortedIds, j, this.m_bisBestWeapons[i]);
      ArrayInsert(sortedScores, j, score);
    };
    i += 1;
  };
  i = 0;
  while i < ArraySize(sortedIds) && slot < 3 {
    BisQueueEquip(equipment, this, sortedIds[i], slot);
    slot += 1;
    count += 1;
    i += 1;
  };
  i = 0;
  while i < ArraySize(this.m_bisBestClothes) {
    item = uiSystem.GetPlayerItem(this.m_bisBestClothes[i]);
    if IsDefined(item) && !item.IsEquipped() {
      BisQueueEquip(equipment, this, this.m_bisBestClothes[i], 0);
      count += 1;
    };
    i += 1;
  };
  if BisEquipConsumables() {
    i = 0;
    while i < ArraySize(this.m_bisBestConsumables) {
      item = uiSystem.GetPlayerItem(this.m_bisBestConsumables[i]);
      if IsDefined(item) && !item.IsEquipped() {
        BisQueueEquip(equipment, this, this.m_bisBestConsumables[i], 0);
        count += 1;
      };
      i += 1;
    };
  };
  return count;
}

public func BisQueueEquip(equipment: ref<EquipmentSystem>, player: ref<PlayerPuppet>, itemID: ItemID, slotIndex: Int32) -> Void {
  let request: ref<EquipRequest> = new EquipRequest();
  request.owner = player;
  request.itemID = itemID;
  request.slotIndex = slotIndex;
  request.addToInventory = false;
  request.equipToCurrentActiveSlot = false;
  equipment.QueueRequest(request);
}

@addField(InventoryItemDisplayController)
let m_bisBadge: wref<inkWidget>;

@addField(InventoryItemDisplayController)
let m_bisUpBadge: wref<inkWidget>;

@addField(InventoryItemDisplayController)
let m_bisBadgeText: wref<inkText>;

@addField(InventoryItemDisplayController)
let m_bisUpBadgeText: wref<inkText>;

@addMethod(InventoryItemDisplayController)
private final func BisPlaceBadges() -> Void {
  let root: ref<inkCompoundWidget> = this.GetRootCompoundWidget();
  let width: Float = IsDefined(root) ? root.GetWidth() : 0.0;
  let tight: Bool = width < 220.0;
  let chipWidth: Float = tight ? 62.0 : 94.0;
  let x: Float = width > chipWidth + 14.0 ? width - chipWidth - 6.0 : 5.0;
  if !IsDefined(this.m_bisBadge) || !IsDefined(this.m_bisUpBadge) {
    return;
  };
  this.m_bisBadge.SetSize(new Vector2(chipWidth, tight ? 32.0 : 44.0));
  this.m_bisBadge.SetTranslation(new Vector2(x, 5.0));
  this.m_bisUpBadge.SetSize(new Vector2(tight ? 34.0 : 50.0, tight ? 34.0 : 50.0));
  this.m_bisUpBadge.SetTranslation(new Vector2(5.0, 5.0));
  if IsDefined(this.m_bisBadgeText) {
    this.m_bisBadgeText.SetFontSize(tight ? 24 : 33);
  };
  if IsDefined(this.m_bisUpBadgeText) {
    this.m_bisUpBadgeText.SetFontSize(tight ? 26 : 38);
  };
}

@wrapMethod(InventoryItemDisplayController)
protected func NewUpdateIndicators(itemData: ref<UIInventoryItem>) -> Void {
  wrappedMethod(itemData);
  this.BisUpdateBadge(itemData);
}

@wrapMethod(InventoryItemDisplayController)
protected func NewRefreshUI(itemData: ref<UIInventoryItem>) -> Void {
  wrappedMethod(itemData);
  this.BisUpdateBadge(itemData);
}

@wrapMethod(InventoryItemDisplayController)
protected func RefreshUI() -> Void {
  wrappedMethod();
  this.BisUpdateBadgeLegacy();
}

@addMethod(InventoryItemDisplayController)
private final func BisIsHudContext() -> Bool {
  return Equals(this.m_itemDisplayContext, ItemDisplayContext.DPAD_RADIAL);
}

@addMethod(InventoryItemDisplayController)
private final func BisUpdateBadgeLegacy() -> Void {
  let player: ref<PlayerPuppet>;
  let item: wref<UIInventoryItem>;
  let uiSystem: ref<UIInventoryScriptableSystem>;
  let isBest: Bool;
  let isUpgrade: Bool;
  this.BisEnsureBadge();
  if !IsDefined(this.m_bisBadge) {
    return;
  };
  if this.BisIsHudContext() {
    this.m_bisBadge.SetVisible(false);
    this.m_bisUpBadge.SetVisible(false);
    return;
  };
  if !InventoryItemData.IsEmpty(this.m_itemData) {
    player = GetPlayer(GetGameInstance());
    isBest = IsDefined(player) && player.BisIsBest(InventoryItemData.GetID(this.m_itemData));
    if IsDefined(player) && !isBest && BisShowUpgradeBadge() {
      uiSystem = UIInventoryScriptableSystem.GetInstance(GetGameInstance());
      item = IsDefined(uiSystem) ? uiSystem.GetPlayerItem(InventoryItemData.GetID(this.m_itemData)) : null;
      isUpgrade = IsDefined(item) && player.BisIsUpgrade(item);
    };
  };
  this.BisPlaceBadges();
  this.m_bisBadge.SetVisible(isBest);
  this.m_bisUpBadge.SetVisible(isUpgrade);
}

@addMethod(InventoryItemDisplayController)
private final func BisUpdateBadge(itemData: ref<UIInventoryItem>) -> Void {
  let player: ref<PlayerPuppet>;
  let isBest: Bool;
  let isUpgrade: Bool;
  this.BisEnsureBadge();
  if !IsDefined(this.m_bisBadge) {
    return;
  };
  if this.BisIsHudContext() {
    this.m_bisBadge.SetVisible(false);
    this.m_bisUpBadge.SetVisible(false);
    return;
  };
  if IsDefined(itemData) {
    player = GetPlayer(GetGameInstance());
    isBest = IsDefined(player) && player.BisIsBest(itemData.GetID());
    isUpgrade = IsDefined(player) && !isBest && BisShowUpgradeBadge() && player.BisIsUpgrade(itemData);
  };
  this.BisPlaceBadges();
  this.m_bisBadge.SetVisible(isBest);
  this.m_bisUpBadge.SetVisible(isUpgrade);
}

@addMethod(InventoryItemDisplayController)
private final func BisEnsureBadge() -> Void {
  let root: ref<inkCompoundWidget>;
  let chip: ref<inkCanvas>;
  let bg: ref<inkRectangle>;
  let label: ref<inkText>;
  if !IsDefined(this.m_bisBadge) {
    root = this.GetRootCompoundWidget();
    if !IsDefined(root) {
      return;
    };
    chip = new inkCanvas();
    chip.SetName(n"BisBadge");
    chip.SetSize(new Vector2(94.0, 44.0));
    chip.SetAnchor(inkEAnchor.TopLeft);
    chip.SetAnchorPoint(new Vector2(0.0, 0.0));
    chip.SetTranslation(new Vector2(5.0, 5.0));
    chip.SetHAlign(inkEHorizontalAlign.Left);
    chip.SetVAlign(inkEVerticalAlign.Top);
    chip.SetAffectsLayoutWhenHidden(false);
    bg = new inkRectangle();
    bg.SetName(n"BisBadgeOutline");
    bg.SetAnchor(inkEAnchor.Fill);
    bg.SetTintColor(new HDRColor(0.0, 0.0, 0.0, 1.0));
    bg.SetOpacity(0.9);
    bg.Reparent(chip);
    bg = new inkRectangle();
    bg.SetName(n"BisBadgeBg");
    bg.SetAnchor(inkEAnchor.Fill);
    bg.SetMargin(new inkMargin(3.0, 3.0, 3.0, 3.0));
    bg.SetTintColor(new HDRColor(2.2, 1.5, 0.2, 1.0));
    bg.SetOpacity(1.0);
    bg.Reparent(chip);
    label = new inkText();
    label.SetName(n"BisBadgeText");
    label.SetText(LocalizationSystem.GetInstance(GetGameInstance()).GetText("Mod-BestInSlot-Badge-Top"));
    label.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
    label.SetFontStyle(n"Bold");
    label.SetFontSize(33);
    label.SetTintColor(new HDRColor(0.05, 0.05, 0.05, 1.0));
    label.SetAnchor(inkEAnchor.Fill);
    label.SetHorizontalAlignment(textHorizontalAlignment.Center);
    label.SetVerticalAlignment(textVerticalAlignment.Center);
    label.Reparent(chip);
    chip.Reparent(root);
    this.m_bisBadge = chip;
    this.m_bisBadgeText = label;
  };
  if !IsDefined(this.m_bisUpBadge) {
    root = this.GetRootCompoundWidget();
    if !IsDefined(root) {
      return;
    };
    chip = new inkCanvas();
    chip.SetName(n"BisUpBadge");
    chip.SetSize(new Vector2(50.0, 50.0));
    chip.SetAnchor(inkEAnchor.TopLeft);
    chip.SetAnchorPoint(new Vector2(0.0, 0.0));
    chip.SetTranslation(new Vector2(5.0, 5.0));
    chip.SetHAlign(inkEHorizontalAlign.Left);
    chip.SetVAlign(inkEVerticalAlign.Top);
    chip.SetAffectsLayoutWhenHidden(false);
    bg = new inkRectangle();
    bg.SetName(n"BisUpBadgeOutline");
    bg.SetAnchor(inkEAnchor.Fill);
    bg.SetTintColor(new HDRColor(0.0, 0.0, 0.0, 1.0));
    bg.SetOpacity(0.9);
    bg.Reparent(chip);
    bg = new inkRectangle();
    bg.SetName(n"BisUpBadgeBg");
    bg.SetAnchor(inkEAnchor.Fill);
    bg.SetMargin(new inkMargin(3.0, 3.0, 3.0, 3.0));
    bg.SetTintColor(new HDRColor(0.3, 2.0, 0.5, 1.0));
    bg.SetOpacity(1.0);
    bg.Reparent(chip);
    label = new inkText();
    label.SetName(n"BisUpBadgeText");
    label.SetText("+");
    label.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
    label.SetFontStyle(n"Bold");
    label.SetFontSize(38);
    label.SetTintColor(new HDRColor(0.05, 0.05, 0.05, 1.0));
    label.SetAnchor(inkEAnchor.Fill);
    label.SetHorizontalAlignment(textHorizontalAlignment.Center);
    label.SetVerticalAlignment(textVerticalAlignment.Center);
    label.Reparent(chip);
    chip.Reparent(root);
    this.m_bisUpBadge = chip;
    this.m_bisUpBadgeText = label;
  };
}

public func BisIsPadKey(key: EInputKey) -> Bool {
  return StrBeginsWith(EnumValueToString("EInputKey", Cast<Int64>(EnumInt(key))), "IK_Pad");
}

public func BisUsePadHint(pad: Bool) -> Bool {
  return pad && !Equals(BisPadBtnKey(), EInputKey.IK_None);
}

public func BisComboFired(key: EInputKey, hotkey: BisHotkey, padHeld: Bool) -> Bool {
  let padBtn: EInputKey = BisPadBtnKey();
  if Equals(key, BisHotkeyToInput(hotkey)) {
    return true;
  };
  return padHeld && !Equals(padBtn, EInputKey.IK_None) && Equals(key, padBtn);
}

public func BisKeyLabel(textKey: String, hotkey: BisHotkey) -> String {
  return "[" + BisHotkeyLabel(hotkey) + "] " + LocalizationSystem.GetInstance(GetGameInstance()).GetText(textKey);
}

public func BisPushHint(hints: wref<ButtonHints>, prevAction: CName, hadHint: Bool, pad: Bool, textKey: String) -> CName {
  let action: CName;
  if !IsDefined(hints) {
    return prevAction;
  };
  if !BisUsePadHint(pad) {
    if hadHint {
      hints.RemoveButtonHint(prevAction);
    };
    return n"";
  };
  action = BisPadHintAction();
  if hadHint && NotEquals(prevAction, action) {
    hints.RemoveButtonHint(prevAction);
  };
  hints.AddButtonHint(action, BisPadModLabel() + " + " + LocalizationSystem.GetInstance(GetGameInstance()).GetText(textKey));
  return action;
}

@addField(BackpackMainGameController)
let m_bisBar: wref<inkText>;

@addField(BackpackMainGameController)
let m_bisPad: Bool;

@addField(BackpackMainGameController)
let m_bisPadHeld: Bool;

@addField(BackpackMainGameController)
let m_bisHintOn: Bool;

@addField(BackpackMainGameController)
let m_bisHintAction: CName;

@addField(BackpackMainGameController)
let m_bisHooked: Bool;

@wrapMethod(BackpackMainGameController)
protected cb func OnPlayerAttach(playerPuppet: ref<GameObject>) -> Bool {
  let player: ref<PlayerPuppet> = playerPuppet as PlayerPuppet;
  if IsDefined(player) {
    player.BisRecompute();
  };
  let result: Bool = wrappedMethod(playerPuppet);
  if IsDefined(this.m_player) {
    this.m_bisPad = !this.m_player.PlayerLastUsedKBM();
    this.BisRefreshUi("");
  };
  if !this.m_bisHooked {
    this.m_bisHooked = true;
    GameInstance.GetCallbackSystem().RegisterCallback(n"Input/Key", this, n"OnBisKeyInput");
  };
  return result;
}

@addMethod(BackpackMainGameController)
private final func BisRefreshUi(status: String) -> Void {
  let text: String = status;
  if StrLen(text) == 0 && IsDefined(this.m_player) {
    text = IntToString(ArraySize(this.m_player.m_bisBestHashes)) + " "
      + LocalizationSystem.GetInstance(GetGameInstance()).GetText("Mod-BestInSlot-Bar-Marked");
  };
  if !BisUsePadHint(this.m_bisPad) {
    text += "   " + BisKeyLabel("Mod-BestInSlot-Bar-EquipBest", BisEquipHotkey());
  };
  this.BisUpdateBar(text);
  this.m_bisHintAction = BisPushHint(this.m_buttonHintsController, this.m_bisHintAction, this.m_bisHintOn,
    this.m_bisPad, "Mod-BestInSlot-Bar-EquipBest");
  this.m_bisHintOn = BisUsePadHint(this.m_bisPad);
}

@addMethod(BackpackMainGameController)
private final func BisUpdateBar(text: String) -> Void {
  let root: ref<inkCompoundWidget>;
  let bar: ref<inkText>;
  if !IsDefined(this.m_bisBar) {
    root = this.GetRootCompoundWidget();
    if !IsDefined(root) {
      return;
    };
    bar = new inkText();
    bar.SetName(n"BisBar");
    bar.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
    bar.SetFontStyle(n"Bold");
    bar.SetFontSize(40);
    bar.SetFitToContent(true);
    bar.SetTintColor(new HDRColor(0.42, 1.25, 1.4, 1.0));
    bar.SetAnchor(inkEAnchor.TopLeft);
    bar.SetAnchorPoint(new Vector2(0.0, 0.0));
    bar.SetTranslation(new Vector2(1000.0, 262.0));
    bar.Reparent(root);
    this.m_bisBar = bar;
  };
  this.m_bisBar.SetText(StrUpper(text));
}

@wrapMethod(BackpackMainGameController)
protected cb func OnUninitialize() -> Bool {
  GameInstance.GetCallbackSystem().UnregisterCallback(n"Input/Key", this, n"OnBisKeyInput");
  this.m_bisHooked = false;
  return wrappedMethod();
}

@addMethod(BackpackMainGameController)
protected cb func OnBisKeyInput(event: ref<KeyInputEvent>) {
  let count: Int32;
  let key: EInputKey = event.GetKey();
  let pad: Bool = BisIsPadKey(key);
  if Equals(key, BisPadModKey()) {
    this.m_bisPadHeld = !Equals(event.GetAction(), EInputAction.IACT_Release);
  };
  if !Equals(event.GetAction(), EInputAction.IACT_Press) {
    return;
  };
  if NotEquals(pad, this.m_bisPad) {
    this.m_bisPad = pad;
    this.BisRefreshUi("");
  };
  if !IsDefined(this.m_player) || !BisComboFired(key, BisEquipHotkey(), this.m_bisPadHeld) {
    return;
  };
  count = this.m_player.BisEquipBest();
  let loc: ref<LocalizationSystem> = LocalizationSystem.GetInstance(this.m_player.GetGame());
  this.BisRefreshUi(loc.GetText("Mod-BestInSlot-Bar-Equipped") + " (" + IntToString(count) + " "
    + loc.GetText("Mod-BestInSlot-Bar-Items") + ")");
}

@addField(gameuiInventoryGameController)
let m_bisInvBar: wref<inkText>;

@addField(gameuiInventoryGameController)
let m_bisPad: Bool;

@addField(gameuiInventoryGameController)
let m_bisPadHeld: Bool;

@addField(gameuiInventoryGameController)
let m_bisHintOn: Bool;

@addField(gameuiInventoryGameController)
let m_bisHintAction: CName;

@addField(gameuiInventoryGameController)
let m_bisHooked: Bool;

@wrapMethod(gameuiInventoryGameController)
protected cb func OnInitialize() -> Bool {
  let player: ref<PlayerPuppet> = GetPlayer(GetGameInstance());
  if IsDefined(player) {
    player.BisRecompute();
  };
  let result: Bool = wrappedMethod();
  if IsDefined(this.m_player) {
    this.m_bisPad = !this.m_player.PlayerLastUsedKBM();
  };
  this.BisRefreshInvUi("");
  if !this.m_bisHooked {
    this.m_bisHooked = true;
    GameInstance.GetCallbackSystem().RegisterCallback(n"Input/Key", this, n"OnBisInvKeyInput");
  };
  return result;
}

@addMethod(gameuiInventoryGameController)
private final func BisRefreshInvUi(status: String) -> Void {
  let text: String = status;
  if !BisUsePadHint(this.m_bisPad) {
    if StrLen(text) > 0 {
      text += "   ";
    };
    text += BisKeyLabel("Mod-BestInSlot-Bar-EquipBest", BisEquipHotkey());
  };
  this.BisUpdateInvBar(text);
  this.m_bisHintAction = BisPushHint(this.m_buttonHintsController, this.m_bisHintAction, this.m_bisHintOn,
    this.m_bisPad, "Mod-BestInSlot-Bar-EquipBest");
  this.m_bisHintOn = BisUsePadHint(this.m_bisPad);
}

@wrapMethod(gameuiInventoryGameController)
private func SwapMode(mode: InventoryModes) -> Void {
  wrappedMethod(mode);
  this.m_bisHintOn = false;
  this.BisRefreshInvUi("");
}

@wrapMethod(gameuiInventoryGameController)
protected cb func OnUninitialize() -> Bool {
  GameInstance.GetCallbackSystem().UnregisterCallback(n"Input/Key", this, n"OnBisInvKeyInput");
  this.m_bisHooked = false;
  return wrappedMethod();
}

@addMethod(gameuiInventoryGameController)
private final func BisUpdateInvBar(text: String) -> Void {
  let root: ref<inkCompoundWidget>;
  let bar: ref<inkText>;
  if !IsDefined(this.m_bisInvBar) {
    root = this.GetRootCompoundWidget();
    if !IsDefined(root) {
      return;
    };
    bar = new inkText();
    bar.SetName(n"BisInvBar");
    bar.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
    bar.SetFontStyle(n"Bold");
    bar.SetFontSize(40);
    bar.SetFitToContent(true);
    bar.SetTintColor(new HDRColor(0.42, 1.25, 1.4, 1.0));
    bar.SetAnchor(inkEAnchor.TopLeft);
    bar.SetAnchorPoint(new Vector2(0.0, 0.0));
    bar.SetTranslation(new Vector2(1000.0, 150.0));
    bar.Reparent(root);
    this.m_bisInvBar = bar;
  };
  this.m_bisInvBar.SetText(StrUpper(text));
}

@addMethod(gameuiInventoryGameController)
protected cb func OnBisInvKeyInput(event: ref<KeyInputEvent>) {
  let key: EInputKey = event.GetKey();
  let pad: Bool = BisIsPadKey(key);
  if Equals(key, BisPadModKey()) {
    this.m_bisPadHeld = !Equals(event.GetAction(), EInputAction.IACT_Release);
  };
  if !Equals(event.GetAction(), EInputAction.IACT_Press) {
    return;
  };
  if NotEquals(pad, this.m_bisPad) {
    this.m_bisPad = pad;
    this.BisRefreshInvUi("");
  };
  if !IsDefined(this.m_player) || !BisComboFired(key, BisEquipHotkey(), this.m_bisPadHeld) {
    return;
  };
  let count: Int32 = this.m_player.BisEquipBest();
  let loc: ref<LocalizationSystem> = LocalizationSystem.GetInstance(this.m_player.GetGame());
  this.BisRefreshInvUi(loc.GetText("Mod-BestInSlot-Bar-Equipped") + " (" + IntToString(count) + " "
    + loc.GetText("Mod-BestInSlot-Bar-Items") + ")");
}

@wrapMethod(RipperDocGameController)
protected cb func OnInitialize() -> Bool {
  let result: Bool = wrappedMethod();
  let player: ref<PlayerPuppet> = GetPlayer(GetGameInstance());
  if IsDefined(player) {
    player.BisRecompute();
  };
  return result;
}

@addField(FullscreenVendorGameController)
let m_bisPad: Bool;

@addField(FullscreenVendorGameController)
let m_bisPadHeld: Bool;

@addField(FullscreenVendorGameController)
let m_bisHintOn: Bool;

@addField(FullscreenVendorGameController)
let m_bisHintAction: CName;

@addField(FullscreenVendorGameController)
let m_bisHooked: Bool;

@addField(FullscreenVendorGameController)
let m_bisVendorBar: wref<inkText>;

@wrapMethod(FullscreenVendorGameController)
protected cb func OnInitialize() -> Bool {
  let player: ref<PlayerPuppet> = GetPlayer(GetGameInstance());
  if IsDefined(player) {
    player.BisRecompute();
  };
  let result: Bool = wrappedMethod();
  if IsDefined(player) {
    this.m_bisPad = !player.PlayerLastUsedKBM();
  };
  this.BisRefreshVendorHint();
  if !this.m_bisHooked {
    this.m_bisHooked = true;
    GameInstance.GetCallbackSystem().RegisterCallback(n"Input/Key", this, n"OnBisVendorKeyInput");
  };
  return result;
}

@addMethod(FullscreenVendorGameController)
private final func BisRefreshVendorHint() -> Void {
  let root: ref<inkCompoundWidget>;
  let bar: ref<inkText>;
  if !IsDefined(this.m_bisVendorBar) {
    root = this.GetRootCompoundWidget();
    if IsDefined(root) {
      bar = new inkText();
      bar.SetName(n"BisVendorBar");
      bar.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily");
      bar.SetFontStyle(n"Bold");
      bar.SetFontSize(40);
      bar.SetFitToContent(true);
      bar.SetTintColor(new HDRColor(0.42, 1.25, 1.4, 1.0));
      bar.SetAnchor(inkEAnchor.TopLeft);
      bar.SetAnchorPoint(new Vector2(0.0, 0.0));
      bar.SetTranslation(new Vector2(690.0, 345.0));
      bar.Reparent(root);
      this.m_bisVendorBar = bar;
    };
  };
  if IsDefined(this.m_bisVendorBar) {
    this.m_bisVendorBar.SetText(BisUsePadHint(this.m_bisPad) ? "" : StrUpper(BisKeyLabel("Mod-BestInSlot-Bar-SellNonTop", BisSellHotkey())));
  };
  this.m_bisHintAction = BisPushHint(this.m_buttonHintsController, this.m_bisHintAction, this.m_bisHintOn,
    this.m_bisPad, "Mod-BestInSlot-Bar-SellNonTop");
  this.m_bisHintOn = BisUsePadHint(this.m_bisPad);
}

@wrapMethod(FullscreenVendorGameController)
protected cb func OnUninitialize() -> Bool {
  GameInstance.GetCallbackSystem().UnregisterCallback(n"Input/Key", this, n"OnBisVendorKeyInput");
  this.m_bisHooked = false;
  return wrappedMethod();
}

@addField(FullscreenVendorGameController)
let m_bisSellPopupToken: ref<inkGameNotificationToken>;

@addMethod(FullscreenVendorGameController)
protected cb func OnBisVendorKeyInput(event: ref<KeyInputEvent>) {
  let key: EInputKey = event.GetKey();
  let pad: Bool = BisIsPadKey(key);
  if Equals(key, BisPadModKey()) {
    this.m_bisPadHeld = !Equals(event.GetAction(), EInputAction.IACT_Release);
  };
  if !Equals(event.GetAction(), EInputAction.IACT_Press) {
    return;
  };
  if NotEquals(pad, this.m_bisPad) {
    this.m_bisPad = pad;
    this.BisRefreshVendorHint();
  };
  if !BisComboFired(key, BisSellHotkey(), this.m_bisPadHeld) {
    return;
  };
  this.BisOpenSellNonTopConfirmation();
}

@addMethod(FullscreenVendorGameController)
private final func BisGetSellableNonTop() -> [wref<gameItemData>] {
  let result: [wref<gameItemData>];
  let values: [wref<IScriptable>];
  let item: wref<UIInventoryItem>;
  let i: Int32;
  let player: ref<PlayerPuppet> = GetPlayer(GetGameInstance());
  let uiSystem: ref<UIInventoryScriptableSystem> = UIInventoryScriptableSystem.GetInstance(GetGameInstance());
  if !IsDefined(player) || !IsDefined(uiSystem) {
    return result;
  };
  player.BisRecompute();
  uiSystem.GetPlayerItemsMap().GetValues(values);
  while i < ArraySize(values) {
    item = values[i] as UIInventoryItem;
    if IsDefined(item)
      && (item.IsWeapon() || (BisSellClothes() && item.IsClothing()))
      && !item.IsEquipped()
      && !item.IsQuestItem()
      && !item.IsIconic()
      && !player.BisIsBest(item.GetID())
      && this.m_VendorDataManager.CanPlayerSellItem(item.GetID())
      && IsDefined(item.GetRealItemData()) {
      ArrayPush(result, item.GetRealItemData());
    };
    i += 1;
  };
  return result;
}

@addMethod(FullscreenVendorGameController)
private final func BisOpenSellNonTopConfirmation() -> Void {
  let data: ref<VendorSellJunkPopupData>;
  let vendorMoney: Int32;
  let limitedItems: [ref<VendorJunkSellItem>];
  let sellableItems: [wref<gameItemData>] = this.BisGetSellableNonTop();
  if ArraySize(sellableItems) == 0 || this.m_isPopupPending {
    return;
  };
  this.m_isPopupPending = true;
  vendorMoney = MarketSystem.GetVendorMoney(this.m_VendorDataManager.GetVendorInstance());
  limitedItems = this.GetLimitedSellableItems(sellableItems, vendorMoney);
  data = new VendorSellJunkPopupData();
  data.notificationName = n"base\\gameplay\\gui\\widgets\\notifications\\vendor_sell_junk_confirmation.inkwidget";
  data.isBlocking = true;
  data.useCursor = true;
  data.queueName = n"modal_popup";
  data.items = sellableItems;
  data.itemsQuantity = ArraySize(sellableItems);
  data.totalPrice = this.GetBulkSellPrice(sellableItems);
  data.limitedTotalPrice = Cast<Int32>(this.GetBulkSellPrice(limitedItems));
  data.limitedItems = limitedItems;
  data.limitedItemsQuantity = ArraySize(limitedItems);
  this.m_bisSellPopupToken = this.ShowGameNotification(data);
  this.m_bisSellPopupToken.RegisterListener(this, n"OnBisSellPopupClosed");
  this.m_buttonHintsController.Hide();
}

@addMethod(FullscreenVendorGameController)
protected cb func OnBisSellPopupClosed(data: ref<inkGameNotificationData>) -> Bool {
  let itemsData: [wref<gameItemData>];
  let amounts: [Int32];
  let i: Int32;
  this.m_isPopupPending = false;
  this.m_bisSellPopupToken = null;
  let closeData: ref<VendorSellJunkPopupCloseData> = data as VendorSellJunkPopupCloseData;
  if IsDefined(closeData) && closeData.confirm {
    while i < ArraySize(closeData.limitedItems) {
      ArrayPush(itemsData, closeData.limitedItems[i].item);
      ArrayPush(amounts, closeData.limitedItems[i].quantity);
      i += 1;
    };
    this.m_VendorDataManager.SellItemsToVendor(itemsData, amounts);
    this.PlaySound(n"Item", n"OnSell");
    this.m_TooltipsManager.HideTooltips();
  } else {
    this.PlaySound(n"Button", n"OnPress");
  };
  this.m_buttonHintsController.Show();
}

@addMethod(NewItemCompareBuilder)
public final func BisTopFirst() -> ref<NewItemCompareBuilder> {
  let player: ref<PlayerPuppet> = GetPlayer(GetGameInstance());
  if IsDefined(player) && IsDefined(this.m_sortData1) && IsDefined(this.m_sortData2) {
    this.m_compareBuilder.BoolTrue(player.BisIsBest(this.m_sortData1.GetID()), player.BisIsBest(this.m_sortData2.GetID()));
  };
  return this;
}

@wrapMethod(BackpackDataView)
protected func NewPreSortingInjection(builder: ref<NewItemCompareBuilder>) -> ref<NewItemCompareBuilder> {
  let result: ref<NewItemCompareBuilder> = wrappedMethod(builder);
  if BisTopFirst() {
    return result.BisTopFirst();
  };
  return result;
}
