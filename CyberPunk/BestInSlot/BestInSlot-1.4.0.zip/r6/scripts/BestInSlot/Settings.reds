module BestInSlot

enum BisHotkey {
  B = 0,
  N = 1,
  F2 = 2,
  F6 = 3,
  F7 = 4,
  F8 = 5,
  F10 = 6,
  F11 = 7,
  Insert = 8
}

enum BisPadMod {
  LB = 0,
  RB = 1
}

enum BisPadBtn {
  Off = 0,
  DpadUp = 1,
  DpadDown = 2,
  DpadLeft = 3,
  DpadRight = 4
}

public class BestInSlotSettings extends ScriptableSystem {

  @runtimeProperty("ModSettings.mod", "Mod-BestInSlot-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-BestInSlot-Set-EquipKey")
  @runtimeProperty("ModSettings.description", "Mod-BestInSlot-Set-EquipKey-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"B\", \"N\", \"F2\", \"F6\", \"F7\", \"F8\", \"F10\", \"F11\", \"Insert\"")
  public let equipKey: BisHotkey = BisHotkey.B;

  @runtimeProperty("ModSettings.mod", "Mod-BestInSlot-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-BestInSlot-Set-SellKey")
  @runtimeProperty("ModSettings.description", "Mod-BestInSlot-Set-SellKey-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"B\", \"N\", \"F2\", \"F6\", \"F7\", \"F8\", \"F10\", \"F11\", \"Insert\"")
  public let sellKey: BisHotkey = BisHotkey.N;

  @runtimeProperty("ModSettings.mod", "Mod-BestInSlot-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-BestInSlot-Set-PadMod")
  @runtimeProperty("ModSettings.description", "Mod-BestInSlot-Set-PadMod-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"LB\", \"RB\"")
  public let padMod: BisPadMod = BisPadMod.LB;

  @runtimeProperty("ModSettings.mod", "Mod-BestInSlot-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-BestInSlot-Set-PadBtn")
  @runtimeProperty("ModSettings.description", "Mod-BestInSlot-Set-PadBtn-Desc")
  @runtimeProperty("ModSettings.displayValues", "\"Off\", \"D-pad Up\", \"D-pad Down\", \"D-pad Left\", \"D-pad Right\"")
  public let padBtn: BisPadBtn = BisPadBtn.DpadDown;

  @runtimeProperty("ModSettings.mod", "Mod-BestInSlot-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-BestInSlot-Set-TopFirst")
  @runtimeProperty("ModSettings.description", "Mod-BestInSlot-Set-TopFirst-Desc")
  public let topFirst: Bool = true;

  @runtimeProperty("ModSettings.mod", "Mod-BestInSlot-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-BestInSlot-Set-UpgradeBadge")
  @runtimeProperty("ModSettings.description", "Mod-BestInSlot-Set-UpgradeBadge-Desc")
  public let showUpgradeBadge: Bool = true;

  @runtimeProperty("ModSettings.mod", "Mod-BestInSlot-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-BestInSlot-Set-SellClothes")
  @runtimeProperty("ModSettings.description", "Mod-BestInSlot-Set-SellClothes-Desc")
  public let sellClothes: Bool = true;

  @runtimeProperty("ModSettings.mod", "Mod-BestInSlot-Title")
  @runtimeProperty("ModSettings.displayName", "Mod-BestInSlot-Set-EquipConsumables")
  @runtimeProperty("ModSettings.description", "Mod-BestInSlot-Set-EquipConsumables-Desc")
  public let equipConsumables: Bool = true;

  public static func Get(game: GameInstance) -> ref<BestInSlotSettings> {
    return GameInstance.GetScriptableSystemsContainer(game).Get(n"BestInSlot.BestInSlotSettings") as BestInSlotSettings;
  }

  @if(ModuleExists("ModSettingsModule"))
  private func OnAttach() -> Void {
    ModSettings.RegisterListenerToClass(this);
  }

  @if(!ModuleExists("ModSettingsModule"))
  private func OnAttach() -> Void {}

  @if(ModuleExists("ModSettingsModule"))
  private func OnDetach() -> Void {
    ModSettings.UnregisterListenerToClass(this);
  }

  @if(!ModuleExists("ModSettingsModule"))
  private func OnDetach() -> Void {}
}

public func BisSellClothes() -> Bool {
  let s: ref<BestInSlotSettings> = BestInSlotSettings.Get(GetGameInstance());
  return !IsDefined(s) || s.sellClothes;
}

public func BisShowUpgradeBadge() -> Bool {
  let s: ref<BestInSlotSettings> = BestInSlotSettings.Get(GetGameInstance());
  return !IsDefined(s) || s.showUpgradeBadge;
}

public func BisEquipConsumables() -> Bool {
  let s: ref<BestInSlotSettings> = BestInSlotSettings.Get(GetGameInstance());
  return !IsDefined(s) || s.equipConsumables;
}

public func BisTopFirst() -> Bool {
  let s: ref<BestInSlotSettings> = BestInSlotSettings.Get(GetGameInstance());
  return !IsDefined(s) || s.topFirst;
}

public func BisHotkeyToInput(hotkey: BisHotkey) -> EInputKey {
  switch hotkey {
    case BisHotkey.N: return EInputKey.IK_N;
    case BisHotkey.F2: return EInputKey.IK_F2;
    case BisHotkey.F6: return EInputKey.IK_F6;
    case BisHotkey.F7: return EInputKey.IK_F7;
    case BisHotkey.F8: return EInputKey.IK_F8;
    case BisHotkey.F10: return EInputKey.IK_F10;
    case BisHotkey.F11: return EInputKey.IK_F11;
    case BisHotkey.Insert: return EInputKey.IK_Insert;
    default: return EInputKey.IK_B;
  };
}

public func BisHotkeyLabel(hotkey: BisHotkey) -> String {
  switch hotkey {
    case BisHotkey.N: return "N";
    case BisHotkey.F2: return "F2";
    case BisHotkey.F6: return "F6";
    case BisHotkey.F7: return "F7";
    case BisHotkey.F8: return "F8";
    case BisHotkey.F10: return "F10";
    case BisHotkey.F11: return "F11";
    case BisHotkey.Insert: return "Insert";
    default: return "B";
  };
}

public func BisEquipHotkey() -> BisHotkey {
  let s: ref<BestInSlotSettings> = BestInSlotSettings.Get(GetGameInstance());
  return IsDefined(s) ? s.equipKey : BisHotkey.B;
}

public func BisSellHotkey() -> BisHotkey {
  let s: ref<BestInSlotSettings> = BestInSlotSettings.Get(GetGameInstance());
  return IsDefined(s) ? s.sellKey : BisHotkey.N;
}

public func BisPadModKey() -> EInputKey {
  let s: ref<BestInSlotSettings> = BestInSlotSettings.Get(GetGameInstance());
  if IsDefined(s) && Equals(s.padMod, BisPadMod.RB) {
    return EInputKey.IK_Pad_RightShoulder;
  };
  return EInputKey.IK_Pad_LeftShoulder;
}

public func BisPadModLabel() -> String {
  let s: ref<BestInSlotSettings> = BestInSlotSettings.Get(GetGameInstance());
  return IsDefined(s) && Equals(s.padMod, BisPadMod.RB) ? "RB" : "LB";
}

public func BisPadBtnKey() -> EInputKey {
  let s: ref<BestInSlotSettings> = BestInSlotSettings.Get(GetGameInstance());
  if !IsDefined(s) {
    return EInputKey.IK_Pad_DigitDown;
  };
  switch s.padBtn {
    case BisPadBtn.DpadUp: return EInputKey.IK_Pad_DigitUp;
    case BisPadBtn.DpadDown: return EInputKey.IK_Pad_DigitDown;
    case BisPadBtn.DpadLeft: return EInputKey.IK_Pad_DigitLeft;
    case BisPadBtn.DpadRight: return EInputKey.IK_Pad_DigitRight;
    default: return EInputKey.IK_None;
  };
}

public func BisPadHintAction() -> CName {
  let key: EInputKey = BisPadBtnKey();
  if Equals(key, EInputKey.IK_Pad_DigitUp) {
    return n"popup_navigate_up";
  };
  if Equals(key, EInputKey.IK_Pad_DigitLeft) {
    return n"popup_navigate_left";
  };
  if Equals(key, EInputKey.IK_Pad_DigitRight) {
    return n"popup_navigate_right";
  };
  return n"popup_navigate_down";
}
