module BestInSlot.Localization
import Codeware.Localization.*

public class English extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-BestInSlot-Badge-Top", "TOP");
    this.Text("Mod-BestInSlot-Bar-Marked", "TOP items marked");
    this.Text("Mod-BestInSlot-Bar-EquipBest", "Equip best loadout");
    this.Text("Mod-BestInSlot-Bar-SellNonTop", "Sell everything without TOP");
    this.Text("Mod-BestInSlot-Bar-Equipped", "Best loadout equipped");
    this.Text("Mod-BestInSlot-Bar-Items", "items");
    this.Text("Mod-BestInSlot-Title", "Best In Slot");
    this.Text("Mod-BestInSlot-Set-EquipKey", "Equip best loadout key");
    this.Text("Mod-BestInSlot-Set-EquipKey-Desc", "Key that equips the best loadout in the backpack and character screens.");
    this.Text("Mod-BestInSlot-Set-SellKey", "Bulk-sell key");
    this.Text("Mod-BestInSlot-Set-SellKey-Desc", "Key that sells everything without the TOP badge at a vendor.");
    this.Text("Mod-BestInSlot-Set-PadMod", "Controller modifier");
    this.Text("Mod-BestInSlot-Set-PadMod-Desc", "Shoulder button you hold before pressing the controller button below.");
    this.Text("Mod-BestInSlot-Set-PadBtn", "Controller button");
    this.Text("Mod-BestInSlot-Set-PadBtn-Desc", "Pressed with the modifier held, does the same as the keys above. Off disables the controller shortcut.");
    this.Text("Mod-BestInSlot-Set-TopFirst", "TOP items first");
    this.Text("Mod-BestInSlot-Set-TopFirst-Desc", "Items with the TOP badge go to the top of the grid, whichever sorting you picked.");
    this.Text("Mod-BestInSlot-Set-UpgradeBadge", "Upgrade (+) badge");
    this.Text("Mod-BestInSlot-Set-UpgradeBadge-Desc", "Green (+) on items that beat the one you have equipped in the same slot or type.");
    this.Text("Mod-BestInSlot-Set-SellClothes", "Bulk-sell includes clothes");
    this.Text("Mod-BestInSlot-Set-SellClothes-Desc", "Selling also covers clothes without the TOP badge. Equipped, iconic and quest items never sell.");
    this.Text("Mod-BestInSlot-Set-EquipConsumables", "Equip best consumables");
    this.Text("Mod-BestInSlot-Set-EquipConsumables-Desc", "Also slots the best healing item and grenade. Off equips weapons and clothes only.");
  }
}

public class BrazilianPortuguese extends ModLocalizationPackage {
  protected func DefineTexts() {
    this.Text("Mod-BestInSlot-Badge-Top", "TOP");
    this.Text("Mod-BestInSlot-Bar-Marked", "itens TOP marcados");
    this.Text("Mod-BestInSlot-Bar-EquipBest", "Equipar os melhores");
    this.Text("Mod-BestInSlot-Bar-SellNonTop", "Vender tudo sem TOP");
    this.Text("Mod-BestInSlot-Bar-Equipped", "Melhor equipamento aplicado");
    this.Text("Mod-BestInSlot-Bar-Items", "itens");
    this.Text("Mod-BestInSlot-Title", "Best In Slot");
    this.Text("Mod-BestInSlot-Set-EquipKey", "Tecla de equipar os melhores");
    this.Text("Mod-BestInSlot-Set-EquipKey-Desc", "Tecla que equipa os melhores itens nas telas de mochila e personagem.");
    this.Text("Mod-BestInSlot-Set-SellKey", "Tecla de venda em massa");
    this.Text("Mod-BestInSlot-Set-SellKey-Desc", "Tecla que vende tudo sem o selo TOP no vendedor.");
    this.Text("Mod-BestInSlot-Set-PadMod", "Modificador do controle");
    this.Text("Mod-BestInSlot-Set-PadMod-Desc", "Botão de ombro que você segura antes de apertar o botão abaixo.");
    this.Text("Mod-BestInSlot-Set-PadBtn", "Botão do controle");
    this.Text("Mod-BestInSlot-Set-PadBtn-Desc", "Apertado com o modificador segurado, faz o mesmo que as teclas acima. Off desliga o atalho no controle.");
    this.Text("Mod-BestInSlot-Set-TopFirst", "Itens TOP primeiro");
    this.Text("Mod-BestInSlot-Set-TopFirst-Desc", "Itens com o selo TOP vão para o começo da grade, seja qual for a ordenação escolhida.");
    this.Text("Mod-BestInSlot-Set-UpgradeBadge", "Selo (+) de upgrade");
    this.Text("Mod-BestInSlot-Set-UpgradeBadge-Desc", "Selo (+) verde em item melhor que o equipado do mesmo slot ou tipo.");
    this.Text("Mod-BestInSlot-Set-SellClothes", "Venda em massa inclui roupas");
    this.Text("Mod-BestInSlot-Set-SellClothes-Desc", "A venda também pega roupas sem o selo TOP. Equipados, icônicos e itens de missão nunca são vendidos.");
    this.Text("Mod-BestInSlot-Set-EquipConsumables", "Equipar melhores consumíveis");
    this.Text("Mod-BestInSlot-Set-EquipConsumables-Desc", "Também põe no slot o melhor item de cura e granada. Desligado, equipa só armas e roupas.");
  }
}

public class LocalizationProvider extends ModLocalizationProvider {
  public func GetPackage(language: CName) -> ref<ModLocalizationPackage> {
    switch language {
      case n"pt-br": return new BrazilianPortuguese();
      default: return new English();
    };
  }

  public func GetFallback() -> CName {
    return n"en-us";
  }
}
