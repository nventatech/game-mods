local VERSION = "1.3.1"
local D = {}
local DEBUG = false
local PERF = true
local REUSE_WIDGET = true
local STORY_TRACE = false
local clock = (os and os.clock) or function() return 0 end
local function log(s) print("[DispatchMenu] " .. tostring(s) .. "\n") end
local function dbg(s) if DEBUG then log(s) end end
local function try(fn, ...)
    local ok, res = pcall(fn, ...)
    if not ok then log("ERR " .. tostring(res)) end
    return ok, res
end

local Strings = {
    en = {
        title = "DISPATCH MENU", tabHeroes = "HEROES", tabStats = "STATS", tabShift = "SHIFT", tabHacking = "HACKING", tabStory = "STORY",
        hero = "Hero", all = "ALL", on = "ON", off = "OFF", none = "-", noHeroes = "Enter a shift to see heroes",
        motivated = "Motivated", instantRest = "Instant rest", noRest = "Never rests", finishRest = "Finish resting now",
        earnXp = "Earns XP", levelUp = "Can level up", sabotage = "Sabotage immune", xpMult = "XP multiplier",
        maxLevel = "Max level", giveXp = "Give XP", levelNow = "Level up now", statPoints = "Stat points +1",
        clearStatus = "Clear negative status", heal = "Heal injuries", rallied = "Rallied", willRefuse = "Never refuses",
        combat = "Combat", mobility = "Mobility", vigor = "Vigor", charisma = "Charisma", intellect = "Intellect",
        allMax = "All stats to 10", allBase = "All stats to 1",
        speed = "Game speed", callOutcome = "Current call result", outcomeNormal = "Normal", outcomeSuccess = "Success", outcomeFail = "Fail", outcomeMiss = "Miss",
        abortCall = "Current call: abort", autoSabotage = "Auto sabotage", noScenario = "no active call",
        endShift = "End shift now", forceEnd = "Force end shift", addHero = "Add to roster", noGM = "no shift running",
        hackLife = "Hacking life +1", hackWin = "Finish hacking (success)", hackTimer = "No fail on time out", hackNone = "no hacking running",
        hackWinUnsupported = "This hack can't be force-finished, use the timer cheat and play it out",
        skipNode = "Skip current scene", skipChoice = "Skip to choice", storyRunning = "Story graph running", storyPaused = "Story paused",
        revealStats = "Reveal call stats", autoQte = "Auto-win QTEs",
        inflictInjury = "Inflict injury", injuryLight = "Light", injuryCritical = "Critical", injuryIncap = "Incapacitation",
        noVars = "No story variables loaded yet",
        run = "run", secRest = "REST", secXp = "XP AND LEVEL", secBehavior = "BEHAVIOR", secRecovery = "RECOVERY",
        secPresets = "PRESETS", secCall = "CURRENT CALL", secShift = "SHIFT", secVars = "STORY VARIABLES",
        help = "Keyboard: arrows move/change   Enter select   Q/E tab   F2 open/close\nController: R stick move/change   X select   LB/RB tab   LB+RB open   B close",
    },
    ["pt-BR"] = {
        title = "MENU DISPATCH", tabHeroes = "HEROIS", tabStats = "STATS", tabShift = "TURNO", tabHacking = "HACKING", tabStory = "HISTORIA",
        hero = "Heroi", all = "TODOS", on = "LIGADO", off = "DESLIGADO", none = "-", noHeroes = "Entre num turno para ver os herois",
        motivated = "Motivado", instantRest = "Descanso instantaneo", noRest = "Nunca descansa", finishRest = "Terminar descanso agora",
        earnXp = "Ganha XP", levelUp = "Pode subir de nivel", sabotage = "Imune a sabotagem", xpMult = "Multiplicador de XP",
        maxLevel = "Nivel maximo", giveXp = "Dar XP", levelNow = "Subir de nivel agora", statPoints = "Pontos de stat +1",
        clearStatus = "Limpar status negativos", heal = "Curar lesoes", rallied = "Inspirado (rally)", willRefuse = "Nunca recusa",
        combat = "Combate", mobility = "Mobilidade", vigor = "Vigor", charisma = "Carisma", intellect = "Intelecto",
        allMax = "Todas as stats em 10", allBase = "Todas as stats em 1",
        speed = "Velocidade do jogo", callOutcome = "Resultado do chamado atual", outcomeNormal = "Normal", outcomeSuccess = "Sucesso", outcomeFail = "Falha", outcomeMiss = "Erro",
        abortCall = "Chamado atual: abortar", autoSabotage = "Sabotagem automatica", noScenario = "sem chamado ativo",
        endShift = "Encerrar turno agora", forceEnd = "Forcar fim do turno", addHero = "Adicionar ao elenco", noGM = "sem turno em andamento",
        hackLife = "Vida de hacking +1", hackWin = "Terminar hacking (sucesso)", hackTimer = "Sem falha por tempo", hackNone = "sem hacking em andamento",
        hackWinUnsupported = "Esse hacking nao da pra forcar, use o cheat do timer e jogue normal",
        skipNode = "Pular cena atual", skipChoice = "Pular ate a escolha", storyRunning = "Historia rodando", storyPaused = "Historia pausada",
        revealStats = "Revelar stats do chamado", autoQte = "Vencer QTEs automaticamente",
        inflictInjury = "Causar lesao", injuryLight = "Leve", injuryCritical = "Critica", injuryIncap = "Incapacitante",
        noVars = "Nenhuma variavel de historia carregada",
        run = "executar", secRest = "DESCANSO", secXp = "XP E NIVEL", secBehavior = "COMPORTAMENTO", secRecovery = "RECUPERACAO",
        secPresets = "PREDEFINICOES", secCall = "CHAMADO ATUAL", secShift = "TURNO", secVars = "VARIAVEIS DA HISTORIA",
        help = "Teclado: setas move/altera   Enter seleciona   Q/E aba   F2 abre/fecha\nControle: analogico dir move/altera   X seleciona   LB/RB aba   LB+RB abre   B fecha",
    },
}
local Lang = "en"
local function T(k) return Strings[Lang][k] or Strings.en[k] or k end

local Theme = {
    frame = { R = 0.29, G = 0.27, B = 0.24, A = 1 },
    panel = { R = 0.17, G = 0.16, B = 0.15, A = 0.97 },
    band = { R = 0.20, G = 0.185, B = 0.17, A = 1 },
    text = { R = 0.93, G = 0.90, B = 0.85, A = 1 },
    muted = { R = 0.56, G = 0.53, B = 0.48, A = 1 },
    accent = { R = 0.95, G = 0.77, B = 0.35, A = 1 },
    rowSel = { R = 0.25, G = 0.23, B = 0.17, A = 1 },
    rowNone = { R = 0, G = 0, B = 0, A = 0 },
    on = { R = 0.56, G = 0.83, B = 0.64, A = 1 },
    off = { R = 0.43, G = 0.40, B = 0.36, A = 1 },
    bad = { R = 0.92, G = 0.42, B = 0.35, A = 1 },
}

local StatKeys = { { 5, "combat" }, { 2, "mobility" }, { 1, "vigor" }, { 3, "charisma" }, { 4, "intellect" } }
local XpAmounts = { 100, 500, 1000, 5000 }
local Speeds = { 1, 2, 4, 8 }
local PauseReason = 0

local Perf = { renders = 0, textSets = 0, colorSets = 0, rowsMade = 0, uiBuilds = 0, polls = 0, pollHits = 0, pollMs = 0, pollMax = 0, pcs = 0, pcScans = 0, lastReport = 0, tickMs = 0, tickMax = 0 }

local MaxRows = 22
local State = { cursors = {}, scrolls = {}, open = false, pausedByMenu = false, pcCount = 0, tab = 1, cursor = 1, heroIndex = 0, xpAmount = 1, speed = 1, rosterIndex = 1, revealStats = false, autoQte = false, injuryType = 1 }
local Frozen = {}

local SettingsPaths = { "ue4ss/Mods/DispatchMenu/settings.txt", "Mods/DispatchMenu/settings.txt" }
local SettingsPath = nil
local SettingsFailLogged = false
local HotkeyName = "F2"

local function encodeValue(v)
    if type(v) == "boolean" then return tostring(v) end
    if type(v) == "number" then return string.format("%.4f", v):gsub("0+$", ""):gsub("%.$", "") end
    return nil
end

local function decodeValue(str)
    if str == "true" then return true end
    if str == "false" then return false end
    return tonumber(str)
end

local function settingsLines()
    local lines = {
        "hotkey=" .. HotkeyName,
        "revealStats=" .. encodeValue(State.revealStats),
        "autoQte=" .. encodeValue(State.autoQte),
        "xpAmount=" .. encodeValue(State.xpAmount),
    }
    local keys = {}
    for key in pairs(Frozen) do keys[#keys + 1] = key end
    table.sort(keys)
    for _, key in ipairs(keys) do
        local props = {}
        for prop in pairs(Frozen[key]) do props[#props + 1] = prop end
        table.sort(props)
        for _, prop in ipairs(props) do
            local enc = encodeValue(Frozen[key][prop])
            if enc then lines[#lines + 1] = "frozen." .. key .. "." .. prop .. "=" .. enc end
        end
    end
    return lines
end

local function applySettingsLine(line)
    local key, value = line:match("^%s*([%w%.%*_]+)%s*=%s*(%S+)%s*$")
    if not key then return end
    if key == "hotkey" then HotkeyName = value:upper() return end
    local v = decodeValue(value)
    if v == nil then return end
    if key == "revealStats" then State.revealStats = v == true
    elseif key == "autoQte" then State.autoQte = v == true
    elseif key == "xpAmount" then
        if type(v) == "number" and v >= 1 and v <= #XpAmounts then State.xpAmount = math.floor(v) end
    else
        local hero, prop = key:match("^frozen%.([%w%*_]+)%.(%w+)$")
        if hero and prop then
            Frozen[hero] = Frozen[hero] or {}
            Frozen[hero][prop] = v
        end
    end
end

local function saveSettings()
    if not io then return end
    local paths = SettingsPath and { SettingsPath } or SettingsPaths
    for _, path in ipairs(paths) do
        local f = io.open(path, "w")
        if f then
            f:write(table.concat(settingsLines(), "\n"), "\n")
            f:close()
            SettingsPath = path
            return
        end
    end
    if not SettingsFailLogged then
        SettingsFailLogged = true
        log("settings: cannot write " .. table.concat(SettingsPaths, " or "))
    end
end

local function loadSettings()
    if not io then return end
    for _, path in ipairs(SettingsPaths) do
        local f = io.open(path, "r")
        if f then
            for line in f:lines() do applySettingsLine(line) end
            f:close()
            SettingsPath = path
            log("settings loaded from " .. path)
            return
        end
    end
end

local Original = {}
local CurrentTick = 0
D.RestCooldown = {}
D.SabotageTick = 0
local InHacking = false
D.LastMapLoad = 0

local function heroName(h)
    return (h:GetClass():GetFName():ToString():gsub("^BP_Hero_", ""):gsub("_C$", ""))
end

local function hasLocalPlayer(pc)
    local ok, v = pcall(function() return pc.Player:IsValid() and pc.PlayerInput:IsValid() end)
    return ok and v
end

local function heroCount(pc)
    local ok, n = pcall(function() return pc.Heroes:GetArrayNum() end)
    return ok and n or 0
end

local Cache = { epoch = 0, pc = nil, pcTick = -1000, heroes = nil, heroesEpoch = -1 }
local function invalidateCache() Cache.epoch = Cache.epoch + 1 end
local function forgetLookups()
    Cache.pcTick = -1000
    D.GmCache = { gm = nil, tick = -1000 }
    D.ScenarioCache = { list = nil, tick = -1000 }
end

local function findPC()
    local best, bestScore
    for _, pc in ipairs(FindAllOf("PC_ShiftPlayerController_C") or {}) do
        if pc:IsValid() then
            local score = (hasLocalPlayer(pc) and 2 or 0) + (heroCount(pc) > 0 and 1 or 0)
            if not best or score > bestScore then best, bestScore = pc, score end
        end
    end
    return best
end

local function getPC()
    local pc = Cache.pc
    if pc ~= nil then
        local ok, good = pcall(function() return pc:IsValid() and hasLocalPlayer(pc) end)
        if ok and good and CurrentTick - Cache.pcTick < 100 then return pc end
    elseif CurrentTick - Cache.pcTick < 50 then
        return nil
    end
    Cache.pc, Cache.pcTick = findPC(), CurrentTick
    return Cache.pc
end

local function anyPC()
    local shift = getPC()
    if shift and hasLocalPlayer(shift) then return shift end
    local fallback
    for _, pc in ipairs(FindAllOf("PlayerController") or {}) do
        if pc:IsValid() then
            if hasLocalPlayer(pc) then return pc end
            fallback = fallback or pc
        end
    end
    return fallback
end

D.GmCache = { gm = nil, tick = -1000 }
local function getGM()
    local c = D.GmCache
    if c.gm ~= nil then
        local ok, v = pcall(function() return c.gm:IsValid() end)
        if ok and v and CurrentTick - c.tick < 100 then return c.gm end
    elseif CurrentTick - c.tick < 50 then
        return nil
    end
    local gm = FindFirstOf("GM_ShiftGameMode_C")
    if not (gm and gm:IsValid()) then gm = nil end
    c.gm, c.tick = gm, CurrentTick
    return gm
end

local function getHeroes()
    if Cache.heroesEpoch == Cache.epoch and Cache.heroes then return Cache.heroes end
    local out = {}
    local pc = getPC()
    if pc then
        pcall(function()
            pc.Heroes:ForEach(function(_, e)
                local h = e:get()
                if h:IsValid() then out[#out + 1] = h end
            end)
        end)
    end
    Cache.heroes, Cache.heroesEpoch = out, Cache.epoch
    return out
end

local function targets()
    local all = getHeroes()
    if State.heroIndex == 0 then return all end
    return { all[State.heroIndex] }
end

local function frozenKey()
    if State.heroIndex == 0 then return "*" end
    local h = targets()[1]
    return h and heroName(h) or "*"
end

local function getFrozen(h, prop)
    local byHero = Frozen[heroName(h)]
    if byHero and byHero[prop] ~= nil then return byHero[prop] end
    local all = Frozen["*"]
    if all and all[prop] ~= nil then return all[prop] end
    return nil
end

local function setFrozen(prop, value)
    local key = frozenKey()
    dbg(string.format("freeze %s.%s = %s", key, prop, tostring(value)))
    Frozen[key] = Frozen[key] or {}
    Frozen[key][prop] = value
    if key == "*" then
        for name, t in pairs(Frozen) do
            if name ~= "*" then t[prop] = nil end
        end
    end
    try(saveSettings)
end

local function rememberOriginal(h, prop)
    local name = heroName(h)
    Original[name] = Original[name] or {}
    if Original[name][prop] == nil then Original[name][prop] = h[prop] end
    return Original[name][prop]
end

local FrozenProps = { "Motivated", "ForceStopResting", "EnabledEarnXP", "EnabledLevelUp", "EnableSabotage", "MaxRestTime", "ScenarioXPRewardsMultiplier", "MaxLevel", "Rallied", "WillRefuse" }
local function anyFrozen()
    for _, t in pairs(Frozen) do
        for _ in pairs(t) do return true end
    end
    return false
end

local function applyFrozen()
    if not anyFrozen() then return end
    if InHacking then return end
    if CurrentTick - D.LastMapLoad < 50 then return end
    local pc = getPC()
    if not pc or not hasLocalPlayer(pc) then return end
    if not getGM() then return end
    for _, h in ipairs(getHeroes()) do
        pcall(function()
            if not h:IsValid() then return end
            local name = heroName(h)
            for _, prop in ipairs(FrozenProps) do
                local v = getFrozen(h, prop)
                if v ~= nil and h[prop] ~= v then
                    dbg(string.format("reapply %s.%s %s -> %s", name, prop, tostring(h[prop]), tostring(v)))
                    rememberOriginal(h, prop)
                    h[prop] = v
                end
            end
            if getFrozen(h, "ForceStopResting") == true and h.HeroState == 4 then
                local last = D.RestCooldown[name]
                if not last or CurrentTick - last > 66 then
                    D.RestCooldown[name] = CurrentTick
                    dbg("finish rest (noRest) " .. name)
                    h.RestTime = h.MaxRestTime
                    h:FinishResting()
                end
            end
        end)
    end
    if CurrentTick - D.SabotageTick < 32 then return end
    D.SabotageTick = CurrentTick
    local sabImmune = false
    for _, t in pairs(Frozen) do
        if t.EnableSabotage == false then sabImmune = true break end
    end
    if sabImmune and not InHacking then
        pcall(function()
            pc.Scenarios:ForEach(function(_, e)
                pcall(function()
                    local sc = e:get()
                    if not sc:IsValid() then return end
                    local ok, actor = pcall(function() return sc.ScenarioActor end)
                    if ok and actor and actor:IsValid() then sc = actor end
                    if sc.EnableSabotage then
                        dbg("reapply scenario EnableSabotage -> false")
                        sc.EnableSabotage = false
                    end
                end)
            end)
        end)
    end
end

local function levelInstances(cls)
    local found = {}
    pcall(function()
        for _, o in ipairs(FindAllOf(cls) or {}) do
            local ok, good = pcall(function()
                return o:IsValid() and o:GetOuter():GetFName():ToString() == "PersistentLevel"
            end)
            if ok and good then found[#found + 1] = o end
        end
    end)
    return found
end

D.RevealOriginal = {}

local function addressOf(o)
    local ok, a = pcall(function() return o:GetAddress() end)
    return ok and a or nil
end

local AllStatKeys = { 1, 2, 3, 4, 5 }

local function arrayValues(arr)
    local out = {}
    pcall(function() arr:ForEach(function(_, e) out[#out + 1] = e:get() end) end)
    return out
end

local function scenarioStatComponent(sc)
    local ok, actor = pcall(function() return sc.ScenarioActor end)
    if ok and actor and actor:IsValid() then sc = actor end
    local comp = sc.StatComponent
    if comp and comp:IsValid() then return comp end
    return nil
end

D.GraphHookDone = false
D.GraphHookPath = "/Game/Shared/Shifts/Gameplay/Widgets/Shift_Misc/StatsGraph/WBP_StatsGraph.WBP_StatsGraph_C:UpdateRevealedStats"

local function scenarioPopupOf(widget)
    local o = widget
    for _ = 1, 10 do
        local ok, outer = pcall(function() return o:GetOuter() end)
        if not ok or not outer or not outer:IsValid() then return nil end
        local ok2, cls = pcall(function() return outer:GetClass():GetFName():ToString() end)
        if ok2 and cls == "WBP_ScenarioPopup_C" then return outer end
        o = outer
    end
    return nil
end

local function fillStatArray(arr)
    for i, k in ipairs(AllStatKeys) do arr[i] = k end
end

D.RepushTick = {}

local function popupStatComponent(popup)
    local ok, sc = pcall(function() return popup.ScenarioActor end)
    if not ok or not sc or not sc:IsValid() then return nil end
    return scenarioStatComponent(sc)
end

D.RepushFromMod = {}

local function onGraphUpdateRevealed(ctx, statsParam, layerParam)
    if not State.revealStats then return end
    local okL, layer = pcall(function() return layerParam:get() end)
    if not okL or layer ~= 0 then return end
    local graph = ctx:get()
    local key = addressOf(graph)
    if not key then return end
    if D.RepushFromMod[key] then
        D.RepushFromMod[key] = nil
        return
    end
    local popup = scenarioPopupOf(graph)
    if not popup then return end
    local comp = popupStatComponent(popup)
    if not comp then return end
    local compArr = comp.RevealedStats
    local before = compArr:GetArrayNum()
    if before < #AllStatKeys then
        local ck = addressOf(comp)
        if ck and D.RevealOriginal[ck] == nil then D.RevealOriginal[ck] = { comp = comp, orig = arrayValues(compArr) } end
        fillStatArray(compArr)
    end
    local last = D.RepushTick[key]
    if last and CurrentTick - last < 20 then return end
    D.RepushTick[key] = CurrentTick
    log("reveal graph layer0 comp " .. before .. " -> " .. compArr:GetArrayNum())
    ExecuteInGameThreadWithDelay(30, function()
        pcall(function()
            if State.revealStats and popup:IsValid() and graph:IsValid() and comp:IsValid() then
                D.RepushFromMod[key] = true
                comp:SetGraphWidget(graph, false)
                log("reveal repush")
            end
        end)
    end)
end

local function registerGraphHook()
    if D.GraphHookDone then return end
    local ok, err = pcall(function()
        RegisterHook(D.GraphHookPath, onGraphUpdateRevealed, function() end)
    end)
    if ok then D.GraphHookDone = true log("reveal graph hook ok") else dbg("reveal graph hook pending: " .. tostring(err)) end
end

local function revealScenario(sc)
    local comp = scenarioStatComponent(sc)
    if not comp then return end
    local arr = comp.RevealedStats
    if arr:GetArrayNum() >= #AllStatKeys then return end
    local ck = addressOf(comp)
    if ck and D.RevealOriginal[ck] == nil then D.RevealOriginal[ck] = { comp = comp, orig = arrayValues(arr) } end
    local before = arr:GetArrayNum()
    fillStatArray(arr)
    log(string.format("reveal stats: %d -> %d", before, arr:GetArrayNum()))
end

local function unrevealScenarios()
    for key, entry in pairs(D.RevealOriginal) do
        local ok, err = pcall(function()
            if not entry.comp:IsValid() then return end
            local arr = entry.comp.RevealedStats
            arr:Empty()
            for i, k in ipairs(entry.orig) do arr[i] = k end
            log("unreveal stats -> " .. arr:GetArrayNum())
        end)
        if not ok then log("unreveal stats ERR " .. tostring(err)) end
        D.RevealOriginal[key] = nil
    end
end

D.ScenarioCache = { list = nil, tick = -1000 }
local function cachedScenarios()
    local c = D.ScenarioCache
    if c.list and CurrentTick - c.tick < 100 then return c.list end
    c.list, c.tick = levelInstances("BP_Scenario_Base_C"), CurrentTick
    return c.list
end

local function revealCallStats()
    local pc = getPC()
    if not pc or not hasLocalPlayer(pc) or not getGM() then return end
    for _, sc in ipairs(cachedScenarios()) do
        pcall(function() if sc:IsValid() then revealScenario(sc) end end)
    end
end

D.QtePendingUntil = 0
D.QteHandled = {}
D.QteFluxSeen = {}
D.QteFluxGraceTicks = 12
D.FluxCdoPath = "/Game/Shared/Sandbox/QTEs/WBP_FluxQTE.Default__WBP_FluxQTE_C"
D.FluxCdoOriginal = nil
D.FluxCdoState = nil
local function applyFluxDefaults()
    local cdo = StaticFindObject(D.FluxCdoPath)
    if not cdo or not cdo:IsValid() then return end
    if D.FluxCdoOriginal == nil then
        D.FluxCdoOriginal = { CantFail = cdo.CantFail, AutoCompleteQTE = cdo.AutoCompleteQTE }
        log(string.format("flux cdo defaults CantFail=%s AutoCompleteQTE=%s", tostring(cdo.CantFail), tostring(cdo.AutoCompleteQTE)))
    end
    local want = State.autoQte
    if D.FluxCdoState == want and cdo.CantFail == (want or D.FluxCdoOriginal.CantFail) then return end
    cdo.CantFail = want or D.FluxCdoOriginal.CantFail
    cdo.AutoCompleteQTE = want or D.FluxCdoOriginal.AutoCompleteQTE
    D.FluxCdoState = want
    log("flux cdo auto-complete " .. tostring(want))
end

local function autoWinQte(kind, ctx)
    if not State.autoQte then return end
    if CurrentTick > D.QtePendingUntil then
        D.QteHandled = {}
        D.QteFluxSeen = {}
    end
    D.QtePendingUntil = CurrentTick + 250
    log("qte start " .. kind)
end

local function baseActive(w)
    local ok, v = pcall(function() return w.WBP_BaseQTE.Active end)
    return ok and v == true
end

local function winCircle(w)
    if not baseActive(w) then return false end
    w.CantFail = true
    try(function() w:SetNotFail() end)
    w.WBP_BaseQTE:OnSuccess()
    return true
end

local function isFinalHackingQte(w)
    local ok, final = pcall(function() return w.FinalHackingQTE == true or w.Duration >= 9000 end)
    return ok and final
end

local function winFlux(w)
    if isFinalHackingQte(w) then return false end
    w.CantFail = true
    w.AutoCompleteQTE = true
    if not baseActive(w) then return false end
    local key = addressOf(w)
    if not key then return false end
    if not D.QteFluxSeen[key] then
        D.QteFluxSeen[key] = CurrentTick
        local dur, flows = -1, -1
        pcall(function() dur = w.Duration end)
        pcall(function() flows = w.FlowsArray:GetArrayNum() end)
        log(string.format("qte flux auto-complete armed duration=%.2f flows=%d", dur, flows))
        return false
    end
    if CurrentTick - D.QteFluxSeen[key] < D.QteFluxGraceTicks then return false end
    log("qte flux still active, forcing success")
    w:SuccessReached()
    return true
end

local function winCommand(w)
    local cmds = {}
    w.PasswordCommands:ForEach(function(_, e) cmds[#cmds + 1] = e:get() end)
    if #cmds == 0 then return false end
    local start = (tonumber(w.CurrentSelected) or 0) + 1
    dbg("qte command list " .. #cmds .. " from " .. start)
    for i = start, #cmds do w:CheckInput(cmds[i]) end
    return true
end

local QteWinners = {
    { cls = "WBP_ShrinkingCircleQTE_C", fn = winCircle },
    { cls = "WBP_FluxQTE_C", fn = winFlux },
    { cls = "WBP_CommandInput_QTE_C", fn = winCommand },
}

local function pollQte()
    if CurrentTick > D.QtePendingUntil then return end
    if not State.autoQte then D.QtePendingUntil = 0 return end
    for _, entry in ipairs(QteWinners) do
        for _, w in ipairs(FindAllOf(entry.cls) or {}) do
            local key = addressOf(w)
            if key and not D.QteHandled[key] then
                local ok, done = pcall(function()
                    if not w:IsValid() or not w:IsVisible() then return false end
                    return entry.fn(w)
                end)
                if not ok then log("qte win " .. entry.cls .. " ERR " .. tostring(done)) end
                if ok and done then
                    D.QteHandled[key] = true
                    log("qte auto-success " .. entry.cls)
                end
            end
        end
    end
end

local function nameOf(o)
    local ok, n = pcall(function() return o:GetFullName() end)
    return ok and n or "?"
end

local function paramName(p)
    local ok, n = pcall(function() return nameOf(p:get()) end)
    return ok and n or "?"
end

local function paramValue(p)
    local ok, v = pcall(function() return p:get() end)
    return ok and tostring(v) or "?"
end

D.TraceHooks = {
    { path = "/Script/AdHocStory.AdHocStorySaveFunctions:SaveStoryBooleanVariable", fn = function(ctx, save, var, val) log("trace SaveStoryBoolean " .. paramName(var) .. " = " .. paramValue(val)) end },
    { path = "/Script/AdHocStory.AdHocStorySaveFunctions:SaveStoryNumberVariable", fn = function(ctx, save, var, val) log("trace SaveStoryNumber " .. paramName(var) .. " = " .. paramValue(val)) end },
    { path = "/Script/AdHocStory.AdHocStorySaveFunctions:GetStoryBooleanVariable", fn = function(ctx, save, var) log("trace GetStoryBoolean " .. paramName(var)) end },
    { path = "/Script/AdHocStory.AdHocStorySubsystem:StartGameplayNode", fn = function(ctx, node) log("trace StartGameplayNode " .. paramName(node)) end },
    { path = "/Script/AdHocStory.AdHocStorySubsystem:StartPlayingNode", fn = function(ctx, node) log("trace StartPlayingNode " .. paramName(node)) end },
    { path = "/Script/AdHocStory.AdHocStorySubsystem:ReturnToStoryFromGameplay", fn = function(ctx) log("trace ReturnToStoryFromGameplay") end },
    { path = "/Script/AdHocStory.AdHocStorySubsystem:DebugSkip", fn = function(ctx) log("trace DebugSkip") end },
    { path = "/Script/AdHocStory.AdHocStorySubsystem:SkipToChoiceInCurrentSequence", fn = function(ctx) log("trace SkipToChoice") end },
    { path = "/Script/AdHocStory.AdHocStoryCondition:Evaluate", fn = function(ctx, ...) log("trace Condition.Evaluate " .. nameOf(ctx:get())) end },
    { path = "/Script/AdHocSaveGame.AdHocSaveGameSubsystem:SaveNodePlayed", fn = function(ctx, ...) local a = { ... } log("trace SaveNodePlayed " .. (a[1] and paramValue(a[1]) or "")) end },
}

local function softPath(v)
    local out = "?"
    if v == nil then return "nil" end
    pcall(function() out = v:ToString() end)
    if out == "?" then pcall(function() out = v.AssetPathName:ToString() end) end
    if out == "?" then pcall(function() out = tostring(v) end) end
    return out
end

local function describeExpression(e)
    local cls = "?"
    pcall(function() cls = e:GetClass():GetFName():ToString() end)
    local extra = ""
    pcall(function() extra = " var=" .. nameOf(e.Variable) end)
    pcall(function() extra = extra .. " op=" .. tostring(e.ComparisonOperator) .. " left=" .. softPath(e.LeftExpression) .. " right=" .. softPath(e.RightExpression) end)
    pcall(function() extra = extra .. " value=" .. tostring(e.Value) end)
    pcall(function() extra = extra .. " bValue=" .. tostring(e.bValue) end)
    return cls .. extra
end

local function dumpStoryGraph()
    local counts = {}
    local function bump(k) counts[k] = (counts[k] or 0) + 1 end
    for _, node in ipairs(FindAllOf("AdHocStoryBaseGameplayNode") or {}) do
        pcall(function()
            if not node:IsValid() then return end
            local lvl = "?"
            pcall(function() lvl = softPath(node.GameplayLevel) end)
            log(string.format("graph gameplay %s level=%s next=%s", nameOf(node), lvl, nameOf(node.NextNode)))
            bump("gameplay")
        end)
    end
    for _, cls in ipairs({ "AdHocStoryBooleanVariableAssignment", "AdHocStoryNumberVariableAddition", "AdHocStoryEnumerationVariableAssignment" }) do
        for _, a in ipairs(FindAllOf(cls) or {}) do
            pcall(function()
                if not a:IsValid() then return end
                log(string.format("graph assign %s %s", nameOf(a), describeExpression(a)))
                bump("assign")
            end)
        end
    end
    for _, c in ipairs(FindAllOf("AdHocStoryCondition") or {}) do
        pcall(function()
            if not c:IsValid() then return end
            log(string.format("graph cond %s root=%s", nameOf(c), softPath(c.RootExpression)))
            pcall(function()
                c.AllSubExpressions:ForEach(function(k, v)
                    local key, expr = "?", "?"
                    pcall(function() key = tostring(k:get()) end)
                    pcall(function() expr = describeExpression(v:get()) end)
                    log(string.format("graph cond   sub %s -> %s", key, expr))
                end)
            end)
            bump("cond")
        end)
    end
    for _, n in ipairs(FindAllOf("AdHocStoryNode") or {}) do
        pcall(function()
            if not n:IsValid() then return end
            local cls = n:GetClass():GetFName():ToString()
            local scene = "?"
            pcall(function() scene = nameOf(n.Scene) end)
            log(string.format("graph node %s class=%s scene=%s gem=%s", nameOf(n), cls, scene, tostring(n.GemSceneId)))
            bump("node")
        end)
    end
    local ss = FindFirstOf("AdHocStorySubsystem")
    if ss and ss:IsValid() then pcall(function() log("graph current node " .. nameOf(ss:GetCurrentNode()) .. " episode " .. nameOf(ss.CurrentEpisode)) end) end
    local parts = {}
    for k, v in pairs(counts) do parts[#parts + 1] = k .. "=" .. v end
    log("graph dump done " .. table.concat(parts, " "))
end

D.ScenarioBasePath = "/Game/Shared/Shifts/Gameplay/Blueprints/Scenarios/BP_Scenario_Base.BP_Scenario_Base_C"
D.ScenarioHackingPath = "/Game/Shared/Shifts/Gameplay/Blueprints/Scenarios/BP_Scenario_Hacking.BP_Scenario_Hacking_C"
D.HkUserPath = "/Game/Shared/Hacking/Blueprints/Users/BP_HkUser_Master.BP_HkUser_Master_C"
D.ShiftTraceHooks = {
    { path = D.ScenarioBasePath .. ":SetHackingOutcome", fn = function(ctx, ok) log("trace SetHackingOutcome " .. nameOf(ctx:get()) .. " success=" .. paramValue(ok)) end },
    { path = D.ScenarioBasePath .. ":Debug_ForceSuccess", fn = function(ctx) log("trace Debug_ForceSuccess " .. nameOf(ctx:get())) end },
    { path = D.ScenarioBasePath .. ":RollOutcome", fn = function(ctx, v) log("trace RollOutcome " .. nameOf(ctx:get()) .. " rolled=" .. paramValue(v)) end },
    { path = D.ScenarioBasePath .. ":Finish", fn = function(ctx) log("trace Scenario.Finish " .. nameOf(ctx:get())) end },
    { path = D.ScenarioBasePath .. ":ForcedFinish", fn = function(ctx) log("trace Scenario.ForcedFinish " .. nameOf(ctx:get())) end },
    { path = D.ScenarioBasePath .. ":SetOutcomeVariables", fn = function(ctx) log("trace SetOutcomeVariables " .. nameOf(ctx:get())) end },
    { path = D.ScenarioBasePath .. ":ApplyFinishHacking", fn = function(ctx) log("trace Scenario.ApplyFinishHacking " .. nameOf(ctx:get())) end },
    { path = D.ScenarioHackingPath .. ":PrepareForHacking", fn = function(ctx) log("trace PrepareForHacking " .. nameOf(ctx:get())) end },
    { path = D.ScenarioHackingPath .. ":OnHackingButtonClicked", fn = function(ctx) log("trace OnHackingButtonClicked " .. nameOf(ctx:get())) end },
    { path = D.HkUserPath .. ":ReturnToShift", fn = function(ctx, ok) log("trace HkUser.ReturnToShift success=" .. paramValue(ok)) end },
    { path = D.HkUserPath .. ":ApplyFinishHacking", fn = function(ctx) log("trace HkUser.ApplyFinishHacking") end },
    { path = "/Game/Shared/Hacking/Blueprints/Effects/BP_HkIE_StackSuccess.BP_HkIE_StackSuccess_C:ReturnToShiftOrStory", fn = function(ctx) log("trace StackSuccess.ReturnToShiftOrStory " .. nameOf(ctx:get())) end },
    { path = "/Game/Shared/Hacking/Blueprints/Effects/BP_HkIE_ReturnToShiftSuccess.BP_HkIE_ReturnToShiftSuccess_C:Process", fn = function(ctx) log("trace ReturnToShiftSuccess.Process " .. nameOf(ctx:get())) end },
}
D.ShiftTraceDone = {}
D.ShiftTraceAllDone = false

local function registerShiftTraceHooks()
    if not STORY_TRACE or D.ShiftTraceAllDone then return end
    local all = true
    for _, h in ipairs(D.ShiftTraceHooks) do
        if not D.ShiftTraceDone[h.path] then
            local ok = pcall(function() RegisterHook(h.path, function(...) pcall(h.fn, ...) end, function() end) end)
            if ok then D.ShiftTraceDone[h.path] = true log("trace hook " .. h.path:match("[^.]+$") .. " ok") else all = false end
        end
    end
    D.ShiftTraceAllDone = all
end

local function dumpShiftScenarios()
    local n = 0
    for _, sc in ipairs(levelInstances("BP_Scenario_Base_C")) do
        pcall(function()
            local cls = sc:GetClass():GetFName():ToString()
            local line = string.format("shift scenario %s state=%s outcome=%s hackingSuccess=%s chance=%.1f", nameOf(sc), tostring(sc.ScenarioState), tostring(sc.Outcome), tostring(sc.HackingSuccess), tonumber(sc.SuccessChance) or -1)
            pcall(function() line = line .. " hackLevel=" .. softPath(sc.TargetHackingLevel) .. " difficulty=" .. tostring(sc.HackingDifficulty) .. " useOutcome=" .. tostring(sc.UseOutcome) end)
            log(line)
            n = n + 1
        end)
    end
    log("shift dump done scenarios=" .. n)
end

local function registerTraceHooks()
    if not STORY_TRACE then return end
    for _, h in ipairs(D.TraceHooks) do
        local ok, err = pcall(function() RegisterHook(h.path, function(...) pcall(h.fn, ...) end, function() end) end)
        log("trace hook " .. h.path:match("[^.]+$") .. " " .. (ok and "ok" or ("FAIL " .. tostring(err))))
    end
end

D.QteHooks = {}
D.QteHooksDone = false
local function registerQteHooks()
    if D.QteHooksDone then return end
    local all = true
    for _, fn in ipairs({ "ShrinkingCircle", "CommandInput", "Flux" }) do
        if not D.QteHooks[fn] then
            local ok, err = pcall(function()
                RegisterHook("/AdHocQTEs/BP_QTEsSubsystemGame.BP_QTEsSubsystemGame_C:BP_OnStart" .. fn .. "QTE", function(ctx) autoWinQte(fn, ctx) end)
            end)
            if ok then
                D.QteHooks[fn] = true
                log("qte hook " .. fn .. " ok")
            else
                all = false
                dbg("qte hook " .. fn .. " pending: " .. tostring(err))
            end
        end
    end
    D.QteHooksDone = all
end

local function readOut(h, fn)
    local t = {}
    h[fn](h, t)
    for _, v in pairs(t) do return v end
    return nil
end

local function statValue(h, key)
    local ok, v = pcall(function() return h.StatComponent.Stats:Find(key):get() end)
    if ok then return v end
    return 0
end

local function setStat(h, key, value)
    dbg(string.format("setStat %s key=%d %s -> %s", heroName(h), key, tostring(statValue(h, key)), tostring(value)))
    local phd = try(function()
        local out = {}
        h:PHD_GetStats(out)
        local src
        for _, v in pairs(out) do src = v break end
        local clean = {}
        if type(src) == "table" then
            for k, v in pairs(src) do
                dbg(string.format("  PHD key %s(%s) = %s", tostring(k), type(k), tostring(v)))
                local nk = math.floor(tonumber(k) or -1)
                if nk >= 1 and nk <= 5 and clean[nk] == nil then clean[nk] = v end
            end
        end
        clean[key] = value
        for _, s in ipairs(StatKeys) do
            if clean[s[1]] == nil then clean[s[1]] = statValue(h, s[1]) end
        end
        h:PHD_SetStats(clean)
    end)
    dbg("  PHD_SetStats " .. tostring(phd))
    h.StatComponent.Stats:Add(key, value)
    try(function() h.HeroData.Stats:Add(key, value) end)
    try(function() h:UpdateCardStatsGraph() end)
end

local function boolText(v) return v and T("on") or T("off") end
local function boolColor(v) return v and Theme.on or Theme.off end

local function gameplayStatics() return StaticFindObject("/Script/Engine.Default__GameplayStatics") end
local function widgetLib() return StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary") end

local function currentScenario()
    local pc = getPC()
    if not pc then return nil end
    local s = pc.CurrentScenario
    if s and s:IsValid() then
        local ok, actor = pcall(function() return s.ScenarioActor end)
        if ok and actor and actor:IsValid() then return actor end
        if s:IsA(StaticFindObject("/Game/Shared/Shifts/Gameplay/Blueprints/Scenarios/BP_Scenario_Base.BP_Scenario_Base_C")) then return s end
    end
    local best
    pc.Scenarios:ForEach(function(_, e)
        local sc = e:get()
        if sc:IsValid() and not best then
            local ok, n = pcall(function() return #sc.Heroes end)
            if ok and n > 0 then best = sc end
        end
    end)
    return best
end

local function setStatus(msg)
    State.status = msg
    dbg("status: " .. msg)
end

local function snapshotScenario(sc)
    local ok, snap = pcall(function() return { state = tostring(sc.ScenarioState), heroes = #sc.Heroes, working = sc.WorkingTime } end)
    return ok and snap or nil
end

local function watchScenario(label, sc)
    local before = snapshotScenario(sc)
    if not before then setStatus(label .. ": ?") return end
    setStatus(string.format("%s: state %s, heroes %d", label, before.state, before.heroes))
    for _, delay in ipairs({ 1000, 3000 }) do
        ExecuteInGameThreadWithDelay(delay, function()
            if not sc:IsValid() then setStatus(label .. ": scenario gone") return end
            local after = snapshotScenario(sc)
            if after then
                setStatus(string.format("%s: state %s->%s, heroes %d->%d, work %.0f->%.0f (%.0fs)", label, before.state, after.state, before.heroes, after.heroes, before.working, after.working, delay / 1000))
            end
        end)
    end
end

local OutcomeModes = {
    { key = "outcomeNormal" },
    { key = "outcomeSuccess", outcome = 1, chance = 100 },
    { key = "outcomeFail", outcome = 2, chance = 0 },
    { key = "outcomeMiss", outcome = 3, chance = 0 },
}
D.OutcomeOriginal = {}

local function outcomeMode(sc)
    if not sc.UseSpecificSuccessChance then return 1 end
    if sc.Outcome == 3 then return 4 end
    if sc.SuccessChance >= 100 then return 2 end
    if sc.SuccessChance <= 0 then return 3 end
    return 1
end

local function applyOutcome(sc, mode)
    local key = sc:GetFullName()
    if not D.OutcomeOriginal[key] then
        D.OutcomeOriginal[key] = { chance = sc.SuccessChance, unrounded = sc.SuccessChanceUnrounded, mult = sc.SuccessChanceMultiplier, specific = sc.UseSpecificSuccessChance, skipMiss = sc.SkipMiss, outcome = sc.Outcome }
    end
    local m = OutcomeModes[mode]
    if mode == 1 then
        local o = D.OutcomeOriginal[key]
        sc.UseSpecificSuccessChance = o.specific
        sc.SuccessChance = o.chance
        sc.SuccessChanceUnrounded = o.unrounded
        sc.SuccessChanceMultiplier = o.mult
        sc.SkipMiss = o.skipMiss
        sc.Outcome = o.outcome
    else
        sc.UseSpecificSuccessChance = true
        sc.SuccessChance = m.chance
        sc.SuccessChanceUnrounded = m.chance
        sc.SuccessChanceMultiplier = m.chance > 0 and 100 or 0
        sc.SkipMiss = m.outcome ~= 3
        sc.Outcome = m.outcome
    end
    dbg(string.format("outcome %s -> %s chance=%.0f specific=%s skipMiss=%s outcome=%s", key, m.key, sc.SuccessChance, tostring(sc.UseSpecificSuccessChance), tostring(sc.SkipMiss), tostring(sc.Outcome)))
end

local function cycleOutcome(delta)
    local sc = currentScenario()
    if not sc then return end
    try(function() applyOutcome(sc, (outcomeMode(sc) - 1 + delta) % #OutcomeModes + 1) end)
end

local function scenarioInfo(s)
    if not s then return "none" end
    local ok, n = pcall(function() return #s.Heroes end)
    return s:GetFullName() .. " state=" .. tostring(s.ScenarioState) .. " heroes=" .. tostring(ok and n or "?")
end

local function levelInstance(cls)
    local all = levelInstances(cls)
    for i = #all, 1, -1 do
        local ok, possessed = pcall(function() return all[i].Controller:IsValid() end)
        if ok and possessed then return all[i] end
    end
    return all[#all]
end

local LookupCache = {}
local LookupTick = {}
local function cachedInstance(cls)
    if LookupTick[cls] and CurrentTick - LookupTick[cls] < 33 then
        local c = LookupCache[cls]
        if c == nil then return nil end
        local ok, valid = pcall(function() return c:IsValid() end)
        if ok and valid then return c end
    end
    local o = levelInstance(cls)
    LookupCache[cls] = o
    LookupTick[cls] = CurrentTick
    return o
end

local function hackingUser() return cachedInstance("BP_HkUser_Master_C") end
local function failTimer() return cachedInstance("BP_FailTimer_C") end

D.Subsystems = {}
local function cachedSubsystem(cls)
    local c = D.Subsystems[cls]
    if c ~= nil then
        local ok, v = pcall(function() return c:IsValid() end)
        if ok and v then return c end
    end
    local s = FindFirstOf(cls)
    if not (s and s:IsValid()) then s = nil end
    D.Subsystems[cls] = s
    return s
end
local function storySubsystem() return cachedSubsystem("AdHocStorySubsystem") end

local function forEachTarget(label, fn)
    local n = 0
    for _, t in ipairs(targets()) do
        local ok = try(function()
            dbg(label .. " " .. heroName(t))
            fn(t)
        end)
        if ok then n = n + 1 end
    end
    setStatus(T(label) .. ": " .. n .. " hero(s)")
end

local function freezeItem(labelKey, prop, onValue)
    return {
        label = function() return T(labelKey) end,
        value = function(h)
            local v = getFrozen(h, prop)
            local active = v ~= nil and v == onValue
            return boolText(active), boolColor(active)
        end,
        select = function()
            local h = targets()[1]
            if not h then return end
            local v = getFrozen(h, prop)
            local active = v ~= nil and v == onValue
            dbg(string.format("toggle %s active=%s targets=%d", prop, tostring(active), #targets()))
            if active then
                setFrozen(prop, nil)
                for _, t in ipairs(targets()) do t[prop] = rememberOriginal(t, prop) end
            else
                for _, t in ipairs(targets()) do rememberOriginal(t, prop) end
                setFrozen(prop, onValue)
                for _, t in ipairs(targets()) do t[prop] = onValue end
            end
        end,
        needsHero = true,
    }
end

local function numberItem(labelKey, prop, step, min, max, fmt)
    local function change(delta)
        local h = targets()[1]
        if not h then return end
        local v = math.max(min, math.min(max, h[prop] + delta))
        dbg(string.format("number %s %s -> %s", prop, tostring(h[prop]), tostring(v)))
        for _, t in ipairs(targets()) do rememberOriginal(t, prop); t[prop] = v end
        setFrozen(prop, v)
    end
    return {
        label = function() return T(labelKey) end,
        value = function(h) return "< " .. string.format(fmt, h[prop]) .. " >" end,
        left = function() change(-step) end,
        right = function() change(step) end,
        needsHero = true,
    }
end

local function statItem(key, nameKey)
    local function change(delta)
        for _, t in ipairs(targets()) do
            setStat(t, key, math.max(0, math.min(10, statValue(t, key) + delta)))
        end
    end
    return {
        label = function() return T(nameKey) end,
        value = function(h) return "< " .. string.format("%d", statValue(h, key)) .. " >" end,
        left = function() change(-1) end,
        right = function() change(1) end,
        needsHero = true,
    }
end

local InjuryTypes = { { 1, "injuryLight" }, { 2, "injuryCritical" }, { 3, "injuryIncap" } }

D.StoryVarKinds = {
    { cls = "AdHocStoryNumberVariable", fn = "GetStoryNumberVariable", kind = "number" },
    { cls = "AdHocStoryBooleanVariable", fn = "GetStoryBooleanVariable", kind = "bool" },
    { cls = "AdHocStoryEnumerationVariable", fn = "GetStoryEnumerationVariable", kind = "enum" },
}
D.StoryVars = { tick = -1000, items = {} }

local function storySaveLib() return StaticFindObject("/Script/AdHocStory.Default__AdHocStorySaveFunctions") end
local function saveSubsystem() return cachedSubsystem("AdHocSaveGameSubsystem") end

local function readStoryVar(entry)
    local lib, save = storySaveLib(), saveSubsystem()
    if not lib or not save or not entry.var:IsValid() then return nil end
    local v = lib[entry.fn](lib, save, entry.var)
    if entry.kind == "number" then return string.format("%g", v) end
    if entry.kind == "bool" then return boolText(v), boolColor(v) end
    return tostring(v:ToString())
end

D.StoryVarSavers = { number = "SaveStoryNumberVariable", bool = "SaveStoryBooleanVariable" }

local function writeStoryVar(entry, value)
    local lib, save = storySaveLib(), saveSubsystem()
    local fn = D.StoryVarSavers[entry.kind]
    if not lib or not save or not fn or not entry.var:IsValid() then return false end
    local ok, err = pcall(function() lib[fn](lib, save, entry.var, value) end)
    if ok then log(string.format("story var %s = %s", entry.name, tostring(value))) else log("story var write ERR " .. tostring(err)) end
    entry.valTick = nil
    return ok
end

local function rawStoryVar(entry)
    local lib, save = storySaveLib(), saveSubsystem()
    if not lib or not save or not entry.var:IsValid() then return nil end
    return lib[entry.fn](lib, save, entry.var)
end

local function storyVarItem(entry)
    local item = {
        label = function() return entry.name end,
        value = function()
            if entry.valTick and CurrentTick - entry.valTick < 25 then return entry.val, entry.valColor end
            local ok, v, c = pcall(readStoryVar, entry)
            entry.valTick = CurrentTick
            if not ok or v == nil then entry.val, entry.valColor = "?", Theme.muted else entry.val, entry.valColor = v, c or Theme.text end
            return entry.val, entry.valColor
        end,
    }
    if entry.kind == "bool" then
        item.select = function()
            local ok, v = pcall(rawStoryVar, entry)
            if ok and v ~= nil then writeStoryVar(entry, not v) end
        end
    elseif entry.kind == "number" then
        local function shift(delta)
            local ok, v = pcall(rawStoryVar, entry)
            if ok and v ~= nil then writeStoryVar(entry, v + delta) end
        end
        item.left = function() shift(-1) end
        item.right = function() shift(1) end
    end
    return item
end

local function finishFinalHackingQte()
    for _, w in ipairs(FindAllOf("WBP_FluxQTE_C") or {}) do
        local ok, hit = pcall(function() return w:IsValid() and w:IsVisible() and baseActive(w) and isFinalHackingQte(w) end)
        if ok and hit then
            log("final hacking qte: forcing success on one widget")
            try(function() w.CantFail = true; w:SuccessReached() end)
            return true
        end
    end
    log("final hacking qte: none active")
    return false
end

local function setStoryBoolByName(name, value)
    for _, v in ipairs(FindAllOf("AdHocStoryBooleanVariable") or {}) do
        local ok, n = pcall(function() return v:IsValid() and v:GetFName():ToString() or nil end)
        if ok and n == name then
            return writeStoryVar({ name = name, var = v, kind = "bool" }, value)
        end
    end
    log("story var " .. name .. " not loaded")
    return false
end

local function prettyVarName(name)
    local n = name:gsub("^Var_", ""):gsub("_s_", "'s_"):gsub("_", " ")
    n = n:gsub("(%l)(%u)", "%1 %2"):gsub("(%u)(%u%l)", "%1 %2")
    return n
end

local function storyVarItems()
    if CurrentTick - D.StoryVars.tick < 50 then return D.StoryVars.items end
    D.StoryVars.tick = CurrentTick
    local list = {}
    for _, k in ipairs(D.StoryVarKinds) do
        for _, v in ipairs(FindAllOf(k.cls) or {}) do
            local ok, name = pcall(function() return v:IsValid() and v:GetFName():ToString() or nil end)
            if ok and name and not name:find("^Default__") then
                list[#list + 1] = { name = prettyVarName(name), var = v, fn = k.fn, kind = k.kind }
            end
        end
    end
    table.sort(list, function(a, b) return a.name < b.name end)
    local items = {}
    for i, e in ipairs(list) do items[i] = storyVarItem(e) end
    if #items == 0 then items[1] = { label = function() return T("noVars") end, value = function() return "", Theme.muted end } end
    items[1].section = "secVars"
    D.StoryVars.items = items
    return items
end

local closeMenuRef
local function actionItem(labelKey, fn, valueFn, needsHero)
    return { label = function() return T(labelKey) end, value = valueFn or function() return T("run"), Theme.muted end, select = fn, needsHero = needsHero }
end

local function afterClose(fn)
    return function()
        dbg("closing menu before action")
        closeMenuRef()
        ExecuteInGameThreadWithDelay(250, function() try(fn) end)
    end
end

local function section(key, item) item.section = key; return item end

D.ActiveHackingScenario = nil
D.HackingOutcomeTick = -1000
D.HackHooksDone = false

local function registerHackHooks()
    if D.HackHooksDone then return end
    local ok1 = pcall(function()
        RegisterHook(D.ScenarioHackingPath .. ":PrepareForHacking", function(ctx)
            pcall(function() D.ActiveHackingScenario = ctx:get(); log("hacking scenario " .. nameOf(D.ActiveHackingScenario)) end)
        end, function() end)
    end)
    local ok2 = pcall(function()
        RegisterHook(D.ScenarioBasePath .. ":SetHackingOutcome", function(ctx, ok)
            D.HackingOutcomeTick = CurrentTick
        end, function() end)
    end)
    D.HackHooksDone = ok1 and ok2
    if D.HackHooksDone then log("hacking hooks ok") end
end

local function activeHackingScenarios()
    local out = {}
    if D.ActiveHackingScenario then
        local ok, valid = pcall(function() return D.ActiveHackingScenario:IsValid() end)
        if ok and valid then out[1] = D.ActiveHackingScenario return out end
    end
    for _, sc in ipairs(levelInstances("BP_Scenario_Hacking_C")) do
        local ok, working = pcall(function() return sc.ScenarioState == 3 end)
        if ok and working then out[#out + 1] = sc end
    end
    return out
end

local function finishHacking()
    local user = hackingUser()
    dbg("hackWin user=" .. (user and user:GetFullName() or "none"))
    if not user then return end
    try(function() setStoryBoolByName("Var_Hacking_Success", true) end)
    local level = user:GetFullName():match("([%w_]+):PersistentLevel") or ""
    dbg("  hacking level " .. level)
    local effects = {}
    for _, cls in ipairs({ "BP_HkIE_ReturnToShiftSuccess_C", "BP_HkIE_ReturnToStorySuccess_C", "BP_HkIE_StackSuccess_C" }) do
        for _, o in ipairs(FindAllOf(cls) or {}) do
            local ok, good = pcall(function()
                return o:IsValid() and o:GetFullName():find(level, 1, true) ~= nil
            end)
            if ok and good then effects[#effects + 1] = o end
        end
    end
    log("hackWin level " .. level .. " effects " .. #effects)
    if #effects == 0 then
        local inShift = getGM() ~= nil
        local present = {}
        pcall(function()
            for _, o in ipairs(FindAllOf("BP_HkInteractiveEffect_C") or {}) do
                local ok, n = pcall(function() return o:IsValid() and o:GetFullName():find(level, 1, true) and o:GetClass():GetFName():ToString() or nil end)
                if ok and n then present[n] = (present[n] or 0) + 1 end
            end
        end)
        local names = {}
        for n, c in pairs(present) do names[#names + 1] = n .. "x" .. c end
        log("hackWin: no known success effect, shift=" .. tostring(inShift) .. " effects in level: " .. table.concat(names, " "))
        try(function()
            local t = failTimer()
            if t and t:IsValid() then
                t.BlockedDueSuccess = true
                t.TimerForFail = 999999
            end
        end)
        local waves = 0
        for _, w in ipairs(FindAllOf("WBP_WaveContainer_C") or {}) do
            pcall(function()
                if not w:IsValid() or not w:IsVisible() then return end
                waves = waves + 1
                w.FinalSuccess = true
                w.PART1Complete = true
                try(function() w:SetReturnToStory(not inShift) end)
                try(function() w:ReturnToBecauseOfFullStack(inShift) end)
                log("hackWin: wave container forced " .. nameOf(w))
            end)
        end
        if waves == 0 then
            for _, setup in ipairs(levelInstances("BP_HkIE_WaveMatchingSetup_C")) do
                waves = waves + 1
                try(function() setup:ReturnToStory(); log("hackWin: WaveMatchingSetup.ReturnToStory") end)
            end
        end
        if inShift then
            try(function()
                for _, sc in ipairs(activeHackingScenarios()) do
                    try(function() applyOutcome(sc, 2); log("hackWin: outcome forced on " .. nameOf(sc)) end)
                end
            end)
        end
        local startTick = CurrentTick
        ExecuteInGameThreadWithDelay(waves > 0 and 4000 or 500, function()
            if not hackingUser() then log("hackWin: already left hacking") return end
            if D.HackingOutcomeTick >= startTick then log("hackWin: game already set the outcome") return end
            if inShift then
                try(function() if user:IsValid() then user:ReturnToShift(true); log("hackWin: ReturnToShift(true)") end end)
            else
                try(function() if user:IsValid() then user:ReturnToStory(); log("hackWin: HkUser.ReturnToStory") end end)
                ExecuteInGameThreadWithDelay(1500, function()
                    if not hackingUser() then return end
                    local ss = storySubsystem()
                    try(function() log("hackWin: ReturnToStoryFromGameplay=" .. tostring(ss:ReturnToStoryFromGameplay())) end)
                end)
            end
        end)
        return
    end
    try(function()
        for _, sc in ipairs(activeHackingScenarios()) do
            try(function() applyOutcome(sc, 2); log("hackWin: outcome forced on " .. nameOf(sc)) end)
        end
    end)
    local toShift = false
    for _, o in ipairs(effects) do
        if o:GetClass():GetFName():ToString():find("Shift") then toShift = true end
        local inter = o:GetOuter()
        dbg("  interactive " .. (inter:IsValid() and inter:GetFullName() or "invalid"))
        try(function() inter:ForceStackFinalNode(); dbg("    ForceStackFinalNode ok") end)
        try(function() inter:FinishInteraction(); dbg("    FinishInteraction ok") end)
        try(function() inter:FinishEffectsAndMessage(); dbg("    FinishEffectsAndMessage ok") end)
    end
    log("hackWin: effects finished, toShift=" .. tostring(toShift))
    ExecuteInGameThreadWithDelay(1000, function() try(finishFinalHackingQte) end)
    local startTick = CurrentTick
    ExecuteInGameThreadWithDelay(6000, function()
        if not hackingUser() then log("hackWin: already left hacking") return end
        if D.HackingOutcomeTick >= startTick then log("hackWin: game already set the outcome, no forced return") return end
        if toShift then
            try(function() if user:IsValid() then user:ReturnToShift(true); log("hackWin: ReturnToShift(true)") end end)
        else
            local ss = storySubsystem()
            try(function() log("hackWin: ReturnToStoryFromGameplay=" .. tostring(ss:ReturnToStoryFromGameplay())) end)
        end
    end)
end

local HeroSelector = {
    label = function() return T("hero") end,
    value = function(h)
        if State.heroIndex == 0 then return "< " .. T("all") .. " >", Theme.accent end
        return "< " .. heroName(h) .. " >", Theme.accent
    end,
    left = function() State.heroIndex = (State.heroIndex - 1) % (#getHeroes() + 1) end,
    right = function() State.heroIndex = (State.heroIndex + 1) % (#getHeroes() + 1) end,
    needsHero = true,
}

local Tabs = {
    {
        key = "tabHeroes",
        items = {
            HeroSelector,
            section("secRest", freezeItem("motivated", "Motivated", true)),
            freezeItem("instantRest", "MaxRestTime", 0.0),
            freezeItem("noRest", "ForceStopResting", true),
            actionItem("finishRest", function()
                forEachTarget("finishRest", function(t) dbg("  rest=" .. t.RestTime .. "/" .. t.MaxRestTime); t.RestTime = t.MaxRestTime; t:FinishResting() end)
            end, nil, true),
            section("secXp", freezeItem("earnXp", "EnabledEarnXP", true)),
            freezeItem("levelUp", "EnabledLevelUp", true),
            numberItem("xpMult", "ScenarioXPRewardsMultiplier", 0.5, 0, 100, "x%.1f"),
            numberItem("maxLevel", "MaxLevel", 1, 1, 99, "%d"),
            {
                label = function() return T("giveXp") end,
                value = function() return "< " .. XpAmounts[State.xpAmount] .. " >" end,
                left = function() State.xpAmount = (State.xpAmount - 2) % #XpAmounts + 1 try(saveSettings) end,
                right = function() State.xpAmount = State.xpAmount % #XpAmounts + 1 try(saveSettings) end,
                select = function()
                    forEachTarget("giveXp", function(t)
                        dbg("  before=" .. tostring(readOut(t, "GetTotalXp")))
                        t:GiveXp(XpAmounts[State.xpAmount])
                        dbg("  after=" .. tostring(readOut(t, "GetTotalXp")))
                    end)
                end,
                needsHero = true,
            },
            actionItem("levelNow", function()
                forEachTarget("levelNow", function(t)
                    local need = (readOut(t, "GetTotalXpRequired") or 0) - (readOut(t, "GetTotalXp") or 0)
                    dbg("  need=" .. need)
                    t:GiveXp(math.max(need, 1))
                end)
            end, function(h)
                local ok, s = pcall(function() return string.format("%d/%d", readOut(h, "GetTotalXp") or 0, readOut(h, "GetTotalXpRequired") or 0) end)
                return ok and s or ""
            end, true),
            actionItem("statPoints", function()
                forEachTarget("statPoints", function(t)
                    local cur = readOut(t, "PHD_GetStatPoints") or 0
                    t:PHD_SetStatPoints(cur + 1)
                    dbg("  " .. cur .. " -> " .. tostring(readOut(t, "PHD_GetStatPoints")))
                end)
            end, function(h)
                local ok, s = pcall(function() return tostring(readOut(h, "PHD_GetStatPoints") or 0) end)
                return ok and s or ""
            end, true),
            section("secBehavior", freezeItem("sabotage", "EnableSabotage", false)),
            freezeItem("willRefuse", "WillRefuse", false),
            freezeItem("rallied", "Rallied", true),
            section("secRecovery", actionItem("clearStatus", function()
                forEachTarget("clearStatus", function(t)
                    dbg(string.format("  scared=%s debuffed=%s spaced=%s sabotaged=%s injured=%s", tostring(t.Scared), tostring(t.Debuffed), tostring(t.SpacedOut), tostring(t.Sabotaged), tostring(t.SabotagedInjured)))
                    t.Scared = false
                    t.Debuffed = false
                    if t.SpacedOut then try(function() t:EndSpacedOut() end) end
                    if t.Sabotaged or t.SabotagedInjured then try(function() t:ResetSabotage() end) end
                    try(function() t:ClearBlazerBarrier() end)
                end)
            end, nil, true)),
            actionItem("heal", function()
                forEachTarget("heal", function(t)
                    local ic = t.InjuryComponent
                    dbg("  injuryComponent=" .. tostring(ic and ic:IsValid()))
                    if ic and ic:IsValid() then ic:ClearInjuries() end
                end)
            end, nil, true),
            {
                label = function() return T("inflictInjury") end,
                value = function() return "< " .. T(InjuryTypes[State.injuryType][2]) .. " >", Theme.bad end,
                left = function() State.injuryType = (State.injuryType - 2) % #InjuryTypes + 1 end,
                right = function() State.injuryType = State.injuryType % #InjuryTypes + 1 end,
                select = function()
                    local kind = InjuryTypes[State.injuryType][1]
                    forEachTarget("inflictInjury", function(t)
                        local ok, err = pcall(function() t:ApplyInjury(kind) end)
                        dbg("  ApplyInjury(" .. kind .. ") ok=" .. tostring(ok) .. " " .. tostring(err))
                        if not ok then t.InjuryComponent:AddInjuryByType(kind) end
                    end)
                end,
                needsHero = true,
            },
        },
    },
    {
        key = "tabStats",
        items = {
            HeroSelector,
            statItem(5, "combat"), statItem(2, "mobility"), statItem(1, "vigor"), statItem(3, "charisma"), statItem(4, "intellect"),
            section("secPresets", actionItem("allMax", function()
                forEachTarget("allMax", function(t) for _, s in ipairs(StatKeys) do setStat(t, s[1], 10) end end)
            end, nil, true)),
            actionItem("allBase", function()
                forEachTarget("allBase", function(t) for _, s in ipairs(StatKeys) do setStat(t, s[1], 1) end end)
            end, nil, true),
        },
    },
    {
        key = "tabShift",
        items = {
            {
                label = function() return T("speed") end,
                value = function() return "< x" .. Speeds[State.speed] .. " >", Theme.accent end,
                left = function()
                    if InHacking then return end
                    State.speed = (State.speed - 2) % #Speeds + 1
                    dbg("speed x" .. Speeds[State.speed])
                    try(function() gameplayStatics():SetGlobalTimeDilation(anyPC(), Speeds[State.speed]) end)
                end,
                right = function()
                    if InHacking then return end
                    State.speed = State.speed % #Speeds + 1
                    dbg("speed x" .. Speeds[State.speed])
                    try(function() gameplayStatics():SetGlobalTimeDilation(anyPC(), Speeds[State.speed]) end)
                end,
            },
            section("secCall", {
                label = function() return T("callOutcome") end,
                value = function()
                    local sc = currentScenario()
                    if not sc then return T("noScenario"), Theme.muted end
                    local mode = outcomeMode(sc)
                    local color = mode == 1 and Theme.text or (mode == 2 and Theme.on or Theme.bad)
                    return "< " .. T(OutcomeModes[mode].key) .. " >", color
                end,
                left = function() cycleOutcome(-1) end,
                right = function() cycleOutcome(1) end,
                select = function() cycleOutcome(1) end,
            }),
            actionItem("abortCall", afterClose(function()
                local s = currentScenario()
                dbg("abort scenario=" .. scenarioInfo(s))
                if s then try(function() s:Abort() end); watchScenario("abort", s) else setStatus("abort: " .. T("noScenario")) end
            end), function() return currentScenario() and T("run") or T("noScenario"), Theme.muted end),
            {
                label = function() return T("revealStats") end,
                value = function() return boolText(State.revealStats), boolColor(State.revealStats) end,
                select = function()
                    State.revealStats = not State.revealStats
                    dbg("revealStats " .. tostring(State.revealStats))
                    if State.revealStats then try(revealCallStats) else try(unrevealScenarios) end
                    try(saveSettings)
                end,
            },
            section("secShift", {
                label = function() return T("autoSabotage") end,
                value = function()
                    local gm = getGM()
                    if not gm then return T("noGM"), Theme.muted end
                    return boolText(gm.CanAutoSabotage), boolColor(gm.CanAutoSabotage)
                end,
                select = function()
                    local gm = getGM()
                    if not gm then return end
                    try(function()
                        dbg("autoSabotage " .. tostring(gm.CanAutoSabotage) .. " -> " .. tostring(not gm.CanAutoSabotage))
                        gm:SetCanAutoSabotage(not gm.CanAutoSabotage)
                    end)
                end,
            }),
            actionItem("endShift", afterClose(function()
                local gm = getGM()
                dbg("endShift gm=" .. tostring(gm ~= nil))
                if gm then try(function() gm:EndShift() end) end
            end), function() return getGM() and T("run") or T("noGM"), Theme.muted end),
            actionItem("forceEnd", afterClose(function()
                local gm = getGM()
                dbg("forceEnd gm=" .. tostring(gm ~= nil))
                if gm then try(function() gm:ForceEnd() end) end
            end), function() return getGM() and T("run") or T("noGM"), Theme.muted end),
        },
    },
    {
        key = "tabHacking",
        items = {
            actionItem("hackLife", function()
                local gm = getGM()
                dbg("hackLife gm=" .. tostring(gm ~= nil))
                if gm then try(function() gm:AddHackingLife() end) end
            end, function() return getGM() and T("run") or T("noGM"), Theme.muted end),
            {
                label = function() return T("hackTimer") end,
                value = function()
                    local t = failTimer()
                    if not t then return T("hackNone"), Theme.muted end
                    return boolText(t.BlockedDueSuccess), boolColor(t.BlockedDueSuccess)
                end,
                select = function()
                    local t = failTimer()
                    if not t then return end
                    try(function()
                        local on = not t.BlockedDueSuccess
                        dbg(string.format("hackTimer %s blocked %s -> %s timerForFail=%s", t:GetFullName(), tostring(t.BlockedDueSuccess), tostring(on), tostring(t.TimerForFail)))
                        if on then State.timerOriginal = t.TimerForFail end
                        t.BlockedDueSuccess = on
                        t.TimerForFail = on and 999999 or (State.timerOriginal or t.TimerForFail)
                    end)
                end,
            },
            actionItem("hackWin", afterClose(finishHacking), function() return hackingUser() and T("run") or T("hackNone"), Theme.muted end),

        },
    },
    {
        key = "tabStory",
        items = {
            {
                label = function() return T("storyRunning") end,
                value = function()
                    local s = storySubsystem()
                    if not s then return T("none"), Theme.muted end
                    local ok, r = pcall(function() return s:IsRunningStoryGraph() end)
                    return boolText(ok and r), boolColor(ok and r)
                end,
            },
            {
                label = function() return T("autoQte") end,
                value = function() return boolText(State.autoQte), boolColor(State.autoQte) end,
                select = function()
                    State.autoQte = not State.autoQte
                    dbg("autoQte " .. tostring(State.autoQte))
                    try(applyFluxDefaults)
                    try(saveSettings)
                end,
            },
            actionItem("skipNode", afterClose(function()
                local s = storySubsystem()
                dbg("skipNode subsystem=" .. tostring(s ~= nil))
                if s then
                    try(function() dbg("  node=" .. tostring(s:GetCurrentNode():GetFullName())) end)
                    s:DebugSkip()
                end
            end)),
            actionItem("skipChoice", afterClose(function()
                local s = storySubsystem()
                dbg("skipChoice subsystem=" .. tostring(s ~= nil))
                if s then s:SkipToChoiceInCurrentSequence() end
            end)),
        },
        dynamic = storyVarItems,
    },
}

local Widget, Ui
local UiStale = false
local FocusTries = 0

local LastText = setmetatable({}, { __mode = "k" })
local LastColor = setmetatable({}, { __mode = "k" })
local LastBrush = setmetatable({}, { __mode = "k" })

local function setText(tb, text)
    if not tb or LastText[tb] == text then return end
    if not tb:IsValid() then return end
    LastText[tb] = text
    Perf.textSets = Perf.textSets + 1
    pcall(function() tb:SetText(FText(text)) end)
end
local function setColor(tb, c)
    if not tb or LastColor[tb] == c then return end
    LastColor[tb] = c
    Perf.colorSets = Perf.colorSets + 1
    try(function() tb:SetColorAndOpacity({ SpecifiedColor = c, ColorUseRule = 0 }) end)
end
local function setBrush(b, c)
    if not b or LastBrush[b] == c then return end
    LastBrush[b] = c
    try(function() b:SetBrushColor(c) end)
end

local function makeText(tree, text, size, color, font)
    local tb = StaticConstructObject(StaticFindObject("/Script/UMG.TextBlock"), tree)
    setText(tb, text)
    try(function() tb.Font.Size = size end)
    if font then try(function() tb.Font.FontObject = font end) end
    setColor(tb, color)
    return tb
end

local function makeBorder(tree, color, padding)
    local b = StaticConstructObject(StaticFindObject("/Script/UMG.Border"), tree)
    setBrush(b, color)
    try(function() b:SetPadding(padding) end)
    return b
end

local function makeSpacer(tree)
    return StaticConstructObject(StaticFindObject("/Script/UMG.Spacer"), tree)
end

local function buildUi(pc)
    local cls = StaticFindObject("/Script/CommonUI.CommonActivatableWidget")
    if not cls or not cls:IsValid() then cls = StaticFindObject("/Script/UMG.UserWidget") end
    local w = widgetLib():Create(pc, cls, pc)
    dbg("createWidget class=" .. cls:GetFName():ToString() .. " widget=" .. tostring(w:IsValid()) .. " pc=" .. pc:GetClass():GetFName():ToString())
    if not w:IsValid() then return false end
    try(function() w.bIsFocusable = true end)
    try(function()
        w.bAutoActivate = false
        w.bIsBackHandler = false
        w.bIsModal = true
        w.bSupportsActivationFocus = true
        w.bAutoRestoreFocus = true
    end)
    for dir = 0, 5 do try(function() w:SetNavigationRuleBase(dir, 3) end) end
    local tree = StaticConstructObject(StaticFindObject("/Script/UMG.WidgetTree"), w)
    w.WidgetTree = tree

    local font = StaticFindObject("/Game/Shared/Shifts/Art/Fonts/Roboto_Regular/Roboto-Medium_Font.Roboto-Medium_Font")
    if font and font:IsValid() then dbg("font ok " .. font:GetFullName()) else font = nil; dbg("font not found") end

    local canvas = StaticConstructObject(StaticFindObject("/Script/UMG.CanvasPanel"), tree)
    local frame = makeBorder(tree, Theme.frame, { Left = 1, Top = 1, Right = 1, Bottom = 1 })
    local panel = makeBorder(tree, Theme.panel, { Left = 0, Top = 0, Right = 0, Bottom = 0 })
    frame:SetContent(panel)
    local vbox = StaticConstructObject(StaticFindObject("/Script/UMG.VerticalBox"), tree)
    panel:SetContent(vbox)

    local header = StaticConstructObject(StaticFindObject("/Script/UMG.HorizontalBox"), tree)
    local title = makeText(tree, T("title"), 17, Theme.accent, font)
    header:AddChildToHorizontalBox(title)
    local headerSpacer = header:AddChildToHorizontalBox(makeSpacer(tree))
    try(function() headerSpacer:SetSize({ SizeRule = 1, Value = 1 }) end)
    local version = makeText(tree, "v" .. VERSION, 11, Theme.muted, font)
    local versionSlot = header:AddChildToHorizontalBox(version)
    try(function() versionSlot:SetVerticalAlignment(3) end)
    local headerSlot = vbox:AddChildToVerticalBox(header)
    try(function() headerSlot:SetPadding({ Left = 18, Top = 12, Right = 18, Bottom = 10 }) end)
    local headerLine = makeBorder(tree, Theme.frame, { Left = 0, Top = 0, Right = 0, Bottom = 0 })
    local headerLineBox = StaticConstructObject(StaticFindObject("/Script/UMG.SizeBox"), tree)
    try(function() headerLineBox:SetHeightOverride(1) end)
    headerLineBox:SetContent(headerLine)
    vbox:AddChildToVerticalBox(headerLineBox)

    local tabsBand = makeBorder(tree, Theme.band, { Left = 18, Top = 0, Right = 18, Bottom = 0 })
    local tabsRow = StaticConstructObject(StaticFindObject("/Script/UMG.HorizontalBox"), tree)
    tabsBand:SetContent(tabsRow)
    local tabs = {}
    for i, tab in ipairs(Tabs) do
        local col = StaticConstructObject(StaticFindObject("/Script/UMG.VerticalBox"), tree)
        local tt = makeText(tree, T(tab.key), 13, Theme.muted, font)
        local ttSlot = col:AddChildToVerticalBox(tt)
        try(function() ttSlot:SetPadding({ Left = 12, Top = 9, Right = 12, Bottom = 7 }) end)
        local lineBox = StaticConstructObject(StaticFindObject("/Script/UMG.SizeBox"), tree)
        try(function() lineBox:SetHeightOverride(2) end)
        local line = makeBorder(tree, Theme.rowNone, { Left = 0, Top = 0, Right = 0, Bottom = 0 })
        lineBox:SetContent(line)
        col:AddChildToVerticalBox(lineBox)
        tabsRow:AddChildToHorizontalBox(col)
        tabs[i] = { line = line, text = tt }
    end
    vbox:AddChildToVerticalBox(tabsBand)
    local tabsLine = makeBorder(tree, Theme.frame, { Left = 0, Top = 0, Right = 0, Bottom = 0 })
    local tabsLineBox = StaticConstructObject(StaticFindObject("/Script/UMG.SizeBox"), tree)
    try(function() tabsLineBox:SetHeightOverride(1) end)
    tabsLineBox:SetContent(tabsLine)
    vbox:AddChildToVerticalBox(tabsLineBox)

    local rowsBox = StaticConstructObject(StaticFindObject("/Script/UMG.VerticalBox"), tree)
    local rowsSlot = vbox:AddChildToVerticalBox(rowsBox)
    try(function() rowsSlot:SetPadding({ Left = 12, Top = 8, Right = 12, Bottom = 10 }) end)

    local footerLine = makeBorder(tree, Theme.frame, { Left = 0, Top = 0, Right = 0, Bottom = 0 })
    local footerLineBox = StaticConstructObject(StaticFindObject("/Script/UMG.SizeBox"), tree)
    try(function() footerLineBox:SetHeightOverride(1) end)
    footerLineBox:SetContent(footerLine)
    vbox:AddChildToVerticalBox(footerLineBox)

    local footer = makeBorder(tree, Theme.band, { Left = 18, Top = 7, Right = 18, Bottom = 9 })
    local footerBox = StaticConstructObject(StaticFindObject("/Script/UMG.VerticalBox"), tree)
    footer:SetContent(footerBox)
    local status = makeText(tree, "", 13, Theme.accent, font)
    local statusSlot = footerBox:AddChildToVerticalBox(status)
    try(function() statusSlot:SetPadding({ Left = 0, Top = 0, Right = 0, Bottom = 4 }) end)
    local help = makeText(tree, (T("help"):gsub("F2", HotkeyName)), 12, Theme.muted, font)
    footerBox:AddChildToVerticalBox(help)
    vbox:AddChildToVerticalBox(footer)

    local slot = canvas:AddChildToCanvas(frame)
    try(function() slot:SetAutoSize(true) end)
    try(function() slot:SetPosition({ X = 48, Y = 48 }) end)
    tree.RootWidget = canvas

    Ui = { tree = tree, font = font, tabs = tabs, rowsBox = rowsBox, rows = {}, rowsShown = -1, help = help, status = status, pcName = pc:GetFullName() }
    Widget = w
    Perf.uiBuilds = Perf.uiBuilds + 1
    dbg("widget built " .. w:GetFullName())
    return true
end

local function buildRows(count)
    for i = #Ui.rows + 1, count do
        local col = StaticConstructObject(StaticFindObject("/Script/UMG.VerticalBox"), Ui.tree)
        local section = makeText(Ui.tree, "", 11, Theme.muted, Ui.font)
        local sectionSlot = col:AddChildToVerticalBox(section)
        try(function() sectionSlot:SetPadding({ Left = 8, Top = 10, Right = 8, Bottom = 3 }) end)
        try(function() section:SetVisibility(1) end)
        local rowBorder = makeBorder(Ui.tree, Theme.rowNone, { Left = 8, Top = 3, Right = 8, Bottom = 3 })
        local hbox = StaticConstructObject(StaticFindObject("/Script/UMG.HorizontalBox"), Ui.tree)
        local labelBox = StaticConstructObject(StaticFindObject("/Script/UMG.SizeBox"), Ui.tree)
        try(function() labelBox:SetWidthOverride(330) end)
        local label = makeText(Ui.tree, "", 16, Theme.text, Ui.font)
        labelBox:SetContent(label)
        local valueBox = StaticConstructObject(StaticFindObject("/Script/UMG.SizeBox"), Ui.tree)
        try(function() valueBox:SetWidthOverride(190) end)
        local value = makeText(Ui.tree, "", 16, Theme.text, Ui.font)
        try(function() value:SetJustification(2) end)
        valueBox:SetContent(value)
        hbox:AddChildToHorizontalBox(labelBox)
        hbox:AddChildToHorizontalBox(valueBox)
        rowBorder:SetContent(hbox)
        col:AddChildToVerticalBox(rowBorder)
        local rslot = Ui.rowsBox:AddChildToVerticalBox(col)
        try(function() rslot:SetPadding({ Left = 0, Top = 1, Right = 0, Bottom = 1 }) end)
        Ui.rows[i] = { col = col, border = rowBorder, label = label, value = value, section = section, sectionShown = false, shown = true }
        Perf.rowsMade = Perf.rowsMade + 1
    end
    for i = 1, #Ui.rows do
        local vis = i <= count
        local row = Ui.rows[i]
        if row.shown ~= vis then
            row.shown = vis
            try(function() row.col:SetVisibility(vis and 0 or 1) end)
            if not vis then
                setText(row.label, "")
                setText(row.value, "")
                setBrush(row.border, Theme.rowNone)
            end
        end
    end
end

local function setSection(row, key)
    local show = key ~= nil
    if row.sectionShown ~= show then
        row.sectionShown = show
        try(function() row.section:SetVisibility(show and 0 or 1) end)
    end
    setText(row.section, show and T(key) or "")
end

local function visibleItems()
    local tab = Tabs[State.tab]
    local hasHeroes = #getHeroes() > 0
    local out = {}
    for _, item in ipairs(tab.items) do
        if not item.needsHero or hasHeroes then out[#out + 1] = item end
    end
    if tab.dynamic then
        local ok, extra = pcall(tab.dynamic)
        if ok then for _, item in ipairs(extra) do out[#out + 1] = item end end
    end
    return out
end

local function render()
    if not Widget or not Widget:IsValid() or not Ui then return end
    Perf.renders = Perf.renders + 1
    if State.heroIndex > #getHeroes() then State.heroIndex = 0 end
    for i, tab in ipairs(Ui.tabs) do
        local active = i == State.tab
        setBrush(tab.line, active and Theme.accent or Theme.rowNone)
        setColor(tab.text, active and Theme.text or Theme.muted)
    end
    setText(Ui.status, State.status or "")
    local items = visibleItems()
    local h = targets()[1]
    if #items == 0 then items = { { label = function() return T("noHeroes") end, value = function() return "", Theme.muted end } } end
    if State.cursor > #items then State.cursor = #items end
    local first = State.scrolls[State.tab] or 1
    if State.cursor < first then first = State.cursor end
    if State.cursor > first + MaxRows - 1 then first = State.cursor - MaxRows + 1 end
    first = math.max(1, math.min(first, #items - MaxRows + 1))
    State.scrolls[State.tab] = first
    local last = math.min(#items, first + MaxRows - 1)
    local shown = last - first + 1
    if Ui.rowsShown ~= shown then
        buildRows(shown)
        Ui.rowsShown = shown
    end
    for i = first, last do
        local item = items[i]
        local row = Ui.rows[i - first + 1]
        local selected = i == State.cursor
        setSection(row, item.section)
        setBrush(row.border, selected and Theme.rowSel or Theme.rowNone)
        setText(row.label, (selected and "> " or "   ") .. item.label())
        setColor(row.label, selected and Theme.accent or Theme.text)
        local ok, v, c = pcall(item.value, h)
        if not ok then v, c = "?", Theme.bad end
        setText(row.value, tostring(v or ""))
        setColor(row.value, c or Theme.text)
    end
end

local function setGameInput(enabled)
    for _, pc in ipairs(FindAllOf("PlayerController") or {}) do
        if pc:IsValid() then
            try(function()
                if enabled then pc:EnableInput(pc) else pc:DisableInput(pc) end
                local pawn = pc.Pawn
                if pawn and pawn:IsValid() then
                    if enabled then pawn:EnableInput(pc) else pawn:DisableInput(pc) end
                end
                dbg("gameInput " .. tostring(enabled) .. " on " .. pc:GetClass():GetFName():ToString())
            end)
        end
    end
end

local function openMenu()
    local pc = anyPC()
    dbg("openMenu pc=" .. (pc and pc:GetFullName() or "none"))
    if not pc then return end
    try(function() Lang = StaticFindObject("/Script/Engine.Default__KismetInternationalizationLibrary"):GetCurrentLanguage():ToString() end)
    dbg("language " .. Lang)
    if not Strings[Lang] then Lang = "en" end
    local reusable = REUSE_WIDGET and not UiStale and Widget and Ui and Ui.pcName == pc:GetFullName()
    if reusable then
        local ok, valid = pcall(function() return Widget:IsValid() and Ui.tree:IsValid() end)
        reusable = ok and valid == true
    end
    if not reusable then
        Widget, Ui = nil, nil
        local ok, built = try(buildUi, pc)
        if not ok or not built then log("could not build menu widget"); Widget, Ui = nil, nil; return end
        UiStale = false
    else
        dbg("reusing widget")
    end
    FocusTries = 0
    Widget:AddToViewport(1000)
    try(function() Widget:ActivateWidget(); dbg("activated=" .. tostring(Widget:IsActivated())) end)
    try(function() Widget:SetFocus() end)
    try(function() dbg("focus=" .. tostring(Widget:HasKeyboardFocus())) end)
    setGameInput(false)
    try(function()
        local ps = FindFirstOf("DispatchPauseSubsystem")
        State.pausedByMenu = not ps:GetPausedForReason(PauseReason)
        if State.pausedByMenu then ps:SetPausedForReason(true, PauseReason) end
        dbg("paused by menu=" .. tostring(State.pausedByMenu))
    end)
    State.open = true
    dbg("menu open, heroes=" .. #getHeroes())
    render()
end

local function closeMenu()
    dbg("closeMenu")
    State.open = false
    setGameInput(true)
    if State.pausedByMenu then
        try(function()
            local ps = FindFirstOf("DispatchPauseSubsystem")
            ps:SetPausedForReason(false, PauseReason)
            dbg("unpaused, stillPaused=" .. tostring(ps:GetPausedForReason(PauseReason)))
        end)
        State.pausedByMenu = false
    end
    if Widget and Widget:IsValid() then
        try(function() Widget:DeactivateWidget() end)
        try(function() Widget:RemoveFromParent() end)
    else
        Widget, Ui = nil, nil
    end
    local pc = anyPC()
    if pc and pc:GetClass():GetFName():ToString():find("DispatchPlayerControllerBase") then
        try(function() widgetLib():SetInputMode_GameOnly(pc); dbg("input mode GameOnly restored for hacking") end)
    end
end

closeMenuRef = closeMenu

local function toggleMenu()
    if State.open then closeMenu() else openMenu() end
end

local function switchTab(delta)
    invalidateCache()
    State.cursors[State.tab] = State.cursor
    State.tab = (State.tab - 1 + delta) % #Tabs + 1
    State.cursor = State.cursors[State.tab] or 1
    dbg("tab " .. Tabs[State.tab].key)
    render()
end

local function nav(dir)
    if not State.open then return end
    invalidateCache()
    local items = visibleItems()
    if #items == 0 then return end
    local item = items[State.cursor] or items[1]
    dbg(string.format("nav %s tab=%d cursor=%d item=%s", dir, State.tab, State.cursor, item.label()))
    if dir == "up" then State.cursor = (State.cursor - 2) % #items + 1
    elseif dir == "down" then State.cursor = State.cursor % #items + 1
    elseif dir == "left" and item.left then try(item.left)
    elseif dir == "right" and item.right then try(item.right)
    elseif dir == "select" then
        if item.select then try(item.select) elseif item.right then try(item.right) end
    end
    render()
end

local PadMap = {
    Gamepad_DPad_Up = "up", Gamepad_DPad_Down = "down", Gamepad_DPad_Left = "left", Gamepad_DPad_Right = "right",
    Gamepad_RightStick_Up = "up", Gamepad_RightStick_Down = "down", Gamepad_RightStick_Left = "left", Gamepad_RightStick_Right = "right",
    Gamepad_FaceButton_Bottom = "select", Gamepad_FaceButton_Left = "select", Gamepad_FaceButton_Right = "close",
    Gamepad_LeftTrigger = "tabPrev", Gamepad_RightTrigger = "tabNext",
}
local PadHold = {}
local KeyArgs = {}
local ComboLatched = false
local ShoulderHold = { lb = 0, rb = 0 }
local Tick = 0

local PcScan = { tick = -99, pcs = {}, inGameplay = false, hacking = false }

local function scanPCs()
    local fresh, stale = {}, {}
    local inGameplay, hacking = false, false
    for _, pc in ipairs(FindAllOf("PlayerController") or {}) do
        if pc:IsValid() then
            local ok, n = pcall(function() return pc:GetClass():GetFName():ToString() end)
            if not ok then n = "" end
            if n:find("^PC_Shift") or n:find("^PC_Story") or n:find("DispatchPlayerController") then inGameplay = true end
            local live = hasLocalPlayer(pc)
            if live and n:find("DispatchPlayerController") then hacking = true end
            if live then fresh[#fresh + 1] = pc else stale[#stale + 1] = pc end
        end
    end
    if #fresh == 0 then fresh = stale end
    PcScan.pcs, PcScan.inGameplay, PcScan.hacking, PcScan.tick = fresh, inGameplay, hacking, Tick
    Perf.pcScans = Perf.pcScans + 1
    Perf.pcs = #fresh
    return fresh
end

local function livePCs()
    if Tick - PcScan.tick < 16 then
        local ok = #PcScan.pcs > 0
        if ok then
            for _, pc in ipairs(PcScan.pcs) do
                if not pc:IsValid() then ok = false break end
            end
        end
        if ok then return PcScan.pcs end
    end
    return scanPCs()
end

local function inGame(fn)
    return function()
        ExecuteInGameThread(function()
            livePCs()
            if State.open or PcScan.inGameplay then fn() end
        end)
    end
end

try(loadSettings)
try(saveSettings)
try(registerTraceHooks)
local function hotkey()
    local k = Key[HotkeyName]
    if k == nil then
        log("settings: unknown hotkey " .. HotkeyName .. ", using F2")
        HotkeyName = "F2"
        k = Key.F2
    end
    return k
end

RegisterKeyBind(hotkey(), {}, inGame(toggleMenu))
if STORY_TRACE then RegisterKeyBind(Key.F7, {}, function() ExecuteInGameThread(function() if getGM() then try(dumpShiftScenarios) else try(dumpStoryGraph) end end) end) end
RegisterKeyBind(Key.ESCAPE, {}, inGame(function() if State.open then closeMenu() end end))
RegisterKeyBind(Key.UP_ARROW, {}, inGame(function() nav("up") end))
RegisterKeyBind(Key.DOWN_ARROW, {}, inGame(function() nav("down") end))
RegisterKeyBind(Key.LEFT_ARROW, {}, inGame(function() nav("left") end))
RegisterKeyBind(Key.RIGHT_ARROW, {}, inGame(function() nav("right") end))
RegisterKeyBind(Key.RETURN, {}, inGame(function() nav("select") end))
RegisterKeyBind(Key.Q, {}, inGame(function() if State.open then switchTab(-1) end end))
RegisterKeyBind(Key.E, {}, inGame(function() if State.open then switchTab(1) end end))

local function pollGamepad()
    local pcs = livePCs()
    InHacking = PcScan.hacking
    if #pcs == 0 or not PcScan.inGameplay then
        PadHold = {}
        ShoulderHold.lb, ShoulderHold.rb = 0, 0
        ComboLatched = false
        return
    end
    if #pcs ~= State.pcCount then
        State.pcCount = #pcs
        local names = {}
        for i, pc in ipairs(pcs) do names[i] = pc:GetClass():GetFName():ToString() end
        dbg("player controllers: " .. table.concat(names, ", "))
    end
    local function down(name)
        local key = KeyArgs[name]
        if not key then key = { KeyName = FName(name) }; KeyArgs[name] = key end
        for _, pc in ipairs(pcs) do
            local ok, v = pcall(function() return pc:IsInputKeyDown(key) end)
            if ok and v then return true end
        end
        return false
    end
    local lb, rb = down("Gamepad_LeftShoulder"), down("Gamepad_RightShoulder")
    if lb and rb then
        if not ComboLatched then ComboLatched = true; dbg("gamepad LB+RB"); toggleMenu() end
    end
    if State.open and not ComboLatched then
        if not lb and ShoulderHold.lb > 0 then dbg("gamepad LB release"); switchTab(-1) end
        if not rb and ShoulderHold.rb > 0 then dbg("gamepad RB release"); switchTab(1) end
    end
    ShoulderHold.lb = lb and ShoulderHold.lb + 1 or 0
    ShoulderHold.rb = rb and ShoulderHold.rb + 1 or 0
    if not lb and not rb then ComboLatched = false end
    if not State.open then
        PadHold = {}
        return
    end
    if Widget and Widget:IsValid() and FocusTries < 3 then
        local ok, has = pcall(function() return Widget:HasKeyboardFocus() end)
        if ok and not has then
            FocusTries = FocusTries + 1
            try(function() Widget:SetFocus() end)
        end
    end
    for name, action in pairs(PadMap) do
        local d = down(name)
        if d then PadHold[name] = (PadHold[name] or 0) + 1 else PadHold[name] = 0 end
        local held = PadHold[name]
        local repeatable = action == "up" or action == "down" or action == "left" or action == "right"
        local fire = held == 1 or (held > 7 and held % 3 == 0 and repeatable)
        if held == 1 then dbg("gamepad " .. name .. " open=" .. tostring(State.open)) end
        if fire and not ComboLatched then
            if action == "close" then closeMenu()
            elseif action == "tabPrev" then switchTab(-1)
            elseif action == "tabNext" then switchTab(1)
            else nav(action) end
        end
    end
end

pcall(function()
    RegisterLoadMapPostHook(function()
        D.LastMapLoad = CurrentTick
        UiStale = true
        invalidateCache()
        forgetLookups()
        PcScan.tick = -99
    end)
end)

local function perfReport(now)
    log(string.format("perf renders=%d text=%d color=%d rows=%d uiBuilds=%d polls=%d hits=%d pollAvgMs=%.2f pollMaxMs=%.2f tickAvgMs=%.2f tickMaxMs=%.2f pcs=%d scans=%d",
        Perf.renders, Perf.textSets, Perf.colorSets, Perf.rowsMade, Perf.uiBuilds, Perf.polls, Perf.pollHits,
        Perf.polls > 0 and (Perf.pollMs * 1000 / Perf.polls) or 0, Perf.pollMax * 1000,
        Perf.polls > 0 and (Perf.tickMs * 1000 / Perf.polls) or 0, Perf.tickMax * 1000, Perf.pcs, Perf.pcScans))
    Perf.renders, Perf.textSets, Perf.colorSets, Perf.polls, Perf.pollHits, Perf.pollMs, Perf.pollMax, Perf.pcScans, Perf.tickMs, Perf.tickMax = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    Perf.lastReport = now
end

LoopInGameThreadWithDelay(60, function()
    invalidateCache()
    local t0 = clock()
    try(pollGamepad)
    local dt = clock() - t0
    Perf.pollMs = Perf.pollMs + dt
    if dt > Perf.pollMax then Perf.pollMax = dt end
    if dt > 0 then Perf.pollHits = Perf.pollHits + 1 end
    Perf.polls = Perf.polls + 1
    Tick = Tick + 1
    CurrentTick = Tick
    if D.QtePendingUntil > CurrentTick and Tick % 3 == 0 then try(pollQte) end

    if Tick % 32 == 0 then
        try(applyFrozen)
        if State.autoQte or D.FluxCdoState then try(applyFluxDefaults) end
        if not D.QteHooksDone then try(registerQteHooks) end
        if not D.HackHooksDone then try(registerHackHooks) end
        if not D.ShiftTraceAllDone then try(registerShiftTraceHooks) end
        if not D.GraphHookDone then try(registerGraphHook) end
    end
    if Tick % 8 == 0 then
        if State.revealStats then try(revealCallStats) end
        if State.speed ~= 1 and (InHacking or not getGM()) then
            State.speed = 1
            log("speed reset to x1" .. (InHacking and " (hacking)" or ""))
            try(function() gameplayStatics():SetGlobalTimeDilation(anyPC(), 1) end)
        end
        if State.open then try(render) end
    end
    local tickDt = clock() - t0
    Perf.tickMs = Perf.tickMs + tickDt
    if tickDt > Perf.tickMax then Perf.tickMax = tickDt end
    if PERF and Tick % 500 == 0 then try(perfReport, clock()) end
end)

log("loaded v" .. VERSION .. " hotkey " .. HotkeyName)
