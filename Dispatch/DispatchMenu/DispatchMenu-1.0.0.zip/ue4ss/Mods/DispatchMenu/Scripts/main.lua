local DEBUG = false
local function log(s) print("[DispatchMenu] " .. tostring(s) .. "\n") end
local function dbg(s) if DEBUG then log(s) end end
local function try(fn, ...)
    local ok, res = pcall(fn, ...)
    if not ok then log("ERR " .. tostring(res)) end
    return ok, res
end

local Strings = {
    en = {
        title = "DISPATCH MENU", tabHeroes = "HEROES", tabStats = "STATS", tabShift = "SHIFT", tabHacking = "HACKING", tabStory = "STORY",
        hero = "Hero", all = "ALL", on = "ON", off = "OFF", none = "-", noHeroes = "Enter a shift to see heroes",
        motivated = "Motivated", instantRest = "Instant rest", noRest = "Never rests", finishRest = "Finish resting now",
        earnXp = "Earns XP", levelUp = "Can level up", sabotage = "Sabotage immune", xpMult = "XP multiplier",
        maxLevel = "Max level", giveXp = "Give XP", levelNow = "Level up now", statPoints = "Stat points +1",
        clearStatus = "Clear negative status", heal = "Heal injuries", rallied = "Rallied", willRefuse = "Never refuses",
        combat = "Combat", mobility = "Mobility", vigor = "Vigor", charisma = "Charisma", intellect = "Intellect",
        allMax = "All stats to 10", allBase = "All stats to 1",
        speed = "Game speed", callOutcome = "Current call result", outcomeNormal = "Normal", outcomeSuccess = "Success", outcomeFail = "Fail", outcomeMiss = "Miss",
        abortCall = "Current call: abort", autoSabotage = "Auto sabotage", noScenario = "no active call",
        endShift = "End shift now", forceEnd = "Force end shift", addHero = "Add to roster", noGM = "no shift running",
        hackLife = "Hacking life +1", hackWin = "Finish hacking (success)", hackTimer = "No fail on time out", hackNone = "no hacking running",
        skipNode = "Skip current scene", skipChoice = "Skip to choice", storyRunning = "Story graph running", storyPaused = "Story paused",
        help = "R stick: move/change   X/Enter: select   B/F2: close   LB/RB: tab   LB+RB: open",
    },
    ["pt-BR"] = {
        title = "MENU DISPATCH", tabHeroes = "HEROIS", tabStats = "STATS", tabShift = "TURNO", tabHacking = "HACKING", tabStory = "HISTORIA",
        hero = "Heroi", all = "TODOS", on = "LIGADO", off = "DESLIGADO", none = "-", noHeroes = "Entre num turno para ver os herois",
        motivated = "Motivado", instantRest = "Descanso instantaneo", noRest = "Nunca descansa", finishRest = "Terminar descanso agora",
        earnXp = "Ganha XP", levelUp = "Pode subir de nivel", sabotage = "Imune a sabotagem", xpMult = "Multiplicador de XP",
        maxLevel = "Nivel maximo", giveXp = "Dar XP", levelNow = "Subir de nivel agora", statPoints = "Pontos de stat +1",
        clearStatus = "Limpar status negativos", heal = "Curar lesoes", rallied = "Inspirado (rally)", willRefuse = "Nunca recusa",
        combat = "Combate", mobility = "Mobilidade", vigor = "Vigor", charisma = "Carisma", intellect = "Intelecto",
        allMax = "Todas as stats em 10", allBase = "Todas as stats em 1",
        speed = "Velocidade do jogo", callOutcome = "Resultado do chamado atual", outcomeNormal = "Normal", outcomeSuccess = "Sucesso", outcomeFail = "Falha", outcomeMiss = "Erro",
        abortCall = "Chamado atual: abortar", autoSabotage = "Sabotagem automatica", noScenario = "sem chamado ativo",
        endShift = "Encerrar turno agora", forceEnd = "Forcar fim do turno", addHero = "Adicionar ao elenco", noGM = "sem turno em andamento",
        hackLife = "Vida de hacking +1", hackWin = "Terminar hacking (sucesso)", hackTimer = "Sem falha por tempo", hackNone = "sem hacking em andamento",
        skipNode = "Pular cena atual", skipChoice = "Pular ate a escolha", storyRunning = "Historia rodando", storyPaused = "Historia pausada",
        help = "Analogico dir: move/altera   X/Enter: seleciona   B/F2: fecha   LB/RB: aba   LB+RB: abre",
    },
}
local Lang = "en"
local function T(k) return Strings[Lang][k] or Strings.en[k] or k end

local Theme = {
    panel = { R = 0.95, G = 0.92, B = 0.84, A = 0.97 },
    band = { R = 0.36, G = 0.73, B = 0.66, A = 1 },
    bandText = { R = 0.98, G = 0.98, B = 0.96, A = 1 },
    text = { R = 0.18, G = 0.15, B = 0.12, A = 1 },
    muted = { R = 0.45, G = 0.42, B = 0.38, A = 1 },
    accent = { R = 0.93, G = 0.62, B = 0.18, A = 1 },
    rowSel = { R = 0.98, G = 0.85, B = 0.60, A = 1 },
    rowNone = { R = 0, G = 0, B = 0, A = 0 },
    tabIdle = { R = 0.80, G = 0.77, B = 0.70, A = 1 },
    on = { R = 0.16, G = 0.55, B = 0.42, A = 1 },
    off = { R = 0.72, G = 0.28, B = 0.20, A = 1 },
}

local StatKeys = { { 5, "combat" }, { 2, "mobility" }, { 1, "vigor" }, { 3, "charisma" }, { 4, "intellect" } }
local XpAmounts = { 100, 500, 1000, 5000 }
local Speeds = { 1, 2, 4, 8 }
local PauseReason = 0

local State = { cursors = {}, open = false, pausedByMenu = false, pcCount = 0, tab = 1, cursor = 1, heroIndex = 0, xpAmount = 1, speed = 1, rosterIndex = 1 }
local Frozen = {}
local Original = {}

local function heroName(h)
    return (h:GetClass():GetFName():ToString():gsub("^BP_Hero_", ""):gsub("_C$", ""))
end

local function getPC()
    local pc = FindFirstOf("PC_ShiftPlayerController_C")
    if pc and pc:IsValid() then return pc end
    return nil
end

local function hasLocalPlayer(pc)
    local ok, v = pcall(function() return pc.Player:IsValid() and pc.PlayerInput:IsValid() end)
    return ok and v
end

local function anyPC()
    local shift = getPC()
    if shift and hasLocalPlayer(shift) then return shift end
    local fallback
    for _, pc in ipairs(FindAllOf("PlayerController") or {}) do
        if pc:IsValid() then
            if hasLocalPlayer(pc) then return pc end
            fallback = fallback or pc
        end
    end
    return fallback
end

local function getGM()
    local gm = FindFirstOf("GM_ShiftGameMode_C")
    if gm and gm:IsValid() then return gm end
    return nil
end

local function getHeroes()
    local out = {}
    local pc = getPC()
    if not pc then return out end
    pc.Heroes:ForEach(function(_, e)
        local h = e:get()
        if h:IsValid() then out[#out + 1] = h end
    end)
    return out
end

local function targets()
    local all = getHeroes()
    if State.heroIndex == 0 then return all end
    return { all[State.heroIndex] }
end

local function frozenKey()
    if State.heroIndex == 0 then return "*" end
    local h = targets()[1]
    return h and heroName(h) or "*"
end

local function getFrozen(h, prop)
    local byHero = Frozen[heroName(h)]
    if byHero and byHero[prop] ~= nil then return byHero[prop] end
    local all = Frozen["*"]
    if all and all[prop] ~= nil then return all[prop] end
    return nil
end

local function setFrozen(prop, value)
    local key = frozenKey()
    dbg(string.format("freeze %s.%s = %s", key, prop, tostring(value)))
    Frozen[key] = Frozen[key] or {}
    Frozen[key][prop] = value
    if key == "*" then
        for name, t in pairs(Frozen) do
            if name ~= "*" then t[prop] = nil end
        end
    end
end

local function rememberOriginal(h, prop)
    local name = heroName(h)
    Original[name] = Original[name] or {}
    if Original[name][prop] == nil then Original[name][prop] = h[prop] end
    return Original[name][prop]
end

local FrozenProps = { "Motivated", "ForceStopResting", "EnabledEarnXP", "EnabledLevelUp", "EnableSabotage", "MaxRestTime", "ScenarioXPRewardsMultiplier", "MaxLevel", "Rallied", "WillRefuse" }
local function applyFrozen()
    for _, h in ipairs(getHeroes()) do
        for _, prop in ipairs(FrozenProps) do
            local v = getFrozen(h, prop)
            if v ~= nil and h[prop] ~= v then
                dbg(string.format("reapply %s.%s %s -> %s", heroName(h), prop, tostring(h[prop]), tostring(v)))
                h[prop] = v
            end
        end
    end
end

local function readOut(h, fn)
    local t = {}
    h[fn](h, t)
    for _, v in pairs(t) do return v end
    return nil
end

local function statValue(h, key)
    local ok, v = pcall(function() return h.StatComponent.Stats:Find(key):get() end)
    if ok then return v end
    return 0
end

local function setStat(h, key, value)
    dbg(string.format("setStat %s key=%d %s -> %s", heroName(h), key, tostring(statValue(h, key)), tostring(value)))
    h.StatComponent.Stats:Add(key, value)
    try(function() h.HeroData.Stats:Add(key, value) end)
    try(function() h:UpdateCardStatsGraph() end)
end

local function boolText(v) return v and T("on") or T("off") end
local function boolColor(v) return v and Theme.on or Theme.off end

local function gameplayStatics() return StaticFindObject("/Script/Engine.Default__GameplayStatics") end
local function widgetLib() return StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary") end

local function currentScenario()
    local pc = getPC()
    if not pc then return nil end
    local s = pc.CurrentScenario
    if s and s:IsValid() then
        local ok, actor = pcall(function() return s.ScenarioActor end)
        if ok and actor and actor:IsValid() then return actor end
        if s:IsA(StaticFindObject("/Game/Shared/Shifts/Gameplay/Blueprints/Scenarios/BP_Scenario_Base.BP_Scenario_Base_C")) then return s end
    end
    local best
    pc.Scenarios:ForEach(function(_, e)
        local sc = e:get()
        if sc:IsValid() and not best then
            local ok, n = pcall(function() return #sc.Heroes end)
            if ok and n > 0 then best = sc end
        end
    end)
    return best
end

local function setStatus(msg)
    State.status = msg
    dbg("status: " .. msg)
end

local function snapshotScenario(sc)
    local ok, snap = pcall(function() return { state = tostring(sc.ScenarioState), heroes = #sc.Heroes, working = sc.WorkingTime } end)
    return ok and snap or nil
end

local function watchScenario(label, sc)
    local before = snapshotScenario(sc)
    if not before then setStatus(label .. ": ?") return end
    setStatus(string.format("%s: state %s, heroes %d", label, before.state, before.heroes))
    for _, delay in ipairs({ 1000, 3000 }) do
        ExecuteWithDelay(delay, function()
            ExecuteInGameThread(function()
                if not sc:IsValid() then setStatus(label .. ": scenario gone") return end
                local after = snapshotScenario(sc)
                if after then
                    setStatus(string.format("%s: state %s->%s, heroes %d->%d, work %.0f->%.0f (%.0fs)", label, before.state, after.state, before.heroes, after.heroes, before.working, after.working, delay / 1000))
                end
            end)
        end)
    end
end

local OutcomeModes = {
    { key = "outcomeNormal" },
    { key = "outcomeSuccess", outcome = 1, chance = 100 },
    { key = "outcomeFail", outcome = 2, chance = 0 },
    { key = "outcomeMiss", outcome = 3, chance = 0 },
}
local OutcomeOriginal = {}

local function outcomeMode(sc)
    if not sc.UseSpecificSuccessChance then return 1 end
    if sc.Outcome == 3 then return 4 end
    if sc.SuccessChance >= 100 then return 2 end
    if sc.SuccessChance <= 0 then return 3 end
    return 1
end

local function applyOutcome(sc, mode)
    local key = sc:GetFullName()
    if not OutcomeOriginal[key] then
        OutcomeOriginal[key] = { chance = sc.SuccessChance, unrounded = sc.SuccessChanceUnrounded, mult = sc.SuccessChanceMultiplier, specific = sc.UseSpecificSuccessChance, skipMiss = sc.SkipMiss, outcome = sc.Outcome }
    end
    local m = OutcomeModes[mode]
    if mode == 1 then
        local o = OutcomeOriginal[key]
        sc.UseSpecificSuccessChance = o.specific
        sc.SuccessChance = o.chance
        sc.SuccessChanceUnrounded = o.unrounded
        sc.SuccessChanceMultiplier = o.mult
        sc.SkipMiss = o.skipMiss
        sc.Outcome = o.outcome
    else
        sc.UseSpecificSuccessChance = true
        sc.SuccessChance = m.chance
        sc.SuccessChanceUnrounded = m.chance
        sc.SuccessChanceMultiplier = m.chance > 0 and 100 or 0
        sc.SkipMiss = m.outcome ~= 3
        sc.Outcome = m.outcome
    end
    dbg(string.format("outcome %s -> %s chance=%.0f specific=%s skipMiss=%s outcome=%s", key, m.key, sc.SuccessChance, tostring(sc.UseSpecificSuccessChance), tostring(sc.SkipMiss), tostring(sc.Outcome)))
end

local function cycleOutcome(delta)
    local sc = currentScenario()
    if not sc then return end
    try(function() applyOutcome(sc, (outcomeMode(sc) - 1 + delta) % #OutcomeModes + 1) end)
end

local function scenarioInfo(s)
    if not s then return "none" end
    local ok, n = pcall(function() return #s.Heroes end)
    return s:GetFullName() .. " state=" .. tostring(s.ScenarioState) .. " heroes=" .. tostring(ok and n or "?")
end

local function hackingUser()
    for _, u in ipairs(FindAllOf("BP_HkUser_Master_C") or {}) do
        if u:IsValid() and u:GetFullName():find("PersistentLevel") then return u end
    end
    return nil
end

local function failTimer()
    for _, t in ipairs(FindAllOf("BP_FailTimer_C") or {}) do
        if t:IsValid() and t:GetFullName():find("PersistentLevel") then return t end
    end
    return nil
end

local function storySubsystem()
    local s = FindFirstOf("AdHocStorySubsystem")
    if s and s:IsValid() then return s end
    return nil
end

local function forEachTarget(label, fn)
    local n = 0
    for _, t in ipairs(targets()) do
        local ok = try(function()
            dbg(label .. " " .. heroName(t))
            fn(t)
        end)
        if ok then n = n + 1 end
    end
    setStatus(label .. ": " .. n .. " hero(s)")
end

local function freezeItem(labelKey, prop, onValue)
    return {
        label = function() return T(labelKey) end,
        value = function(h)
            local v = getFrozen(h, prop)
            local active = v ~= nil and v == onValue
            return boolText(active), boolColor(active)
        end,
        select = function()
            local h = targets()[1]
            if not h then return end
            local v = getFrozen(h, prop)
            local active = v ~= nil and v == onValue
            dbg(string.format("toggle %s active=%s targets=%d", prop, tostring(active), #targets()))
            if active then
                setFrozen(prop, nil)
                for _, t in ipairs(targets()) do t[prop] = rememberOriginal(t, prop) end
            else
                for _, t in ipairs(targets()) do rememberOriginal(t, prop) end
                setFrozen(prop, onValue)
                for _, t in ipairs(targets()) do t[prop] = onValue end
            end
        end,
        needsHero = true,
    }
end

local function numberItem(labelKey, prop, step, min, max, fmt)
    local function change(delta)
        local h = targets()[1]
        if not h then return end
        local v = math.max(min, math.min(max, h[prop] + delta))
        dbg(string.format("number %s %s -> %s", prop, tostring(h[prop]), tostring(v)))
        for _, t in ipairs(targets()) do rememberOriginal(t, prop); t[prop] = v end
        setFrozen(prop, v)
    end
    return {
        label = function() return T(labelKey) end,
        value = function(h) return "< " .. string.format(fmt, h[prop]) .. " >" end,
        left = function() change(-step) end,
        right = function() change(step) end,
        needsHero = true,
    }
end

local function statItem(key, nameKey)
    local function change(delta)
        for _, t in ipairs(targets()) do
            setStat(t, key, math.max(0, math.min(10, statValue(t, key) + delta)))
        end
    end
    return {
        label = function() return T(nameKey) end,
        value = function(h) return "< " .. string.format("%d", statValue(h, key)) .. " >" end,
        left = function() change(-1) end,
        right = function() change(1) end,
        needsHero = true,
    }
end

local closeMenuRef
local function actionItem(labelKey, fn, valueFn, needsHero)
    return { label = function() return T(labelKey) end, value = valueFn or function() return "" end, select = fn, needsHero = needsHero }
end

local function afterClose(fn)
    return function()
        dbg("closing menu before action")
        closeMenuRef()
        ExecuteWithDelay(250, function() ExecuteInGameThread(function() try(fn) end) end)
    end
end

local HeroSelector = {
    label = function() return T("hero") end,
    value = function(h)
        if State.heroIndex == 0 then return "< " .. T("all") .. " >", Theme.accent end
        return "< " .. heroName(h) .. " >", Theme.accent
    end,
    left = function() State.heroIndex = (State.heroIndex - 1) % (#getHeroes() + 1) end,
    right = function() State.heroIndex = (State.heroIndex + 1) % (#getHeroes() + 1) end,
    needsHero = true,
}

local function loadedHeroClasses()
    local out = {}
    local inRoster = {}
    for _, h in ipairs(getHeroes()) do inRoster[heroName(h)] = true end
    for _, c in ipairs(FindAllOf("BlueprintGeneratedClass") or {}) do
        if c:IsValid() then
            local n = c:GetFName():ToString()
            if n:find("^BP_Hero_") and n ~= "BP_Hero_Base_C" and n ~= "BP_Hero_Helpers_C" and n ~= "BP_Hero_Duplicate_C" and n ~= "BP_Hero_Employee_C" then
                local short = n:gsub("^BP_Hero_", ""):gsub("_C$", "")
                if not inRoster[short] then out[#out + 1] = { name = short, class = c } end
            end
        end
    end
    table.sort(out, function(a, b) return a.name < b.name end)
    return out
end

local Tabs = {
    {
        key = "tabHeroes",
        items = {
            HeroSelector,
            freezeItem("motivated", "Motivated", true),
            freezeItem("instantRest", "MaxRestTime", 0.0),
            freezeItem("noRest", "ForceStopResting", true),
            actionItem("finishRest", function()
                forEachTarget("finishRest", function(t) dbg("  rest=" .. t.RestTime .. "/" .. t.MaxRestTime); t.RestTime = t.MaxRestTime; t:FinishResting() end)
            end, nil, true),
            freezeItem("earnXp", "EnabledEarnXP", true),
            freezeItem("levelUp", "EnabledLevelUp", true),
            numberItem("xpMult", "ScenarioXPRewardsMultiplier", 0.5, 0, 100, "x%.1f"),
            numberItem("maxLevel", "MaxLevel", 1, 1, 99, "%d"),
            {
                label = function() return T("giveXp") end,
                value = function() return "< " .. XpAmounts[State.xpAmount] .. " >" end,
                left = function() State.xpAmount = (State.xpAmount - 2) % #XpAmounts + 1 end,
                right = function() State.xpAmount = State.xpAmount % #XpAmounts + 1 end,
                select = function()
                    forEachTarget("giveXp", function(t)
                        dbg("  before=" .. tostring(readOut(t, "GetTotalXp")))
                        t:GiveXp(XpAmounts[State.xpAmount])
                        dbg("  after=" .. tostring(readOut(t, "GetTotalXp")))
                    end)
                end,
                needsHero = true,
            },
            actionItem("levelNow", function()
                forEachTarget("levelNow", function(t)
                    local need = (readOut(t, "GetTotalXpRequired") or 0) - (readOut(t, "GetTotalXp") or 0)
                    dbg("  need=" .. need)
                    t:GiveXp(math.max(need, 1))
                end)
            end, function(h)
                local ok, s = pcall(function() return string.format("%d/%d", readOut(h, "GetTotalXp") or 0, readOut(h, "GetTotalXpRequired") or 0) end)
                return ok and s or ""
            end, true),
            actionItem("statPoints", function()
                forEachTarget("statPoints", function(t)
                    local cur = readOut(t, "PHD_GetStatPoints") or 0
                    t:PHD_SetStatPoints(cur + 1)
                    dbg("  " .. cur .. " -> " .. tostring(readOut(t, "PHD_GetStatPoints")))
                end)
            end, function(h)
                local ok, s = pcall(function() return tostring(readOut(h, "PHD_GetStatPoints") or 0) end)
                return ok and s or ""
            end, true),
            freezeItem("sabotage", "EnableSabotage", false),
            freezeItem("willRefuse", "WillRefuse", false),
            freezeItem("rallied", "Rallied", true),
            actionItem("clearStatus", function()
                forEachTarget("clearStatus", function(t)
                    dbg(string.format("  scared=%s debuffed=%s spaced=%s sabotaged=%s injured=%s", tostring(t.Scared), tostring(t.Debuffed), tostring(t.SpacedOut), tostring(t.Sabotaged), tostring(t.SabotagedInjured)))
                    t.Scared = false
                    t.Debuffed = false
                    if t.SpacedOut then try(function() t:EndSpacedOut() end) end
                    if t.Sabotaged or t.SabotagedInjured then try(function() t:ResetSabotage() end) end
                    try(function() t:ClearBlazerBarrier() end)
                end)
            end, nil, true),
            actionItem("heal", function()
                forEachTarget("heal", function(t)
                    local ic = t.InjuryComponent
                    dbg("  injuryComponent=" .. tostring(ic and ic:IsValid()))
                    if ic and ic:IsValid() then ic:ClearInjuries() end
                end)
            end, nil, true),
        },
    },
    {
        key = "tabStats",
        items = {
            HeroSelector,
            statItem(5, "combat"), statItem(2, "mobility"), statItem(1, "vigor"), statItem(3, "charisma"), statItem(4, "intellect"),
            actionItem("allMax", function()
                forEachTarget("allMax", function(t) for _, s in ipairs(StatKeys) do setStat(t, s[1], 10) end end)
            end, nil, true),
            actionItem("allBase", function()
                forEachTarget("allBase", function(t) for _, s in ipairs(StatKeys) do setStat(t, s[1], 1) end end)
            end, nil, true),
        },
    },
    {
        key = "tabShift",
        items = {
            {
                label = function() return T("speed") end,
                value = function() return "< x" .. Speeds[State.speed] .. " >", Theme.accent end,
                left = function()
                    State.speed = (State.speed - 2) % #Speeds + 1
                    dbg("speed x" .. Speeds[State.speed])
                    try(function() gameplayStatics():SetGlobalTimeDilation(anyPC(), Speeds[State.speed]) end)
                end,
                right = function()
                    State.speed = State.speed % #Speeds + 1
                    dbg("speed x" .. Speeds[State.speed])
                    try(function() gameplayStatics():SetGlobalTimeDilation(anyPC(), Speeds[State.speed]) end)
                end,
            },
            {
                label = function() return T("callOutcome") end,
                value = function()
                    local sc = currentScenario()
                    if not sc then return T("noScenario"), Theme.muted end
                    local mode = outcomeMode(sc)
                    local color = mode == 1 and Theme.text or (mode == 2 and Theme.on or Theme.off)
                    return "< " .. T(OutcomeModes[mode].key) .. " >", color
                end,
                left = function() cycleOutcome(-1) end,
                right = function() cycleOutcome(1) end,
                select = function() cycleOutcome(1) end,
            },
            actionItem("abortCall", afterClose(function()
                local s = currentScenario()
                dbg("abort scenario=" .. scenarioInfo(s))
                if s then try(function() s:Abort() end); watchScenario("abort", s) else setStatus("abort: " .. T("noScenario")) end
            end), function() return currentScenario() and "" or T("noScenario"), Theme.muted end),
            {
                label = function() return T("autoSabotage") end,
                value = function()
                    local gm = getGM()
                    if not gm then return T("noGM"), Theme.muted end
                    return boolText(gm.CanAutoSabotage), boolColor(gm.CanAutoSabotage)
                end,
                select = function()
                    local gm = getGM()
                    if not gm then return end
                    try(function()
                        dbg("autoSabotage " .. tostring(gm.CanAutoSabotage) .. " -> " .. tostring(not gm.CanAutoSabotage))
                        gm:SetCanAutoSabotage(not gm.CanAutoSabotage)
                    end)
                end,
            },
            actionItem("endShift", afterClose(function()
                local gm = getGM()
                dbg("endShift gm=" .. tostring(gm ~= nil))
                if gm then try(function() gm:EndShift() end) end
            end), function() return getGM() and "" or T("noGM"), Theme.muted end),
            actionItem("forceEnd", afterClose(function()
                local gm = getGM()
                dbg("forceEnd gm=" .. tostring(gm ~= nil))
                if gm then try(function() gm:ForceEnd() end) end
            end), function() return getGM() and "" or T("noGM"), Theme.muted end),
        },
    },
    {
        key = "tabHacking",
        items = {
            actionItem("hackLife", function()
                local gm = getGM()
                dbg("hackLife gm=" .. tostring(gm ~= nil))
                if gm then try(function() gm:AddHackingLife() end) end
            end, function() return getGM() and "" or T("noGM"), Theme.muted end),
            {
                label = function() return T("hackTimer") end,
                value = function()
                    local t = failTimer()
                    if not t then return T("hackNone"), Theme.muted end
                    return boolText(t.BlockedDueSuccess), boolColor(t.BlockedDueSuccess)
                end,
                select = function()
                    local t = failTimer()
                    if not t then return end
                    try(function()
                        local on = not t.BlockedDueSuccess
                        dbg(string.format("hackTimer %s blocked %s -> %s timerForFail=%s", t:GetFullName(), tostring(t.BlockedDueSuccess), tostring(on), tostring(t.TimerForFail)))
                        if on then State.timerOriginal = t.TimerForFail end
                        t.BlockedDueSuccess = on
                        t.TimerForFail = on and 999999 or (State.timerOriginal or t.TimerForFail)
                    end)
                end,
            },
            actionItem("hackWin", afterClose(function()
                local user = hackingUser()
                dbg("hackWin user=" .. (user and user:GetFullName() or "none"))
                if not user then return end
                local effects = {}
                for _, cls in ipairs({ "BP_HkIE_ReturnToShiftSuccess_C", "BP_HkIE_ReturnToStorySuccess_C", "BP_HkIE_StackSuccess_C" }) do
                    for _, o in ipairs(FindAllOf(cls) or {}) do
                        if o:IsValid() and o:GetFullName():find("PersistentLevel") then effects[#effects + 1] = o end
                    end
                end
                local toShift = false
                for _, o in ipairs(effects) do
                    if o:GetClass():GetFName():ToString():find("Shift") then toShift = true end
                    local inter = o:GetOuter()
                    dbg("  interactive " .. (inter:IsValid() and inter:GetFullName() or "invalid"))
                    try(function() inter:ForceStackFinalNode(); dbg("    ForceStackFinalNode ok") end)
                    try(function() inter:FinishInteraction(); dbg("    FinishInteraction ok") end)
                    try(function() inter:FinishEffectsAndMessage(); dbg("    FinishEffectsAndMessage ok") end)
                end
                ExecuteWithDelay(1500, function()
                    ExecuteInGameThread(function()
                        if not hackingUser() then dbg("  already left hacking") return end
                        if toShift then
                            try(function() user:ReturnToShift(true); dbg("  ReturnToShift(true) called") end)
                        else
                            local ss = storySubsystem()
                            try(function() dbg("  ReturnToStoryFromGameplay=" .. tostring(ss:ReturnToStoryFromGameplay())) end)
                        end
                    end)
                end)
            end), function() return hackingUser() and "" or T("hackNone"), Theme.muted end),
        },
    },
    {
        key = "tabStory",
        items = {
            {
                label = function() return T("storyRunning") end,
                value = function()
                    local s = storySubsystem()
                    if not s then return T("none"), Theme.muted end
                    local ok, r = pcall(function() return s:IsRunningStoryGraph() end)
                    return boolText(ok and r), boolColor(ok and r)
                end,
            },
            actionItem("skipNode", afterClose(function()
                local s = storySubsystem()
                dbg("skipNode subsystem=" .. tostring(s ~= nil))
                if s then
                    try(function() dbg("  node=" .. tostring(s:GetCurrentNode():GetFullName())) end)
                    s:DebugSkip()
                end
            end)),
            actionItem("skipChoice", afterClose(function()
                local s = storySubsystem()
                dbg("skipChoice subsystem=" .. tostring(s ~= nil))
                if s then s:SkipToChoiceInCurrentSequence() end
            end)),
        },
    },
}

local Widget, Ui

local function setText(tb, text)
    if not tb or not tb:IsValid() then return end
    pcall(function() tb:SetText(FText(text)) end)
end
local function setColor(tb, c) try(function() tb:SetColorAndOpacity({ SpecifiedColor = c, ColorUseRule = 0 }) end) end

local function makeText(tree, text, size, color, font)
    local tb = StaticConstructObject(StaticFindObject("/Script/UMG.TextBlock"), tree)
    setText(tb, text)
    try(function() tb.Font.Size = size end)
    if font then try(function() tb.Font.FontObject = font end) end
    setColor(tb, color)
    return tb
end

local function makeBorder(tree, color, padding)
    local b = StaticConstructObject(StaticFindObject("/Script/UMG.Border"), tree)
    try(function() b:SetBrushColor(color) end)
    try(function() b:SetPadding(padding) end)
    return b
end

local function buildUi(pc)
    local cls = StaticFindObject("/Script/CommonUI.CommonActivatableWidget")
    if not cls or not cls:IsValid() then cls = StaticFindObject("/Script/UMG.UserWidget") end
    local w = widgetLib():Create(pc, cls, pc)
    dbg("createWidget class=" .. cls:GetFName():ToString() .. " widget=" .. tostring(w:IsValid()) .. " pc=" .. pc:GetClass():GetFName():ToString())
    if not w:IsValid() then return false end
    try(function() w.bIsFocusable = true end)
    try(function()
        w.bAutoActivate = false
        w.bIsBackHandler = false
        w.bIsModal = true
        w.bSupportsActivationFocus = true
        w.bAutoRestoreFocus = true
    end)
    for dir = 0, 5 do try(function() w:SetNavigationRuleBase(dir, 3) end) end
    local tree = StaticConstructObject(StaticFindObject("/Script/UMG.WidgetTree"), w)
    w.WidgetTree = tree

    local font = StaticFindObject("/Game/Shared/Shifts/Art/Fonts/Roboto_Regular/Roboto-Medium_Font.Roboto-Medium_Font")
    if font and font:IsValid() then dbg("font ok " .. font:GetFullName()) else font = nil; dbg("font not found") end

    local canvas = StaticConstructObject(StaticFindObject("/Script/UMG.CanvasPanel"), tree)
    local panel = makeBorder(tree, Theme.panel, { Left = 0, Top = 0, Right = 0, Bottom = 0 })
    local vbox = StaticConstructObject(StaticFindObject("/Script/UMG.VerticalBox"), tree)
    panel:SetContent(vbox)

    local titleBand = makeBorder(tree, Theme.band, { Left = 18, Top = 8, Right = 18, Bottom = 8 })
    local title = makeText(tree, T("title"), 22, Theme.bandText, font)
    titleBand:SetContent(title)
    vbox:AddChildToVerticalBox(titleBand)

    local tabsRow = StaticConstructObject(StaticFindObject("/Script/UMG.HorizontalBox"), tree)
    local tabs = {}
    for i, tab in ipairs(Tabs) do
        local tb = makeBorder(tree, Theme.tabIdle, { Left = 14, Top = 5, Right = 14, Bottom = 5 })
        local tt = makeText(tree, T(tab.key), 15, Theme.text, font)
        tb:SetContent(tt)
        local slot = tabsRow:AddChildToHorizontalBox(tb)
        try(function() slot:SetPadding({ Left = 0, Top = 0, Right = 3, Bottom = 0 }) end)
        tabs[i] = { border = tb, text = tt }
    end
    local tabsSlot = vbox:AddChildToVerticalBox(tabsRow)
    try(function() tabsSlot:SetPadding({ Left = 12, Top = 8, Right = 12, Bottom = 4 }) end)

    local rowsBox = StaticConstructObject(StaticFindObject("/Script/UMG.VerticalBox"), tree)
    local rowsSlot = vbox:AddChildToVerticalBox(rowsBox)
    try(function() rowsSlot:SetPadding({ Left = 12, Top = 4, Right = 12, Bottom = 4 }) end)

    local status = makeText(tree, "", 13, Theme.accent, font)
    local statusSlot = vbox:AddChildToVerticalBox(status)
    try(function() statusSlot:SetPadding({ Left = 16, Top = 6, Right = 16, Bottom = 0 }) end)
    local help = makeText(tree, T("help"), 12, Theme.muted, font)
    local helpSlot = vbox:AddChildToVerticalBox(help)
    try(function() helpSlot:SetPadding({ Left = 16, Top = 6, Right = 16, Bottom = 10 }) end)

    local slot = canvas:AddChildToCanvas(panel)
    try(function() slot:SetAutoSize(true) end)
    try(function() slot:SetPosition({ X = 48, Y = 48 }) end)
    tree.RootWidget = canvas

    Ui = { tree = tree, font = font, tabs = tabs, rowsBox = rowsBox, rows = {}, rowsTab = 0, help = help, status = status }
    Widget = w
    dbg("widget built " .. w:GetFullName())
    return true
end

local function buildRows(count)
    Ui.rowsBox:ClearChildren()
    Ui.rows = {}
    for i = 1, count do
        local rowBorder = makeBorder(Ui.tree, Theme.rowNone, { Left = 8, Top = 3, Right = 8, Bottom = 3 })
        local hbox = StaticConstructObject(StaticFindObject("/Script/UMG.HorizontalBox"), Ui.tree)
        local labelBox = StaticConstructObject(StaticFindObject("/Script/UMG.SizeBox"), Ui.tree)
        try(function() labelBox:SetWidthOverride(330) end)
        local label = makeText(Ui.tree, "", 16, Theme.text, Ui.font)
        labelBox:SetContent(label)
        local value = makeText(Ui.tree, "", 16, Theme.text, Ui.font)
        hbox:AddChildToHorizontalBox(labelBox)
        hbox:AddChildToHorizontalBox(value)
        rowBorder:SetContent(hbox)
        local rslot = Ui.rowsBox:AddChildToVerticalBox(rowBorder)
        try(function() rslot:SetPadding({ Left = 0, Top = 1, Right = 0, Bottom = 1 }) end)
        Ui.rows[i] = { border = rowBorder, label = label, value = value }
    end
end

local function visibleItems()
    local tab = Tabs[State.tab]
    local hasHeroes = #getHeroes() > 0
    local out = {}
    for _, item in ipairs(tab.items) do
        if not item.needsHero or hasHeroes then out[#out + 1] = item end
    end
    return out
end

local function render()
    if not Widget or not Widget:IsValid() or not Ui then return end
    if State.heroIndex > #getHeroes() then State.heroIndex = 0 end
    for i, tab in ipairs(Ui.tabs) do
        local active = i == State.tab
        try(function() tab.border:SetBrushColor(active and Theme.band or Theme.tabIdle) end)
        setColor(tab.text, active and Theme.bandText or Theme.text)
    end
    setText(Ui.status, State.status or "")
    local items = visibleItems()
    local h = targets()[1]
    if #items == 0 then items = { { label = function() return T("noHeroes") end, value = function() return "", Theme.muted end } } end
    if State.cursor > #items then State.cursor = #items end
    if Ui.rowsTab ~= State.tab or #Ui.rows ~= #items then
        buildRows(#items)
        Ui.rowsTab = State.tab
    end
    for i, item in ipairs(items) do
        local row = Ui.rows[i]
        local selected = i == State.cursor
        try(function() row.border:SetBrushColor(selected and Theme.rowSel or Theme.rowNone) end)
        setText(row.label, (selected and "> " or "   ") .. item.label())
        local ok, v, c = pcall(item.value, h)
        if not ok then v, c = "?", Theme.off end
        setText(row.value, tostring(v or ""))
        setColor(row.value, c or Theme.text)
    end
end

local function setGameInput(enabled)
    for _, pc in ipairs(FindAllOf("PlayerController") or {}) do
        if pc:IsValid() then
            try(function()
                if enabled then pc:EnableInput(pc) else pc:DisableInput(pc) end
                local pawn = pc.Pawn
                if pawn and pawn:IsValid() then
                    if enabled then pawn:EnableInput(pc) else pawn:DisableInput(pc) end
                end
                dbg("gameInput " .. tostring(enabled) .. " on " .. pc:GetClass():GetFName():ToString())
            end)
        end
    end
end

local function openMenu()
    local pc = anyPC()
    dbg("openMenu pc=" .. (pc and pc:GetFullName() or "none"))
    if not pc then return end
    try(function() Lang = StaticFindObject("/Script/Engine.Default__KismetInternationalizationLibrary"):GetCurrentLanguage():ToString() end)
    dbg("language " .. Lang)
    if not Strings[Lang] then Lang = "en" end
    local ok, built = try(buildUi, pc)
    if not ok or not built then log("could not build menu widget"); Widget, Ui = nil, nil; return end
    Widget:AddToViewport(1000)
    try(function() Widget:ActivateWidget(); dbg("activated=" .. tostring(Widget:IsActivated())) end)
    try(function() Widget:SetFocus() end)
    try(function() dbg("focus=" .. tostring(Widget:HasKeyboardFocus())) end)
    setGameInput(false)
    try(function()
        local ps = FindFirstOf("DispatchPauseSubsystem")
        State.pausedByMenu = not ps:GetPausedForReason(PauseReason)
        if State.pausedByMenu then ps:SetPausedForReason(true, PauseReason) end
        dbg("paused by menu=" .. tostring(State.pausedByMenu))
    end)
    State.open = true
    dbg("menu open, heroes=" .. #getHeroes())
    render()
end

local function closeMenu()
    dbg("closeMenu")
    State.open = false
    setGameInput(true)
    if State.pausedByMenu then
        try(function()
            local ps = FindFirstOf("DispatchPauseSubsystem")
            ps:SetPausedForReason(false, PauseReason)
            dbg("unpaused, stillPaused=" .. tostring(ps:GetPausedForReason(PauseReason)))
        end)
        State.pausedByMenu = false
    end
    if Widget and Widget:IsValid() then
        try(function() Widget:DeactivateWidget() end)
        Widget:RemoveFromParent()
    end
    Widget, Ui = nil, nil
    local pc = anyPC()
    if pc and pc:GetClass():GetFName():ToString():find("DispatchPlayerControllerBase") then
        try(function() widgetLib():SetInputMode_GameOnly(pc); dbg("input mode GameOnly restored for hacking") end)
    end
end

closeMenuRef = closeMenu

local function toggleMenu()
    if State.open then closeMenu() else openMenu() end
end

local function switchTab(delta)
    State.cursors[State.tab] = State.cursor
    State.tab = (State.tab - 1 + delta) % #Tabs + 1
    State.cursor = State.cursors[State.tab] or 1
    dbg("tab " .. Tabs[State.tab].key)
    render()
end

local function nav(dir)
    if not State.open then return end
    local items = visibleItems()
    if #items == 0 then return end
    local item = items[State.cursor] or items[1]
    dbg(string.format("nav %s tab=%d cursor=%d item=%s", dir, State.tab, State.cursor, item.label()))
    if dir == "up" then State.cursor = (State.cursor - 2) % #items + 1
    elseif dir == "down" then State.cursor = State.cursor % #items + 1
    elseif dir == "left" and item.left then try(item.left)
    elseif dir == "right" and item.right then try(item.right)
    elseif dir == "select" then
        if item.select then try(item.select) elseif item.right then try(item.right) end
    end
    render()
end

local function inGame(fn) return function() ExecuteInGameThread(fn) end end

RegisterKeyBind(Key.F2, {}, inGame(toggleMenu))
RegisterKeyBind(Key.ESCAPE, {}, inGame(function() if State.open then closeMenu() end end))
RegisterKeyBind(Key.UP_ARROW, {}, inGame(function() nav("up") end))
RegisterKeyBind(Key.DOWN_ARROW, {}, inGame(function() nav("down") end))
RegisterKeyBind(Key.LEFT_ARROW, {}, inGame(function() nav("left") end))
RegisterKeyBind(Key.RIGHT_ARROW, {}, inGame(function() nav("right") end))
RegisterKeyBind(Key.RETURN, {}, inGame(function() nav("select") end))
RegisterKeyBind(Key.Q, {}, inGame(function() if State.open then switchTab(-1) end end))
RegisterKeyBind(Key.E, {}, inGame(function() if State.open then switchTab(1) end end))

local PadMap = {
    Gamepad_DPad_Up = "up", Gamepad_DPad_Down = "down", Gamepad_DPad_Left = "left", Gamepad_DPad_Right = "right",
    Gamepad_RightStick_Up = "up", Gamepad_RightStick_Down = "down", Gamepad_RightStick_Left = "left", Gamepad_RightStick_Right = "right",
    Gamepad_FaceButton_Bottom = "select", Gamepad_FaceButton_Left = "select", Gamepad_FaceButton_Right = "close",
    Gamepad_LeftTrigger = "tabPrev", Gamepad_RightTrigger = "tabNext",
}
local PadHold = {}
local ComboLatched = false
local ShoulderHold = { lb = 0, rb = 0 }
local Tick = 0

local function pollGamepad()
    local pcs = {}
    for _, pc in ipairs(FindAllOf("PlayerController") or {}) do
        if pc:IsValid() then pcs[#pcs + 1] = pc end
    end
    if #pcs == 0 then return end
    if #pcs ~= State.pcCount then
        State.pcCount = #pcs
        local names = {}
        for i, pc in ipairs(pcs) do names[i] = pc:GetClass():GetFName():ToString() end
        dbg("player controllers: " .. table.concat(names, ", "))
    end
    local function down(name)
        for _, pc in ipairs(pcs) do
            local ok, v = pcall(function() return pc:IsInputKeyDown({ KeyName = FName(name) }) end)
            if ok and v then return true end
        end
        return false
    end
    local lb, rb = down("Gamepad_LeftShoulder"), down("Gamepad_RightShoulder")
    if lb and rb then
        if not ComboLatched then ComboLatched = true; dbg("gamepad LB+RB"); toggleMenu() end
    end
    if State.open and not ComboLatched then
        if not lb and ShoulderHold.lb > 0 then dbg("gamepad LB release"); switchTab(-1) end
        if not rb and ShoulderHold.rb > 0 then dbg("gamepad RB release"); switchTab(1) end
    end
    ShoulderHold.lb = lb and ShoulderHold.lb + 1 or 0
    ShoulderHold.rb = rb and ShoulderHold.rb + 1 or 0
    if not lb and not rb then ComboLatched = false end
    if State.open and Widget and Widget:IsValid() then
        local ok, has = pcall(function() return Widget:HasKeyboardFocus() end)
        if ok and not has then try(function() Widget:SetFocus() end) end
    end
    for name, action in pairs(PadMap) do
        local d = down(name)
        if d then PadHold[name] = (PadHold[name] or 0) + 1 else PadHold[name] = 0 end
        local held = PadHold[name]
        local repeatable = action == "up" or action == "down" or action == "left" or action == "right"
        local fire = held == 1 or (held > 7 and held % 3 == 0 and repeatable)
        if held == 1 then dbg("gamepad " .. name .. " open=" .. tostring(State.open)) end
        if fire and State.open and not ComboLatched then
            if action == "close" then closeMenu()
            elseif action == "tabPrev" then switchTab(-1)
            elseif action == "tabNext" then switchTab(1)
            else nav(action) end
        end
    end
end

LoopAsync(60, function()
    ExecuteInGameThread(function()
        try(pollGamepad)
        Tick = Tick + 1
        if Tick % 8 == 0 then
            try(applyFrozen)
            if State.open then try(render) end
        end
    end)
    return false
end)

log("loaded v2")
