extends CanvasLayer

const TAB_DEFS = [
	["items", "GME_TAB_ITEMS"],
	["weapons", "GME_TAB_WEAPONS"],
	["upgrades", "GME_TAB_UPGRADES"],
	["resources", "GME_TAB_RESOURCES"],
	["inventory", "GME_TAB_INVENTORY"],
	["unlocks", "GME_TAB_UNLOCKS"],
]
const GRID_TABS = ["items", "weapons", "upgrades"]
const SECTION_DEFS = [
	["characters", "GME_SEC_CHARACTERS"],
	["items", "GME_SEC_ITEMS"],
	["weapons", "GME_SEC_WEAPONS"],
	["enemies", "GME_SEC_ENEMIES"],
	["danger", "GME_SEC_DANGER"],
	["wins", "GME_SEC_WINS"],
	["challenges", "GME_SEC_CHALLENGES"],
]
const ICON_SIZE = 56
const GRID_SEPARATION = 4
const THEME_PATH = "res://resources/themes/base_theme.tres"
const FONT_PATH = "res://resources/fonts/actual/base/font_22.tres"
const TITLE_FONT_PATH = "res://resources/fonts/actual/base/font_26_outline.tres"
const ACCENT = Color(0.95, 0.75, 0.3)
const BTN_BG = Color(0.12, 0.12, 0.14)
const BTN_BORDER = Color(0.4, 0.4, 0.46)

var mod_main = null
var pause_when_open: bool = true

var current_tab: String = "items"
var current_tier: int = -1
var unlock_section: String = "characters"
var _section_all_button: Button
var _section_all_confirm_pending: = false
var search_text: String = ""
var player_index: int = 0
var cursed_mode: bool = false
var run_active: bool = true
var _ack_wait_started: = false
var _last_ack_msec: int = -1
var _ack_text: String = ""

var _panel: PanelContainer
var _content_scroll: ScrollContainer
var _content_holder: MarginContainer
var _detail_panel: PanelContainer
var _detail_icon: TextureRect
var _detail_name: Label
var _detail_tier: Label
var _detail_text: RichTextLabel
var _info_label: Label
var _search_edit: LineEdit
var _give_all_button: Button
var _cursed_button: Button
var _tab_buttons: = {}
var _tier_buttons: = []
var _prev_paused: = false
var _prev_mouse_mode: int = Input.MOUSE_MODE_VISIBLE
var _last_columns: int = 0
var _trigger_down: = {6: false, 7: false}
var _rebuild_queued: = false
var _restore_focus_to = null
var _tier_style_cache: = {}
var _guard_depth: = {}
var _wave_value_label: Label
var _loadout_name_edit: LineEdit
var win_brush: int = 5


func _guard(fn: String) -> bool:
	var depth = _guard_depth.get(fn, 0)
	if depth > 4:
		ModLoaderLog.warning("Recursion blocked in %s" % fn, "opaaaaaaaaaaaa-GiveMeEverything")
		return true
	_guard_depth[fn] = depth + 1
	return false


func _unguard(fn: String) -> void :
	_guard_depth[fn] = _guard_depth.get(fn, 1) - 1


func _ready() -> void :
	layer = 100
	pause_mode = PAUSE_MODE_PROCESS
	run_active = _detect_run_active()
	player_index = mod_main.local_player_index()
	if not run_active:
		current_tab = "unlocks"
	_prev_paused = get_tree().paused
	_prev_mouse_mode = Input.get_mouse_mode()
	if pause_when_open and run_active:
		get_tree().paused = true
	_build_ui()
	_restore_focus_to = _info_label.get_focus_owner()
	_queue_rebuild()


func _detect_run_active() -> bool:
	if RunData.players_data.empty():
		return false
	var scene = get_tree().current_scene
	if scene == null:
		return false
	return scene.get("_players") != null or scene.has_method("_get_gear_container")


func _queue_rebuild() -> void :
	if _rebuild_queued:
		return
	_rebuild_queued = true
	call_deferred("_do_rebuild")


func _do_rebuild() -> void :
	_rebuild_queued = false
	_refresh_content()


func _focus_first(button) -> void :
	if _search_edit != null and _search_edit.has_focus():
		return
	if is_instance_valid(button) and button.is_inside_tree():
		button.grab_focus()


func _input(event) -> void :
	if event.is_action_pressed("ui_cancel"):
		get_tree().set_input_as_handled()
		close()
	elif event is InputEventJoypadButton:
		if event.button_index == JOY_L2 or event.button_index == JOY_R2:
			get_tree().set_input_as_handled()
			var axis = 6 if event.button_index == JOY_L2 else 7
			if event.pressed:
				if not _trigger_down[axis]:
					_trigger_down[axis] = true
					_cycle_tier(-1 if axis == 6 else 1)
			else:
				_trigger_down[axis] = false
		elif event.pressed:
			match event.button_index:
				JOY_L:
					get_tree().set_input_as_handled()
					_cycle_tab(-1)
				JOY_R:
					get_tree().set_input_as_handled()
					_cycle_tab(1)
				JOY_XBOX_Y:
					if _cursed_button.visible:
						get_tree().set_input_as_handled()
						_cursed_button.pressed = not _cursed_button.pressed
						cursed_mode = _cursed_button.pressed
				JOY_XBOX_X:
					if current_tab == "unlocks":
						get_tree().set_input_as_handled()
						_on_unlock_section_all()
	elif event is InputEventJoypadMotion and _trigger_down.has(event.axis):
		get_tree().set_input_as_handled()
		if abs(event.axis_value) > 0.6 and not _trigger_down[event.axis]:
			_trigger_down[event.axis] = true
			_cycle_tier(-1 if event.axis == 6 else 1)
		elif abs(event.axis_value) < 0.4:
			_trigger_down[event.axis] = false


func _tab_ids() -> Array:
	var ids: = []
	for def in TAB_DEFS:
		ids.push_back(def[0])
	return ids


func _cycle_tab(direction: int) -> void :
	if not run_active:
		return
	var ids = _tab_ids()
	var index = wrapi(ids.find(current_tab) + direction, 0, ids.size())
	current_tab = ids[index]
	_set_pressed_silent(_tab_buttons[current_tab])
	_queue_rebuild()


func _set_pressed_silent(button: Button) -> void :
	button.set_block_signals(true)
	button.pressed = true
	button.set_block_signals(false)


func _cycle_tier(direction: int) -> void :
	if current_tab == "unlocks":
		var ids: = []
		for def in SECTION_DEFS:
			ids.push_back(def[0])
		unlock_section = ids[wrapi(ids.find(unlock_section) + direction, 0, ids.size())]
		_queue_rebuild()
		return
	if not GRID_TABS.has(current_tab):
		return
	current_tier = wrapi(current_tier + 1 + direction, 0, 5) - 1
	_set_pressed_silent(_tier_buttons[current_tier + 1])
	_queue_rebuild()


func _process(_delta: float) -> void :
	if Input.get_mouse_mode() != Input.MOUSE_MODE_VISIBLE:
		Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)


func close() -> void :
	set_process(false)
	Input.set_mouse_mode(_prev_mouse_mode)
	if pause_when_open and run_active:
		get_tree().paused = _prev_paused
	if _restore_focus_to != null and is_instance_valid(_restore_focus_to) and _restore_focus_to.is_inside_tree():
		_restore_focus_to.call_deferred("grab_focus")
	queue_free()


func _layout_panel() -> void :
	if _guard("_layout_panel"):
		return
	_do_layout_panel()
	_unguard("_layout_panel")


func _do_layout_panel() -> void :
	var vp = get_viewport().size
	var w = min(vp.x * 0.72, 1620.0)
	var h = min(vp.y * 0.9, 980.0)
	_panel.anchor_left = 0.5
	_panel.anchor_top = 0.5
	_panel.anchor_right = 0.5
	_panel.anchor_bottom = 0.5
	_panel.margin_left = - w / 2
	_panel.margin_top = - h / 2
	_panel.margin_right = w / 2
	_panel.margin_bottom = h / 2
	var scale = mod_main.menu_scale if mod_main != null else 1.0
	_panel.rect_pivot_offset = Vector2(w / 2, h / 2)
	_panel.rect_scale = Vector2(scale, scale)


func _build_ui() -> void :
	var dim = ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	dim.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	add_child(dim)

	_panel = PanelContainer.new()
	var game_theme = load(THEME_PATH)
	if game_theme != null:
		game_theme = game_theme.duplicate()
		var small_font = load(FONT_PATH)
		if small_font != null:
			game_theme.default_font = small_font
			game_theme.set_font("font", "Button", small_font)
		_panel.theme = game_theme
	add_child(_panel)
	_layout_panel()
	get_viewport().connect("size_changed", self, "_layout_panel")

	var root = VBoxContainer.new()
	root.add_constant_override("separation", 8)
	_panel.add_child(root)

	var top = HBoxContainer.new()
	root.add_child(top)

	var title = Label.new()
	title.text = "GIVE ME EVERYTHING"
	title.add_color_override("font_color", ACCENT)
	var title_font = load(TITLE_FONT_PATH)
	if title_font != null:
		title.add_font_override("font", title_font)
	top.add_child(title)

	var spacer = Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(spacer)

	if run_active and RunData.get_player_count() > 1:
		var player_select = OptionButton.new()
		for i in RunData.get_player_count():
			player_select.add_item(tr("GME_PLAYER_N") % (i + 1))
		player_select.select(player_index)
		player_select.connect("item_selected", self, "_on_player_selected")
		top.add_child(player_select)

	var close_button = Button.new()
	close_button.text = "X"
	close_button.connect("pressed", self, "close")
	_style_button(close_button)
	top.add_child(close_button)

	root.add_child(HSeparator.new())

	var tabs = HBoxContainer.new()
	tabs.add_constant_override("separation", 8)
	root.add_child(tabs)
	var tab_group = ButtonGroup.new()
	for def in TAB_DEFS:
		var b = Button.new()
		b.text = tr(def[1])
		b.toggle_mode = true
		b.group = tab_group
		b.pressed = def[0] == current_tab
		b.disabled = not run_active and def[0] != "unlocks"
		b.connect("pressed", self, "_on_tab_pressed", [def[0]])
		_style_button(b)
		tabs.add_child(b)
		_tab_buttons[def[0]] = b

	var filters = HBoxContainer.new()
	filters.add_constant_override("separation", 8)
	root.add_child(filters)

	_search_edit = LineEdit.new()
	_search_edit.placeholder_text = tr("GME_SEARCH")
	_search_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_search_edit.focus_mode = Control.FOCUS_CLICK
	_search_edit.connect("text_changed", self, "_on_search_changed")
	filters.add_child(_search_edit)

	var tier_group = ButtonGroup.new()
	for i in 5:
		var b = Button.new()
		b.text = tr("GME_ALL") if i == 0 else "T%d" % i
		b.toggle_mode = true
		b.group = tier_group
		b.pressed = (i - 1) == current_tier
		b.connect("pressed", self, "_on_tier_pressed", [i - 1])
		_style_button(b)
		filters.add_child(b)
		_tier_buttons.push_back(b)

	var body = HBoxContainer.new()
	body.add_constant_override("separation", 12)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(body)

	_content_scroll = ScrollContainer.new()
	_content_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_content_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_content_scroll.scroll_horizontal_enabled = false
	_content_scroll.connect("resized", self, "_on_scroll_resized")
	body.add_child(_content_scroll)

	_content_holder = MarginContainer.new()
	_content_holder.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_content_scroll.add_child(_content_holder)

	_detail_panel = PanelContainer.new()
	_detail_panel.rect_min_size.x = 340
	body.add_child(_detail_panel)

	var detail_box = VBoxContainer.new()
	detail_box.add_constant_override("separation", 8)
	_detail_panel.add_child(detail_box)

	_detail_icon = TextureRect.new()
	_detail_icon.rect_min_size = Vector2(96, 96)
	_detail_icon.expand = true
	_detail_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	detail_box.add_child(_detail_icon)

	_detail_name = Label.new()
	_detail_name.align = Label.ALIGN_CENTER
	_detail_name.autowrap = true
	detail_box.add_child(_detail_name)

	_detail_tier = Label.new()
	_detail_tier.align = Label.ALIGN_CENTER
	detail_box.add_child(_detail_tier)

	_detail_text = RichTextLabel.new()
	_detail_text.bbcode_enabled = true
	_detail_text.scroll_active = true
	_detail_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_detail_text.focus_mode = Control.FOCUS_NONE
	detail_box.add_child(_detail_text)

	var bottom = HBoxContainer.new()
	root.add_child(bottom)

	_give_all_button = Button.new()
	_give_all_button.text = tr("GME_GIVE_ALL")
	_give_all_button.connect("pressed", self, "_on_give_all")
	_style_button(_give_all_button)
	bottom.add_child(_give_all_button)

	_cursed_button = Button.new()
	_cursed_button.text = tr("GME_CURSED")
	_cursed_button.toggle_mode = true
	_cursed_button.pressed = cursed_mode
	_cursed_button.connect("toggled", self, "_on_cursed_toggled")
	_style_button(_cursed_button)
	bottom.add_child(_cursed_button)

	var hints = Label.new()
	var hint_parts = [tr("GME_HINTS_NAV")]
	if ProgressData.available_dlcs.size() > 0:
		hint_parts.append(tr("GME_HINT_CURSED"))
	hint_parts.append(tr("GME_HINT_LOCK"))
	hints.text = "  " + PoolStringArray(hint_parts).join("   ")
	hints.modulate = Color(1, 1, 1, 0.5)
	hints.visible = not Input.get_connected_joypads().empty()
	bottom.add_child(hints)

	_info_label = Label.new()
	_info_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_info_label.align = Label.ALIGN_RIGHT
	bottom.add_child(_info_label)

	if not run_active:
		_info_label.text = tr("GME_NEEDS_RUN")


func _refresh_content() -> void :
	if _guard("_refresh_content"):
		return
	_do_refresh_content()
	_unguard("_refresh_content")


func _do_refresh_content() -> void :
	var focus_owner = _info_label.get_focus_owner()
	if focus_owner != null and _content_holder.is_a_parent_of(focus_owner):
		_tab_buttons[current_tab].grab_focus()
	for child in _content_holder.get_children():
		child.queue_free()
	_give_all_button.visible = GRID_TABS.has(current_tab)
	_search_edit.editable = GRID_TABS.has(current_tab) or current_tab == "unlocks"
	_detail_panel.visible = current_tab != "resources"
	_cursed_button.visible = (current_tab == "items" or current_tab == "weapons") and ProgressData.available_dlcs.size() > 0
	for i in _tier_buttons.size():
		_tier_buttons[i].visible = GRID_TABS.has(current_tab)
	match current_tab:
		"items", "weapons", "upgrades":
			_build_element_grid()
		"resources":
			_build_resources()
		"inventory":
			_build_inventory()
		"unlocks":
			_build_unlocks()


func _detail_player_index() -> int:
	return player_index if run_active else RunData.DUMMY_PLAYER_INDEX


func _grid_columns() -> int:
	var avail = _content_scroll.rect_size.x - 16
	return int(clamp(floor(avail / (ICON_SIZE + GRID_SEPARATION)), 4, 40))


func _on_scroll_resized() -> void :
	if _guard("_on_scroll_resized"):
		return
	if current_tab != "resources" and _grid_columns() != _last_columns:
		_queue_rebuild()
	_unguard("_on_scroll_resized")


func _element_pool() -> Array:
	match current_tab:
		"items":
			return ItemService.items
		"weapons":
			return ItemService.weapons
		"upgrades":
			return ItemService.upgrades
	return []


func _filtered_elements() -> Array:
	var result: = []
	for data in _element_pool():
		if data.my_id == "item_axolotl":
			continue
		if current_tier >= 0 and data.tier != current_tier:
			continue
		if search_text != "" and tr(data.name).to_lower().find(search_text) < 0:
			continue
		result.push_back(data)
	result.sort_custom(self, "_sort_elements")
	return result


func _sort_elements(a, b) -> bool:
	if a.tier != b.tier:
		return a.tier < b.tier
	return tr(a.name) < tr(b.name)


func _make_icon_button(data, count: int = 0, with_tier_style: bool = true) -> Button:
	var b = Button.new()
	b.rect_min_size = Vector2(ICON_SIZE, ICON_SIZE)
	var tex = TextureRect.new()
	tex.texture = data.icon
	tex.expand = true
	tex.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	tex.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	tex.margin_left = 6
	tex.margin_top = 6
	tex.margin_right = - 6
	tex.margin_bottom = - 6
	tex.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(tex)
	if count > 1:
		var count_label = Label.new()
		count_label.text = "x%d" % count
		count_label.set_anchors_and_margins_preset(Control.PRESET_BOTTOM_RIGHT)
		count_label.margin_left = - 34
		count_label.margin_top = - 24
		count_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		b.add_child(count_label)
	if with_tier_style:
		var styles = _get_tier_styles(data.tier)
		for style_name in styles:
			b.add_stylebox_override(style_name, styles[style_name])
	b.connect("focus_entered", self, "_on_element_focused", [b, data])
	b.connect("mouse_entered", self, "_show_details", [data])
	return b


func _build_element_grid() -> void :
	var columns = _grid_columns()
	_last_columns = columns
	var grid = GridContainer.new()
	grid.columns = columns
	grid.add_constant_override("hseparation", GRID_SEPARATION)
	grid.add_constant_override("vseparation", GRID_SEPARATION)
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_content_holder.add_child(grid)
	var buttons: = []
	for data in _filtered_elements():
		var b = _make_icon_button(data)
		b.connect("pressed", self, "_on_element_pressed", [data])
		grid.add_child(b)
		buttons.push_back(b)
	for i in buttons.size():
		var b = buttons[i]
		if i % columns > 0:
			b.focus_neighbour_left = b.get_path_to(buttons[i - 1])
		if i % columns < columns - 1 and i + 1 < buttons.size():
			b.focus_neighbour_right = b.get_path_to(buttons[i + 1])
		if i - columns >= 0:
			b.focus_neighbour_top = b.get_path_to(buttons[i - columns])
		else:
			b.focus_neighbour_top = b.get_path_to(_tab_buttons[current_tab])
		if i + columns < buttons.size():
			b.focus_neighbour_bottom = b.get_path_to(buttons[i + columns])
		else:
			b.focus_neighbour_bottom = b.get_path_to(_give_all_button)
	if not buttons.empty():
		call_deferred("_focus_first", buttons[0])


func _give_payload(kind: String, data) -> Dictionary:
	var cursed = cursed_mode and (kind == "items" or kind == "weapons")
	return {"kind": kind, "id": data.my_id, "cursed": cursed}


func _request(route: String, payload: Dictionary, done_text: String) -> bool:
	payload["player_index"] = player_index
	if mod_main.request(route, payload):
		_info_label.text = done_text
		return true
	_ack_text = done_text
	_info_label.text = tr("GME_SENT_TO_HOST")
	if not _ack_wait_started:
		_ack_wait_started = true
		_last_ack_msec = -1
		get_tree().create_timer(2.0).connect("timeout", self, "_on_ack_timeout")
	return false


func _on_ack_timeout() -> void :
	_ack_wait_started = false
	if _last_ack_msec < 0 and is_instance_valid(_info_label):
		_info_label.text = tr("GME_HOST_NEEDS_MOD")


func on_host_ack(payload: Dictionary) -> void :
	_last_ack_msec = OS.get_ticks_msec()
	if not is_instance_valid(_info_label):
		return
	_info_label.text = _ack_text if bool(payload.get("ok", false)) else tr("GME_HOST_REFUSED")
	if current_tab == "inventory" or current_tab == "resources":
		_queue_rebuild()


func _on_element_pressed(data) -> void :
	_request("give", _give_payload(current_tab, data), tr("GME_GIVEN") % tr(data.name))


func _on_give_all() -> void :
	var elements = _filtered_elements()
	for data in elements:
		_request("give", _give_payload(current_tab, data), tr("GME_GIVEN_N") % elements.size())


func _get_player_node():
	return mod_main.get_player_node(player_index)


func _on_element_focused(button: Control, data) -> void :
	if not is_instance_valid(button) or not button.is_inside_tree() or button.is_queued_for_deletion():
		return
	if _guard("_on_element_focused"):
		return
	_content_scroll.ensure_control_visible(button)
	_show_details(data)
	_unguard("_on_element_focused")


func _tier_color(tier: int, dark_version: bool = false) -> Color:
	if tier == 0:
		return ItemService.TIER_DANGER_0_COLOR_DARK if dark_version else ItemService.TIER_DANGER_0_COLOR
	return ItemService.get_color_from_tier(tier, dark_version)


func _get_tier_styles(tier: int) -> Dictionary:
	if _tier_style_cache.has(tier):
		return _tier_style_cache[tier]
	var color = _tier_color(tier)
	var dark = _tier_color(tier, true)
	var normal = StyleBoxFlat.new()
	normal.bg_color = dark
	normal.border_color = color
	normal.set_border_width_all(2)
	normal.set_corner_radius_all(4)
	var hover = normal.duplicate()
	hover.bg_color = dark.lightened(0.25)
	hover.border_color = color.lightened(0.3)
	var focus = StyleBoxFlat.new()
	focus.draw_center = false
	focus.border_color = Color(1, 1, 1)
	focus.set_border_width_all(3)
	focus.set_corner_radius_all(4)
	var styles = {"normal": normal, "hover": hover, "pressed": hover, "hover_pressed": hover, "focus": focus}
	_tier_style_cache[tier] = styles
	return styles


func _style_button(b: Button) -> void :
	if not _tier_style_cache.has("ui"):
		var normal = StyleBoxFlat.new()
		normal.bg_color = BTN_BG
		normal.border_color = BTN_BORDER
		normal.set_border_width_all(1)
		normal.set_corner_radius_all(4)
		normal.content_margin_left = 10
		normal.content_margin_right = 10
		normal.content_margin_top = 4
		normal.content_margin_bottom = 4
		var hover = normal.duplicate()
		hover.bg_color = Color(0.32, 0.32, 0.36)
		hover.border_color = Color(0.85, 0.85, 0.9)
		var pressed = normal.duplicate()
		pressed.bg_color = ACCENT
		pressed.border_color = ACCENT
		var hover_pressed = pressed.duplicate()
		hover_pressed.bg_color = ACCENT.lightened(0.15)
		var disabled = normal.duplicate()
		disabled.bg_color = Color(0.09, 0.09, 0.1)
		disabled.border_color = Color(0.2, 0.2, 0.22)
		var focus = StyleBoxFlat.new()
		focus.draw_center = false
		focus.border_color = Color(1, 1, 1)
		focus.set_border_width_all(2)
		focus.set_corner_radius_all(4)
		_tier_style_cache["ui"] = {"normal": normal, "hover": hover, "pressed": pressed, "hover_pressed": hover_pressed, "disabled": disabled, "focus": focus}
	var styles = _tier_style_cache["ui"]
	for style_name in styles:
		b.add_stylebox_override(style_name, styles[style_name])
	b.add_color_override("font_color", Color(0.92, 0.92, 0.92))
	b.add_color_override("font_color_hover", Color(1, 1, 1))
	b.add_color_override("font_color_focus", Color(1, 1, 1))
	b.add_color_override("font_color_pressed", Color(0.12, 0.1, 0.05))


func _show_details(data) -> void :
	if _guard("_show_details"):
		return
	_do_show_details(data)
	_unguard("_show_details")


func _do_show_details(data) -> void :
	var pi = _detail_player_index()
	_detail_icon.texture = data.icon
	_detail_name.text = tr(data.name)
	var text = ""
	if current_tab == "unlocks":
		var unlocked = _is_unlocked_entry(data)
		_detail_name.add_color_override("font_color", Color(1, 1, 1))
		if unlock_section == "wins":
			var win_value = _get_win(data)
			_detail_tier.text = tr("GME_WIN_STATE") % _win_state_text(win_value)
			_detail_tier.add_color_override("font_color", _tier_color(win_value) if win_value >= 0 else Color(0.6, 0.6, 0.6))
		else:
			_detail_tier.text = tr("GME_UNLOCKED") if unlocked else tr("GME_LOCKED")
			_detail_tier.add_color_override("font_color", Color(0.35, 1.0, 0.35) if unlocked else Color(0.6, 0.6, 0.6))
		if unlock_section == "challenges":
			text = tr(data.description)
		elif run_active and data.has_method("get_effects_text"):
			text = data.get_effects_text(pi)
	else:
		_detail_name.add_color_override("font_color", _tier_color(data.tier))
		_detail_tier.text = tr("GME_TIER_N") % (data.tier + 1)
		_detail_tier.add_color_override("font_color", _tier_color(data.tier))
		if data.has_method("get_weapon_stats_text"):
			text = data.get_weapon_stats_text(pi)
			var effects_text = data.get_effects_text(pi)
			if effects_text != "":
				text += "\n" + effects_text
		elif data.has_method("get_effects_text"):
			text = data.get_effects_text(pi)
	_detail_text.bbcode_text = text


func _build_resources() -> void :
	var box = VBoxContainer.new()
	box.add_constant_override("separation", 16)
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_content_holder.add_child(box)

	var gold_row = _make_row(box, tr("GME_GOLD"))
	var first_button = null
	for amount in [-1000, -100, 100, 1000]:
		var b = Button.new()
		b.text = ("+%d" % amount) if amount > 0 else str(amount)
		b.connect("pressed", self, "_on_gold_pressed", [amount])
		_style_button(b)
		gold_row.add_child(b)
		if first_button == null:
			first_button = b
	var inf = Button.new()
	inf.text = tr("GME_INFINITE")
	inf.toggle_mode = true
	inf.pressed = mod_main.gold_infinite[player_index]
	inf.connect("toggled", self, "_on_gold_infinite_toggled")
	_style_button(inf)
	gold_row.add_child(inf)

	var xp_row = _make_row(box, tr("GME_XP"))
	for amount in [10, 100, 1000]:
		var b = Button.new()
		b.text = "+%d" % amount
		b.connect("pressed", self, "_on_xp_pressed", [amount])
		_style_button(b)
		xp_row.add_child(b)

	var cheats_row = _make_row(box, tr("GME_CHEATS"))
	for entry in [["GME_INVULNERABLE", "invulnerable"], ["GME_ONE_SHOT", "one_shot"], ["GME_INSTANT_WAVES", "instant_waves"], ["GME_HIDE_TIMER", "hide_timer"]]:
		var b = Button.new()
		b.text = tr(entry[0])
		b.toggle_mode = true
		b.pressed = _cheat_state(entry[1])
		b.connect("toggled", self, "_on_cheat_toggled", [entry[1]])
		_style_button(b)
		cheats_row.add_child(b)
	if get_tree().current_scene.get("_wave_timer") != null:
		var end_wave = Button.new()
		end_wave.text = tr("GME_END_WAVE")
		end_wave.connect("pressed", self, "_on_end_wave")
		_style_button(end_wave)
		cheats_row.add_child(end_wave)

	var wave_row = _make_row(box, tr("GME_STARTING_WAVE"))
	var minus = Button.new()
	minus.text = "-"
	minus.connect("pressed", self, "_on_starting_wave_changed", [-1])
	_style_button(minus)
	wave_row.add_child(minus)
	_wave_value_label = Label.new()
	_wave_value_label.text = str(DebugService.starting_wave)
	_wave_value_label.rect_min_size.x = 40
	_wave_value_label.align = Label.ALIGN_CENTER
	wave_row.add_child(_wave_value_label)
	var plus = Button.new()
	plus.text = "+"
	plus.connect("pressed", self, "_on_starting_wave_changed", [1])
	_style_button(plus)
	wave_row.add_child(plus)

	if get_tree().current_scene.get("_consumables_container") != null:
		var cons_row = _make_row(box, tr("GME_CONSUMABLES"))
		for data in ItemService.consumables:
			if data.icon == null:
				continue
			var b = _make_icon_button(data)
			b.connect("pressed", self, "_on_spawn_consumable", [data])
			cons_row.add_child(b)

	if first_button != null:
		call_deferred("_focus_first", first_button)


func _on_end_wave() -> void :
	var scene = get_tree().current_scene
	var timer = scene.get("_wave_timer")
	if timer == null:
		return
	timer.stop()
	scene._on_WaveTimer_timeout()
	close()


func _on_starting_wave_changed(delta: int) -> void :
	DebugService.starting_wave = int(clamp(DebugService.starting_wave + delta, 1, 100))
	_wave_value_label.text = str(DebugService.starting_wave)


func _on_spawn_consumable(data) -> void :
	var scene = get_tree().current_scene
	var player = _get_player_node()
	if player == null or scene.get("consumable_scene") == null:
		return
	var consumable = scene.consumable_scene.instance()
	consumable.consumable_data = data
	scene._consumables_container.add_child(consumable)
	var _error = consumable.connect("picked_up", scene, "on_consumable_picked_up")
	consumable.set_texture(data.icon)
	var pos = player.global_position
	consumable.drop(pos, 0, Vector2(pos.x + rand_range(-150, 150), pos.y + rand_range(-150, 150)))
	scene._consumables.push_back(consumable)
	_info_label.text = tr("GME_SPAWNED") % tr(data.name)


func _make_row(parent: Control, label_text: String) -> HBoxContainer:
	var row = HBoxContainer.new()
	row.add_constant_override("separation", 8)
	parent.add_child(row)
	var label = Label.new()
	label.text = label_text
	label.rect_min_size.x = 120
	label.add_color_override("font_color", ACCENT)
	row.add_child(label)
	return row


func _cheat_state(flag: String) -> bool:
	match flag:
		"invulnerable":
			return DebugService.invulnerable
		"one_shot":
			return DebugService.one_shot_enemies
		"instant_waves":
			return DebugService.instant_waves
		"hide_timer":
			return DebugService.hide_wave_timer
	return false


func _on_cheat_toggled(pressed: bool, flag: String) -> void :
	match flag:
		"invulnerable":
			DebugService.invulnerable = pressed
			RunData.invulnerable = pressed
		"one_shot":
			DebugService.one_shot_enemies = pressed
		"instant_waves":
			DebugService.instant_waves = pressed
			RunData.instant_waves = pressed
		"hide_timer":
			DebugService.hide_wave_timer = pressed
	_info_label.text = "%s: %s" % [tr("GME_CHEATS"), tr("GME_ON") if pressed else tr("GME_OFF")]


func _on_gold_pressed(amount: int) -> void :
	if _request("gold", {"amount": amount}, tr("GME_GOLD")):
		_info_label.text = tr("GME_GOLD_N") % RunData.players_data[player_index].gold


func _on_gold_infinite_toggled(pressed: bool) -> void :
	mod_main.gold_infinite[player_index] = pressed
	_request("gold_infinite", {"pressed": pressed}, tr("GME_INFINITE_GOLD") % (tr("GME_ON") if pressed else tr("GME_OFF")))


func _on_xp_pressed(amount: int) -> void :
	if _request("xp", {"amount": amount}, tr("GME_XP")):
		_info_label.text = tr("GME_LEVEL_N") % RunData.players_data[player_index].current_level


func _build_inventory() -> void :
	var box = VBoxContainer.new()
	box.add_constant_override("separation", 12)
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_content_holder.add_child(box)

	var hint = Label.new()
	hint.text = tr("GME_REMOVE_HINT")
	hint.modulate = Color(1, 1, 1, 0.5)
	box.add_child(hint)

	var actions = HBoxContainer.new()
	actions.add_constant_override("separation", 8)
	box.add_child(actions)
	var clear_weapons = Button.new()
	clear_weapons.text = tr("GME_REMOVE_ALL_WEAPONS")
	clear_weapons.connect("pressed", self, "_on_remove_all_weapons")
	_style_button(clear_weapons)
	actions.add_child(clear_weapons)
	var clear_items = Button.new()
	clear_items.text = tr("GME_REMOVE_ALL_ITEMS")
	clear_items.connect("pressed", self, "_on_remove_all_items")
	_style_button(clear_items)
	actions.add_child(clear_items)

	var first_button = null
	var weapons = RunData.get_player_weapons(player_index)
	var items = _player_items_without_character()

	if weapons.empty() and items.empty():
		var empty = Label.new()
		empty.text = tr("GME_EMPTY_INVENTORY")
		box.add_child(empty)
		_build_loadouts(box)
		return

	if not weapons.empty():
		var weapons_label = Label.new()
		weapons_label.text = tr("GME_TAB_WEAPONS")
		weapons_label.add_color_override("font_color", ACCENT)
		box.add_child(weapons_label)
		var weapons_grid = GridContainer.new()
		weapons_grid.columns = _grid_columns()
		weapons_grid.add_constant_override("hseparation", GRID_SEPARATION)
		weapons_grid.add_constant_override("vseparation", GRID_SEPARATION)
		box.add_child(weapons_grid)
		for i in weapons.size():
			var b = _make_icon_button(weapons[i])
			b.connect("pressed", self, "_on_remove_weapon_pressed", [i, weapons[i]])
			weapons_grid.add_child(b)
			if first_button == null:
				first_button = b

	if not items.empty():
		var items_label = Label.new()
		items_label.text = tr("GME_TAB_ITEMS")
		items_label.add_color_override("font_color", ACCENT)
		box.add_child(items_label)
		var items_grid = GridContainer.new()
		items_grid.columns = _grid_columns()
		items_grid.add_constant_override("hseparation", GRID_SEPARATION)
		items_grid.add_constant_override("vseparation", GRID_SEPARATION)
		box.add_child(items_grid)
		var unique: = {}
		var order: = []
		for item in items:
			var id_hash = item.my_id_hash
			if unique.has(id_hash):
				unique[id_hash][1] += 1
			else:
				unique[id_hash] = [item, 1]
				order.push_back(id_hash)
		for id_hash in order:
			var entry = unique[id_hash]
			var b = _make_icon_button(entry[0], entry[1])
			b.connect("pressed", self, "_on_remove_item_pressed", [entry[0]])
			items_grid.add_child(b)
			if first_button == null:
				first_button = b

	_build_loadouts(box)

	if first_button != null:
		call_deferred("_focus_first", first_button)


func _build_loadouts(box: Control) -> void :
	box.add_child(HSeparator.new())
	var lo_label = Label.new()
	lo_label.text = tr("GME_LOADOUTS")
	lo_label.add_color_override("font_color", ACCENT)
	box.add_child(lo_label)

	var save_row = HBoxContainer.new()
	save_row.add_constant_override("separation", 8)
	box.add_child(save_row)
	_loadout_name_edit = LineEdit.new()
	_loadout_name_edit.placeholder_text = tr("GME_LOADOUT_NAME")
	_loadout_name_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_loadout_name_edit.focus_mode = Control.FOCUS_CLICK
	save_row.add_child(_loadout_name_edit)
	var save_button = Button.new()
	save_button.text = tr("GME_SAVE_LOADOUT")
	save_button.connect("pressed", self, "_on_save_loadout")
	_style_button(save_button)
	save_row.add_child(save_button)

	var names = mod_main.loadouts.keys()
	names.sort()
	for lo_name in names:
		var row = HBoxContainer.new()
		row.add_constant_override("separation", 8)
		box.add_child(row)
		var name_label = Label.new()
		name_label.text = lo_name
		name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(name_label)
		var apply_button = Button.new()
		apply_button.text = tr("GME_APPLY")
		apply_button.connect("pressed", self, "_on_apply_loadout", [lo_name])
		_style_button(apply_button)
		row.add_child(apply_button)
		var delete_button = Button.new()
		delete_button.text = tr("GME_DELETE")
		delete_button.connect("pressed", self, "_on_delete_loadout", [lo_name])
		_style_button(delete_button)
		row.add_child(delete_button)


func _player_items_without_character() -> Array:
	var result: = []
	for item in RunData.get_player_items(player_index):
		if not (item is CharacterData):
			result.push_back(item)
	return result


func _find_by_id(pool: Array, my_id: String):
	for data in pool:
		if data.my_id == my_id:
			return data
	return null


func _on_save_loadout() -> void :
	var lo_name = _loadout_name_edit.text.strip_edges()
	if lo_name == "":
		lo_name = "Loadout %d" % (mod_main.loadouts.size() + 1)
	var weapons: = []
	for weapon in RunData.get_player_weapons(player_index):
		weapons.push_back(weapon.my_id)
	var items: = {}
	for item in _player_items_without_character():
		items[item.my_id] = items.get(item.my_id, 0) + 1
	mod_main.save_loadout(lo_name, {"weapons": weapons, "items": items})
	_info_label.text = tr("GME_LOADOUT_SAVED") % lo_name
	_queue_rebuild()


func _on_apply_loadout(lo_name: String) -> void :
	var loadout = mod_main.loadouts.get(lo_name)
	if loadout == null:
		return
	var done_text = tr("GME_LOADOUT_APPLIED") % lo_name
	for weapon_id in loadout.get("weapons", []):
		var weapon = _find_by_id(ItemService.weapons, weapon_id)
		if weapon != null:
			_request("give", {"kind": "weapons", "id": weapon.my_id, "cursed": false}, done_text)
	var items = loadout.get("items", {})
	for item_id in items:
		var item = _find_by_id(ItemService.items, item_id)
		if item != null:
			for _n in int(items[item_id]):
				_request("give", {"kind": "items", "id": item.my_id, "cursed": false}, done_text)
	_queue_rebuild()


func _on_delete_loadout(lo_name: String) -> void :
	mod_main.delete_loadout(lo_name)
	_queue_rebuild()


func _on_remove_all_weapons() -> void :
	_request("remove_all_weapons", {}, tr("GME_REMOVED") % tr("GME_TAB_WEAPONS"))
	_queue_rebuild()


func _on_remove_all_items() -> void :
	_request("remove_all_items", {}, tr("GME_REMOVED") % tr("GME_TAB_ITEMS"))
	_queue_rebuild()


func _on_remove_weapon_pressed(index: int, weapon) -> void :
	_request("remove_weapon", {"index": index}, tr("GME_REMOVED") % tr(weapon.name))
	_queue_rebuild()


func _on_remove_item_pressed(item) -> void :
	_request("remove_item", {"id": item.my_id}, tr("GME_REMOVED") % tr(item.name))
	_queue_rebuild()


func _build_unlocks() -> void :
	var box = VBoxContainer.new()
	box.add_constant_override("separation", 12)
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_content_holder.add_child(box)

	var sections = HBoxContainer.new()
	sections.add_constant_override("separation", 8)
	box.add_child(sections)
	var section_group = ButtonGroup.new()
	for entry in SECTION_DEFS:
		var b = Button.new()
		b.text = tr(entry[1])
		b.toggle_mode = true
		b.group = section_group
		b.pressed = entry[0] == unlock_section
		b.connect("pressed", self, "_on_unlock_section_pressed", [entry[0]])
		_style_button(b)
		sections.add_child(b)

	var spacer = Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sections.add_child(spacer)

	_section_all_button = Button.new()
	_section_all_button.text = tr("GME_CONFIRM") if _section_all_confirm_pending else _section_all_text()
	_section_all_button.connect("pressed", self, "_on_unlock_section_all")
	_style_button(_section_all_button)
	sections.add_child(_section_all_button)

	var hint = Label.new()
	hint.text = tr("GME_WIN_HINT") if unlock_section == "wins" else tr("GME_UNLOCK_HINT")
	hint.modulate = Color(1, 1, 1, 0.5)
	box.add_child(hint)

	if unlock_section == "wins":
		var brush_row = _make_row(box, tr("GME_WIN_BRUSH"))
		var brush_group = ButtonGroup.new()
		for value in [-1, 0, 1, 2, 3, 4, 5, 6]:
			var b = Button.new()
			if value < 0:
				b.text = tr("GME_WIN_NONE")
			elif value == 6:
				b.text = tr("GME_NIGHTMARE")
			else:
				b.text = "P%d" % value
			b.toggle_mode = true
			b.group = brush_group
			b.pressed = value == win_brush
			b.connect("pressed", self, "_on_win_brush_pressed", [value])
			_style_button(b)
			brush_row.add_child(b)

	var grid = GridContainer.new()
	grid.columns = _grid_columns()
	grid.add_constant_override("hseparation", GRID_SEPARATION)
	grid.add_constant_override("vseparation", GRID_SEPARATION)
	box.add_child(grid)
	var first_button = null
	for data in _filtered_unlock_pool():
		var b = _make_icon_button(data, 0, false)
		if unlock_section == "wins":
			_apply_win_style(b, _get_win(data))
		else:
			_apply_unlock_style(b, _is_unlocked_entry(data))
		b.connect("pressed", self, "_on_unlock_toggle", [b, data])
		grid.add_child(b)
		if first_button == null:
			first_button = b

	if first_button != null:
		call_deferred("_focus_first", first_button)


func _entry_hash(data) -> int:
	if unlock_section == "weapons":
		return data.get_weapon_id_hash()
	if data.has_method("get_my_id_hash"):
		return data.get_my_id_hash()
	return data.my_id_hash


func _unlock_pool_all() -> Array:
	var pool: = []
	match unlock_section:
		"characters", "danger", "wins":
			pool = ItemService.characters
		"items":
			pool = ItemService.items
		"weapons":
			pool = ItemService.weapons
		"enemies":
			pool = ItemService.entities
		"challenges":
			pool = ChallengeService.challenges
	var seen: = {}
	var result: = []
	for data in pool:
		var id_hash = _entry_hash(data)
		if seen.has(id_hash):
			continue
		seen[id_hash] = true
		if data.icon == null:
			continue
		result.push_back(data)
	return result


func _filtered_unlock_pool() -> Array:
	var result: = []
	for data in _unlock_pool_all():
		if search_text != "" and tr(data.name).to_lower().find(search_text) < 0:
			continue
		result.push_back(data)
	result.sort_custom(self, "_sort_by_name")
	return result


func _is_section_all_unlocked() -> bool:
	for data in _unlock_pool_all():
		if not _is_unlocked_entry(data):
			return false
	return true


func _sort_by_name(a, b) -> bool:
	return tr(a.name) < tr(b.name)


func _is_unlocked_entry(data) -> bool:
	var id_hash = _entry_hash(data)
	match unlock_section:
		"characters":
			return ProgressData.characters_unlocked.has(id_hash)
		"items":
			return ProgressData.items_unlocked.has(id_hash)
		"weapons":
			return ProgressData.weapons_unlocked.has(id_hash)
		"enemies":
			return ProgressData.killed_enemies.has(id_hash)
		"challenges":
			return ChallengeService.is_challenge_completed(id_hash)
		"wins":
			return _get_win(data) >= 0
		"danger":
			for info in ProgressData.difficulties_unlocked:
				if info.character_id == data.my_id:
					for zone_info in info.zones_difficulty_info:
						if zone_info.max_selectable_difficulty >= ProgressData.MAX_DIFFICULTY:
							return true
			return false
	return false


func _set_unlocked_entry(data, value: bool) -> void :
	var id_hash = _entry_hash(data)
	match unlock_section:
		"characters":
			if value:
				ProgressData.characters_unlocked.push_back(id_hash)
			else:
				ProgressData.characters_unlocked.erase(id_hash)
		"items":
			if value:
				ProgressData.items_unlocked.push_back(id_hash)
				ProgressData.items_bought[id_hash] = 10
			else:
				ProgressData.items_unlocked.erase(id_hash)
				ProgressData.items_bought.erase(id_hash)
		"weapons":
			if value:
				ProgressData.weapons_unlocked.push_back(id_hash)
			else:
				ProgressData.weapons_unlocked.erase(id_hash)
		"enemies":
			if value:
				ProgressData.killed_enemies[id_hash] = 1000
			else:
				ProgressData.killed_enemies.erase(id_hash)
		"challenges":
			if value:
				ChallengeService.complete_challenge(id_hash)
			else:
				ProgressData.challenges_completed.erase(id_hash)
				ChallengeService._challenges_completed_map.erase(id_hash)
		"danger":
			for i in range(ProgressData.difficulties_unlocked.size() - 1, -1, -1):
				if ProgressData.difficulties_unlocked[i].character_id == data.my_id:
					ProgressData.difficulties_unlocked.remove(i)
			if value:
				var info = CharacterDifficultyInfo.new(data.my_id)
				for zone in ZoneService.zones:
					if zone.unlocked_by_default:
						var zone_info = ZoneDifficultyInfo.new(zone.my_id)
						zone_info.max_selectable_difficulty = ProgressData.MAX_DIFFICULTY
						info.zones_difficulty_info.push_back(zone_info)
				ProgressData.difficulties_unlocked.push_back(info)


func _find_char_difficulty_info(data):
	for info in ProgressData.difficulties_unlocked:
		if info.character_id == data.my_id:
			return info
	return null


func _get_win(data) -> int:
	var info = _find_char_difficulty_info(data)
	if info == null or info.zones_difficulty_info.empty():
		return -1
	return info.zones_difficulty_info[0].max_difficulty_beaten.difficulty_value


func _set_win(data, value: int) -> void :
	var info = _find_char_difficulty_info(data)
	if info == null:
		info = CharacterDifficultyInfo.new(data.my_id)
		for zone in ZoneService.zones:
			if zone.unlocked_by_default:
				var zone_info = ZoneDifficultyInfo.new(zone.my_id)
				info.zones_difficulty_info.push_back(zone_info)
		ProgressData.difficulties_unlocked.push_back(info)
	for zone_info in info.zones_difficulty_info:
		zone_info.max_difficulty_beaten.difficulty_value = value
		zone_info.max_difficulty_beaten.wave_number = 20 if value >= 0 else -1
		if value >= 0:
			zone_info.max_selectable_difficulty = int(max(zone_info.max_selectable_difficulty, min(value + 1, ProgressData.MAX_DIFFICULTY)))


func _apply_win_style(button: Button, value: int) -> void :
	var key = "win_%d" % value
	if not _tier_style_cache.has(key):
		var color = Color(0.45, 0.45, 0.45) if value < 0 else _tier_color(value)
		var dark = Color(0.1, 0.1, 0.1) if value < 0 else _tier_color(value, true)
		var normal = StyleBoxFlat.new()
		normal.bg_color = dark
		normal.border_color = color
		normal.set_border_width_all(4 if value >= 5 else 2)
		normal.set_corner_radius_all(4)
		var hover = normal.duplicate()
		hover.bg_color = dark.lightened(0.25)
		var focus = StyleBoxFlat.new()
		focus.draw_center = false
		focus.border_color = Color(1, 1, 1)
		focus.set_border_width_all(3)
		focus.set_corner_radius_all(4)
		_tier_style_cache[key] = {"normal": normal, "hover": hover, "pressed": hover, "hover_pressed": hover, "focus": focus}
	var styles = _tier_style_cache[key]
	for style_name in styles:
		button.add_stylebox_override(style_name, styles[style_name])
	button.modulate = Color(0.55, 0.55, 0.55) if value < 0 else Color(1, 1, 1)


func _win_state_text(value: int) -> String:
	if value < 0:
		return tr("GME_WIN_NONE")
	if value >= 6:
		return tr("GME_NIGHTMARE")
	return tr("GME_DANGER_N") % value


func _on_win_brush_pressed(value: int) -> void :
	win_brush = value


func _apply_unlock_style(button: Button, unlocked: bool) -> void :
	var key = "unlocked" if unlocked else "locked"
	if not _tier_style_cache.has(key):
		var color = Color(0.35, 1.0, 0.35) if unlocked else Color(0.8, 0.3, 0.3)
		var normal = StyleBoxFlat.new()
		normal.bg_color = Color(0.08, 0.12, 0.08) if unlocked else Color(0.12, 0.08, 0.08)
		normal.border_color = color
		normal.set_border_width_all(2)
		normal.set_corner_radius_all(4)
		var hover = normal.duplicate()
		hover.bg_color = normal.bg_color.lightened(0.25)
		hover.border_color = color.lightened(0.3)
		var focus = StyleBoxFlat.new()
		focus.draw_center = false
		focus.border_color = Color(1, 1, 1)
		focus.set_border_width_all(3)
		focus.set_corner_radius_all(4)
		_tier_style_cache[key] = {"normal": normal, "hover": hover, "pressed": hover, "hover_pressed": hover, "focus": focus}
	var styles = _tier_style_cache[key]
	for style_name in styles:
		button.add_stylebox_override(style_name, styles[style_name])
	button.modulate = Color(1, 1, 1) if unlocked else Color(0.55, 0.55, 0.55)


func _on_unlock_section_pressed(section: String) -> void :
	unlock_section = section
	_section_all_confirm_pending = false
	_queue_rebuild()


func _section_all_text() -> String:
	return tr("GME_LOCK_ALL_SECTION") if _is_section_all_unlocked() else tr("GME_UNLOCK_ALL_SECTION")


func _on_unlock_toggle(button: Button, data) -> void :
	if unlock_section == "wins":
		var value = -1 if _get_win(data) == win_brush else win_brush
		_set_win(data, value)
		ProgressData.save()
		_apply_win_style(button, value)
		_show_details(data)
		_info_label.text = "%s: %s" % [tr(data.name), _win_state_text(value)]
		return
	var unlocked = not _is_unlocked_entry(data)
	_set_unlocked_entry(data, unlocked)
	ProgressData.save()
	_apply_unlock_style(button, unlocked)
	_show_details(data)
	_info_label.text = "%s: %s" % [tr(data.name), tr("GME_UNLOCKED") if unlocked else tr("GME_LOCKED")]


func _on_unlock_section_all() -> void :
	if not _section_all_confirm_pending:
		_section_all_confirm_pending = true
		_section_all_button.text = tr("GME_CONFIRM")
		get_tree().create_timer(3.0).connect("timeout", self, "_on_section_all_confirm_timeout")
		return
	_section_all_confirm_pending = false
	_apply_section_all()


func _on_section_all_confirm_timeout() -> void :
	if not _section_all_confirm_pending:
		return
	_section_all_confirm_pending = false
	if is_instance_valid(_section_all_button):
		_section_all_button.text = _section_all_text()


func _complete_all_challenges_quiet() -> void :
	for chal in ChallengeService.challenges:
		var id_hash = chal.get_my_id_hash()
		if ChallengeService.is_challenge_completed(id_hash):
			continue
		ProgressData.challenges_completed.append(id_hash)
		ChallengeService._challenges_completed_map[id_hash] = true
		ChallengeService.unlock_reward(chal)


func _apply_section_all() -> void :
	if _is_section_all_unlocked():
		for data in _unlock_pool_all():
			if unlock_section == "wins":
				_set_win(data, -1)
			else:
				_set_unlocked_entry(data, false)
		_info_label.text = tr("GME_LOCKED_ALL") % unlock_section
	else:
		match unlock_section:
			"characters":
				ProgressData.unlock_all_characters()
			"items":
				ProgressData.unlock_all_items()
			"weapons":
				ProgressData.unlock_all_weapoons()
			"enemies":
				ProgressData.unlock_all_enemies()
			"challenges":
				_complete_all_challenges_quiet()
			"wins":
				for character in ItemService.characters:
					_set_win(character, win_brush)
			"danger":
				ProgressData.unlock_all_difficulties()
		_info_label.text = tr("GME_UNLOCKED_ALL") % unlock_section
	ProgressData.save()
	_queue_rebuild()


func _on_cursed_toggled(pressed: bool) -> void :
	cursed_mode = pressed


func _on_player_selected(index: int) -> void :
	player_index = index
	_queue_rebuild()


func _on_tab_pressed(tab: String) -> void :
	current_tab = tab
	_queue_rebuild()


func _on_tier_pressed(tier: int) -> void :
	current_tier = tier
	_queue_rebuild()


func _on_search_changed(text: String) -> void :
	search_text = text.to_lower()
	_queue_rebuild()
