extends Node

const MOD_DIR = "opaaaaaaaaaaaa-GiveMeEverything/"
const LOG_NAME = "opaaaaaaaaaaaa-GiveMeEverything"

const KEYS = {
	"F2": KEY_F2,
	"F3": KEY_F3,
	"F4": KEY_F4,
	"F6": KEY_F6,
	"F7": KEY_F7,
	"F8": KEY_F8,
	"F9": KEY_F9,
	"F10": KEY_F10,
	"F12": KEY_F12,
}

const LOADOUTS_PATH = "user://gme_loadouts.json"

var open_scancode: int = KEY_F6
var controller_shortcut: String = "L3 + R3"
var pause_when_open: bool = true
var menu_scale: float = 1.0
var gold_infinite: = [false, false, false, false]
var loadouts: = {}

var _menu = null
var _menu_script = null
var _key_name: String = "F6"
var _open_key_down: = false
var _open_joy_down: = false


func _init() -> void :
	ModLoaderLog.info("Init", LOG_NAME)
	var dir = ModLoaderMod.get_unpacked_dir() + MOD_DIR
	_menu_script = load(dir + "ui/gme_menu.gd")
	var i18n = load(dir + "i18n.gd")
	i18n.install()


func _ready() -> void :
	pause_mode = PAUSE_MODE_PROCESS
	_load_config()
	_load_loadouts()
	call_deferred("_connect_mod_options")


func save_loadout(loadout_name: String, data: Dictionary) -> void :
	loadouts[loadout_name] = data
	_save_loadouts()


func delete_loadout(loadout_name: String) -> void :
	loadouts.erase(loadout_name)
	_save_loadouts()


func _load_loadouts() -> void :
	var f = File.new()
	if not f.file_exists(LOADOUTS_PATH):
		return
	if f.open(LOADOUTS_PATH, File.READ) != OK:
		return
	var parsed = parse_json(f.get_as_text())
	f.close()
	if parsed is Dictionary:
		loadouts = parsed


func _save_loadouts() -> void :
	var f = File.new()
	if f.open(LOADOUTS_PATH, File.WRITE) == OK:
		f.store_string(to_json(loadouts))
		f.close()


func _process(_delta: float) -> void :
	_poll_open_shortcut()
	_refill_infinite_gold()


func _poll_open_shortcut() -> void :
	var key_down = Input.is_key_pressed(open_scancode)
	if key_down and not _open_key_down:
		toggle_menu()
	_open_key_down = key_down
	var joy_down = false
	for device in Input.get_connected_joypads():
		if controller_shortcut == "L3 + R3":
			joy_down = joy_down or (Input.is_joy_button_pressed(device, JOY_L3) and Input.is_joy_button_pressed(device, JOY_R3))
		elif controller_shortcut == "Select/Back":
			joy_down = joy_down or Input.is_joy_button_pressed(device, JOY_SELECT)
	if joy_down and not _open_joy_down:
		toggle_menu()
	_open_joy_down = joy_down


func _refill_infinite_gold() -> void :
	if RunData.players_data.empty():
		return
	for i in RunData.get_player_count():
		if gold_infinite[i] and RunData.players_data[i].gold < 999000:
			RunData.add_gold(999999 - RunData.players_data[i].gold, i)


func toggle_menu() -> void :
	if is_instance_valid(_menu):
		_menu.close()
		return
	_menu = _menu_script.new()
	_menu.mod_main = self
	_menu.pause_when_open = pause_when_open
	get_tree().root.add_child(_menu)


func _load_config() -> void :
	var configs = ModLoaderConfig.get_configs(LOG_NAME)
	var config = configs.get("current", configs.get("default"))
	if config == null:
		return
	_apply_setting("open_key", config.data.get("open_key", _key_name))
	_apply_setting("controller_shortcut", config.data.get("controller_shortcut", controller_shortcut))
	_apply_setting("pause_when_open", config.data.get("pause_when_open", pause_when_open))
	_apply_setting("menu_scale", config.data.get("menu_scale", menu_scale))


func _connect_mod_options() -> void :
	var iface = get_node_or_null("/root/ModLoader/dami-ModOptions/ModsConfigInterface")
	if iface != null and not iface.is_connected("setting_changed", self, "_on_setting_changed"):
		iface.connect("setting_changed", self, "_on_setting_changed")


var _in_setting_changed: = false


func _on_setting_changed(setting_name: String, value, mod_name: String) -> void :
	if mod_name != LOG_NAME or _in_setting_changed:
		return
	_in_setting_changed = true
	_apply_setting(setting_name, value)
	_save_config()
	_in_setting_changed = false


func _apply_setting(setting_name: String, value) -> void :
	match setting_name:
		"open_key":
			_key_name = str(value)
			open_scancode = KEYS.get(_key_name, KEY_F6)
		"controller_shortcut":
			controller_shortcut = str(value)
		"pause_when_open":
			pause_when_open = bool(value)
		"menu_scale":
			menu_scale = float(value)
			if is_instance_valid(_menu):
				_menu._layout_panel()


func _save_config() -> void :
	var data: = {
		"open_key": _key_name,
		"controller_shortcut": controller_shortcut,
		"pause_when_open": pause_when_open,
		"menu_scale": menu_scale,
	}
	var config = ModLoaderConfig.get_config(LOG_NAME, "current")
	if config == null:
		config = ModLoaderConfig.create_config(LOG_NAME, "current", data)
	else:
		config.data = data
		config = ModLoaderConfig.update_config(config)
	if config != null:
		ModLoaderConfig.set_current_config(config)
