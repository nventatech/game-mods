extends Node

const MOD_DIR = "opaaaaaaaaaaaa-GiveMeEverything/"
const LOG_NAME = "opaaaaaaaaaaaa-GiveMeEverything"

const KEYS = {
	"F2": KEY_F2,
	"F3": KEY_F3,
	"F4": KEY_F4,
	"F6": KEY_F6,
	"F7": KEY_F7,
	"F8": KEY_F8,
	"F9": KEY_F9,
	"F10": KEY_F10,
	"F12": KEY_F12,
}

const LOADOUTS_PATH = "user://gme_loadouts.json"
const BO_API_GROUP = "brotato_online_api"
const BO_OPTIONS = {"scope": "menu", "reliable": true}

var open_scancode: int = KEY_F6
var controller_shortcut: String = "L3 + R3"
var pause_when_open: bool = true
var menu_scale: float = 1.0
var gold_infinite: = [false, false, false, false]
var loadouts: = {}

var _menu = null
var _menu_script = null
var _key_name: String = "F6"
var _open_key_down: = false
var _open_joy_down: = false
var _bo_api = null


func _init() -> void :
	ModLoaderLog.info("Init", LOG_NAME)
	var dir = ModLoaderMod.get_unpacked_dir() + MOD_DIR
	_menu_script = load(dir + "ui/gme_menu.gd")
	var i18n = load(dir + "i18n.gd")
	i18n.install()


func _ready() -> void :
	pause_mode = PAUSE_MODE_PROCESS
	_load_config()
	_load_loadouts()
	call_deferred("_connect_mod_options")
	call_deferred("get_bo_api")


func save_loadout(loadout_name: String, data: Dictionary) -> void :
	loadouts[loadout_name] = data
	_save_loadouts()


func delete_loadout(loadout_name: String) -> void :
	loadouts.erase(loadout_name)
	_save_loadouts()


func _load_loadouts() -> void :
	var f = File.new()
	if not f.file_exists(LOADOUTS_PATH):
		return
	if f.open(LOADOUTS_PATH, File.READ) != OK:
		return
	var parsed = parse_json(f.get_as_text())
	f.close()
	if parsed is Dictionary:
		loadouts = parsed


func _save_loadouts() -> void :
	var f = File.new()
	if f.open(LOADOUTS_PATH, File.WRITE) == OK:
		f.store_string(to_json(loadouts))
		f.close()


func _process(_delta: float) -> void :
	_poll_open_shortcut()
	_refill_infinite_gold()


func _poll_open_shortcut() -> void :
	var key_down = Input.is_key_pressed(open_scancode)
	if key_down and not _open_key_down:
		toggle_menu()
	_open_key_down = key_down
	var joy_down = false
	for device in Input.get_connected_joypads():
		if controller_shortcut == "L3 + R3":
			joy_down = joy_down or (Input.is_joy_button_pressed(device, JOY_L3) and Input.is_joy_button_pressed(device, JOY_R3))
		elif controller_shortcut == "Select/Back":
			joy_down = joy_down or Input.is_joy_button_pressed(device, JOY_SELECT)
	if joy_down and not _open_joy_down:
		toggle_menu()
	_open_joy_down = joy_down


func _refill_infinite_gold() -> void :
	if RunData.players_data.empty() or not gold_infinite.has(true):
		return
	if not is_authoritative():
		return
	for i in RunData.get_player_count():
		if gold_infinite[i] and RunData.players_data[i].gold < 999000:
			RunData.add_gold(999999 - RunData.players_data[i].gold, i)


func toggle_menu() -> void :
	if is_instance_valid(_menu):
		ModLoaderLog.info("menu close", LOG_NAME)
		_menu.close()
		return
	ModLoaderLog.info("menu open scene=%s" % get_tree().current_scene.name, LOG_NAME)
	_menu = _menu_script.new()
	_menu.mod_main = self
	_menu.pause_when_open = pause_when_open
	get_tree().root.add_child(_menu)


func get_bo_api():
	if _bo_api == null or not is_instance_valid(_bo_api):
		_bo_api = null
		var apis = get_tree().get_nodes_in_group(BO_API_GROUP)
		if not apis.empty():
			_bo_api = apis[0]
	if _bo_api != null and not _bo_api.is_connected("mod_message_received", self, "_on_bo_message"):
		_bo_api.connect("mod_message_received", self, "_on_bo_message")
	return _bo_api


func is_authoritative() -> bool:
	var api = get_bo_api()
	return api == null or api.should_run_authoritative_logic()


func local_player_index() -> int:
	var api = get_bo_api()
	if api == null:
		return 0
	var indices = api.get_local_player_indices()
	return int(indices[0]) if not indices.empty() else 0


func request(route: String, payload: Dictionary) -> bool:
	if is_authoritative():
		if apply_request(route, payload):
			_broadcast_mirror(route, payload)
		return true
	var sent = get_bo_api().send_to_host(LOG_NAME, route, payload, BO_OPTIONS)
	ModLoaderLog.info("request %s player=%s sent=%s" % [route, payload.get("player_index", -1), sent], LOG_NAME)
	return false


func _on_bo_message(mod_id: String, route: String, payload, meta) -> void :
	if mod_id != LOG_NAME or not (payload is Dictionary):
		return
	ModLoaderLog.info("message %s from_player=%s from_role=%s authoritative=%s" % [route, meta.get("from_player_index", -1) if meta is Dictionary else -1, meta.get("from_role", "") if meta is Dictionary else "", is_authoritative()], LOG_NAME)
	if route == "ack":
		if is_instance_valid(_menu):
			_menu.on_host_ack(payload)
		return
	if route == "mirror":
		_apply_mirror(payload)
		return
	if not is_authoritative():
		return
	var ok = apply_request(route, payload)
	if ok:
		_broadcast_mirror(route, payload)
	var api = get_bo_api()
	if api != null and meta is Dictionary and str(meta.get("from_role", "")) == "client":
		var sender = int(meta.get("from_player_index", -1))
		if sender >= 0:
			var ack_sent = api.send_to_player(sender, LOG_NAME, "ack", {"route": route, "ok": ok}, BO_OPTIONS)
			ModLoaderLog.info("ack %s ok=%s to_player=%s sent=%s" % [route, ok, sender, ack_sent], LOG_NAME)


func _broadcast_mirror(route: String, payload: Dictionary) -> void :
	var api = get_bo_api()
	if api == null or not api.is_online():
		return
	var sent = api.broadcast(LOG_NAME, "mirror", {"route": route, "payload": payload}, BO_OPTIONS)
	ModLoaderLog.info("mirror %s player=%s broadcast=%s" % [route, payload.get("player_index", -1), sent], LOG_NAME)


func _apply_mirror(mirror: Dictionary) -> void :
	if is_authoritative():
		return
	var payload = mirror.get("payload")
	if not (payload is Dictionary):
		return
	var route = str(mirror.get("route", ""))
	var applied = apply_request(route, payload)
	ModLoaderLog.info("mirror %s player=%s applied=%s" % [route, payload.get("player_index", -1), applied], LOG_NAME)


func apply_request(route: String, payload: Dictionary) -> bool:
	var pi = int(payload.get("player_index", 0))
	if pi < 0 or pi >= RunData.get_player_count():
		return false
	match route:
		"give":
			var data = find_element(str(payload.get("kind", "")), str(payload.get("id", "")))
			if data == null:
				return false
			give(str(payload.get("kind", "")), data, pi, bool(payload.get("cursed", false)))
		"remove_weapon":
			remove_weapon(int(payload.get("index", -1)), pi)
		"remove_item":
			var item = _find_by_id(RunData.get_player_items(pi), str(payload.get("id", "")))
			if item == null or item is CharacterData:
				return false
			RunData.remove_item(item, pi)
		"remove_all_weapons":
			remove_all_weapons(pi)
		"remove_all_items":
			for item in RunData.get_player_items(pi):
				if not (item is CharacterData):
					RunData.remove_item(item, pi)
		"gold":
			var amount = int(payload.get("amount", 0))
			if amount > 0:
				RunData.add_gold(amount, pi)
			else:
				RunData.remove_gold(int(min(- amount, RunData.players_data[pi].gold)), pi)
		"gold_infinite":
			gold_infinite[pi] = bool(payload.get("pressed", false))
		"xp":
			RunData.add_xp(int(payload.get("amount", 0)), pi)
		_:
			return false
	refresh_shop_ui(pi)
	return true


func element_pool(kind: String) -> Array:
	match kind:
		"items":
			return ItemService.items
		"weapons":
			return ItemService.weapons
		"upgrades":
			return ItemService.upgrades
	return []


func find_element(kind: String, my_id: String):
	return _find_by_id(element_pool(kind), my_id)


func _find_by_id(pool: Array, my_id: String):
	for data in pool:
		if data.my_id == my_id:
			return data
	return null


func give(kind: String, data, pi: int, cursed: bool) -> void :
	match kind:
		"items":
			RunData.add_item(_maybe_curse(data, pi, cursed), pi)
		"weapons":
			var new_weapon = RunData.add_weapon(_maybe_curse(data, pi, cursed), pi)
			_spawn_weapon_on_player(new_weapon, pi)
		"upgrades":
			RunData.apply_item_effects(data, pi)


func _maybe_curse(data, pi: int, cursed: bool):
	if cursed and ProgressData.available_dlcs.size() > 0:
		return ProgressData.available_dlcs[0].curse_item(data, pi)
	return data


func _spawn_weapon_on_player(new_weapon, pi: int) -> void :
	var player = get_player_node(pi)
	if player != null:
		player.add_weapon(new_weapon, player.current_weapons.size())


func get_player_node(pi: int):
	var scene = get_tree().current_scene
	if scene == null:
		return null
	var players = scene.get("_players")
	if players == null or pi >= players.size():
		return null
	var player = players[pi]
	return player if is_instance_valid(player) else null


func remove_weapon(index: int, pi: int) -> void :
	if index < 0 or index >= RunData.get_player_weapons(pi).size():
		return
	var _r = RunData.remove_weapon_by_index(index, pi)
	var player = get_player_node(pi)
	if player == null:
		return
	for node in player.current_weapons:
		if node.weapon_pos == index:
			player.current_weapons.erase(node)
			for other in player.current_weapons:
				if other.weapon_pos > index:
					other.weapon_pos -= 1
			node.queue_free()
			break


func remove_all_weapons(pi: int) -> void :
	RunData.remove_all_weapons(pi)
	var player = get_player_node(pi)
	if player != null:
		for node in player.current_weapons:
			node.queue_free()
		player.current_weapons.clear()


func refresh_shop_ui(pi: int) -> void :
	var scene = get_tree().current_scene
	if scene == null or not scene.has_method("_get_gear_container"):
		return
	var gear = scene._get_gear_container(pi)
	if gear == null:
		return
	gear.set_items_data(RunData.get_player_items(pi))
	gear.set_weapons_data(RunData.get_player_weapons(pi))


func _load_config() -> void :
	var configs = ModLoaderConfig.get_configs(LOG_NAME)
	var config = configs.get("current", configs.get("default"))
	if config == null:
		return
	_apply_setting("open_key", config.data.get("open_key", _key_name))
	_apply_setting("controller_shortcut", config.data.get("controller_shortcut", controller_shortcut))
	_apply_setting("pause_when_open", config.data.get("pause_when_open", pause_when_open))
	_apply_setting("menu_scale", config.data.get("menu_scale", menu_scale))


func _connect_mod_options() -> void :
	var iface = get_node_or_null("/root/ModLoader/dami-ModOptions/ModsConfigInterface")
	if iface != null and not iface.is_connected("setting_changed", self, "_on_setting_changed"):
		iface.connect("setting_changed", self, "_on_setting_changed")


var _in_setting_changed: = false


func _on_setting_changed(setting_name: String, value, mod_name: String) -> void :
	if mod_name != LOG_NAME or _in_setting_changed:
		return
	_in_setting_changed = true
	_apply_setting(setting_name, value)
	_save_config()
	_in_setting_changed = false


func _apply_setting(setting_name: String, value) -> void :
	match setting_name:
		"open_key":
			_key_name = str(value)
			open_scancode = KEYS.get(_key_name, KEY_F6)
		"controller_shortcut":
			controller_shortcut = str(value)
		"pause_when_open":
			pause_when_open = bool(value)
		"menu_scale":
			menu_scale = float(value)
			if is_instance_valid(_menu):
				_menu._layout_panel()


func _save_config() -> void :
	var data: = {
		"open_key": _key_name,
		"controller_shortcut": controller_shortcut,
		"pause_when_open": pause_when_open,
		"menu_scale": menu_scale,
	}
	var config = ModLoaderConfig.get_config(LOG_NAME, "current")
	if config == null:
		config = ModLoaderConfig.create_config(LOG_NAME, "current", data)
	else:
		config.data = data
		config = ModLoaderConfig.update_config(config)
	if config != null:
		ModLoaderConfig.set_current_config(config)
